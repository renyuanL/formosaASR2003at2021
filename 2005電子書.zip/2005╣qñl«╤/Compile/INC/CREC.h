#ifndef __CREC_H
#define __CREC_H

#include "CMMF.h"
#include "CDic.h"
#include "CNet.h"
#include "CFeaBuf.h"

/*class RANK
{
public:
	USHORT          iNodeIdx;
	USHORT          iModelIdx;
	USHORT		iSateIdx;
        USHORT		iDicIdx;
	float		fLogProb;

	vector<USHORT>  viSylHistory;
	vector<int>     viSylBoundary;
        vector<int>     viModelBoundary;


	vector<USHORT>  viNodePath;
	vector<USHORT>  viModelPath;
	vector<USHORT>  viStatePath;
	vector<float>   viProbPath;
	vector<USHORT>  viDicPath;
	vector<int>     viRank;

//	RANK():iNodeIdx(2),iModelIdx(0),iSateIdx(0),iDicIdx(0),fLogProb(LZERO) {}
	RANK(int frm):iNodeIdx(2),iModelIdx(0),iSateIdx(0),iDicIdx(0),fLogProb(LZERO)
        {               viRank.resize(frm); viStatePath.resize(frm);
                        viModelPath.resize(frm); viNodePath.resize(frm);
			viProbPath.resize(frm);  viDicPath.resize(frm);
	}

}; */

struct RANK
{
	USHORT iNodeIdx;
	USHORT iModelIdx;
	USHORT iSateIdx;
        USHORT iDicIdx;
	vector<int> viSylBoundary;
        vector<float> vfSylGrade;//Record Grade�Ϊ�,add by Hong Wen
	vector<USHORT> viSylHistory;
	vector<int> viModelBoundary;
	float fLogProb;
	RANK():iNodeIdx(2),iModelIdx(0),iSateIdx(0),iDicIdx(0),fLogProb(LZERO) {}
};

struct CacheData
{
   int fid;
   float prob;
   CacheData():fid(-1) {}
};

struct CachePool
{
   CacheData state[5];      // state number = 5
};
struct WtS
{
        char Word[128];
        char Syl[128];
};
class CRec
{
	private:

		CMMF      *m_model;
		CDic      *m_dic;
		CNet      *m_net;
		CFeaBuf   *m_fea;
                RANK       m_rank;

                int        m_beam;

                float      m_recTime;

                CachePool *m_cache;

		list<RANK>           m_plRank;
		list<RANK>::iterator m_plist;
		vector<RANK *>       m_pvRank;


		float  stateProb    (int fid,int mid,int sid);
		float  streamProb   (int fid,int mid,int sid,int smid);
		float  mixtureProb  (int fid,int mid,int sid,int smid,int xid);
		double mixLogSum    (double x,double y);

		float  transProb    (int xst,int sid,int bid,int mode=1);
		int    nextStateCase(RANK &rank);
		void   stateMerge   (int lastone);

		void   initRank();

	public:
		CRec():m_model(0),m_dic(0),m_net(0),m_fea(0),m_cache(0),m_beam(200),m_recTime(0.0) {}
		void        doRec       (CFeaBuf &,int g=1);
		void        init        (CMMF & ,CDic& ,CNet&);
		string      getAns	(int iRank);
		void        changeNet   (CNet &net) { m_net   = &net; }
		void        setBeam     (int beam)  { m_beam = beam ; }
                float       getScore    (int iRank) { return  m_pvRank[iRank]->fLogProb / m_fea->getFrameNum()  ;}
                vector<float> getSylGrade(int iRank);  //ADD BY HONG WEN 2005/1/28
                vector<int> getSylBoundary (int iRank);
		string      getModelName(int iRank);
                vector<int> getModelBoundary(int iRank);

                float       getRecTime() { return m_recTime ;}
		~CRec()
		{
			m_model = 0; m_dic = 0 ; m_net = 0 ; m_fea = 0;
			if(m_cache) delete [] m_cache;
		}
                //ADD BYE HONE WEN
                //2005/1/18
                WtS* m_wts;
                int m_wtssize;
                void rwordtosyl(const char* fn);		
};

inline bool Sort_Ref_RANK_By_Prob(const RANK &a , const RANK &b)
{
	return a.fLogProb > b.fLogProb;
}

inline bool Sort_Ptr_RANK_By_Prob(RANK *a,RANK *b)
{
	return a->fLogProb > b->fLogProb;
}

inline bool Is_LogZero(const RANK& a)
{
	return a.fLogProb == LZERO;
}



class Beam
{
	private:
		float m_prob,m_beam;
	public:
		Beam(float &p,int &beam) : m_prob(p),m_beam(beam) {}
		void operator() (RANK *elem) const
		{
			elem->fLogProb = (m_prob - elem->fLogProb > m_beam) ? LZERO : elem->fLogProb ;
		}
};

class PTR_RANK_INSERTER
{
	public:
        PTR_RANK_INSERTER(vector<RANK *>& v) : _v(v) {}
        void operator()(RANK &i)
        {
             _v.push_back(&i);
        }
	private:
        vector<RANK *>& _v;
};



#endif




