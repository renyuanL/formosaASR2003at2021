#include "CRec.h"
#include <time.h>
#include <CONIO.H>

void CRec::init(CMMF &mmf ,CDic &dic ,CNet &net)
{
	m_model = &mmf;
	m_dic	= &dic;
	m_net   = &net;
}
void CRec::rwordtosyl(const char* fn)
{
        CStrScan strScan;
        ifstream fin;
        fin.open(fn,ios::in);
        char LineBuf[128];
        int Num=0;
        while (!fin.eof())
        {
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                Num=Num+1;
        }
	fin.clear();	// clear eof bit once set in order to make the stream oparations [4/7/2003]
	fin.seekg(0,ios::beg); // reset file point to original [4/7/2003]
        m_wtssize=Num;
        m_wts=new WtS[Num];
        int idx=0;
        while (!fin.eof())
        {
                strcpy(LineBuf,"");
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                strScan.r2b(LineBuf,sizeof(LineBuf));
                strScan>>m_wts[idx].Word>>m_wts[idx].Syl;
                idx++;
        }
        fin.close();
}
//�`call,�令inline �i�[�ֿ��ѳt��[4/25/2003]
//
//	�ѨMunderflow problem
//  �w��logA�BlogB�A������log(A+B)
//   ����Xmax(A,B) if A is bigger
//  log(A+B) = log(A(1+B/A)) = logA + log(1+B/A)
//  ==> log(1+B/A) = log(1+exp(logB - logA))
//  ==> log(A+B) = logA + log(1+exp(logB - logA))
//

double CRec::mixLogSum(double x,double y)
{
	// x , y �w�ƥ���log
 	double diff,temp;

  	if (x<y) { temp=x; x=y; y=temp ;}
   
  	diff=y-x;

   	if (diff<MIN_LOG_EXP)			// MIN_LOG_EXP = -log(-LZERO) , see HTK
   		return (x<LSMALL)?LZERO:x;
   	else
    		return(x+log(1.0+exp(diff)));
}


//
//	�p�� mixture Prob  see HTK book p6 formula 1.9
//  ����:
//		-1/2{ log(2pi) + log|Z| + (u - u)'|Z|^(u-u0)}
//		      ^^^^^^^^^^^^^^^^^
//			      GConst
//


float CRec::mixtureProb(int fid,int mid,int sid,int smid,int xid)
{
				// fExpValue = (u-u0)'|Z|^-1(u-u0)
	float fDiff,fExpValue = 0 ;

	MIXTURE *p2m = &(*m_model)[mid].pState[sid].pStream[smid].pMixture[xid];

	int iOffset = m_model->getStreamDim(smid) * smid;

	for(int i = 0 ; i < m_model->getStreamDim(smid) ; i++)
	{
		fDiff = (*m_fea)[fid][i+iOffset] - p2m->pfMean[i];
		fExpValue += fDiff * fDiff * p2m->pfVariance[i];	// Reciprocal of variance was taken already
	}
	return (-(fExpValue + p2m->fGConst)/2);
}

float CRec::streamProb(int fid,int mid,int sid,int smid)
{
	double fLogProb = LZERO;
	float  fLogMixW;

	STREAM *p2sm = &(*m_model)[mid].pState[sid].pStream[smid];

	//int iMixtureNum = p2sm->iMixtureNum;

	for(int xid = 0 ; xid < p2sm->iMixtureNum ; xid++)
	{
		fLogMixW = p2sm->pMixture[xid].fMixtureW;
		if(fLogMixW > MIN_LOG_MIXTURE_WEIGHT)
			fLogProb = mixLogSum(fLogProb , fLogMixW + mixtureProb(fid,mid,sid,smid,xid));
	}
	return fLogProb;
}

float CRec::stateProb(int fid,int mid,int sid)
{
	if (m_cache[mid].state[sid].fid == fid)
		return m_cache[mid].state[sid].prob;

	float fLogProb = 0.0;
	for(int smid = 0 ; smid < m_model->getStreamNum() ; smid++)
		// stream weight = 1 by default.
		fLogProb += (*m_model)[mid].pState[sid].pfStreamW[smid] * streamProb(fid,mid,sid,smid);

	m_cache[mid].state[sid].fid  = fid;
	m_cache[mid].state[sid].prob = fLogProb;

	return fLogProb;
}

float CRec::transProb(int xst,int sid,int did,int mode)
{

	int nid = (*m_net)[m_pvRank[xst]->iNodeIdx].viDicIdx[did];
	int mid = m_pvRank[xst]->iModelIdx;

	int iWhichModel =  (*m_dic)[nid].viModelIdx[mid];

	return((*m_model)[iWhichModel].pfTransProb[sid+1][sid+1]);
}


int CRec::nextStateCase(RANK &rank)
{
	int iWhichModel = rank.iModelIdx;
	int iWhichState = rank.iSateIdx;
	int iStateNum =
		(*m_model)[(*m_dic)[(*m_net)[rank.iNodeIdx].viDicIdx[rank.iDicIdx ]].viModelIdx[rank.iModelIdx]].iStateNum;

	//��2:enter�Bexit state����A��1:index�q0�}�l [4/18/2003]
        // if(iWhichState >= (iStateNum - 2 - 1) )
       if(iWhichState+4 > iStateNum)
			 return iWhichModel + 1 >= (*m_dic)[(*m_net)[rank.iNodeIdx].viDicIdx[rank.iDicIdx]].viModelIdx.size() ? 0 : 1 ;
	else
			 return 2;

	// return 0:enter syl [4/18/2003]
	//		  1:enter model
 	//                2:enter state
}

void CRec::stateMerge(int iCandidate)
{
	int cid , sid_in_node ,nid , rid;

  	for(cid = 0 ; cid < iCandidate ; cid++)
       	for(rid = 0 ; rid < 15 ; rid++)
 	    	(*m_net)[m_pvRank[cid]->iNodeIdx].rankBeenHere[rid] = -1;


	for(cid = 0 ; cid < iCandidate ; cid++)
	{
       	   sid_in_node = m_pvRank[cid]->iModelIdx * 3 + m_pvRank[cid]->iSateIdx;
	   nid = m_pvRank[cid]->iNodeIdx;

	   rid = (*m_net)[nid].rankBeenHere[sid_in_node];
	   if(rid == -1)
	   {	// No one had gone before
			(*m_net)[nid].rankBeenHere[sid_in_node] = cid;// Rank-cid arrives the location
	   }
           else
	   {
  		   if(m_pvRank[cid]->fLogProb > m_pvRank[rid]->fLogProb)
		   {
		   	// Set it to zero and it'll be pruned out
		   		m_pvRank[rid]->fLogProb = LZERO;
		   		(*m_net)[nid].rankBeenHere[sid_in_node] = cid;
		   }
		   else
		   		m_pvRank[cid]->fLogProb = LZERO;
	   }
    }
}

void CRec::doRec(CFeaBuf &fea,int Group)
{
    m_fea = &fea;

    clock_t start;

    int FrameNum = m_fea->getFrameNum();

    RANK tmpRank,rank1,rank2,rank3;
    int  iCandidate ;
    int  groupSize = ((*m_net)[2]).viOut.size()/Group;
    float prob1,prob2;
    //int enter2 = 0;
    //int sstate=0;
    //float maxprob = LZERO;
   start = clock();

   for(int gid =0 ;gid<Group;gid++)
   {
        initRank();
      // int  groupSize = ((*m_net)[2]).viOut.size()/Group;

	for(int fid = 1 ; fid < FrameNum  ; fid++)
	{

           iCandidate = m_plRank.size();

       for(int xst = 0; xst < iCandidate ; xst++)
	   {
           if(m_pvRank[xst]->fLogProb==LZERO) break;
           if(m_pvRank[xst]->fLogProb!=LZERO)
           {
		//m_pvRank[xst]->viRank[fid] = xst;

                tmpRank = *m_pvRank[xst];
                int iWhichModel = (*m_dic)[(*m_net)[m_pvRank[xst]->iNodeIdx].viDicIdx[m_pvRank[xst]->iDicIdx]].viModelIdx[m_pvRank[xst]->iModelIdx];

		// Self-state transition
                m_pvRank[xst]->fLogProb += transProb(xst,m_pvRank[xst]->iSateIdx,m_pvRank[xst]->iDicIdx,0);
                m_pvRank[xst]->fLogProb += stateProb(fid, iWhichModel,m_pvRank[xst]->iSateIdx);


 		switch(nextStateCase(tmpRank))
                {
                    //leave syllable
                    case 0:
                                tmpRank.iSateIdx = 0; tmpRank.iModelIdx = 0;	// Move to the next syllable
                                int bid , did , iModelIdx,beam;
                                if(m_pvRank[xst]->iNodeIdx==2)
                                {
                                bid = gid*groupSize;
                                beam = bid+groupSize;//((*m_net)[m_pvRank[xst]->iNodeIdx]).viOut.size();
                                }
                                else
                                {
                                bid = 0;
                                beam = ((*m_net)[m_pvRank[xst]->iNodeIdx]).viOut.size();
                                }
                                for(; bid <beam ; bid++)
                                {

                                        for(did = 0 ; did < (*m_net)[(*m_net)[m_pvRank[xst]->iNodeIdx].viOut[bid]].viDicIdx.size() ; did++)
                                        {


                                                rank1 = tmpRank;
                                                rank1.iNodeIdx = (*m_net)[m_pvRank[xst]->iNodeIdx].viOut[bid];
                                                rank1.iDicIdx = did;
                                                rank1.viSylHistory.push_back((*m_net)[m_pvRank[xst]->iNodeIdx].viDicIdx[m_pvRank[xst]->iDicIdx]);
                                                if((*m_net)[m_pvRank[xst]->iNodeIdx].viOut[bid] == 1 )
                                                {
                                                        if( fid < m_fea->getFrameNum() - 1 )
                                                             rank1.fLogProb = LZERO;
                                                        else
                                                        {
                                                                rank1.fLogProb += transProb(xst,m_pvRank[xst]->iSateIdx,m_pvRank[xst]->iDicIdx);
                                                                rank1.iNodeIdx  = 1;
                                                        }
                                                }
                                                else
                                                {
                                                        rank1.fLogProb += transProb(xst,m_pvRank[xst]->iSateIdx,m_pvRank[xst]->iDicIdx);
                                                        iModelIdx = (*m_dic)[(*m_net)[(*m_net)[m_pvRank[xst]->iNodeIdx].viOut[bid]].viDicIdx[did]].viModelIdx[0];
                                                        rank1.fLogProb += stateProb(fid,iModelIdx,0);

                                                }
                                                rank1.viSylBoundary.push_back(fid);
                                                //add by Hong Wen
                                                //2005/1/28
                                                rank1.vfSylGrade.push_back(rank1.fLogProb);
                                                //
                                                m_plRank.push_back(rank1);
                                                m_plist++;
                                                m_pvRank.push_back(&(*m_plist));
                                             }
                                           }
                                         //end for
					break;
					case 1: // leave a model

                                                tmpRank.iSateIdx = 0; tmpRank.iModelIdx++;	// Move to the next model
                                                rank2 = tmpRank;
                                                rank2.fLogProb += transProb(xst,rank2.iSateIdx ,m_pvRank[xst]->iDicIdx);
                                                prob2 = stateProb(fid,(*m_dic)[(*m_net)[m_pvRank[xst]->iNodeIdx].viDicIdx[rank2.iDicIdx]].viModelIdx[rank2.iModelIdx],0);

                                        //        if(-prob2>120) break;
						rank2.viModelBoundary.push_back(fid);
                                                rank2.fLogProb += prob2;

                                                m_plRank.push_back(rank2);
                                                m_plist++;
                                                m_pvRank.push_back(&(*m_plist));

							break;

					case 2: //leave a state
                				tmpRank.iSateIdx++;	// Move to the next state
                                                rank3 = tmpRank;
 						rank3.fLogProb += transProb(xst,rank3.iSateIdx,m_pvRank[xst]->iDicIdx,1);
                                                prob1 = stateProb(fid,(*m_dic)[(*m_net)[m_pvRank[xst]->iNodeIdx].viDicIdx[m_pvRank[xst]->iDicIdx]].viModelIdx[m_pvRank[xst]->iModelIdx],m_pvRank[xst]->iSateIdx+1);

                                                //2005/1/19
                                                //�ק�by hong wen
                                                /*if(-prob1>130)
                                                {
                                                        break;
                                                }
                                                */
                                                rank3.fLogProb += prob1;

						m_plRank.push_back(rank3);
           				        m_plist++;
						m_pvRank.push_back(&(*m_plist));
                                                //sstate++;
						break;

					} //end switch
			} //end if
		} // end for xst

      //cout<<"============================" <<endl;
      // getch();
       stateMerge(m_plRank.size());
       m_plRank.sort(Sort_Ref_RANK_By_Prob);

       m_plRank.remove_if(Is_LogZero);
       m_pvRank.clear();

       for_each( m_plRank.begin(), m_plist = m_plRank.end(), PTR_RANK_INSERTER(m_pvRank));
       m_plist--;
       for(int s=((*m_net)[2]).viOut.size()*4.5 ; s< m_pvRank.size();s++)
                        m_pvRank[s]->fLogProb = LZERO;
 

       for_each(m_pvRank.begin(),m_pvRank.end(),Beam(m_pvRank[0]->fLogProb,m_beam));
     } //end for fid

         //sstate=0;
   }

   m_recTime = float(clock()-start)/CLOCKS_PER_SEC;
}

void CRec::initRank()
{
    m_plRank.clear();
    m_pvRank.clear();

	if(m_cache) delete [] m_cache;

	m_cache = new CachePool[m_model->getModelNum()];

	//RANK rank(m_fea->getFrameNum());
    RANK rank;
	int mid = (*m_dic)[(*m_net)[2].viDicIdx[0]].viModelIdx[0];
	rank.fLogProb = stateProb(0,mid,0);
        m_rank = rank;
	m_plRank.push_back(rank);
	m_plist = m_plRank.begin();
	m_pvRank.push_back(&(*m_plist));

}

string CRec::getAns(int iRank)
{
	iRank = max(0,min(iRank,(int)m_plRank.size()-1));

	string strTopN = "";
	Lexicon *p2L;
	for(int i = 0 ; i< m_pvRank[iRank]->viSylHistory.size(); i++ )
	{
     	p2L = &(*m_dic)[m_pvRank[iRank]->viSylHistory[i]];

		if(p2L->bReplace)
			strTopN += p2L->strUBI;
		else
		{
			if(p2L->strSyl !="." && p2L->strSyl != "!NULL")
				strTopN += p2L->strSyl;
		}

	}

    return strTopN;
}
vector<float> CRec::getSylGrade(int iRank)
{
        return  m_pvRank[iRank]->vfSylGrade;
}
vector<int> CRec::getSylBoundary(int iRank)
{
        return  m_pvRank[iRank]->viSylBoundary;
}

vector<int> CRec::getModelBoundary(int iRank)
{
        return  m_pvRank[iRank]->viModelBoundary;
}


string CRec::getModelName(int iRank)
{
	Lexicon *p2L;
	string  strPinim="";
	string  strModel;
	for(int i = 0 ; i< m_pvRank[iRank]->viSylHistory.size(); i++ )
	{
     	p2L = &(*m_dic)[m_pvRank[iRank]->viSylHistory[i]];
		if(p2L->strSyl !="." && p2L->strSyl != "!NULL")
		{
		    for(int j=0;j<p2L->viModelIdx.size()-1;j++)
 		    {
				strModel =  (*m_model)[p2L->viModelIdx[j]].szPinim;
				if(j == (p2L->viModelIdx.size()-2) )
				{
                                        if(strModel.length()>1)
                                        {
                                                strPinim +=  strModel[0];
                                                strPinim +=  strModel[strModel.length()-1];
                                        }
					   else
						  strPinim += strModel;

				}
				else
				        strPinim += strModel[0];
		    }
			strPinim += "-";
		}
	}
	strPinim[strPinim.size()-1] = '\0';
	return strPinim;
}


