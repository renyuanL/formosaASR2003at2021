 
/*****************************************************************************************
 *										CNet.h                                           *		
 *****************************************************************************************
 *	AUTHOR      : asd										                             *
 *	PROJECT     : CNet 																	 *
 *	DESCRIPTION : Read HTK net fle , support bigram                                      *
 *  -----------------------------------------------------------------------------------  *
 *	Revision History :                                                                   *
 *  13/04/2003  asd.    Initial Version.                                                 *
 *	                                                                                     *
 *  -----------------------------------------------------------------------------------  *
 *				Copyright (c) 2003 CGU Msp LAB                                           *
 ****************************************************************************************/
#ifndef __CNet_H
#define __CNet_H

#include "CDic.h"
//#include "CFunc.h"
#define MAX_COL 50
#define CHAR_LEN 7 //�~ù�åΡAù���r�̪�6

/*****************************************************************************************
 *	STRUCT	    : NETNODE                                                                *
 *---------------------------------------------------------------------------------------*
 *	DESCRIPTION : �O��NET���C��node�bDic�̪�index�B��dic index�s�����p�A��Language       *
 *	              Probability                                                            *
 *	ARGUMENT    : viDicIdx�BviOut�BfLangProb�B                                           *
 *					                                                                     *
 ****************************************************************************************/

struct NETNODE
{				
	vector<int>    viDicIdx;
	int		       rankBeenHere[15];
	vector<int>    viOut;
	vector<float>  vfLangProb;
};


//�O���C�Ӻ~�r�y�Ц�m
struct POS
{
  int x,y;
  POS():x(-1),y(-1){}
};

//for build tree net 
struct TNODE
{
        int    nid;		  // node id
        string name;      // node name
        POS    pt;		  // node position
        vector<int> out;  // next node's node id
};
typedef vector<TNODE> strVec;

class CNet
{
	private:
			NETNODE		   *m_NN;

			int				m_iNodeNum;
			int				m_iLinkNum;
			//ifstream        m_fin;
				
			bool  openFile(const char *szFileName);
			int   dic2idx (CDic &dic,const char* szFindStr,int lo,int hi);
			char* oct2big5(char* szStr);
			void  upDownSearch(CDic &dic,int from,int &up,int &down,int range);
			
			/************************************************************/
			 char  ***p2t;
             int    **p2n;
             int   loadSylTable(const char *fn);
             int   fillTable(const char *fn,char ***p2t);
			 void  free(char ***p2t,int **p2n,int row);
		     void  sortRow(char ***p2t,int rowCount,int rolCount);
			 void  quickSort(char ***p2t,int low,int up,int c) ;
			 int   findRange(char ***p2t,int row,int low,int c);
			 void  swapLine(char ***p2t,int i,int j,int col);
			 void  markRepeated(char ***p2t,int rowCount,int colCount); 
			 void  assignNumber(char ***p2t,int **p2n,int rowCount,int colCount);
			 int   buildNode(FILE *fid,char ***p2t,int **p2n,int rowCount,int colCount);
			 int   buildLink(FILE *fid,bool backarc,int **p2n,int rowCount,int colCount) ;
			 int   findBranch(int **p2n,int i,int j)  ;

			 int   m_colCount;
			
			/***********************************************************/
			
			void  destroy()
			{
				if(m_NN) delete [] m_NN;
				m_NN = 0 ; m_iNodeNum = 0 ; m_iLinkNum = 0 ;
			}
	public:
			CNet():m_NN(0),m_iNodeNum(0),m_iLinkNum(0),m_colCount(0){}
			
			//void  interWordMerge(CDic& dic);
			bool  readTxt      (const char *szFileName,CDic &dic);
			bool  write2Bin    (const char *szFileName);
			bool  readBin      (const char *szFileName);
			int   getNodeNum() { return m_iNodeNum ; };
			int   getLinkNum() { return m_iLinkNum ; };
			bool  buildTreeNet(const char *in,const char *out,CDic &dic);
			NETNODE&  operator[](int idx) { return *(m_NN + max(0,min(idx,m_iNodeNum-1))); }
			~CNet(){ destroy(); }
                        vector<string> m_word;
                        vector<string> m_noexistword;
                        int m_count;
};

#endif