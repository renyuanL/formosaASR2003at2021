#ifndef __CWAVEBUFFER_H
#define __CWAVEBUFFER_H

#include <windows.h>
#include <assert.h>
template<typename T>
T fixmin(T a,T b) { return a<b?b:a;}
class CWaveBuffer  
{
public:	
	int   getSampleSize() const;
	void  setBuffer    (void* pBuffer, DWORD dwNumSamples, int nSize);
	void  setNumSamples(DWORD dwNumSamples, int nSize = sizeof(short));
	void  copyBuffer   (void* pBuffer, DWORD dwNumSamples, int nSize = sizeof(short));
	DWORD getNumSamples() const;
	void* getBuffer    () const;
	
	CWaveBuffer();
        short operator[](unsigned long idx);
	virtual ~CWaveBuffer();
        float avgEng();

private:
	int   m_nSampleSize;
	void* m_pBuffer;
	DWORD m_dwNum;
};


#endif