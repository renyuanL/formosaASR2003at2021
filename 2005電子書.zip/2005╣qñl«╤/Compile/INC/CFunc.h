#ifndef __CFUNC_H
#define __CFUNC_H

#include "HParam.h"

/*	��������ifstream>>var ����]�O�ɮ׫��Шä��|���ʨ�U�@��Amaybe���B�z\n [4/8/2003]
 *  �ҥH���read2buf�A����getlineŪ�@��ibuffer�A�A�qbuffer��Ū���榡�Ʀr�� 
 *	���C++ ��istrstream����C��sscanf�榡��Ū���r��
 *  istrstream�ϥέn�I:1�BConstructor�n�]�wbuffer��}�Τj�p�A�]�w�Y�������
 *					   2�B�Y�n�B�z�U�@��A��seeg(0,ios::beg)�A�Bcopy�r���]�w�غc�l�ɫ��w���r���};
 */ 


/*  Binary Output C++ File IO[4/10/2003]
 *	Overload operator << 
 *		bofstream bfout("output_file_name");
 *		bfout << variable;
 *	Directly use << , very easy to use
*/
class bofstream : public ofstream
{
	public:
		
		bofstream(const char *fn):ofstream(fn,ios::out|ios::binary) {}
		
		void writeBytes(const void *p,int len)
		{
			if(!p) return;
			if(len <= 0) return;
			write((char *)p,len);
		}
		
		friend bofstream & operator<<(bofstream &bofs ,int q)
		{
			bofs.writeBytes(&q,sizeof(q));
			return bofs;
		}
		
		friend bofstream & operator<<(bofstream &bofs ,unsigned int q)
		{
			bofs.writeBytes(&q,sizeof(q));
			return bofs;
		}
		
		friend bofstream & operator<<(bofstream &bofs ,short q)
		{
			bofs.writeBytes(&q,sizeof(q));
			return bofs;
		}
		
		friend bofstream & operator<<(bofstream &bofs ,unsigned short q)
		{
			bofs.writeBytes(&q,sizeof(q));
			return bofs;
		}
		
		friend bofstream & operator<<(bofstream &bofs ,float q)
		{
			bofs.writeBytes(&q,sizeof(q));
			return bofs;
		}
		
		friend bofstream & operator<<(bofstream &bofs ,double q)
		{
			bofs.writeBytes(&q,sizeof(q));
			return bofs;
		}
};


/*  Binary Input C++ File IO[4/10/2003]
 *	Overload operator >> 
 *		bifstream bfin("input_Binary_file_name");
 *		bfin >> variable;
 *	Directly use >> , very easy to use
*/
class bifstream : public ifstream
{
	public:
		
		bifstream(const char *fn):ifstream(fn,ios::in|ios::binary) {}
		
		void readBytes(void *p,int len)
		{
				if(!p) return;
				if(len <= 0) return;
				read((char *)p,len);
		}
		
		friend bifstream & operator>>(bifstream &bifs ,int &q)
		{
			bifs.readBytes(&q,sizeof(q));
			return bifs;
		}
		
		friend bifstream & operator>>(bifstream &bifs ,unsigned int &q)
		{
				bifs.readBytes(&q,sizeof(q));
				return bifs;
		}
		
		friend bifstream & operator>>(bifstream &bifs ,short &q)
		{
				bifs.readBytes(&q,sizeof(q));
				return bifs;
		}

		friend bifstream & operator>>(bifstream &bifs ,unsigned short &q)
		{
				bifs.readBytes(&q,sizeof(q));
				return bifs;
		}
		friend bifstream & operator>>(bifstream &bifs ,float &q)
		{
				bifs.readBytes(&q,sizeof(q));
				return bifs;
		}
		friend bifstream & operator>>(bifstream &bifs ,double &q)
		{
				bifs.readBytes(&q,sizeof(q));
				return bifs;
		}
};


//void split(const string& s, const string& sep, string dest);

//#include "CFunc.hpp"

#endif