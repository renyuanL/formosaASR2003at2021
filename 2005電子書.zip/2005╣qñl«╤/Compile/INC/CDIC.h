#ifndef __CDic_H
#define __CDic_H

#include "CFunc.h"
#include "CMMF.H"
#include "HParam.h"

struct	Lexicon
{
	string		strSyl;
	bool		bReplace;
	string		strUBI;
	UINT        iModelNum;
	vector<int> viModelIdx;
	float       fDicProb;
	Lexicon() : strSyl(""),bReplace(false),iModelNum(0),strUBI(""),fDicProb(1.0) {}
};


class CDic
{
	private:
			Lexicon	   *m_pLex;
			UINT	   *m_piRank;
			UINT        m_iLines;
			ifstream    m_fin;
			
			bool		openFile(const char *szFileName);
			
			bool		getLines();			
			
			int         model2idx(CMMF& mmf ,const char *szFind,int left,int right);
			
			void		rankInit();
			void		heapSort(UINT iTotalLine);
			void        destroy() ;
		        string addgong(char strLine[]);
			
	public:
		CDic():  m_pLex(0),m_iLines(0),m_piRank(0) {} ;
		
		UINT     getDicNum(){ return m_iLines; }
		bool     readDic    (const char *szfn, CMMF &mmf);				
		Lexicon& operator[] (int idx);
		~CDic() { destroy();}

};

#endif
