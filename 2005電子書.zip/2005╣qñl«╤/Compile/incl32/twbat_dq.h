//
// file twbat_dq.h
//

#ifndef TWBAT_DQ_H
#define TWBAT_DQ_H
char* imzet12twbat(char* imzet1);
char* imzet12imso (char* imzet1, char sep='-', int keeptone=0);
#endif //#ifndef TWBAT_DQ_H

