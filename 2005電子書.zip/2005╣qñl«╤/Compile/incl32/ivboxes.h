//
// file ivboxes.h
//
#ifndef IVBOXES_H
#define IVBOXES_H

#include <vwin.h>

template<class T>
class cuma {// cumulative array, only4 numeric type suchas int/double
						// (*) start with an invisible a[0]=0, so it is 1-based array
public:  int allocsize; int   asz;// asz is the size used
  T*    a;
  void  init20() {a=0;asz=0;allocsize=0; }
public:
  int  resize(int size) { size++;if(size<=allocsize)return 1;a=(T*)realloc(a,size*sizeof(T));
                          if(a){allocsize=size; return 1;} init20();return 0; }
  int  nextsize(){if(allocsize<16)return 16;if(allocsize<=512)return 2*allocsize;return int(allocsize*1.1);}
public:
  T*  operator()(			)				{ return a; }		// or (variable name).a
  //T&  operator[](int i) const { return a[i]; }// so no app thru this function
  T&  operator[](int i) const { 
		return a[i]; 
	}// so no app thru this function
  int size() { 		return asz-1;	} // -1 since start with 0, see above (*)
  int app	(T delta)	{ 
		if( asz >= allocsize ){ if(! resize( nextsize() ) ) return 0;}
		memset(&a[asz],0,sizeof(T)); 
		if(asz>0) a[asz]=a[asz-1]+delta; else a[asz]=delta;	asz++; 
		return 1;
	}
  T   ldel(int n)		{ T t=0; if(!isgood(n))return t;t=delta(n);asz--;
											for(int s=n; s<asz; s++) a[s]=a[s+1]-t; return t; }
  T   rdel(int n)		{ return ldel(n+1); }
	int ins	(int n, T delta){ if(n>asz)n=asz; if(n<=0) n=1; app(0); int nn;
														for(nn=asz-1;nn>=n;nn--)a[nn]=a[nn-1]+delta;}
	T   ldelta (int n){ 
		if((n<1)||(n>asz-1)) return 0; return a[n]-a[n-1]; 
	}
	T   rdelta (int n){ return ldelta(n+1); }
public: // append r for robust
	int isgoodat (int n){ return ( (0< n)&&(n<asz  ) )?1:0;	}
	int isgoodin (int n){ return ( (0<=n)&&(n<asz-1) )?1:0;	}
	int isgoodinr(int n){ return ( (0<=n)&&(n<asz-1) )?1:0;	}
	int findat (T   t){ if(t<=0)return  0;for(int i=1;i<asz;i++)if(t<a[i])return i-1;return asz-1;}
	int findin (T   t){ if(t< 0)return -1;for(int i=1;i<asz;i++)if(t<a[i])return i-1;return -1;		}
	int findinr(T   t){ if(t< 0)return  0;for(int i=1;i<asz;i++)if(t<a[i])return i-1;return asz-2;}
public:
  cuma()         :a(0){ init20(); app(0); }		//app(0), keep start w/ 0th 0
  cuma(int size) :a(0){ init20(); resize(size); app(0); }
 ~cuma()					{ destroy(); }
  void destroy()  { free(a); init20(); }
  void clear()		{ asz=1; } // asz=1, keep start w/ 0th 0
	void reset()    { asz=1; }
public:
  int push_back	(T& delta) { return app(delta); }
};

static int junk=0;

template<int R_>
struct hboxes_ { // a class for screen boxes
	hboxes_() { reset(); }
	cuma<int> xs[R_]; cuma<int> ys;
	point_ crc; // current row and current column
							// cr is IN the rows
							// cc is between boxes(char's)
							// always refer to the box left2 cc-th of xs[cr] in the cr-th row
	point_ cxy; // current x-y position
	//void init20(){ for(int r=0; r<R_;r++)xs.init20();ys.init20(); cr=cc=cx=cy=0;}
	void reset (){ for(int r=0; r<R_;r++)xs[r].reset ();ys.reset (); crc.x=crc.y=cxy.x=cxy.y=0;}
public:
	int  cr()		{ return crc.y; }
	int  cc()		{ return crc.x; }
	int  cx()		{ return cxy.x; }
	int  cy()		{ return cxy.y; }
	int  cdxat(){ return (crc.x>0 )?xs[crc.y].ldelta(crc.x):0; }
	int  cdyat(){ return (crc.y>0 )?ys       .rdelta(crc.y):0; }
	int  cdxin(){ return (crc.x>=0)?xs[crc.y].rdelta(crc.x):0; }
	int  cdyin(){ return (crc.y>=0)?ys       .rdelta(crc.y):0; }
public:
	point_  lt(int r, int c)	{ point_ pt(xs[r][c],ys[r]);return pt;}	//left top of current box
	point_ clt()	{ return lt(crc.y, crc.x); }	//left top of current box
	rect_ getrect(int r,int c) { rect_ rect(x(r,c),y(r),x(r,c+1), y(r+1) );	return rect;}
public:
	int& x (int r, int c) const { return xs[r][c];}
	int& y (int r, int c) const { return ys[r];		}
	int& y (int r				) const { return ys[r];		}
	int  R() { return R_; }
	point_ findat (int x, int y){point_ pt;
															pt.y=ys.findat(y);
															pt.x=xs[pt.y].findat(x);
															return pt; 
	}
	point_ findin (int x, int y){point_ pt;pt.x=pt.y=-1; 
										int r=ys   .findin(y);if(r<0) return pt;
										int c=xs[r].findin(x);if(c<0) return pt;
										pt.x=c, pt.y=r; return pt;
	}
	point_ findinr(int x, int y){point_ pt;pt.x=pt.y=-1; 
										int r=ys   .findinr(y);if(r<0) return pt;
										int c=xs[r].findinr(x);if(c<0) return pt;
										pt.x=c, pt.y=r; return pt;
	}
	int		isgoodat (point_ rc) { return ( (ys.isgoodat (rc.y))&&(xs[rc.y].isgoodat (rc.x)) )?1:0; }
	int		isgoodin (point_ rc) { return ( (ys.isgoodin (rc.y))&&(xs[rc.y].isgoodin (rc.x)) )?1:0; }
	int		isgoodinr(point_ rc) { return ( (ys.isgoodinr(rc.y))&&(xs[rc.y].isgoodinr(rc.x)) )?1:0; }
public:
	int	 trymove2xy(int x, int y) {	point_ rc=findinr(x,y); 
					if(!isgoodinr(rc) ) 		return 0;
					if( rc==crc ) 			return 0; 
					cxy.x=x; cxy.y=y;		crc=rc;
					int sz=xs[cr()].asz-2;	if(crc.x>=sz) { cxy.x= xs[cr()].a[sz]; }
					return 1;
	}
	int  onleft()	{int tx=cx()-cdxin(); return trymove2xy(tx, cy()); }
	int  onright(){int tx=cx()+cdxin(); return trymove2xy(tx, cy()); }
	int  onup()		{int ty=cy()-cdyin(); return trymove2xy(cx(), ty); }
	int  ondown()	{int ty=cy()+cdyin(); return trymove2xy(cx(), ty); }
};

extern hboxes_<10> hboxes;


#endif //#ifndef IVBOXES_H

