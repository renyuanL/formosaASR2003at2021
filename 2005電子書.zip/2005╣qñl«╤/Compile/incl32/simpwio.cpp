////
//// file simpwio.cpp
//// a simpler version for wave io
//// copyright2004 IZGang/RHLyu
////	finished 2004/03/31
////

#ifndef SIMPWIO_CPP
#define SIMPWIO_CPP

#include<simpwio.h>

wiomessage wiom;




//*********************************************************************
//*********************************************************************
//**  BEG of class owavebase
//*********************************************************************

void	owavebase::
sleep2end0(int ms)
{		while(ms>0){if(!bBangImDiong) break; ms-=10;	Sleep(10);}		}

//inline	MMRESULT owavebase::open(DWORD dwInst, OWPROC p)
//{
//	res=waveOutOpen(&hwo,WAVE_MAPPER,&wfx,(DWORD)p, dwInst,	CALLBACK_FUNCTION);
//	return res;
//}

int		owavebase::
open	(DWORD dwInst, OWPROC p, waveformatex* wf)
{
	//�]��owbang.play���|���~�٦^�A�ҥH���ɪ�open���|��bPlaying�����D
	//�Y�ϥΦbthread���ɡA�ݭn�ˬdbPlaying
	crtsection cs;	cs.enter();
	int same=1;
	if(wf) same=wfx.eq(*wf); if(!same){if(wf) wfx=(*wf);}
	//if(p!=owproc){same=0; owproc=p;}
	if(same&&bOpened) return 1;
	if(!same&&bOpened){
		close(200);
		if(bBangImDiong) return 0;
	}
	//did not check p
	if(!bOpened){
		res=waveOutOpen(&hwo,WAVE_MAPPER,&wfx,(DWORD)p,dwInst,CALLBACK_FUNCTION);
	}
	cs.leave();
	return bOpened;
}

/// do not call close() , it will be autoly-called inside dtor
////// since a call to close() after thread-exit will lead to program hang
/// reset()/stop() are the same, will stop the current playing
////// call waveOutReset(...) more than necessary will hang the program(?)
////// so reset() wrap it with safe guard.
////// reset()/stop() will not call close():i.e., leaves the device open
////// but in case one really need, use owclose()

int		owavebase::
close	(int mswait)
{// if(!bBangImDiong)return 0;//donot do this, need to close
	////res=ow.close();//close() will be called inside destructor
	////calling ow.close() inside a thread is tideous to manage
	crtsection cs;	cs.enter(); //if(owproc==NULL)owp=OWPdef;
	if(bBangImDiong) {reset();Sleep(10);}
	sleep2end(mswait);
	if(!bBangImDiong){
		res=waveOutClose(hwo);
		//res=close0();
		bOpened=0;
	}else
		res=WAVERR_STILLPLAYING;
	cs.leave();
	return res;
}

int		owavebase::
reset	(int mswait)
{
	crtsection cs;	cs.enter();
	if(!bBangImDiong) return MMSYSERR_NOERROR;//no need for reset in this case
	//res= reset0();
	res=waveOutReset(hwo);
	Sleep(1);
	sleep2end(mswait);
	cs.leave();
	return res;
}

__int64	owavebase::position ()
{
	MMTIME	mmt1;	mmt1.u.sample=0; mmt1.wType=TIME_SAMPLES;
	crtsection cs;	cs.enter();
	if(bBangImDiong){
		waveOutGetPosition(hwo,&mmt1,sizeof(mmt1));
	}
	cs.leave();
	return mmt1.u.sample;
}

//*********************************************************************
//**  BEG of class owavebase
//*********************************************************************
//*********************************************************************




//*********************************************************************
//*********************************************************************
//**  BEG of class owplayer
//*********************************************************************


int owplayer::
play(short* sh, int shsize, pcmfmt_* pcm)
{
	////crtsection cs;	cs.enter();
	if(isplaying()) return 0;
	if( (!sh) ||(shsize<=0)) {
		strcpy(errtxt,"empty buffer for play");
		return 0;
	}
	if(!ow.open(pcm->wfex)){
		strcpy(errtxt,"can not open owave device");
		return 0;
	}
	ow.sethdr(sh,shsize);
	res=ow.prep();
	ow.bBangImDiong=1;
	ow.reset4wait();
	res=ow.write();
	ow.wait2end();
	ow.unprep();
	////res=ow.close();//close() will be called inside destructor
	////calling ow.close() inside a thread is tideous/difficult to manage
	////at least it will intermingle thin-thread and thin-waveout
	////leading to coupled codes between 2 classes
	////cs.leave();
	return 1;
}

int owplayer::
tplay(short* sh, int shsize, pcmfmt_* pcm)
{
	crtsection cs;	cs.enter();
	if( (!sh) ||(shsize<=0)) {
		strcpy(errtxt,"empty buffer for play");
		return 0;
	}
	if(ow.bBangImDiong) ow.reset(200);
	if(!ow.open(pcm->wfex)){
		strcpy(errtxt,"can not open owave device");
		return 0;
	}
	sh0=sh; shsize0=shsize;//pcm is set inside open(pcm)
	cs.leave();
	thd.begin(thdf,this);
	return 1;
}
int owplayer::
sztplay()
{
	crtsection cs;	cs.enter();
	if(ow.bBangImDiong) return 0;
	////if((!sh)||(shsize<=0)){strcpy(errtxt,"empty buffer for play");return 0;}
	////if(!open(pcm)){strcpy(errtxt,"can not open owave device");return 0;}
	////the possible err cases has been checked in tplay(...)
	ow.sethdr(sh0,shsize0);
	res=ow.prep();
	ow.bBangImDiong=1;
	ow.reset4wait();
	res=ow.write();
	cs.leave();
	ow.wait2end();
	cs.enter();
	ow.unprep();
	////res=ow.close();//close() will be called inside destructor
	////calling ow.close() inside a thread is tideous/difficult to manage
	////at least it will intermingle thin-thread and thin-waveout
	////leading to coupled codes between 2 classes
	ow.bBangImDiong=0;
	cs.leave();
	return 1;
}

//*********************************************************************
//**  end of class owplayer
//*********************************************************************
//*********************************************************************

//*********************************************************************
//*********************************************************************
//**  Comment of class owplayer
//*********************************************************************
/*
	�`���ܤ֦�3�ر��΢���
	1. ��W�@��(�u)�ɮ� �񭵡A�ϥΪ̥i�H �Y�ɵ��A ���쵲��(�W²��)
	2. ��W�@���ɮש񭵡A�ݭnthread���H�ɳB�z�G�Om�O��F�H�ϥΪ̬Om�O����L�ݨD
	3. �ƭ��ɮ׶��ǩ񭵡A���ɻݭnthread�ӳB�z�G(�P�B���D�B�ϥΪ̤��~�n�D���D)
	owplayer.play()�O�ѨM�Ĥ@�ӱ��΢���k�A�]��²��A�ҥH���Ҥ]�u�n�C
	owplayer.tplay()�O�ѨM�ĤG�B�T�ӱ��΢���k�A�ݭncallback��Ʀۤv�B�z�C

	���B�O��waveOutProc�ө񭵡A�аѦ�Win32 SDK���
	�򥻤W�A�{�Ǧpplay(...)�ҥܡA���Fopen/close�����G
	����play(...)�ݭn�����n���񧹤~�|�^��C

	�]���ݭn�ϥ�thread�A�ҥH�Nopen/close���X�~�f�C
	�[�Wthread���ɡA
		��open()�A�~����/�i�Jthread�Athread�����H��A�~close()
	�p�Gopen()/close() kng�Jthread�����A�`�`�|�o��thread delete��loh�A
	�~��close()�A�P�ϽĬ���~�A�{�������C
*/
//*********************************************************************
//**  Comment of class owplayer
//*********************************************************************
//*********************************************************************

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

void	iwavebase:: sethdr(short*data,int shsize)
{
	memset(&hdr,0,sizeof(hdr));
	hdr.lpData=(LPSTR)(data);
	hdr.dwBufferLength=shsize*sizeof(short);
}

void	iwavebase::
sleep2end0(int ms)
{		while(ms>0){if(!bLokImDiong) break; ms-=10;	Sleep(10);}		}



int		iwavebase::
open	(DWORD dwInst, OWPROC p, waveformatex* wf)
{
	//�]��owbang.play���|���~�٦^�A�ҥH���ɪ�open���|��bPlaying�����D
	//�Y�ϥΦbthread���ɡA�ݭn�ˬdbPlaying
	crtsection cs;	cs.enter();
	int same=1;
	if(wf) same=wfx.eq(*wf); if(!same){if(wf) wfx=(*wf);}
	//if(p!=owproc){same=0; owproc=p;}
	if(same&&bOpened) return 1;
	if(!same&&bOpened){
		close(200);
		if(bLokImDiong) return 0;
	}
	//did not check p
	if(!bOpened){
		res=waveInOpen(&hwi,WAVE_MAPPER,&wfx,(DWORD)p,dwInst,CALLBACK_FUNCTION);
	}
	cs.leave();
	return bOpened;
}

int		iwavebase::
close	(int mswait)
{
	crtsection cs;	cs.enter(); //if(owproc==NULL)owp=OWPdef;
	if(bLokImDiong) {reset();Sleep(10);}
	sleep2end(mswait);
	if(!bLokImDiong){
		res=waveInClose(hwi);
		bOpened=0;
	}else
		res=WAVERR_STILLPLAYING;
	cs.leave();
	return res;
}
int		iwavebase::
reset	(int mswait)
{
	crtsection cs;	cs.enter();
	if(!bLokImDiong) return MMSYSERR_NOERROR;//no need for reset in this case
	if(isfixthreaded)
		nshbeforereset=position();
	cs.leave();
	res=waveInReset(hwi);
	cs.enter();
	Sleep(1);
	sleep2end(mswait);
	cs.leave();
	return res;
}

__int64	iwavebase::position ()
{
	MMTIME	mmt1;	mmt1.u.sample=0; mmt1.wType=TIME_SAMPLES;
	crtsection cs;	cs.enter();
	if(bLokImDiong){
		waveInGetPosition(hwi,&mmt1,sizeof(mmt1));
	}
	cs.leave();
	return mmt1.u.sample;
}

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////



//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
int iwlokim1::lokim(qiimbuf_ & qbuf, int nsec)
{
	int nsh=qbuf.pcm.ms2nsh(nsec*1000);
	qbuf.reserve(nsh);
		//[1] waveopen, fill-in wfx first
	if(!iw.open(&(qbuf.pcm.wfex))){	return 0;	}
		//[2]  prepare the wavein buf, fill-in WAVEHDR first
	iw.sethdr(qbuf.sh, nsh);
	res=iw.prep();
		//[3] addwavein buf
	res=iw.add();
		//[4] start recording
	iw.reset4wait(); iw.bLokImDiong=1;
	res=iw.start();
		//[5]  wait for wavein to return
	iw.wait2end();
	qbuf.nshused=iw.hdr.dwBytesRecorded/sizeof(short);
	qbuf.setbytesize();
		//[6]  unprepare wavein buf
	res=iw.unprep();
		//[7]  stop will only cause current buf done, so use reset() instead
		//////	res=waveInStop(hwi);// not necessary?
		//[8]  reset will cause all buf's done
		//since end normally, no reset is required here, but call it anyway
		//It is not harm to call reset, as long as hwi is opened
	res=iw.reset();
	iw.bLokImDiong=0;
		//[9]  close waveinv
	////res=iw.close();//called in dtor/another open
	return qbuf.ssize();
}

int iwlokim1::
tlokim(qiimbuf_& qb, int nsec)
{
	crtsection cs;	cs.enter();
	if(nsec<=0) return 0;
	if(iw.bLokImDiong) iw.reset(200);
	int nsh=qb.pcm.ms2nsh(nsec*1000);
	p2qbuf=&qb;
	shsize=nsh;
//	if(!iw.open(&(qb.pcm.wfex))){	return 0;	}
//	sh0=sh; shsize0=shsize;//pcm is set inside open(pcm)
	cs.leave();
	thd.begin(thdf,this);
	return 1;
}


int iwlokim1::sztlokim  	()//really(sit-ze) threaded lokim
{
	//almost the same as lokim, except criticalsection is added
	iw.isfixthreaded=1;////so that if reset(), it will getposition first
	qiimbuf_& qbuf=*p2qbuf; int nsh=shsize;
	qbuf.reserve(nsh);
	crtsection cs; cs.enter();
	//[1] waveopen, fill-in wfx first
	if(!iw.open(&(qbuf.pcm.wfex))){	return 0;}
	//[2]  fill-in WAVEHDR
	iw.sethdr(qbuf.sh, nsh);
	//[3]  prepare the wavein buf
	res=iw.prep();
	//[4] addwavein buf
	res=iw.add();

	iw.reset4wait();	iw.bLokImDiong=1;
	//[5] start recording
	res=iw.start();		cs.leave();
	//[6]  wait for wavein to return
	iw.wait2end();		cs.enter();
	//[7] collect the wavedata
	if(iw.nshbeforereset>0) qbuf.nshused=int(iw.nshbeforereset);
	else qbuf.nshused=iw.hdr.dwBytesRecorded/sizeof(short);
	qbuf.setbytesize();
	//[8]  unprepare wavein buf
	res=iw.unprep();
	//[9]  reset will cause all buf's done, but isnot nec. here: no harm
	res=iw.reset();
	////res=iw.stop();//[10]stop cause only current buf done,use reset() instead
	iw.bLokImDiong=0;
	////res=iw.close();//[11] close wavein, or called in dtor/another open
	iw.isfixthreaded=0;		cs.leave();
	return qbuf.ssize();
}


//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////



//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
float*iwhbc::
dnsmp2spt(ehfs_& ehfs, int nFS, int dnsmp, int dboff)
{
	int n,dn;
	for(n=0, dn=0; n<nFS; n+=dnsmp, dn++) shs[dn]=sh[n];
	nFS=nFS/dnsmp;
	if(dboff){
		int sum=0;
		for(dn=0; dn<nFS; dn++) sum+=shs[dn];sum=sum/nFS;
		for(dn=0; dn<nFS; dn++) shs[n]-=sum;
  }
  ehfs.fs1(shs, nFS, fts);
  return fts;
}


int  iwbessc::
ssc			(iwhbc& hbc, int forbegin)// always w/ dboff, and dnsample
{
	iwoption& opt=*p2opt;
	float* spt=hbc.dnsmp2spt(ehfs, opt.nFS, opt.dnsmp, 1 );
	int n, NN=opt.nFFT/2, cnt=0; float* cut=(forbegin)?cutb:cute;
	int	delta=(forbegin)?nbSSC:neSSC;
	for(n=1; n<NN/2; ++n) if(spt[n]>cut[n])cnt+=delta;
	for(   ; n<NN	; ++n) if(spt[n]>cut[n])cnt+=delta;
//	for(n=1; n<NN; n++) if(spt[n]>cut[n]) cnt++;
	if(forbegin) return cnt>=nbSSC; else return cnt>=neSSC;
}

void	iwbessc::
setTHRESH(double bTHRSH, double eTHRSH)
{
	if(!adaptset)return;if(!p2opt)return ;
	if(bTHRESH>0&&eTHRESH>0)
		if(bTHRESH==bTHRSH&&eTHRESH==eTHRSH) return;
	bTHRESH=bTHRSH;		eTHRESH=eTHRSH;
	if(bTHRESH<=0||eTHRESH<0){bTHRESH=12;eTHRESH=12;}
	if(bTHRESH<0)bTHRESH=0;if(bTHRESH>36)bTHRESH=36;
	if(eTHRESH<0)eTHRESH=0;if(eTHRESH>36)eTHRESH=36;
	iwoption& opt=*p2opt; float base=1.1;
	float b=pow(base,float(bTHRESH-12)), e=pow(base,float(eTHRESH-12));
	int nn, NN=opt.nFFT/2;
	for(nn=0;nn<NN;++nn){
		cutb[nn]=cutb0[nn]*b;
		cute[nn]=cute0[nn]*e;
	}
}

int		iwbessc::
setadapt (iwoption& opt1, qiimbuf_* qb1=0)// if(0) use in-class qbuf, else copy
{
	//	qiimbuf_ &qb=(qb1)?(*qb1):adbuf;
	if(!qb1) return 0; qiimbuf_& qb=*qb1; p2opt=&opt1; iwoption& opt=*p2opt;
	int&	nsrt	=opt.nsrt;		// sampling rate, sample per sec
	int&	nFS	=opt.nFS;		// frame size, in sample
	int&	nFFT	=opt.nFFT;		// num of points to take FFT
	int&	dnsmp	=opt.dnsmp;		// 1/2/4, down sample for endpoint

	if(!qb.rmb(nFS)) return 0;//remove a small section that look like abnormal
	int dnsmporg=dnsmp; int nFSorg=nFS; int qbsr=qb.pcm.sr();
	if(qbsr!=nsrt) {
		int tt=qbsr/nsrt;
		if(tt*nsrt != qbsr) return 0;
		dnsmp=tt*dnsmp;
		nFS=nFS*tt;		////?????
	}
	dbbias=qb.mean();
	float     spt [MFRMSZ]; // spt: spectrogram
	float     avg [MFRMSZ]; // the mean vector of the background noise
	float     var [MFRMSZ]; // the variance vector of the background noise
	//qb-=dbbias;
	memset(avg,0,sizeof(short)*nFSorg/4);
	memset(var,0,sizeof(short)*nFSorg/4);
	//int n, NN=nframes(qb), m, M=nFFT/2;
	int n, NN, m, M=nFFT/2;
	NN=qb.nshused/(nFS);
	for(n=0; n<NN; n++) {
		//sh2spt(qb.sh+beg4nthframe(n), nFS, spt, nFFT, dnsmp);
		//sh2spt(qb.sh+nFS*n, nFS, spt, nFFT, dnsmp);
		sh2spt_woff(qb.sh+nFS*n, nFS, spt, nFFT, dnsmp);
		for(m=0; m<M; m++){
		  avg[m]+=spt[m];
		  var[m]+=spt[m]*spt[m];
		}
	}
	for(m=0; m<M; m++){
		avg[m]=avg[m]/NN;
		var[m]=var[m]/NN-avg[m]*avg[m];
		if(var[m]<0) var[m]=0;
		var[m]=sqrt(var[m]);
	}
	int gaps[]=     { 0,    M/4,    M*4/5,  M};
	int gapsz=sizeof(gaps)/sizeof(int);
//	float bstimes[]={ 3,      3,        3};
//	float estimes[]={ 2.5,    2.5,      2};
	float bstimes[]={ 3.5,		3.5,		3};
	float estimes[]={ 2.5,		2.5,		2};
	for(int g=0; g<gapsz-1; g++) {
		for(m=gaps[g]; m<gaps[g+1]; m++){
			//cutb[m]=var[m]*bsigmatimes;
			//cute[m]=var[m]*esigmatimes;
			cutb0[m]=(avg[m]+var[m]*bstimes[g]);
			cute0[m]=(avg[m]+var[m]*estimes[g]);
		}
	}
	nFS=nFSorg; dnsmp=dnsmporg;
	adaptset=1;
	setTHRESH(bTHRESH,eTHRESH);
	return 1;
}


int		iwbessc::
setadapt	(iwoption& opt1, char*fn, char*pn)// if(0) use "4adapt.sp"
{
	qb.read(fn,pn); if(!qb.isOK())return 0;
	return setadapt(opt1,&qb);
}

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////


//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

char* iwoption:: msgdef="ť��...\x01�@������...\x01�@��������";

void	iwoption::
setmsgs(char*s, char sep)
{
	msgs[0]=msgs[1]=msgs[2]=NULL;
	int n;char*t=s;msgs[0]=t++;
	n=str_find1(t,ch01);if(n>=0){t[n]=0;t+=n+1;msgs[1]=t;}
	if(n>=0){n=str_find1(t,sep);if(n>=0){t[n]=0;t+=n+1;msgs[2]=t;}}
}
void	iwoption::
setbems (int msbDUR1,int mseDUR1,	int msbSIL1,	int mseSIL1,	int msBLURB1)
{
	 msbDUR=msbDUR1;mseDUR=mseDUR1;	csbe(msbDUR,0,10000); csbe(mseDUR,0,10000);
	 msbSIL=msbSIL1;mseSIL=mseSIL1;	csbe(msbSIL,0,10000); csbe(mseSIL,0,10000);
	 msBLURB=msBLURB1;
}
void    iwoption::set_sr(int srcase)
{
	csbe(srcase,int(sr08K), int(sr44K)+1);
	if(iwcase==srcase) return;
	iwcase=srcase;
	nchl=1;nBps=2; //adaptset=0;
	switch(iwcase){
	case sr08K:
			nsrt=8000;nspd=1250;
			nFS=128; //nSS=64;    // 16ms per frame
			//dnsmp=1; nFFT=128;
			dnsmp=2; nFFT=64;
			break;
	case sr16K:
			nsrt=16000;nspd=625;
			nFS=256; //nSS=128;   // 16ms per frame
			//dnsmp=2; nFFT=128;
			dnsmp=4; nFFT=64;
			break;
	case sr32K:
			nsrt=32000;nspd=312;
			nFS=512; //nSS=256;   // 16ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=8; nFFT=64;
			break;
	case sr48K:
			nsrt=48000;nspd=208;
			nFS=1024; //nSS=256;   // 21.3ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=16; nFFT=64;
			break;
	case sr64K:
			nsrt=64000;nspd=156;
			nFS=1024; //nSS=256;   // 16ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=16; nFFT=64;
			break;
	case sr11K:
			nsrt=11025;nspd=907;
			nFS=128; //nSS=64;    // 11.6ms per frame
			//dnsmp=1; nFFT=128;
			dnsmp=2; nFFT=64;
			break;
	case sr22K:
			nsrt=22050;nspd=456;
			nFS=256; //nSS=128;   // 11.6ms per frame
			//dnsmp=2; nFFT=128;
			dnsmp=4; nFFT=64;
			break;
	case sr44K:
			nsrt=44100;nspd=227;
			nFS=1024; //nSS=256;   // 23.2ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=16; nFFT=64;
			break;
	}
}
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////



//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

void	endpointb::
setDUR		(int nbDUR1, int nbSIL1)
{
	nbDUR=nbDUR1;		csbe(nbDUR,		3, nBUF+1);
	nbSIL=nbSIL1;		csbe(nbSIL,		1, nBUF-nbDUR+1);
}

int	endpointb::
wavein(iwhbc* p2whbc, int is4bspeech )
{
	if(beged) return 0;
	if(is4bspeech){
		if(nbdur==0)
			nbegspeech=ncbuf;
		++nbdur;
		if(nbdur>=nbDUR){
			beged=1;
			if(msg)wiom.iwm(msg);////"lokim..."
		}
	}else{
		nbdur=0;
		nbegspeech=ncbuf;
	}
	memmove(buf+ncbuf*frmsz,  p2whbc->sh,  frmsz*sizeof(short));
	////thus, after beged=1, we have nbDUR frames of speech and indefinite # of sil-frames
	++ncbuf;
	if(ncbuf>=nBUF){ncbuf=0;round2=1;}
	return beged;
}

int	endpointb::
nshsil		()
{
	int b1; int nfrm;
	//e1=nbegspeech+nbDUR;
	b1=nbegspeech-nbSIL;
	if(round2){
		nfrm=nbSIL;
	}else{
		if(b1>=0)	nfrm=nbSIL;
		else     	nfrm=nbegspeech;
	}
	return nfrm*frmsz;
}


int	endpointb::
nframe_tz()
{
	int b1, e1, nfrm;
	e1=nbegspeech+nbDUR;		b1=nbegspeech-nbSIL;
	if(round2){//// so that nbSIL and nbDUR is real
		nfrm=nbDUR+nbSIL;
	}else{
		if(b1>=0)	nfrm=e1-b1;//nbDUR+nbSIL;
		else     	nfrm=e1;//nbegspeech+nbDUR;
	}
	return nfrm;
}


int	endpointb::
copy2tz	(qiimbuf_  & qb)//copy2 front(tz:tauzing) of qiimbuf_
{
	int b1, e1; int len;
	e1=nbegspeech+nbDUR;		b1=nbegspeech-nbSIL;
	if(round2){
		if(e1>nBUF){	////thus 0 <= b1 <  nBUF<e1
			len=(nBUF-b1);
			memmove(qb.sh, 		 	buf+b1*frmsz,	sizeof(short)*frmsz*len);
			memmove(qb.sh+len*frmsz,buf,				sizeof(short)*frmsz*(e1-nBUF));
		}else if(b1<0){////thus b1<  0  <= e1  <nBUF
			len=(-b1);
			memmove(qb.sh, 			buf+(nBUF+b1)*frmsz,	sizeof(short)*frmsz*len);
			memmove(qb.sh+len*frmsz,buf,						sizeof(short)*frmsz*e1 );
		}else{			////thus 0 <= b1 <  e1 <=nBUF
			len=(e1-b1);
			memmove(qb.sh,	buf+b1*frmsz,	sizeof(short)*frmsz*len);
		}
	}else{
		if(b1>=0){	////thus 0<= b1 <  e1  <nBUF
			len=e1-b1;
			memmove(qb.sh,	buf+b1*frmsz,	sizeof(short)*frmsz*len);
		}else{		////thus b1< 0  <  e1  <nBUF
			len=e1;
			memmove(qb.sh,	buf, 				sizeof(short)*frmsz*len);
		}
	}
	return 1;
}
//////////////////////////////////////////////////
//////////////////////////////////////////////////


int	endpointe::
wavein(int is4esil)
{
	if(ended) return 0;
//	mout<<"nedur beg total "<<ntotal<<memo;
	++ntotal;
	if(is4esil){
		++nedur;
		if(nedur==1) nbegsilence=ntotal;
		if(nedur>1)neblurb=0;else ++neblurb;//too short a silence willnot count
	}else{
		++neblurb;
		if(neblurb>neBLURB){//if true,it is speech,not blurb
			nedur=0; neblurb=0;
		}
	}
	if(nedur>=neDUR){ended=1;}
	return ended;
}

int	endpointe::
trimsil	(qiimbuf_& qb, int frontfrms	)
{
	if(nbegsilence<=0){//this probably is from manual lokim
		qb.nsheqiim=qb.nshused;
		return 1;
	}
	int sz;
	sz=(nbegsilence+frontfrms)*frmsz;
	qb.nsheqiim=sz;
	sz=(nbegsilence+frontfrms+neSIL)*frmsz;
	qb.nshused=sz; if(qb.nshused>qb.nshalloc)qb.nshused=qb.nshalloc;
	return 1;
}

void	endpointe::
setDUR		(int neDUR1, int neSIL1,	int neBLURB1)
{
	neDUR=neDUR1;		csbe(neDUR,1, 1000+1);
	neSIL=neSIL1;		csbe(neSIL,1, 1000+1);
	neBLURB=neBLURB1;	csbe(neBLURB,	0,	5);
}


//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

#endif	////#ifndef SIMPWIO_CPP

