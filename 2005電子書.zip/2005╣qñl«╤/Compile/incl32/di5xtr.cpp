
#include <di5xtr.h>

chars less4fslen:: cs;
chars less4fslen:: lfn;
chars less4fslen:: rfn;

mfcatter_ macat;

uint mfcatter_:: testmfb(char* fname)
{ /*
	mfb.mfr.close();
	char* fn=(fname)?fname:"mftest.dig";
	chars cs; cs.clear();
	int n=400,N=n+100; char* t; int len;
	if(mfb.open(fn)){
		if(N>mfb.size())N=mfb.size();
		for(;n<N;n++){
			t=mfb.sfbeg(n);len=mfb.sfsize(n);
			//cs+=mfb.sfname(n); cs+="\t"; cs+=len; cs.appln();
			qb.readp(t,len);
			qb.play();
		}
	}
	Form1->Memo1->Lines->Text=cs.s;
	return N;
	*/
	return 0;
}

uint dir2chars__(chars &ocs, char* pname, char* fname)
{
	ocs.clear();
	chars fn, pn; pn=pname; if(pn.hassome())pn.appifen("\\");
	fn=pn; if(fname&&fname[0]) fn+=fname; else fn+="*.*";
	struct ffblk ffblk;
	int done; int NN=0;
	done = findfirst(fn.s,&ffblk,0);
	while (!done) {
		ocs+=ffblk.ff_name;		ocs+="\r\n"; ++NN;
		done = findnext(&ffblk);
	}
	ocs.deleif("\r\n");
	return NN;
}
uint dir2flset__(set<fslen, less4fslen>&flset, char* pname, char* fname,int prpnd_pname)
{
	chars fn, pn; pn=pname; if(pn.hassome())pn.appifen("\\");
	fn=pn; if(fname&&fname[0]) fn+=fname; else fn+="*.*";
	struct ffblk ffblk;
	int done; int NN=0;
	fslen fl;
	done = findfirst(fn.s,&ffblk,0);
	while (!done) {
		if(prpnd_pname) fl.f=pn.s; else fl.f.clear();
		fl.f+=ffblk.ff_name;
		if(!fl.f.has('~')){
			fl.l=ffblk.ff_fsize;	flset.insert(fl); ++NN;
		}
		done = findnext(&ffblk);
	}
	return NN;
}

uint flist2flset__(set<fslen, less4fslen>&flset, char* dt, char* ext)
{
	charspp spp; chars cs;
	spp.set2Nhunlet(dt);
	uint n,N=spp.size(); int NN=0;
	tyio tio, w; uint flen;
	fslen fl;
	for(n=0;n<N;n++){
		cs=spp[n]; if(ext) cs+=ext;
		if(cs.hasnone())continue;
		if(!tio.open(cs.s))continue;
		uint flen=tio.filesize();
		fl.f=cs.s; fl.l=flen;
		flset.insert(fl);
		++NN;
		tio.close();
	}
	return NN;
}



uint mfcatter_:: catdirsp(char* pname)
{
	flset.clear();
	mffsize=0;
	dir2flset(pname,"*.sp");
	tyio io; 	char fn[]="mftest.dig";
	mfh.setidf("78dpy");
	cat2(fn);
	//Form1->Edit1->Text=flset2seqbsz();//flset.size();
	return 0;
}

uint	mfcatter_::catdidzc		(char* fname, char* pname, char* spextname, char iv_iusen)
{//cat an tml file
	chars pn, fn, cs; int res;
	mffsize=0;
	fn.getsetfname(fname); if(fn.hasnone()) return 0;
	if(pname&&pname[0])pn=pname;else pn.getsetfname(fname);
	if(pn.hassome()) pn.appifen("\\");
	flset.clear();
	if(!tml2flset(pn, fn, spextname, cs)){
		cs.appln(); cs.appln(); cs+="�Om�Oveh�~��H";
		res=MessageBox(NULL,cs.s, "dzc catter",MB_YESNOCANCEL);
		if(res!=IDYES)
			return 0;
	}
	mfh.setidf("didzc1.0");
	mfh.opt[1]=iv_iusen;//opt[1] should be 'i'/'v'/'b' for yim/vun/both iusen
	//mfh.setmfname(fn.s);
	int n=fn.findlast('.'); if(n>0) fn[n]=0;
	fn.app(".dzc");
	cat2(fn.s,pname);
	return 0;
}

uint mfcatter_:: cat2(char* fname, char* pname)
{
	tyio io;
	io.creat(fname,pname);
	if(io.isERR()) return 0;
	mfh.nSUBF=flset.size();
	mfh.seqlen=flset2seqbsz();
	mfh.fsize=sizeof(mfh)+flset2dzbbsz()+mfh.seqlen;
	if(mffsize>0){
		mfh.fsize+=sizeof(int)+ mfh.ftimesize()+ mffsize;
							//mpos4 mffsize, mpos4 ftime3, mpos4 msfile
	}
	csset=mfh.mfname; // csset is used here as a temp variable only
	memset(mfh.mfname,0,256);
	strncpy(mfh.mfname,csset.getfname(),255);
	mfh.write(io); // header
	strncpy(mfh.mfname,csset.s,255);
	flset2(io);    // dzb
	// main script file will be written at writesubfseq
	writesubfseq(io);
	io.close();
	chars cs; cs=pname; cs.appifen("\\"); cs+=fname; cs.appln();
	cs.app("���\�s�@");
	MessageBox(NULL,cs.s,"dqs31.exe",MB_OK);
	return 0;
}


int	 mfcatter_::	writesubfseq		(tyio&	io)
{
	ftime3 ft;  flitr itr; tyio r;  uint len;
	int catft=catftime3(); int LEN=0;
	if(mffsize>0){
		r.open(mfh.mfname); if(r.isERR()) return 0;//comment below
		LEN+=io.write(&mffsize,sizeof(int));
		if(catft){ft.get(r); LEN+=ft.write(io);}
		LEN+=io.appfile(mfh.mfname);
	}
	for(itr=flset.begin();itr!=flset.end();itr++){
		r.open((*itr).f.s);
		if(r.isERR())//this is real error, was opened OK, but not now
			return 0;
		len=(*itr).l;	LEN+=io.write(&len, sizeof(uint));
		if(catft){ft.get(r); LEN+=ft.write(io);}
		LEN+=io.appfile(r);
	}
	return LEN; // check with the seqsize
}
/*
// used in dqs31.ext
uint mfcatter_:: tml2flset		(chars& pn, chars& fn, char* spextname, chars& errmes)
{
	if(pn.hassome())pn.appifen("\\");
	chars cs; errmes.clear();errmes.appln("�L�k�׶} :\r\n");
	cs=pn; cs+=fn;
	tcp3_ tcp;
	tcp.read(cs.s);
	if(tcp.size()<=0){errmes="�Ţ��@��";return 0;}
	struct ffblk ffblk;
	fslen fl;	int fnderr; uint n, N, NN=0, EE=0;
	fnderr=findfirst(cs.s, &ffblk,0);
	if(fnderr) {errmes+=cs.s;return 0;}
	//fl.f=cs.s; fl.l=ffblk.ff_fsize; flset.insert(fl); ++NN;
	mffsize=ffblk.ff_fsize;
	mfh.setmfname(cs.s);
	N=tcp.size();
	for(n=0; n<N; n++){
		cs=pn; cs+=tcp.spf(n);
		cs.appifen(spextname);
		fnderr=findfirst(cs.s,&ffblk,0);
		if(fnderr ) { ++EE; if(EE<10) {errmes.appln(cs.s);} }
		if(!fnderr) { fl.f=cs.s; fl.l=ffblk.ff_fsize; flset.insert(fl);++NN;}
	}
	if(EE>0) {
		if(EE>10){errmes+="...\r\netc\r\n";errmes+=int(EE);errmes.appln(" errors");}
		return 0;
	}
	return NN;
}
*/


int	mfcatter_:: flset2dzbbsz()
{
	//compute dzb bsz
	int bsz=0;  flitr itr;
	for(itr=flset.begin(); itr!=flset.end(); itr++){
		bsz+=sizeof(int);// offset
		bsz+=strlen((*itr).f.getfname())+1;
	}
	bsz++;//for the last entry to be set to 0
	return bsz;
}

int	mfcatter_::	flset2seqbsz()
{
	//compute subfile sequence bsz
	int bsz=0;  flitr itr;  int catft=catftime3();
	for(itr=flset.begin(); itr!=flset.end(); itr++){
		bsz+=sizeof(int);// sizeof(int) for real subfile size
		if(catft) bsz+=sizeof(ftime3); //if ftime3 is going to be save
		bsz+=(*itr).l;                 //the real file content size
	}
	return bsz;
}


int	mfcatter_::flset2(tyio& io)
{
	int tot=0, len, LEN; // int szi=sizeof(int);
	len=sizeof(rdhdr53);
	int asz, bsz; flitr itr;
	//writing dzb rdhdr
	rdhdr53 hdr;
	asz=long(flset.size());
	bsz=flset2dzbbsz();
	hdr.setabu(asz,bsz,0);
	hdr.setfqkck(1,'d','r',1,DIRD_DZB);
	tot+=io.write(&len,sizeof(int));
	tot+=hdr.write(io);
	tot+=io.write(&bsz, sizeof(int));
	//writing dzb data
	uchar clen;  chars cs;
	LEN=0;
	LEN+=sizeof(mfheader);
	LEN+=sizeof(int);// for the mem of dzbhdr size
	LEN+=sizeof(rdhdr53);
	LEN+=sizeof(int);// for the mem of bsz
	LEN+=bsz;
	if(mffsize>0){
		LEN+=sizeof(int);
		LEN+=mfh.ftimesize();
		LEN+=mffsize;
	}
	for(itr=flset.begin();itr!=flset.end(); itr++){
		clen=sizeof(int);clen+=strlen((*itr).f.getfname())+1;tot+=io.write(&clen,1);
		len=(*itr).l; tot+=io.write(&LEN,sizeof(int));
		LEN+=sizeof(int)+mfh.ftimesize()+len;
		cs=(*itr).f.getfname(); len=cs.size(); tot+=io.write(cs.s,len);
	}
	clen=0; tot+=io.write(&clen,1);
	// write the subfiles here
	return tot;//int(flset.size());
}

int	mfcatter_::flset2a(tyio& io)
{
	int tot=0, len; // int szi=sizeof(int);
	len=sizeof(rdhdr53);
	int asz, bsz; flitr itr;
	//writing dzb rdhdr
	rdhdr53 hdr;
	asz=long(flset.size());
	bsz=flset2dzbbsz();
	hdr.setabu(asz,bsz,0);
	hdr.setfqkck(1,'d','r',1,DIRD_DZB);
	tot+=io.write(&len,sizeof(int));
	tot+=hdr.write(io);
	tot+=io.write(&bsz, sizeof(int));
	//writing dzb data
	uchar clen;  chars cs;
	for(itr=flset.begin();itr!=flset.end(); itr++){
		clen=sizeof(int);clen+=strlen((*itr).f.getfname())+1;tot+=io.write(&clen,1);
		len=(*itr).l; tot+=io.write(&len,sizeof(int));
		cs=(*itr).f.getfname(); len=cs.size(); tot+=io.write(cs.s,len);
	}
	clen=0; tot+=io.write(&clen,1);
	// write the subfiles here
	return tot;//int(flset.size());
}



char*mfcatter_::flset2(chars& cs)
{
	cs="  ";
	cs.clear();
	flitr itr;
	for(itr=flset.begin(); itr!=flset.end();itr++){
		cs+=itr->f.getfname();
		cs+=" \t";
		cs+=tos(itr->l);
		cs.appln();
	}
	return cs.s;
}

char*mfcatter_::dzb2(chars& cs)
{
	cs="  ";
	cs.clear();
	if(!dzb.isOK()) return cs.s;
	int n,N=dzb.size();
	for(n=0; n<N; n++){
		cs+=dzb.d0(n); cs+=" \t";
		cs+=tos(dzb.freq(n));
		cs.appln();
	}
	return cs.s;
}



//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
