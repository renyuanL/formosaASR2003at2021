//
// di5tcp.h
//

#ifndef DI5TCP_H
#define DI5TCP_H

#include <di5base.h>

//#define ENABLED
#ifdef ENABLED
class ivdetc_ { public:
  char  qq;
  //HDC   hdc;
  char  *v, *y;
  int   xb, yb;
  int   sugap, lnhite;
};
#endif //ENABLED

class tcp3_ {public:
      tcp3_(){clear();}
public:
	uint  size      (      ){return ss.size();           }
  int   nG        (uint n){return ckbe(n,uint(0),size());  }
  int   nC        (uint n){return int(n)==cln;             }
  char* operator[](uint n){return(nG(n))?ss[n]:null.s;  }
  char* yim       (uint n){getset4(n);return cparts[2]; }
  char* vun       (uint n){getset4(n);return cparts[1]; }
  char* spf       (uint n){getset4(n);return cparts[0]; }
  char* yim       (      ){return yim(cln); }
  char* vun       (      ){return vun(cln); }
  char* spf       (      ){return spf(cln); } // no ext
  char* yimtr     (uint n){static chars cs; cs=yim(n);cs.tr('=',' ');return cs.s; }
  char* vuntr     (uint n){static chars cs; cs=vun(n);cs.tr('=',' ');return cs.s; }
  char* yimtr     (      ){static chars cs; cs=yim(cln);cs.tr('=',' ');return cs.s; }
  char* vuntr     (      ){static chars cs; cs=vun(cln);cs.tr('=',' ');return cs.s; }
  int   set       (uint n){if(n==uint(cln))return n;csbe(n,uint(0),size());getset4(n);return cln;}
  int   inc       (int d=1){return set(cln+d);}
  int   dec       (int d=1){return set(cln+d);}
  void  getset4   (uint n);
	char  qiqen1c   (      );
	char* qiqenhanri(char c);
	char* qiqenhanri(      ){return qiqenhanri(qiqen1c());}
public:
public:
	uint  readtcp1(xreader& lr, chars& prev);
	uint  readxml (xreader& lr);
	uint  read    (char* fn, char* pn=0);
	int   zogu    (char* s);
public:
	int		getcln	(){return cln;}
	int		goodndx	(int 	nln	){return ss.goodndx		(nln);}
	char*	pname		(){return pn.s;	}
public:
	charss ss;  charspp cparts; chars pfn, pn;
	vector<uint> ndllines;
	int cln; chars null; chars qiqen;
	void  clear0();//shallow clear
	void  clear ();//deep clear, include pn, pfn
	void  clearcparts();
};
#include <time.h>
extern char* duligstarttext;
class 	duligtcp_ {
public: duligtcp_ (){clear(); pn="C:\\c2k\\bcb\\dulig\\test\\";}
	char* spfnext	(				);
	char* spf			(				){return spf(cln);}//sppln.set2Nhun(ss[cln]); return sppln[0];}
	char* spf			(uint bb);//{sppln.set2Nhun(ss[bb ]); return sppln[0];}
public:
	char* ctimefn(){time_t t=time(NULL); return ctime(&t);}
public:
	char*	oxvz();
	char* oxgu(){ static char s[]	="<gu sp=\"\" >";	return s;}
	char* cxgu(){ static char s[]	="</gu> ";					return s;}
	char* xsu	(){ static char s[] =" <su v=\"\" y=\"\" k=\"\" /> ";	return s;}
public:
	//int		creat	(chars& newfn, char* sphead=0);//use fname if sphead is null
	int		creat	(chars& newfn, char* sphead, int nthsmprate);//use fname if sphead is null
	uint	save	(char* tcpfn=0);
	uint  read	(char* fn=0, char* pn=0);
	uint	read	(xreader& r);
	int   zogu	(char* s);
	char* vuntr (uint n){static chars cs; cs="";return cs.s; }
	char* vuntr (			 ){static chars cs; cs="";return cs.s; }
public:
	uint	size	(				){return ss.size();}
	void	clear	(				){cln=0;nxt=0;dirty=0;smprate=22050;sppln.set2Nhun(" ");ss.clear();ndllines.clear();}
	//int		smprate2nth(int smplingrate);//44/22/11/48/16/08
	void	setsmprate		(int smprt		){smprate=smprt;}
	int		setnthsmprate	(int nthsmprt	);
	int		getnthsmprate	(							);
	char* getsrstr			(							);
public:
	int		goodappndx(int 	nln	){return ss.goodappndx(nln);}
	int		goodndx		(int 	nln	){return ss.goodndx		(nln);}
	int		goodndx		(			  	){return ss.goodndx		(cln);}
	int		setxgu		(char* spfn, int replacemode);
	int		delxgu		(int 	ngu	);
public:
	int		setclnki	(chars& cs);
	int		setclnvun	(chars& cs);
	int		setclnyim	(chars& cs);
	int		getki			(int nln, chars& cs);
	int		getvun		(int nln, chars& cs);
	int		getyim		(int nln, chars& cs);
	int		getvunyim (int nln, chars& cs, char sep1=' ', char sep2=' ');
	int		getclnki	(chars& cs){return getki (cln,cs);}
	int		getclnvun	(chars& cs){return getvun(cln,cs);}
	int		getclnyim	(chars& cs){return getyim(cln,cs);}
	int		delcur		(					);
public:
	char*	pname	(){return pn.s;	}
	int		incnxt(){return ++nxt;}
	int		inccln(){cln++;cslmt(cln,0,ss.size());return cln;}
	int		deccln(){cln--;cslmt(cln,0,ss.size());return cln;}
	int		getcln(){return cln;}
	int		setcln(int cln1){cslmt(cln1,0,ss.size());cln=cln1;return cln;}
public:
	charss ss;  vector<uint> ndllines;
	chars sphd;
private:
	xtagrw xtg; xtag xfn;
	int cln, nxt, dirty;
	int smprate;
	charspp sppln;
	chars pn, fn;
};





#endif  //DI5TCP_H

