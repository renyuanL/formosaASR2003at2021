








#ifndef SPIOSDL_CC
#define SPIOSDL_CC



TPCI2(V1,V2)	TRChart& rchartf_::
line(TRChart& rct, V1& vx, V2& vy, int  beg, int  end)
{
	uint n,N=vx.size(); if(N<=0||N!=vy.size()) return rct;
//	rct.MoveTo  (vx[beg],vy[beg]);
	rct.MoveTo  (vx[0],vy[0]);
	for(n=1; n<N; n++)
		rct.DrawTo(vx[n],vy[n]);
	return rct;
}
TPCI2(V1,V2)	TRChart& rchartf_::
stem(TRChart& rct, V1& vx, V2& vy, int  beg, int  end)
{
	uint n,N=vx.size(); if(N<=0||N!=vy.size()) return rct;
//	rct.MoveTo  (vx[beg],vy[beg]);
	for(n=0; n<N; n++)
		rct.Line(vx[n],0,vx[n],vy[n]);
//		rct.DrawTo(vx[n],vy[n]);
	return rct;
}

TPCI2(V1,V2)	TRChart& rchartf_::
mark(TRChart& rct, V1& vx, V2& vy, int markkind, int beg, int end)
{
	uint n,N=vx.size(); if(N<=0||N!=vy.size()) return rct;
//	rct.MoveTo  (vx[beg],vy[beg]);
	for(n=0; n<N; n++)
		rct.MarkAt(vx[n],vy[n],markkind);
//		rct.Line(n,0,n,v[n]);
//		rct.DrawTo(vx[n],vy[n]);
	return rct;
}




//* handy class to get/set color/cnum/wid from/to TRChart
//* (saves some typing, and destructor will auto-ly restore the original setting
//* usage example:   use it as a local variable
//*    ccsccwlocal_ cswl((*RChart1), csw);
//* where csw is a ccsccw_ with appropriate values, and was passed as a argument to the plot routine
//* The constructor will get from RChart, and then set2RChart using csw.
//* Thus, state of RChart1 is pushed/restored. The restore will auto-ly happened at end of cswl
class	ccsccwlocal_: public ccsccw_ { public: TRChart& rct;
		ccsccwlocal_ (TRChart& rcta, ccsccw_&csw	) :  rct(rcta){get();set(csw);}
		~ccsccwlocal_(			 ){restore();}
public:
	void restore( ){set();}
	void set 	( ) {rct.DataColor=clr;    rct.ClassDefault=cno;    rct.LineWidth=wid;   }
	void get 	( ) {clr=rct.DataColor;    cno=rct.ClassDefault;    wid=rct.LineWidth;   }
	void set 	(ccsccw_&csw	)	{csw.validate();rct.DataColor=csw.clr; rct.ClassDefault=csw.cno; rct.LineWidth=csw.wid;}
};





template<class R> inline TRChart& rchartf_::
csbeNcr (TRChart& rct, vector<R>& v, ccsccw_& csw, int &beg, int &end)
{   //check/set beg end and clear and range
	uint N=v.size(); if(N<=0) return rct;
	if(beg<0) beg=0;
	if(end<0) end=N;
	if(end<=beg) std::swap(beg,end);
	if(csw.cgf) rct.ClearGraf();
	if(csw.ccn) rct.RemoveItemsByClass(csw.cno);
	if(csw.scaley()){
		double MY=*max_element(v.begin()+beg, v.begin()+N);
		double my=*min_element(v.begin()+beg, v.begin()+N);
		rct.RangeHiY=MY;
		rct.RangeLoY=my;
	}
	if(csw.scalex()){
		rct.RangeHiX=end-1;
		rct.RangeLoX=beg;
	}
//	if(csw.sxy) {
//		N=end-beg;
//		double MY=*max_element(v.begin()+beg, v.begin()+N);
//		double my=*min_element(v.begin()+beg, v.begin()+N);
//		rct.SetRange(beg,my, end,MY);
//	}
	return rct;
}
template<class R> inline TRChart& rchartf_::
csbeNcr (TRChart& rct, valarray<R>& v, ccsccw_& csw, int &beg, int &end)
{   //check/set beg end and clear and range
	uint N=v.size(); if(N<=0) return rct;
	if(beg<0) beg=0;
	if(end<0) end=N;
	if(end<=beg) swap(beg,end);
	if(csw.cgf) rct.ClearGraf();
	if(csw.ccn) rct.RemoveItemsByClass(csw.cno);
	if(csw.scaley()){
		double MY=v.max();//*max_element(v.begin()+beg, v.begin()+N);
		double my=v.min();//*min_element(v.begin()+beg, v.begin()+N);
		rct.RangeHiY=MY;
		rct.RangeLoY=my;
	}
	if(csw.scalex()){
		rct.RangeHiX=end-1;
		rct.RangeLoX=beg;
	}
//	if(csw.sxy) {
//		N=end-beg;
//		double MY=*max_element(v.begin()+beg, v.begin()+N);
//		double my=*min_element(v.begin()+beg, v.begin()+N);
//		rct.SetRange(beg,my, end,MY);
//	}
	return rct;
}

template<class R1, class R2> inline TRChart& rchartf_::
csbeNcr (TRChart& rct, vector<R1>& vx, vector<R2>& vy, ccsccw_& csw, int &beg, int &end)
{   //check/set beg end and clear and range
	uint N=vx.size(); if(N<=0||N!=vy.size()) return rct;
	if(beg<0) beg=0;
	if(end<0) end=N;
	if(end<=beg) swap(beg,end);
	if(csw.cgf) rct.ClearGraf();
	if(csw.ccn) rct.RemoveItemsByClass(csw.cno);
	if(csw.scalex()) {
		N=end-beg;
		double MX=*max_element(vx.begin()+beg, vx.begin()+N);
		double mx=*min_element(vx.begin()+beg, vx.begin()+N);
		rct.RangeHiX=MX;
		rct.RangeLoX=mx;
	}
	if(csw.scaley()) {
		N=end-beg;
		double MY=*max_element(vy.begin()+beg, vy.begin()+N);
		double my=*min_element(vy.begin()+beg, vy.begin()+N);
		rct.RangeHiY=MY;
		rct.RangeLoY=my;
	}
	return rct;
}

template<class R> inline TRChart& rchartf_::
line (TRChart& rct, vector<R>& v, ccsccw_& csw, int beg, int end)
{
	uint n,N=v.size(); if(N<=0) return rct;
	csbeNcr(rct,v,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	rct.MoveTo  (beg,v[beg]);
	for(n=1; n<N; n++)
		rct.DrawTo(n,v[n]);
//	rct.AutoRange(5);
//	rct.ShowGraf();
	return rct;
}

template<class R> inline TRChart& rchartf_::
line (TRChart& rct, valarray<R>& v, ccsccw_& csw, int beg, int end)
{
	uint n,N=v.size(); if(N<=0) return rct;
	csbeNcr(rct,v,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	rct.MoveTo  (beg,v[beg]);
	for(n=1; n<N; n++)
		rct.DrawTo(n,v[n]);
//	rct.ShowGraf();
	return rct;
}

template<class R1, class R2> inline TRChart& rchartf_::
line (TRChart& rct, vector<R1>& vx, vector<R2>& vy, ccsccw_& csw, int beg, int end)
{
	uint n,N=vx.size(); if(N<=0||N!=vy.size()) return rct;
	csbeNcr(rct,vx,vy,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	rct.MoveTo  (vx[beg],vy[beg]);
	for(n=1; n<N; n++)
		rct.DrawTo(vx[n],vy[n]);
//	rct.ShowGraf();
	return rct;
}


template<class R> inline TRChart& rchartf_::
stem(TRChart& rct, vector<R>& v, ccsccw_& csw, int beg, int end)
{
	uint n,N=v.size(); if(N<=0) return rct;
	csbeNcr(rct,v,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	for(n=0; n<N; n++)
		rct.Line(n,0,n,v[n]);
//	rct.ShowGraf();
	return rct;
}
template<class R> inline TRChart& rchartf_::
stem(TRChart& rct, valarray<R>& v, ccsccw_& csw, int beg, int end)
{
	uint n,N=v.size(); if(N<=0) return rct;
	csbeNcr(rct,v,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	for(n=0; n<N; n++)
		rct.Line(n,0,n,v[n]);
//	rct.ShowGraf();
	return rct;
}

template<class R1, class R2> inline TRChart& rchartf_::
stem(TRChart& rct, vector<R1>& vx, vector<R2>& vy, ccsccw_& csw, int beg, int end)
{
	uint n,N=vx.size(); if(N<=0||N!=vy.size()) return rct;
	csbeNcr(rct,vx,vy,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	for(n=0; n<N; n++)
		rct.Line(vx[n],0, vx[n],vy[n]);//make no much sense, but do it anyway, for symmetrics
//	rct.ShowGraf();
	return rct;
}


template<class R> inline TRChart& rchartf_::
mark (TRChart& rct, vector<R>& v, ccsccw_& csw, int markkind, int beg, int end)
{
	uint n,N=v.size(); if(N<=0) return rct;
	csbeNcr(rct,v,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	for(n=0; n<N; n++)
		rct.MarkAt(n,v[n],markkind);
//	rct.ShowGraf();
	return rct;
}

template<class R> inline TRChart& rchartf_::
mark (TRChart& rct, valarray<R>& v, ccsccw_& csw, int markkind, int beg, int end)
{
	uint n,N=v.size(); if(N<=0) return rct;
	csbeNcr(rct,v,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	for(n=0; n<N; n++)
		rct.MarkAt(n,v[n],markkind);
//	rct.ShowGraf();
	return rct;
}

template<class R1, class R2> inline TRChart& rchartf_::
mark (TRChart& rct, vector<R1>& vx, vector<R2>& vy, ccsccw_& csw, int markkind, int beg, int end)
{
	uint n,N=vx.size(); if(N<=0||N!=vy.size()) return rct;
	csbeNcr(rct,vx,vy,csw,beg,end);
	ccsccwlocal_ cswl(rct,csw);
	for(n=0; n<N; n++)
		rct.MarkAt(vx[n],vy[n],markkind);
//	rct.ShowGraf();
	return rct;
}

inline TRChart& rchartf_::
hist(TRChart& rct, ucCounter& cnt, int scale)
{
//	rct.ClearGraf();
	size_t n,N=cnt.cnts.size();
	double scl=1; double yhi=-1;
	if(scale){scl=0;for(n=0;n<N;++n)scl+=cnt.cnts[n];}
	for(n=0;n<N;++n){
		rct.Rectangle
			(cnt.bdry[n],0,
			 cnt.bdry[n+1],cnt.cnts[n]/scl);
		if(yhi<cnt.cnts[n]/scl)yhi=cnt.cnts[n]/scl;
	}
//	rct.ShowGraf();
	return rct;
}

template<class R> inline TRChart& rchartf_::
hist(TRChart& rct, frqCounter<R>& frq, int scale)
{
//	rct.ClearGraf();
	map<R,int>::iterator itr;
	double fCNT=1;
	if(scale){fCNT=0;
	for(itr=frq.frq.begin(); itr!=frq.frq.end();++itr){
		fCNT+=itr->second;
	}}  int ccnt=0; double yhi=-1;
	for(itr=frq.frq.begin(); itr!=frq.frq.end();++itr){++ccnt;
		rct.Rectangle(ccnt-0.4,0, ccnt+0.4,itr->second/fCNT);
		if(yhi<itr->second/fCNT)yhi=itr->second/fCNT;
	}
//	rct.ShowGraf();
	return rct;
}









#endif //#ifndef SPIOSDL_CC
