//
//	di5vp.cpp
//	vector processing
//	.h  	contains only prototype and comment only
//	.cc 	contains template implementation, included at end of .h
//	.cpp 	contains other    implementation, add-to project
//

#ifndef DI5VP_CPP
#define DI5VP_CPP
#include<di5vp.h>
//	almost nothing here yet. may be added in the future.
//	so always add this to project.
calm_  calm;
//cals_ cals;

#endif //#ifndef DI5VP_CPP


