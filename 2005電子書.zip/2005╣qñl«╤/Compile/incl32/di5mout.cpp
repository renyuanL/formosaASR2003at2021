//
// di5mout.cpp
// 2003-04 (C)IZGang
//

#ifndef DI5MOUT_CPP
#define DI5MOUT_CPP

#include <di5mout.h>

chars mout;

#ifdef _CONSOLE

#include<iostream>
using namespace std;

int	mout_tie2	(void* memo1)
{
	return 1;
}



void	csoutshowmemohint(chars& cs, int warning)
{
}

chars& hint	(chars& cs)
{
	return cs;
}

chars& memo(chars&cs)
{
	cout<<cs.s; cs.clear();return cs;
}
chars& moutbox	(chars&cs)
{
	if(cs.hassome())MessageBox(NULL,cs.s,"mout",MB_OK);
	cs.clear();
	return cs;
}
chars& mmclear(chars&cs)
{
	cs.clear();
	return cs;
}

#else //#ifdef _CONSOLE
#include <vcl.h>

//these are for bcb's common vcl's: Edit/CheckedBox/RadioBox
//inline template<class T> char* getText	(T*t		){return t->Text.c_str();}
//inline template<class T> void	 setText	(T*t,cchar*s){t->Text=s;}
//inline template<class T> bool  emptyText	(T*t		){return t->Text.IsEmpty();}
//inline template<class T> bool  Checked	(T*t		){return t->Checked;}
//inline template<class T> void  Checked	(T*t, bool b){t->Checked=b;}


static TMemo* p2memo4csout=0;

int	mout_tie2	(void* memo1)
{	//* memo1 should be TMemo* of bcb
	TMemo* mm=(TMemo*)memo1;
	TMemo* t= dynamic_cast<TMemo*>(mm);
	if(t) p2memo4csout=t; else return 0;
	return 1;
}



void	csoutshowmemohint(chars& cs, int warning)
{
	if(warning)	cs="No TMemo tied to chars cs!\n\n";
	else		cs="This is how to tie a TMemo memo to chars cs.\n";
	cs+="Do 2 things:\n\n\n";
	cs+="1. Include and add di5mout (also add di5base)\n\n";
	cs+="2. At Form constructor, call\n";
	cs+="\tmout_tie2(Memo1); or cs_tie2(Memo1);  ";
	cs+="\n     Given Memo1 is defined.\n\n\n";
	cs+="Then in places such as cout<<100;\n one can (almost) use   cs<<100; etc.";
	cs+="\n\nThis Message will show 2 times.";
	cs.show();
	cs.clear();
}

chars& hint	(chars& cs)
{
	csoutshowmemohint(cs,0);
	return cs;
}

chars& memo(chars&cs)
{
	if(cs.hasnone())return cs;
	static int hinttimes=-1;
	if(p2memo4csout){
		(p2memo4csout)->Lines->Append(cs.s);
		(p2memo4csout)->Update();
	}else{
		if(hinttimes<=0){
			csoutshowmemohint(cs,1);
			++hinttimes;
		}
	}
	cs.clear();
	return cs;
}
chars& moutbox	(chars&cs)
{
	if(cs.hassome())MessageBox(NULL,cs.s,"mout",MB_OK);
	cs.clear();
	return cs;
}

chars& mmclear(chars&cs)
{
	if(p2memo4csout){
		(p2memo4csout)->Lines->Clear();
		(p2memo4csout)->Update();
	}
	cs.clear();
	return cs;
}
#endif //#ifdef _CONSOLE


#endif //#ifndef DI5MOUT_CPP


