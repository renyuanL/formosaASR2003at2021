// file di5cpdll.cpp

#include <di5cpdll.h>

void di5cpdll_::del()
{
	if(hinst)
		FreeLibrary(hinst);
	di5proc=NULL; hinst=NULL;
}

void di5cpdll_::init(char* pfn)
{
	res=0;
	//char *pfndef="C:\\c2k\\di\\di5cpdll\\Debug\\di5cpdll.dll";
	char *pfndef="c:\\daiim\\di6cpdll.dll";
	if(!(pfn&&pfn[0])) pfn=pfndef;
	hinst=LoadLibrary(pfn);
	if(hinst)di5proc = (DI5PROC) GetProcAddress(hinst, (const char*)1);
}

int di5cpdll_::getset(int m, void*w, void*l)
{
	if(!di5proc)return 0;
	int res=0;
	try{res=di5proc(m,w,l);}catch(...){}
	return res;
}

