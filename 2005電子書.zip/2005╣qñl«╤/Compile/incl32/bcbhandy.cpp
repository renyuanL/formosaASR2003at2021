//
// file bcbhandy.cpp
//

#ifndef BCBHANDY_CPP
#define BCBHANDY_CPP

#include <vcl.h>

bool isFormOpened(TForm* form)
{
	if(form==NULL) return false;
	bool formexist=false;
	for(int i=0; i<Screen->FormCount;++i){
		if(Screen->Forms[i]->ClassType()==form->ClassType())
			formexist=true;
		if(formexist)	break;
	}
	if(!formexist) return formexist;
	//SW_SHOW...
	if(form->WindowState==wsMinimized)
		ShowWindow(form->Handle,SW_SHOWNORMAL);
	else
		ShowWindow(form->Handle,SW_SHOWNA);
	//make it visible
	if(!form->Visible)form->Visible=true;
	//set focus
	form->BringToFront();
	form->SetFocus();
	return true;
}

#endif	//#ifndef BCBHANDY_CPP



