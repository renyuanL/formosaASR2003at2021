// file di5cpconst.h
// cross process const

enum di5dllmes
{
	DIDM_init=0,
	DIDM_cflagclear,	//clear the change flag
	DIDM_wlchanged,		//query if lw is changed (return 1 if changed, 0 o.w.)
	DIDM_wlset,				//set the wl param
	DIDM_wlget,				//get the wl param, clear change flag too
	DIDM_hndleditsetw,	//set the edit-handle as handle for the wparam
	DIDM_hndleditgetw,  //get the edit-handle in the wparam, clear no handle
	DIDM_hndleditclear,	//clear the edit-handle 
	DIDM_hndlprntsetw,	//set the parent-handle as handle for the wparam
	DIDM_hndlprntgetw,  //get the parent-handle in the wparam, clear no handle
	DIDM_hndlprntclear,	//clear the parent-handle (parent: one that use ime) 
	DIDM_strsetw,
	DIDM_strgetw,				// clear too
	DIDM_strwlen,				// return num of Bytes in the str
	DIDM_str10setw,			// set str10 buf, 1by1, append to c:\daiim\di5usr\str10.txt if exceed 10 str's.
	DIDM_str10getw,			// get str10 buf, each separated by \r\n
	DIDM_str10wlen,     // return num of bytes in the str10 buf,
	DIDM_DLL_PROCESS_DETACH,//used internally as dll detached 
	DIDM_ENDALL
};

