//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "spthread.h"
#include "speechio.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

// two parts : spmsgthreads and spthreads
//************************************************************
//************************************************************
// BEG of part 1: spmsgthreads ( of spmsgthreads and spthreads )
//************************************************************

class  TStatusTH : public TThread {  static String s; TEdit*edit;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
  TStatusTH(TEdit *edit1, char*s1): TThread(true)
				  { edit=edit1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
  update() { edit->Text=s; edit->Update();}
};String TStatusTH::s;

class  TRcgOutTH : public TThread { static  String s; TEdit*edit;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
  TRcgOutTH(TEdit *edit1, char*s1): TThread(true)
			  { edit=edit1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
  update() {edit->Text=s;edit->Update();}
}; String TRcgOutTH::s;

class  TDebugTH : public TThread { static  String s; TMemo*memo;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
  TDebugTH(TMemo *memo1, char*s1): TThread(true)
  { memo=memo1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
  update() {memo->Lines->Append(s);memo->Update();}
}; String TDebugTH::s;

void spmsgStatusBCB(TEdit*edit, char* msg)
{
	static chars s;  if(strcmp(s.s,msg)==0)return;s=msg;new TStatusTH(edit, s.s);
  //new TStatusTH(edit, msg);
}

void spmsgDebugBCB(TMemo*memo, char* msg)
{
	static chars s;if(strcmp(s.s,msg)==0)return;s=msg; new TDebugTH(memo, s.s);
  //new TDebugTH(memo, msg);
}

void spmsgRcgOutBCB(TEdit*edit, char* msg)
{
	static chars s;if(strcmp(s.s,msg)==0)return;s=msg; new TRcgOutTH(edit, s.s);
  //new TRcgOutTH(edit, msg);
}

//************************************************************
// END of part 1: spmsgthreads ( of spmsgthreads and spthreads )
//************************************************************
//************************************************************


// two parts : spmsgthreads and spthreads
//************************************************************
//************************************************************
// BEG of part 2: spthreads ( of spmsgthreads and spthreads )
//************************************************************
#ifdef OLDOLDOLDOLDOLD

#include <speechio.h>

class TAdaptBCB :public TThread { public: iwclientbase* client; VFNV fn_updown;
			TAdaptBCB (adaptation_* client1, VFNV fn_updown1=NULL) : TThread(true)
      { client=client1; fn_updown=fn_updown1; client->init4def(); FreeOnTerminate=true; Resume();}
private:
	void __fastcall Execute(){ client->kaisi(); }
  void __fastcall DoTerminate() { if(fn_updown) (*fn_updown)(); }
};

class TQiyimBCB :public TThread { public: iwclientbase* client;
			TQiyimBCB(siuqiim_* client1):TThread(true)
      { client=client1; client->init4def();  FreeOnTerminate=true;Resume();}
private:
	void __fastcall Execute(){ client->kaisi(); }
};
#endif //#ifdef OLDOLDOLDOLDOLD

//************************************************************
//************************************************************
// END of part 2: spthreads ( of spmsgthreads and spthreads )
//************************************************************


