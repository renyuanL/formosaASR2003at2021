//
//	di5vp.h
//	vector processing
//	.h  	contains only prototype and comment only
//	.cc 	contains template implementation, included at end of .h
//	.cpp 	contains other    implementation, add it to the project
//

#ifndef DI5VP_H
#define DI5VP_H
#include <vector>
#include <valarray>
#include <map>
#include <math.h>
#include <di5rand.h>
using namespace std;

//#ifndef TPC(X)
#ifndef TPC
// first a macro for a shorter name,
// remember spaces after TPC(X)
#define TPC(X)			template<class X>
#define TPC1(X)			template<class X>
#define TPC2(X,Y)		template<class X, class Y>
#define TPC3(X,Y,Z)		template<class X, class Y, class Z>
#define TPCI(X)			template<class X> inline
#define TPCI1(X)		template<class X> inline
#define TPCI2(X,Y)		template<class X, class Y> inline
#define TPCI3(X,Y,Z)	template<class X, class Y, class Z> inline
//vitr means iterator of vector/valarray/array, or random acess iterator
#endif //#ifndef TPC(X)

TPCI(R) R* pbeg(vector  <R>&v){return &v[0];}
TPCI(R) R* pbeg(valarray<R>&v){return &v[0];}
TPCI(R) R* pend(vector  <R>&v){return &v[0]+v.size();}
TPCI(R) R* pend(valarray<R>&v){return &v[0]+v.size();}
////////////////////////////////////////////////////////
template<class T>
class 	vecvec : public vector< vector<T> > { public:
		vecvec  (){}
		vecvec  (int ntimes1, int ncmpts1):vector< vector<T> >(ntimes1, vector<T>(ncmpts1)){}
public:
	size_t nfrm      (              ){return size();}
	size_t ncmp      (              ){return (size()>0)?(*this)[0].size():0;}
	T&  v         (int tt, int cc){return (*this)[tt][cc];}
	T&  operator()(int tt, int cc){return (*this)[tt][cc];}//or use [tt][cc] to access an entry
public:
	void resize(int ntimes1, int ncmpts1);
};

TPC(R) int	getminmax (R& vmin, R& vmax, vecvec<R>&m );
TPC(R) int	getminmax (R& vmin, R& vmax, vecvec<R>&m, int nthfrm);

////////////////////////////////////////////////////////
TPC(real)	real	kthlargest(vector<real>&v, size_t K);//destructive to v

template<class real>
real quantile(vector<real>&v, float p);
template<class real>
int quantile(vector<real>&v, real&vp1, real&vp2, float p1, float p2);
template<class real>
real quantile(vecvec<real>&vv, float p1);
template<class real>
int quantile(vecvec<real>&vv, real& vvp1, real& vvp2, float p1, float p2);

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
//* ucCounter 4 histogram: uniform divide, continuous data, counts in each bands
class ucCounter{public:
	valarray<int  > cnts;
	valarray<float> bdry;
	int scale;// for plotting
public:
TPC(VEC)  int set (VEC &vi, int nbands=-1){return set (cnts,bdry,pbeg(vi),pend(vi),nbands);}
TPC(vitr) int set (	valarray<int>& cnts, valarray<float>&bndy, vitr beg, vitr end, int nbands);
					//implemented below
};
//* frqCounter 4 histogram: discrete data, counts for each class of T
template<class T>
class frqCounter{public:
	map<T,int> 	frq;
	int scale;// for plotting
public:
TPC(VEC)	int set (VEC &vi){return set(frq,pbeg(vi),pend(vi));}
			int set (map<T,int>& frq, T* beg, T* end);//below
//TPC(vitr) int set (map<T,int>& frq, vitr beg, vitr end);//below
};

////////////////////////////////////////////////////////
TPC(vitr) 	int zerocross(vitr beg, vitr end);
TPC(real)	int zerocross(vector  <real> & v);
TPC(real)	int zerocross(valarray<real> & v);

TPC(vitr)	double avgvar(double& mean, double& var, vitr beg, vitr end);
TPC(real)	double avgvar(double& mean, double& var, vector  <real>& v);
TPC(real)	double avgvar(double& mean, double& var, valarray<real>& v);

TPC(vitr) 	double avg(vitr beg, vitr end);
TPC(real) 	double avg(vector  <real> & v);
TPC(real) 	double avg(valarray<real> & v);

TPC(vitr) 	double var(vitr beg, vitr end);
TPC(real) 	double var(vector  <real> & v);
TPC(real) 	double var(valarray<real> & v);

TPC(vitr) 	double sum(vitr beg, vitr end);
TPC(real) 	double sum(vector  <real> & v);
TPC(real) 	double sum(valarray<real> & v);

TPC(vitr) 	double L1 (vitr beg, vitr end);
TPC(real) 	double L1 (vector  <real> & v);
TPC(real) 	double L1 (valarray<real> & v);

TPC(vitr) 	double L22(vitr beg, vitr end);//* L2-norm square
TPC(real) 	double L22(vector  <real> & v);//* L2-norm square
TPC(real) 	double L22(valarray<real> & v);//* L2-norm square

TPC2(R,vitr)	bool getminmax (R& m, R& M, vitr beg, vitr end);
TPC(R)			bool getminmax (R& m, R& M, vector  <R>&v);
TPC(R)			bool getminmax (R& m, R& M, valarray<R>&v);

TPC3(R1,R2,R3)	int setseq(vector  <R1>&v, R2 beg, R3 end);
TPC3(R1,R2,R3)	int setseq(valarray<R1>&v, R2 beg, R3 end);
TPC(R)			int setseq(vector  <R >&v, R beg, R end, R delta);
TPC(R)			int setseq(valarray<R >&v, R beg, R end, R delta);

TPC(vitr)	int to2rank		(vector<int> & r, vitr beg, vitr end);
TPC(real)	int to2rank		(vector<int> & r, vector  <real> & v);
TPC(real)	int to2rank		(vector<int> & r, valarray<real> & v);

TPC(vitr)	int to2locmpos	(vector<int> & r, vitr beg, vitr end);
TPC(real)	int to2locmpos	(vector<int> & r, vector  <real> & v);
TPC(real)	int to2locmpos	(vector<int> & r, valarray<real> & v);

TPC(vitr)	int to2lmaxpos	(vector<int> & r, vitr beg, vitr end);
TPC(real)	int to2lmaxpos	(vector<int> & r, vector  <real> & v);
TPC(real)	int to2lmaxpos	(vector<int> & r, valarray<real> & v);

TPC(vitr) int count_pos(vitr beg, vitr end);
TPC(real) int count_pos(vector  <real> & v);
TPC(real) int count_pos(valarray<real> & v);

TPC(vitr) int count_neg(vitr beg, vitr end);
TPC(real) int count_neg(vector  <real> & v);
TPC(real) int count_neg(valarray<real> & v);
////////////////////////////////////////////////////////
class	calm_ { public: //char ver[21];
//namespace 	calm { //public: //char ver[21];
///*
TPC(P) double L1 	(P beg, P end);
TPC(P) double L22	(P beg, P end);
TPC(P) double sum	(P beg, P end);
TPC(P) size_t npos	(P beg, P end);	// num of positive
TPC(P) size_t nneg	(P beg, P end);	// num of negative
TPC(R) R	  max_	(R*beg, R*end);
TPC(R) R	  min_	(R*beg, R*end);
TPC(R) size_t maxndx(R*beg, R*end);
TPC(R) size_t minndx(R*beg, R*end);
TPC(P) size_t maxndx(P beg, P end);
TPC(P) size_t minndx(P beg, P end);
TPC(R) bool   maxndx(R*beg, R*end, R&val, size_t& ndx);
TPC(R) bool   minndx(R*beg, R*end, R&val, size_t& ndx);
public:
TPC2(P1,P2) double dot	(P1 beg1, P2 beg2, size_t N);
//*/
public:
TPC(R) double L1 	(vector  <R>&v){return L1		(pbeg(v),pend(v));}
TPC(R) double L22	(vector  <R>&v){return L22		(pbeg(v),pend(v));}
TPC(R) double sum	(vector  <R>&v){return sum		(pbeg(v),pend(v));}
TPC(R) size_t npos	(vector  <R>&v){return npos		(pbeg(v),pend(v));}
TPC(R) size_t nneg	(vector  <R>&v){return nneg		(pbeg(v),pend(v));}
TPC(R) R	  max_	(vector  <R>&v){return max_		(pbeg(v),pend(v));}
TPC(R) R	  min_	(vector  <R>&v){return min_		(pbeg(v),pend(v));}
TPC(R) size_t maxndx(vector  <R>&v){return maxndx	(pbeg(v),pend(v));}
TPC(R) size_t minndx(vector  <R>&v){return minndx	(pbeg(v),pend(v));}
TPC(R) bool   maxndx(vector  <R>&v, R&val, size_t& ndx);
TPC(R) bool   minndx(vector  <R>&v, R&val, size_t& ndx);
public:
TPC(R) double L1 	(valarray<R>&v){return L1		(pbeg(v),pend(v));}
TPC(R) double L22	(valarray<R>&v){return L22		(pbeg(v),pend(v));}
TPC(R) double sum	(valarray<R>&v){return sum		(pbeg(v),pend(v));}
TPC(R) size_t npos	(valarray<R>&v){return npos		(pbeg(v),pend(v));}
TPC(R) size_t nneg	(valarray<R>&v){return nneg		(pbeg(v),pend(v));}
TPC(R) R	  max_	(valarray<R>&v){return max_		(pbeg(v),pend(v));}
TPC(R) R	  min_	(valarray<R>&v){return min_		(pbeg(v),pend(v));}
TPC(R) size_t maxndx(valarray<R>&v){return maxndx	(pbeg(v),pend(v));}
TPC(R) size_t minndx(valarray<R>&v){return minndx	(pbeg(v),pend(v));}
public:
TPC(R) bool   maxndx(valarray<R>&v, R&val, size_t& ndx);
TPC(R) bool   minndx(valarray<R>&v, R&val, size_t& ndx);
};
extern calm_ calm;
////////////////////////////////////////////////////////
/*
class	cals_ { public: char var[21];
TPC(P) double avg	(P beg, P end);
TPC(P) double var	(P beg, P end);
public:
TPC(P) bool	acf		(P beg, P end);
TPC(P) bool pacf	();
public:
TPC2(P1,P2) double cor(P1 beg1, P1 beg1, P2 beg2, P2 beg2);
};
*/


////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
//* The following 4 is EQ2 +=
TPC2(R1, R2) bool operator<<(vector  <R1>& lhs, vector  <R2> &rhs);
TPC2(R1, R2) bool operator<<(valarray<R1>& lhs, valarray<R2> &rhs);
TPC2(R1, R2) bool operator<<(vector  <R1>& lhs, valarray<R2> &rhs);
TPC2(R1, R2) bool operator<<(valarray<R1>& lhs, vector  <R2> &rhs);
////////////////////////////////////////////////////////
//* The following 4 is {lhs copy to rhs}
TPC2(R1, R2) bool operator>>(vector  <R1>& lhs, vector  <R2> &rhs);
TPC2(R1, R2) bool operator>>(valarray<R1>& lhs, valarray<R2> &rhs);
TPC2(R1, R2) bool operator>>(vector  <R1>& lhs, valarray<R2> &rhs);
TPC2(R1, R2) bool operator>>(valarray<R1>& lhs, vector  <R2> &rhs);
////////////////////////////////////////////////////////
// why the need and difference between << and >>?
// need:	both = and += are very convenient,
//						  should be in full strength (type/size)
//			and  = cannot be defined as ordinary function
// diff:	1. << should be like +=, like in the case of cout
//					(outputting by appending, not clearing previous content)
//			2. >> no need to duplicate functionality of <<.
//					(inputting by copy-to,    DO clear previous content)
// cout<<v; cin>>v; performs differently in terms of the previous content
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////

class 	sinugen_{public://* sinusoid signal generator, know how to modi vec/vala
		sinugen_(			):sprate(16000)  ,twopi(3.1415926535*2){}
		sinugen_(int smprate):sprate(smprate),twopi(3.1415926535*2){}
public:
	TPC(R) bool cr2v(vector  <R>& v, int ms){v.clear();v.resize(ms2np(ms));}
	TPC(R) bool cr2v(valarray<R>& v, int ms){v.resize(ms2np(ms)); v=0;}
public:
	TPC(R) bool add (vector<R>  &v, double amp, double frq, double phs);//*add sinusoid(cosine w/ phase)
	TPC(R) bool addc(vector<R>  &v, double amp, double frq);//*add cosine
	TPC(R) bool adds(vector<R>  &v, double amp, double frq);//*add sine
	TPC(R) bool addn(vector<R>  &v, double amp);//*add gaussian white noise
	TPC(R) bool addh(vector<R>  &v, double amp, double frq, int nhar);//*add harmonic
public:
	TPC(R) bool add (valarray<R>&v, double amp, double frq, double phs);//*add sinusoid(cosine w/ phase)
	TPC(R) bool addc(valarray<R>&v, double amp, double frq);//*add cosine
	TPC(R) bool adds(valarray<R>&v, double amp, double frq);//*add sine
	TPC(R) bool addn(valarray<R>&v, double amp);//*add gaussian white noise
	TPC(R) bool addh(valarray<R>&v, double amp, double frq, int nhar);//*add harmonic
public:
	int		ms2np(int ms){return int(sprate/1000.0*ms+0.001);}//* msec to num_of_points
	int 	sprate;
	double	twopi;
protected:
	// The workers, without mem-alloc
	TPC(vitr) bool add (vitr beg, vitr end, double amp, double frq, double phs);//*add sinusoid(cosine w/ phase)
	TPC(vitr) bool addc(vitr beg, vitr end, double amp, double frq);//*add cosine
	TPC(vitr) bool adds(vitr beg, vitr end, double amp, double frq);//*add sine
	TPC(vitr) bool addn(vitr beg, vitr end,	double amp);//*add gaussian white noise
	TPC(vitr) bool addh(vitr beg, vitr end, double amp, double frq, int nhar);//*add harmonic
	TPC(vitr) bool smth(vitr beg, vitr end, double msec);//*smooth wav at end
};

class 	sinusig_ : public sinugen_{public://* sinusoid signal, know how to modi vec/vala
		sinusig_(int smprate):sinugen_(smprate){}
public:
	TPC(R) bool	add(vector  <R>& v);
	TPC(R) bool	add(valarray<R>& v);
public:
	double 	amp, frq, phs; int nhar;
	char 	kind;
public:
	void	def2 (){set2(100,100,0,1,' ');}
	void	set2 (double amp1, double frq1, double phs1, int nhar1, char kind1)
					{amp=amp1;	  frq=frq1;    phs=phs1;nhar=nhar1; kind=kind1;}
};

////////////////////////////////////////////////////////
struct clearNresize_ { size_t sz; };
inline clearNresize_ clrrsz(size_t sz){clearNresize_ cr; cr.sz=sz; return cr;}

//*example: v<<cr(1024);//1024 points
TPC(R) vector  <R>  & operator<<(vector  <R>&v,clearNresize_ cr){v.clear();  v.resize(cr.sz);return v;}
TPC(R) valarray<R>  & operator<<(valarray<R>&v,clearNresize_ cr){v.resize(r);v=0; return v;}

////////////////////////////////////////////////////////

struct ms2np_ { int ms; int smprate; };
inline ms2np_ ms2np(int ms, int smprate=16000)//* return ms2np_ so << knows what to do
{	ms2np_ s; s.ms=ms;s.smprate=smprate;return s; }

//*example: v<<ms2np(40); //* 40 msec
TPC(R) vector  <R>  & operator<<(vector  <R>&v,ms2np_ s){int r=int(s.smprate/1000.0*s.ms+0.001);v.clear();v.resize(r);return v;}
TPC(R) valarray<R>  & operator<<(valarray<R>&v,ms2np_ s){int r=int(s.smprate/1000.0*s.ms+0.001);v.resize(r);v=0; return v;}

////////////////////////////////////////////////////////

//examples: vector<short> v; // or valarray<short> v;
// v<<ms2np(40)<<sinusoid(10000,440,3)<<sigsin(5000,200)<<sigcos(3000,300)
//	<<siggwn()<<smooth();
inline sinusig_ sinusoid(double amp, double frq, double phs,int smprate=16000){sinusig_ ss(smprate);ss.set2(amp,frq,phs, 1,' ');return ss;}
inline sinusig_ sigsin  (double amp, double frq, 			int smprate=16000){sinusig_ ss(smprate);ss.set2(amp,frq,0,   1,'c');return ss;}
inline sinusig_ sigcos  (double amp, double frq, 			int smprate=16000){sinusig_ ss(smprate);ss.set2(amp,frq,0,   1,'s');return ss;}
inline sinusig_ sighar  (double amp, double frq, int  nhar, int smprate=16000){sinusig_ ss(smprate);ss.set2(amp,frq,0,nhar,'h');return ss;}
inline sinusig_ siggwn  (double dev=100, int smprate=16000){sinusig_ ss(smprate);ss.set2( dev,0,0,0,'n');return ss;}
inline sinusig_ smooth  (double msec=5,  int smprate=16000){sinusig_ ss(smprate);ss.set2(msec,0,0,0,'~');return ss;}

TPC(R) vector<R>  & operator<<(vector  <R>&v,sinusig_ ss){ss.add(v);return v;}
TPC(R) valarray<R>& operator<<(valarray<R>&v,sinusig_ ss){ss.add(v);return v;}

////////////////////////////////////////////////////////
TPC(R) int log (vecvec<R>& m);
TPC(R) int exp (vecvec<R>& m);
TPC(R) int sin (vecvec<R>& m);
TPC(R) int cos (vecvec<R>& m);
TPC(R) int tan (vecvec<R>& m);
TPC(R) int asin(vecvec<R>& m);
TPC(R) int acos(vecvec<R>& m);
TPC(R) int atan(vecvec<R>& m);
TPC(R) int pow (vecvec<R>& m);
TPC(R) int sqr (vecvec<R>& m);
TPC(R) int sqrt(vecvec<R>& m);
TPC(R) int abs (vecvec<R>& m);

TPC2(R1, R2) vecvec<R1>& set2	   (vecvec<R1>& m, R2 c);
TPC2(R1, R2) vecvec<R1>& operator+=(vecvec<R1>& m, R2 c);
TPC2(R1, R2) vecvec<R1>& operator-=(vecvec<R1>& m, R2 c);
TPC2(R1, R2) vecvec<R1>& operator*=(vecvec<R1>& m, R2 c);
TPC2(R1, R2) vecvec<R1>& operator/=(vecvec<R1>& m, R2 c);


////////////////////////////////////////////////////////
TPC(R) int log	(vector<R>& v);
TPC(R) int exp	(vector<R>& v);
TPC(R) int sin	(vector<R>& v);
TPC(R) int cos	(vector<R>& v);
TPC(R) int tan	(vector<R>& v);
TPC(R) int asin	(vector<R>& v);
TPC(R) int acos	(vector<R>& v);
TPC(R) int atan	(vector<R>& v);
TPC(R) int pow	(vector<R>& v);
TPC(R) int sqr	(vector<R>& v);
TPC(R) int sqrt	(vector<R>& v);
TPC(R) int abs	(vector<R>& v);
TPC(R) int inv	(vector<R>& v);
TPC(R) int recip(vector<R>& v){return inv(v);}

TPC2(R1, R2) vector<R1>& set2	   (vector<R1>& v, R2 c);
TPC2(R1, R2) vector<R1>& operator+=(vector<R1>& v, R2 c);
TPC2(R1, R2) vector<R1>& operator-=(vector<R1>& v, R2 c);
TPC2(R1, R2) vector<R1>& operator*=(vector<R1>& v, R2 c);
TPC2(R1, R2) vector<R1>& operator/=(vector<R1>& v, R2 c);

TPC2(R1, R2) vector<R1>& eeae(vector<R1>& v, vector<R2>& c);
TPC2(R1, R2) vector<R1>& eese(vector<R1>& v, vector<R2>& c);
TPC2(R1, R2) vector<R1>& eede(vector<R1>& v, vector<R2>& c);
TPC2(R1, R2) vector<R1>& eeme(vector<R1>& v, vector<R2>& c);//elem by elem *=
TPC2(R1, R2) double dot(vector<R1>& v, vector<R2>& c);


#include<di5vp.cc>
/*
#undef TPC(X)
#undef TPC1(X)
#undef TPC2(X)
#undef TPC3(X)
#undef TPCI(X)
#undef TPCI1(X)
#undef TPCI2(X)
#undef TPCI3(X)
*/
#endif //#ifndef DI5VP_H

