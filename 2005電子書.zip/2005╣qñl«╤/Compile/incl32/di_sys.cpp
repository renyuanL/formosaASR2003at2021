//
// file di_sys.cpp
//

#ifndef DI_SYS_CPP
#define DI_SYS_CPP

#include <di_sys.h>

#include <windows.h>
#include "tyio8.h"
//#include "tyic8a.h"
#include "di5paint.h"



unsigned int getSystemDirectory( char* buf, int buflen)
{ return GetSystemDirectory(buf,buflen); }

char getSystemDrive()
{ char buf[101]; GetSystemDirectory(buf,100); return buf[0]; }

const char* daiim_pathname()
{
	static char  t[]="c:\\daiim\\";
	t[0]=getSystemDrive();
	char checker[]="c:\\daiim\\ime2cntl.exe"; // only a must-exist file to check
	checker[0]=t[0];
	tyio io; int res=io.open(checker); io.close();
	if(res) return t;
	t[0]='c';
	return t;
}

int ty7ic_shiftisdown() // need to implemented in ty7wp.cpp
{ return (GetAsyncKeyState(VK_SHIFT)<0); }

diini_ diini;

int diini_::
read()
{
	init0();
	chars s; 
	s.set2((char*)daiim_pathname()); 	
	s.app("daiim.ini");
	lreader rd;			
	if(!rd.openERRMES(s.s)) return 0;
	//plusline pl;
	charspp pl;
	rd.getgline(s);
	if(pl.set2Nhunplus(s.s)!=3) return 0;

	imex0=s2i(pl[0]); imey0=s2i(pl[1]);

	int res;
	res=((pl[2])[0]=='1')?1:0; yesetc.setsoridiau	(res);
	res=((pl[2])[1]=='2')?2:0; yesetc.sethensi		(res);
	res=((pl[2])[2]=='3')?3:0; yesetc.setuannsu		(res);
	return 1;
}

int diini_::
write()
{
	chars s; 
	s.set2((char*)daiim_pathname()); 	
	s.app("daiim.ini");
	writer w; w.creat(s.s);
	if(w.isERR()) return 0;
	w.outln("//���D�A���v�Am�q�ק糧�ɮסA���O�R���ɮ׵L�n��");
							w.out(typaint.imex0);
	w.out("+");	w.out(typaint.imey0); 
	w.out("+");	w.out(yesetc.getsoridiau()); 
							w.out(yesetc.gethensi		()); 
							w.out(yesetc.getuannsu	()); 
	w.outln();
	w.close();

	return 1;
}

int diini_::
init0()
{
	imex0=32726; imey0=32726;
	yesetc.setsoridiau(0);
	yesetc.sethensi		(2);
	yesetc.setuannsu	(3);
	return 1;
}


#include "string.h"

yesetc_  yesetc;

int yesetc_::
process(char* str) // set various setting if yes, 0 ow.
{
	char c; int change=0; int k;
	char* t=str; while(*t) { if('='==*t++) { change=1; break; } }
	if(change==0) return 0; change=0;
	k=9; if(strncmp(str, "soridiau=", k)==0) { c=str[k];
		switch (c) {
		case 'n': case '0': change=1; soridiau=0; break;
		case 'y': case '1': change=1; soridiau=1; break;
		}
		return change;
	}

	k=6; if(strncmp(str, "hensi=", k)==0) { c=str[k];
		switch (c) {
		case 'n': case '0': change=2; hensi=0; break;
		case 'y': case '1': change=2; hensi=2; break;
		}
		return change;
	}

	k=7; if(strncmp(str, "uannsu=", k)==0) { c=str[k];
		switch (c) {
		case 'n': case '0': change=3; uannsu=0; break;
		case 'y': case '1': change=3; uannsu=3; break;
		}
		return change;
	}

	return 0;
}




#endif //#ifndef DI_SYS_CPP
