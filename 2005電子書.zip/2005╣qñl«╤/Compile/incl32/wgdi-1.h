//
// file wgdi.h
//
#ifndef WGDI_H
#define WGDI_H

struct	pen_ { HPEN p, op; HDC hdc;
				pen_	(						): p(0) {}
	void destroy(						) { if(p) DeleteObject(p); }
	void select	(HDC hdc1		)	{ hdc=hdc1; op=(HPEN) SelectObject(hdc, p); }
	void restore(HDC hdc1=0	)	{ SelectObject((hdc1)?hdc1:hdc, op); }
	void create( int PenStyle=PS_SOLID, int nWidth=1, COLORREF crColor=RGB(255,0,0))
							{ p=CreatePen(PenStyle, nWidth, crColor); }
	HPEN operator()()					{ return p; }
};

struct	font_ { HFONT f, of; HDC hdc; TEXTMETRIC tm;
				font_ (						): f(0), of(0) {}
	void destroy(						) { if(f) DeleteObject(f); f=0; }
	void select	(HDC hdc1		){ hdc=hdc1; of=(HFONT) SelectObject(hdc, f); }
	void restore(HDC hdc1=0	){ SelectObject((hdc1)?hdc1:hdc, of); }
  void create	(int height, char* fontname="�з���"){	f =
			 CreateFont( height,0,0,0,FW_NORMAL,
									 FALSE,FALSE,FALSE,DEFAULT_CHARSET,
									 OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
									 DEFAULT_QUALITY,FF_DONTCARE,	fontname);
			 HDC dc=GetDC(NULL); select(dc); GetTextMetrics(dc,&tm); restore();
			 ReleaseDC(NULL, dc);
	}
	HFONT operator()()					{ return f; }
	int		height()	{ return tm.tmHeight; }
};


#endif //#ifndef WGDI_H
