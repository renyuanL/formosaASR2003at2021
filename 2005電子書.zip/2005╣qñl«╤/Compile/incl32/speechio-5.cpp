//
// file speech.cpp
// copyright 2000 Gang, IrngZin
//
// speechio-5.cpp 2003-04

#ifndef SPEECHIO_CPP
#define SPEECHIO_CPP

#include <windows.h>
#include <speechio.h>

spmsg_ spmsg1;
spmsg_ spmsg;
spmsg_ spmsg2;
//spmsgcase spmsgNULL(0);
void spmsgcase::setasdef(int asdef)
{
	spmsg.set2(this, asdef);
}
//spmsgcase::spmsgcase(int asdef){ spmsg.set2(this, asdef);   }


#ifndef RCFFT_CPP
#define RCFFT_CPP

const double    pi=3.141592653589793;
const double twopi=6.28318530717959;
uint  next2pow(uint t)
{
	float tt=t-0.05;int rr=1;
	while(rr<tt)rr*=2;return rr;
}
int twopowerbound(int N)
{
  if(N<=0) return 0;
  N--;
  int cnt=0; while(N  ){ N=N>>1;  cnt++;  }
  N=1;       while(cnt){ cnt--;  N=N<<1;  }
  return N;
}


//#include <rcfft.h>
//#include <string.h>

rcfft_  rcfft;
//emhamfft_<256,256> ehfft;

//static fftjunk;

void rcfft_:: cfftf(float *data, int nn, int isign)
{ //data: nn complex points, 1-based, faster version
	int n, mmax, m, j, istep, i;
	double wtemp, wr, wpr, wpi, wi, theta;
	double tempr, tempi;
	int sndx;

	n=nn<<1;

	if( (lastCN!=nn)||(lastisign!=isign) ) {
		mmax=2; sndx=0;
		while(n>mmax) {
			theta=6.28318530717959/(isign*mmax);
			sinhalftheta[sndx]=sin(0.5*theta);
			sintheta    [sndx]=sin(theta);
			sndx++; mmax*=2;
		}
		if(lastCN!=nn) { memset(bitrev, 0, sizeof(bitrev));
			j=1;
			for(i=1;i<n;i+=2) {
				if(j>i) bitrev[i]=(short)j;
				m=n>>1;
				while(m>=2 && j>m) { j -= m; m >>= 1; }
				j+=m;
			}
		}
		lastCN=nn;lastisign=isign;
	}

	for(i=1; i<n; i+=2) { float ttt; // doing rearrangement
		if( (j=bitrev[i]) >0 ) {
			ttt=data[j  ]; data[j  ]=data[i  ]; data[i  ]=ttt;
			ttt=data[j+1]; data[j+1]=data[i+1]; data[i+1]=ttt;
		}
	}
	mmax=2; sndx=0;
	while(n>mmax) {
		istep=2*mmax;
		//theta=6.28318530717959/(isign*mmax);
		wtemp=sinhalftheta[sndx];//sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sintheta[sndx];//sin(theta);
		sndx++;
		wr=1.0;
		wi=0.0;
		for(m=1; m<mmax; m+=2) {
			for(i=m; i<=n; i+=istep) {
				j=i+mmax;
				tempr=wr*data[j  ]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j  ] =float(data[i  ]-tempr);
				data[j+1] =float(data[i+1]-tempi);
				data[i  ]+=float(tempr);
				data[i+1]+=float(tempi);
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}

void rcfft_:: cfftg(float *data, int nn, int isign)
{ //data: nn complex points, 1-based, arbitrary size
	int n, mmax, m, j, istep, i;
	double wtemp, wr, wpr, wpi, wi, theta;
	double tempr, tempi;
	n=nn<<1;
	j=1;
	for(i=1;i<n;i+=2) {
		if(j>i) {	float ttt;
			ttt=data[j  ]; data[j  ]=data[i  ]; data[i  ]=ttt;
			ttt=data[j+1]; data[j+1]=data[i+1]; data[i+1]=ttt;
		}
		m=n>>1;
		while(m>=2 && j>m) {
			j  -= m;
			m >>= 1;
		}
		j+=m;
	}
	mmax=2;
	while(n>mmax) {
		istep=2*mmax;
		theta=6.28318530717959/(isign*mmax);
		wtemp=sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sin(theta);
		wr=1.0;
		wi=0.0;
		for(m=1; m<mmax; m+=2) {
			for(i=m; i<=n; i+=istep) {
				j=i+mmax;
				tempr=wr*data[j  ]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j  ] =float(data[i  ]-tempr);
				data[j+1] =float(data[i+1]-tempi);
				data[i  ]+=float(tempr);
				data[i+1]+=float(tempi);
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}

void rcfft_:: rfft1(float *data, int N, int isign)
{// data has N real points, 1-based
	int i, i1, i2, i3, i4, np3;
	double c1=0.5, c2, h1r, h1i, h2r, h2i;
	double wr, wi, wpr, wpi, wtemp, theta;
	//theta=3.141592653589793/(double)(N>>1);
	theta = 6.28318530717959 /(double)(N);
	if(isign==1) { c2=-0.5; cfft1(data, N>>1, 1);}
	else         { c2= 0.5; theta=-theta;     }
	wtemp=sin(0.5*theta);
	wpr = -2.0*wtemp*wtemp;
	wpi=sin(theta);
	wr=1.0+wpr;
	wi=wpi;
	np3=N+3; int Nd4=N/4;
	//for(i=2;i<=N/2;i++){
	for(i=2;i<=Nd4;i++){
		i4=1+(i3=np3-(i2=1+(i1=i+i-1)));
		h1r= c1*(data[i1]+data[i3]);
		h1i= c1*(data[i2]-data[i4]);
		h2r=-c2*(data[i2]+data[i4]);
		h2i= c2*(data[i1]-data[i3]);
		data[i1]=float( h1r+wr*h2r-wi*h2i);
		data[i2]=float( h1i+wr*h2i+wi*h2r);
		data[i3]=float( h1r-wr*h2r+wi*h2i);
		data[i4]=float(-h1i+wr*h2i+wi*h2r);
		wr=(wtemp=wr)*wpr-wi*wpi+wr;
		wi=wi*wpr+wtemp*wpi+wi;
	}
	if(isign==1) {
		data[1]=(h1r=data[1])+data[2];
		data[2]=float(h1r-data[2]);
	}else{
		data[1]=c1*((h1r=data[1])+data[2]);
		data[2]=float(c1*(h1r-data[2]));
		cfft1(data, N>>1, -1);
	}
	//data[2]=0;  // for htk's ???, this will be same as matlab
							// data[0,1] should cor2 X[0], which has 0 img part
}

void rcfft_::
rspt0(float*x,  int N)//replace x (len 2^K) w/its spectrum, only N/2 is useful, 0-based
{
  rfft0(x, N);
  int nn,NN=N/2;
  double dtmp; //uint nn, NN=spec1.size()/2;
  for(nn=1; nn<NN; nn++){
	dtmp=(x[nn*2]*x[nn*2]+x[nn*2+1]*x[nn*2+1]);
	x[nn]=sqrt(dtmp);
  }
}




int ehfs_::alloc4work(int FRMSZ1)
{
	if(FRMSZ1<allcFRMSZ) return 1;
	if(ham) delete[] ham; ham=new float[FRMSZ1]; if(!ham) return 0;
	if(ham){allcFRMSZ=FRMSZ1;}
	int allcRN4FFT1=next2pow(allcFRMSZ);	if(allcRN4FFT1<allcRN4FFT) return 1;
	if(xdef) delete[] xdef; xdef=new float[allcRN4FFT1];if(!xdef) return 0;
	if(xdef){allcRN4FFT=allcRN4FFT1;}
	if(dnsh) delete[] dnsh; dnsh=new short[allcFRMSZ]; if(!dnsh)return 0;
	return 1;
}

int ehfs_::set4FRMSZ(int FRMSZ1)
{// assume mem is OK
	if(!alloc4work(FRMSZ1)) return 0;
	lastFRMSZ=FRMSZ1;
	lastRN4FFT=next2pow(FRMSZ1);// this should be
	initham();
	return 1;
}
short* ehfs_::downsample(short* osh,int nosh, int dnsmp)//ret: down-sampled array
{
	if(dnsmp<1) return 0;
	int frmsz=nosh/dnsmp;
	if(nosh!=frmsz*dnsmp)return 0;
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return dnsh; }
	//if(lastFRMSZ!=frmsz) {
		//if(!alloc4work(frmsz)) return dnsh;
		//lastFRMSZ=frmsz;
		//lastRN4FFT=next2pow(lastFRMSZ);// this should be
		//initham();
	//}
	int n,N;
	for(n=0,N=0; n<nosh; n+=dnsmp,N++) dnsh[N]=osh[n];
	return dnsh;
}

float* ehfs_::
ehfps(short* shobs, int frmsz, float* res1, int preem)
{
	if(!shobs) return (res1)?res1:xdef;
	float* r; r=ehf(shobs, frmsz, res1);
	int i; float *f1=r, *f2r=r, *f2c=r+1;
	*f1 =(*f2r)*(*f2r); f1++; f2r+=2; f2c+=2;
	for(i=1; i<lastRN4FFT/2; i++, f1++, f2r+=2, f2c+=2){
		(*f1)=( (*f2r)*(*f2r)+(*f2c)*(*f2c) );
  }
	return r;
}

float* ehfs_::
ehfs(short* shobs, int frmsz, float* res1, int preem)
{
	if(!shobs) return (res1)?res1:xdef;
	float* r; r=ehfps(shobs, frmsz, res1);
	int i; float *f1=r;
	for(i=0; i<lastRN4FFT/2; i++){
		(*f1)=sqrt(*f1);
	}
	return r;
}

float* ehfs_::
ehfs1(short* shobs, int frmsz, float* res1, int preem)
{
	if(!shobs) return (res1)?res1:xdef;
	float* r; r=ehf(shobs, frmsz, res1);
	int i; float *f1=r, *f2r=r, *f2c=r+1;
	*f1 =fabs(*f2r); f1++; f2r+=2; f2c+=2;
	for(i=0; i<lastRN4FFT/2; i++, f1++, f2r+=2, f2c+=2)
		(*f1)=fabs(*f2r)+fabs(*f2c);
		//(*f1)=(*f2r)*(*f2r)+(*f2c)*(*f2c);
	return r;
}


float* ehfs_::
fs(short* shobs, int frmsz, float* res1)
{
	if(!shobs) return (res1)?res1:xdef;
	float* r; r=fps(shobs, frmsz, res1);
	int i; float *f1=r;
	for(i=0; i<lastRN4FFT/2; i++){
		(*f1)=sqrt(*f1);
	}
	return r;
}


float* ehfs_::
fps(short* shobs, int frmsz, float* res1)
{
	if(!shobs) return (res1)?res1:xdef;
	float* x;
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return res1; }
	if(res1) x=res1; else x=xdef;
	fft.sh2ft(x,shobs,frmsz);
	if((lastRN4FFT-lastFRMSZ)>0)
		memset(x+lastFRMSZ, 0, (lastRN4FFT-lastFRMSZ)*sizeof(float));//zero-padding
	fft.rfft0(x,lastRN4FFT);
	//float* r; r=ehf(shobs, frmsz, res1);
	int i; float *f1=x, *f2r=x, *f2c=x+1;
	*f1 =(*f2r)*(*f2r); f1++; f2r+=2; f2c+=2;
	for(i=0; i<lastRN4FFT/2; i++, f1++, f2r+=2, f2c+=2)
		//(*f1)=fabs(*f2r)+fabs(*f2c);
		(*f1)=(*f2r)*(*f2r)+(*f2c)*(*f2c);
	return x;
}


float* ehfs_::
fs1(short* shobs, int frmsz, float* res1)
{
	if(!shobs) return (res1)?res1:xdef;
	float* x;
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return res1; }
	if(res1) x=res1; else x=xdef;
	fft.sh2ft(x,shobs,frmsz);
	if((lastRN4FFT-lastFRMSZ)>0)
		memset(x+lastFRMSZ, 0, (lastRN4FFT-lastFRMSZ)*sizeof(float));//zero-padding
	//fft.rfft0(x,lastNRFFT/2);
	fft.rfft0(x,lastRN4FFT);
	//float* r; r=ehf(shobs, frmsz, res1);
	int i; float *f1=x, *f2r=x, *f2c=x+1;
	*f1 =fabs(*f2r); f1++; f2r+=2; f2c+=2;
	for(i=0; i<lastRN4FFT/2; i++, f1++, f2r+=2, f2c+=2)
		(*f1)=fabs(*f2r)+fabs(*f2c);
		//(*f1)=(*f2r)*(*f2r)+(*f2c)*(*f2c);
	return x;
}

float* ehfs_::
fs1off(short* shobs, int frmsz, float* res1)
{
	if(!shobs) return (res1)?res1:xdef;
	float* x; int i;
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return res1; }
	if(res1) x=res1; else x=xdef;
	fft.sh2ft(x,shobs,frmsz);
	float sum=0;   for(i=0;i<frmsz;i++)sum+=x[i];
	sum=sum/frmsz; for(i=0;i<frmsz;i++)x[i]-=sum;
	if((lastRN4FFT-lastFRMSZ)>0)
		memset(x+lastFRMSZ, 0, (lastRN4FFT-lastFRMSZ)*sizeof(float));//zero-padding
	//fft.rfft0(x,lastNRFFT/2);
	fft.rfft0(x,lastRN4FFT);
	//float* r; r=ehf(shobs, frmsz, res1);
	float *f1=x, *f2r=x, *f2c=x+1;
	*f1 =fabs(*f2r); f1++; f2r+=2; f2c+=2;
	for(i=0; i<lastRN4FFT/2; i++, f1++, f2r+=2, f2c+=2)
		(*f1)=fabs(*f2r)+fabs(*f2c);
		//(*f1)=(*f2r)*(*f2r)+(*f2c)*(*f2c);
	return x;
}


float* ehfs_::
hf(short* shobs, int frmsz, float* res1)
{
	if(!shobs) return (res1)?res1:xdef;
	int i; float* x;
	//if(lastFRMSZ!=frmsz) {
	//	alloc4work(frmsz);
	//	lastFRMSZ=frmsz; lastNRFFT=ge2pow(lastFRMSZ);
	//	initham();
	//}
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return res1; }
	if(res1) x=res1; else x=xdef;
	for(i=0; i<lastFRMSZ; i++) x[i]=shobs[i];
	doham(x);
	if((lastRN4FFT-lastFRMSZ)>0)
		memset(x+lastFRMSZ, 0, (lastRN4FFT-lastFRMSZ)*sizeof(float));//zero-padding
	//fft.rfft1(x-1, lastNRFFT/2); // real fft, -1:since 1-based
	fft.rfft1(x-1, lastRN4FFT); // real fft, -1:since 1-based
	//x[1]=0; // for htk's ???
	return x;
}

float* ehfs_::
ehf(short* shobs, int frmsz, float* res1, int preem)
{
	if(!shobs) return (res1)?res1:xdef;
	int i; float* x;
	//if(lastFRMSZ!=frmsz) {
	//	alloc4work(frmsz);
	//	lastFRMSZ=frmsz; lastNRFFT=ge2pow(lastFRMSZ);
	//	initham();
	//}
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return res1; }
	if(res1) x=res1; else x=xdef;
	for(i=0; i<lastFRMSZ; i++) x[i]=shobs[i];
	if(preem)
		dopreem(x);
	doham(x);
	if((lastRN4FFT-lastFRMSZ)>0)
		memset(x+lastFRMSZ, 0, (lastRN4FFT-lastFRMSZ)*sizeof(float));//zero-padding
	//fft.rfft1(x-1, lastNRFFT/2); // real fft, -1:since 1-based
	fft.rfft1(x-1, lastRN4FFT); // real fft, -1:since 1-based
	//x[1]=0; // for htk's ???
	return x;
}


float* ehfs_::
eh(short* shobs, int frmsz, float* res1, int preem)
{
	if(!shobs) return (res1)?res1:xdef;
	int i; float* x;
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return res1; }
	if(res1) x=res1; else x=xdef;
	for(i=0; i<lastFRMSZ; i++) x[i]=shobs[i];
	if(preem)
		dopreem(x);
	doham(x);
	//if((lastRN4FFT-lastFRMSZ)>0)
		//memset(x+lastFRMSZ, 0, (lastRN4FFT-lastFRMSZ)*sizeof(float));//zero-padding
	//fft.rfft1(x-1, lastNRFFT/2); // real fft, -1:since 1-based
	//fft.rfft1(x-1, lastRN4FFT); // real fft, -1:since 1-based
	//x[1]=0; // for htk's ???
	return x;
}

float* ehfs_::
cpy(short* shobs, int frmsz, float* res1)
{
	if(!shobs) return (res1)?res1:xdef;
	int i; float* x;
	if(lastFRMSZ!=frmsz) { if( !set4FRMSZ(frmsz) ) return res1; }
	if(res1) x=res1; else x=xdef;
	for(i=0; i<lastFRMSZ; i++) x[i]=shobs[i];

	return x;
}




void ehfs_::
dopreem(float* obs)
{
	for(int i=lastFRMSZ-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] *=float(1.0-preem);
}

void ehfs_::
dopreem(float* obs, float prevvalue)
{
	for(int i=lastFRMSZ-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] -=prevvalue*preem;
}

void ehfs_::
initham()
{
	//const double pi=3.141592653589793;
	//double twopi=2*pi;
	if(lastFRMSZ<2) return;
	float dt=float(twopi/(lastFRMSZ-1));
	for(int i=0; i<lastFRMSZ; i++)
		ham[i]=float(0.54-0.46*cos(dt*i));
}

void ehfs_::
doham(float*obs)
{
	float*o=obs, *h=ham;
	for(register int i=0; i<lastFRMSZ; i++)
		*o++ *= *h++;
}

/*
int calspec__(rmmat<double>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem)
{
	int rr,cc, RR,CC; int nn,NN=twopowerbound(frmsz/2); float* res;
	RR=(qb.size()-frmsz)/sftsz;	CC=NN;
	mm.init2(RR,CC);
	for(rr=0; rr<RR; rr++){
		res=ehfs.ehfs(qb.sh+sftsz*rr, frmsz,0,preem);
		for(nn=0;nn<NN; nn++){
			mm(rr,nn)=res[nn];
		}
	}
	return 1;
}

int calspec__(vecvec<double>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem)
{
	int rr,cc, RR,CC; int nn,NN=twopowerbound(frmsz/2); float* res;
	RR=(qb.size()-frmsz)/sftsz;	CC=NN;
	mm.resize(RR,CC);
	for(rr=0; rr<RR; rr++){
		res=ehfs.ehfs(qb.sh+sftsz*rr, frmsz,0,preem);
		for(nn=0;nn<NN; nn++){
			mm(rr,nn)=res[nn];
		}
	}
	return 1;
}

int calspec__(vecvec<float>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem)
{
	int rr,cc, RR,CC; int nn,NN=twopowerbound(frmsz/2); float* res;
	RR=(qb.size()-frmsz)/sftsz;	CC=NN;
	mm.resize(RR,CC);
	for(rr=0; rr<RR; rr++){
		res=ehfs.ehfs(qb.sh+sftsz*rr, frmsz,0,preem);
		for(nn=0;nn<NN; nn++){
			mm(rr,nn)=res[nn];
		}
	}
	return 1;
}
*/

#endif //#ifndef RCFFT_CPP


extern samplingrate srdef;
samplingrate srdef;

int 	samplingrate::nth2rate(int nth)
{
	switch(nth){
	case sr08K:return  8000;
	case sr16K:return 16000;
	case sr32K:return 32000;
	case sr48K:return 48000;
	case sr11K:return 11025;
	case sr22K:return 22050;
	case sr44K:return 44100;
	}
	return 16000;
}

char* 	samplingrate::nth2str(int nth)
{
	cs="16K";
	switch(nth){
	case sr08K:cs= "8000";break;
	case sr16K:cs="16000";break;
	case sr32K:cs="32000";break;
	case sr48K:cs="48000";break;
	case sr11K:cs="11025";break;
	case sr22K:cs="22050";break;
	case sr44K:cs="44100";break;
	}
	return cs.s;
}

char* 	samplingrate::nth2sstr(int nth)
{
	cs="16K";
	switch(nth){
	case sr08K:cs="08K";break;
	case sr16K:cs="16K";break;
	case sr32K:cs="32K";break;
	case sr48K:cs="48K";break;
	case sr11K:cs="11K";break;
	case sr22K:cs="22K";break;
	case sr44K:cs="44K";break;
	}
	return cs.s;
}


char* 	samplingrate::rate2str(int rate)
{ int nth=rate2nth(rate); return nth2str(nth); }

char* 	samplingrate::rate2sstr(int rate)
{ int nth=rate2nth(rate); return nth2sstr(nth); }

int 	samplingrate::rate2nth(int rate)
{
	switch(rate){
	case  8000:return sr08K ;
	case 16000:return sr16K;
	case 32000:return sr32K;
	case 48000:return sr48K;
	case 11025:return sr11K;
	case 22050:return sr22K;
	case 44100:return sr44K;
	}
	return sr16K;
}

int 	samplingrate::str2rate(char* s)
{ int nth=str2nth(s); return nth2rate(nth); }

int 	samplingrate::str2nth(char* s)
{
	cs=s;int len=cs.find('k'); if(len>=0) cs[len]='K';
	if(cs.is("08K"))return sr08K; else
	if(cs.is( "8K"))return sr08K; else
	if(cs.is("16K"))return sr16K; else
	if(cs.is("32K"))return sr32K; else
	if(cs.is("48K"))return sr48K; else
	if(cs.is("11K"))return sr11K; else
	if(cs.is("22K"))return sr22K; else
	if(cs.is("44K"))return sr44K; else
	if(cs.is( "8000"))return sr08K; else
	if(cs.is("16000"))return sr16K; else
	if(cs.is("32000"))return sr32K; else
	if(cs.is("48000"))return sr48K; else
	if(cs.is("11025"))return sr11K; else
	if(cs.is("22050"))return sr22K; else
	if(cs.is("44100"))return sr44K; else
		return sr16K;
}


//#include <spmsg.h>

//*********************************************************************
//*********************************************************************
//** ���|�ؤ覡thato ���ĥd driver �|��q���{���A
//** dijia �ĥ� CALLBACK FUNCTION
//**
//** For CALLBACK function to be used as a member,
//** it is necessary to be static
//** to avoid auto-insertion of class object as an argument.
//** Otherwise, must use standalone function
//**
//*********************************************************************
//*********************************************************************
/*
typedef struct {
		LPSTR  lpData;
		DWORD  dwBufferLength;
		DWORD  dwBytesRecorded;
		DWORD  dwUser;
		DWORD  dwFlags;
		DWORD  dwLoops;
		struct wavehdr_tag * lpNext;
		DWORD  reserved;
} WAVEHDR;
*/

//*********************************************************************
//*********************************************************************
//**  BEG of class DQShdrbuf
//*********************************************************************
/*
wave file format of a simple kind
A. how to find for the file format of *.wav?
	 1. take a .sp file, load it into cool-edit
			( or generate an short sequence of known pattern, save it and read it into cooledit)
	 2. pick a selection, say, of 8 samples.
	 3. save the selection as
			a. Windows PCM ( the usual kind, uncompressed )
			b. Microsoft ADPCM (compressed? by MS)
	 4. view it in ultraedit.  You should find
B. File format of .wav ( only the Windows PCM and Microsoft ADPCM )
	 1. Start with FOURCC "RIFF" (FOURCC: 4 char code, tail-padded with space)
	 2. int of File size in byte - 8 (4 for "RIFF", 4 for this int)
	 3. FOURCC with "WAVE"
	 4. FOURCC with "fmt "
	 5. int of size, meaning:
			a. sizeof(WAVEFORMATEX)-sizeof(WAVEFORMATEX.cbsize),
								18           -       2
				 (in 10h, you should read "10 00 00 00" in ultraedit )
				 in this case, the following WAVEFORMATEX.wFormatTag should be 1
				 (in 14h, you should read "01 00" in ultraedit )
			b. sizeof(WAVEFORMATEX)+   WAVEFORMATEX.cbsize,
								18           +   32
				 (in 10h, you should read "32 00 00 00" in ultraedit )
				 in this case, the following WAVEFORMATEX.wFormatTag should be 2
				 (in 14h, you should read "02 00" in ultraedit )
			// upto here, there are 20B
	 6. struct of WAVEFORMATEX, less(case a) or not(case b) the cbsize field
			a. 16 bytes of WAVEFORMATEX, i.e. less the WAVEFORMATEX.cbsize field
			b. 18 bytes of WAVEFORMATEX, and then 32 byte of stuff for compression
				 in the case of ADPCM
	 7. FOURCC with "data"
	 8. wave data size in byte( so it is the int-field in #2 less 36/62
			//upto here, there are (20+16+8)B or (20+50+8)B where 16/50 depends
			//on the int-field #5, starting from 16th byte
*/



int pcmfmt_::set2(DWORD samppsec, WORD channels, WORD bitspsamp)
{
	wfex.wFormatTag=WAVE_FORMAT_PCM;
	wfex.nChannels=channels;
	wfex.nSamplesPerSec=samppsec;
	wfex.wBitsPerSample=bitspsamp;
	wfex.cbSize=0;
	wfex.nBlockAlign=WORD(channels*bitspsamp/8);
	wfex.nAvgBytesPerSec=samppsec*wfex.nBlockAlign;
  return 0;
}

int pcmfmt_::isconsistent()
{
	if(!( (wfex.nBlockAlign==WORD(wfex.nChannels*wfex.wBitsPerSample/8))&&
				(wfex.nAvgBytesPerSec==(wfex.nSamplesPerSec*wfex.nBlockAlign)) )  )
		return 0;
	return 1;
}

void pcmfmt_::set4wfex 		()
{
	wfexsz=16;	// this could be 50 for Microsoft ADPCM, when read from file
	strncpy(ccriff,"RIFF",4);
	strncpy(ccwave,"WAVE",4);
	strncpy(ccfmt ,"fmt ",4);
	strncpy(ccdata,"data",4);
}

int	 pcmfmt_::setbytesize(int databytesize)
{
	dataBsz=databytesize;
	fsizel8=databytesize+wfexsz+4+16;
	return databytesize;
}

int  pcmfmt_::write(tyio& o, int databytesize)
{
	if(databytesize>0) setbytesize(databytesize);
	o.outs(&ccriff[0],4); o.put(&fsizel8);
	o.outs(&ccwave[0],4); o.outs(&ccfmt[0],4);
	o.put(&wfexsz);
	if( wfexsz==16 ){
		o.write(&wfex,16);
	}else{
		o.write(&wfex,18);
		o.write(extra,32);
	}
	o.outs(&ccdata[0],4); o.put(&dataBsz);
	return 16+wfexsz+wfex.cbSize;
}


int  pcmfmt_::read(tyio& io)
{
	//int filesize; filesize=io.filesize();
	int nn=0;
	if(io.read(ccriff,4)				!=4)	return 0; nn+=4;
	if(strncmp(ccriff,"RIFF",4)	!=0)	{io.rmoveto(-nn); return 0; }
	if(io.read(&fsizel8,4)			!=4)	return 0; nn+=4;
	if(io.read(ccwave,4)				!=4)	return 0; nn+=4;
	if(strncmp(ccwave,"WAVE",4)	!=0)	{io.rmoveto(-nn); return 0; }
	if(io.read(ccfmt,4)					!=4)	return 0; nn+=4;
	if(strncmp(ccfmt, "fmt ",4)	!=0)	{io.rmoveto(-nn); return 0; }
	if(io.read(&wfexsz,4)				!=4)	return 0; nn+=4;
	if(!(wfexsz==16||wfexsz==50)	 ) 	{io.rmoveto(-nn); return 0; }//what to do?
	if(wfexsz==16){
		if(io.read(&wfex,16)			!=16)	return 0; nn+=16;
		wfex.cbSize=0;
		if(!isPCM	()								 	)	{io.rmoveto(-nn); return 0; }
	}else{
		if(io.read(&wfex,18)			!=18)	return 0; nn+=18;
		if(!isADPCM()									)	{io.rmoveto(-nn); return 0; }
		if(io.read(extra,32)			!=32) return 0;	nn+=32;
	}
	if(io.read(ccdata,4)				!=4)	return 0; nn+=4;
	if(strncmp(ccdata,"data",4)	!=0)	{io.rmoveto(-nn); return 0; }
	if(io.read(&dataBsz,4)			!=4)	return 0; nn+=4;
	if(isPCM()){
		if(dataBsz+36!=fsizel8)					{io.rmoveto(-nn); return 0; }
	}else{
		if(dataBsz+62!=fsizel8)					{io.rmoveto(-nn); return 0; }
	}
	return nn;
}

int  pcmfmt_::readp(void* p, int plen)
{
	if(!p)return 0;
	char*t=(char*)p;  int nn=0;
	if(plen>0&&plen<8)return 0;
	strncpy(ccriff,  t+nn,4);	if(strncmp(ccriff,"RIFF",4)!=0)		return 0; nn+=4;
	fsizel8=*((int*)(t+nn));	if(plen>0&&(uint)plen!=fsizel8+8)	return 0; nn+=4;
	//so length isOK now if plen>0
	strncpy(ccwave,  t+nn,4);	if(strncmp(ccwave,"WAVE",4)!=0)		return 0; nn+=4;
	strncpy(ccfmt,   t+nn,4);	if(strncmp(ccfmt ,"fmt ",4)!=0)		return 0; nn+=4;
	wfexsz =*((int*)(t+nn));	if(!(wfexsz==16||wfexsz==50))  		return 0; nn+=4;
	if(wfexsz==16){
		memmove(&wfex,t+nn,16);wfex.cbSize=0;	if(!isPCM  ())	return 0;     nn+=16;
	}else{
		memmove(&wfex,t+nn,18);								if(!isADPCM())	return 0;     nn+=18;
		memmove(extra,t+nn,32);                               	            nn+=32;
	}
	strncpy(ccdata, t+nn,4);	if(strncmp(ccdata,"data",4)!=0)	return 0; 	nn+=4;
	dataBsz=*((int*)(t+nn));                                            	nn+=4;
	if(isPCM()){
		if(dataBsz+36!=fsizel8)					{return 0; }
	}else{
		if(dataBsz+62!=fsizel8)					{return 0; }
	}
	return nn;
}



int  htkfmt_::read(tyio& io)
{
	int sz=(io.filesize()-sizeof(htkfmt_))/sizeof(short);
	io.read(this, sizeof(htkfmt_));
	if(		(totSamp!= sz			)// totSamp in shorts
			//||(sampPeriod!= 625	)//=625; for 16K
			||(sizePerSamp!=2		)//=2;   2 bytes per sample
			||(fileDataKind!=0	)//=0;   wavedata, in HTK sense
		) { io.rmoveto(-int(sizeof(htkfmt_))); return 0;}
	return sizeof(htkfmt_);
}

int  htkfmt_::readp(void*p, int plen)
{
	if(!p)return 0;
	if(plen>0&&plen<sizeof(htkfmt_))return 0;
	memmove(this,p,sizeof(htkfmt_));
	int sz;
	//int sz=(io.filesize()-sizeof(htkfmt_))/sizeof(short);
	if(plen>0)
		sz=(plen-sizeof(htkfmt_))/sizeof(short);
	else sz=totSamp;
	//io.read(this, sizeof(htkfmt_));
	if(		(totSamp!= sz			)// totSamp in shorts
			//||(sampPeriod!= 625	)//=625; for 16K
			||(sizePerSamp!=2		)//=2;   2 bytes per sample
			||(fileDataKind!=0  )//=0;   wavedata, in HTK sense
		) { return 0;}
	return sizeof(htkfmt_);
}

int htkfmt_::operator=(pcmfmt_& pcm) //ret: success or not
{
	if(!pcm.isPCM()) return 0;
	sampPeriod		=10000000/pcm.wfex.nSamplesPerSec;
	sizePerSamp		=pcm.wfex.wBitsPerSample/8;
	fileDataKind	=0;
	totSamp				=pcm.dataBsz/sizePerSamp;
	return 1;
}

int pcmfmt_::operator=(htkfmt_& htk) //ret: success or not
{
	set4wfex();
	wfex.nSamplesPerSec		=10000000/htk.sampPeriod;
	wfex.nAvgBytesPerSec	=wfex.nSamplesPerSec * htk.sizePerSamp;
	wfex.wBitsPerSample 	=htk.sizePerSamp*8;
	setbytesize(htk.totSamp*htk.sizePerSamp);
	return 1;
}

//down: for use with wplaysound
class mpcmfmt_: public pcmfmt_{ public:// an in-memory version of the filehdr of pcmfmt_
int realsize(){if(wfexsz==16) return 20+16+8; else if(wfexsz==50) return sizeof(pcmfmt_);return 0;}
int operator=(pcmfmt_&pcm){	memmove(this,&pcm,sizeof(pcmfmt_));	compact();return 0;	}
int compact (){
				if(wfexsz==16){
					char* t=(char*)this+20+16; char* s=t+34;
					memmove(t,s,8);
					uchar c; c=t[4];t[4]=t[6];t[6]=c;c=t[5];t[5]=t[7];t[7]=c;//donot understand
				}
				return 0;
				}
};

int wplaysound::operator=(qiimbuf_& qb)
{
	if(qb.nshused<=0) {clear();return 0;}
	uint pcmsz=sizeof(pcmfmt_);
	uint len=pcmsz+qb.bsize();
	if(len>nallc){
		del();
		t=new char[len];nallc=len;
	}
	if(!t){nallc=0;nused=0;return 0;}
	nused=len;// nused should be len less the compact, but this should be OK
	memmove(t,&(qb.pcm),pcmsz);
	mpcmfmt_* hdr=(mpcmfmt_*)t;
	hdr->compact();
	int offset=(*hdr).realsize();
	memmove(t+offset,qb.sh, qb.bsize());
	return 1;
}

int wtts_:: dobendiau(charspp& spp, char*fns)
{
	cs=fns;
	str_auto_simple_bendiau2(&cs);
	str_del2kauqidiau(cs.s);
	spp.set2Nhunhanlor(cs.s);
	return spp.size();
}


int wtts_:: cat(charspp& spp, char*ext, char* pname, char apptoneifnot)
{
	int n,N=spp.size(); if(N<=0) return 0;
	qb.clear(); qbt.clear();  //int isptkh;
	for(n=0;n<N;n++){
		cst=spp[n];
		if(cst.is("???")) cst="shdu.sp";else
		if(apptoneifnot)cst.insifnotone(apptoneifnot);
		if(cst.hasfileext())cs.set24fep(cst.s, "", pname);
		else cs.set24fep(cst.s, ext, pname);
		if(qbt.read(cs.s))
			qb.app(qbt);
	}
	wps=qb;
	return N;
}

BOOL wtts_:: thplayd4ask(char*    fns)
{
	dobendiau(spp,fns);
	return tqplay(spp,ename_.s,pname_.s);
}





int frmcenter(vector<int>& v, int qiimsz, int frmsz, int sftsz)
{
	v.clear(); if(sftsz<=0) return 0;
	uint n,N=(qiimsz-frmsz)/sftsz+1; //+1, see qiimbuf_.nfrm(frmsz,sftsz);
	v.resize(N);
	int  cen=frmsz/2;
	for(n=0; n<N; n++){
		v[n]=cen;
		cen+=sftsz;
	}
	return N;
}




int  qiimbuf_::resize(int nshorts)
{
	if(nshorts<=0)nshorts=0;
  if(nshorts<=nshused) {
    nshused=nshorts;
  }else if(nshorts<=nshalloc){
    memset(sh+nshused, 0, sizeof(short)*(nshorts-nshused));
    nshused=nshorts;
  }else{
    short* nwsh=new short[nshorts];
    if(!nwsh) return 0; //values of nwsh[] was set2 0
    if(nshused>0)
    memmove(nwsh,         sh, sizeof(short)*nshused);
    memset (nwsh+nshused, 0,  sizeof(short)*(nshorts-nshused));
    del(); sh=nwsh; nshused=nshalloc=nshorts;
  }
  pcm.setbytesize(sizeof(short)*nshused);
  return(1);
}

int  qiimbuf_::reserve(int nshorts)
{
	if(nshorts<=0)return 0;
	if(nshalloc<nshorts)
		{del(); sh=new short[nshorts];nshalloc=(sh)?nshorts:0;}
	nshused=0;
	return((sh)?1:0);
}


int  qiimbuf_::rmb (int nsh1)
{
	if(!sh) return 0;
	if(nsh1<0) return 0;
	if(nsh1>nshused) return 0;
	memmove(sh,sh+nsh1, sizeof(short)*(nshused-nsh1));
	nshused-=nsh1;
	pcm.fsizel8-=nsh1*sizeof(short);
	pcm.dataBsz-=nsh1*sizeof(short);
	return nsh1;
}

int  qiimbuf_::rme (int end)
{
	if(!sh) return 0;
	if(end<0) return 0;
	if(end>nshused) end=nshused;
	nshused-=end;
	pcm.fsizel8-=end*sizeof(short);
	pcm.dataBsz-=end*sizeof(short);
	return end;
}

int  qiimbuf_::rm (int beg, int end)
{
	if(!sh) return 0;if(beg<0) return 0;
	if(beg>=nshused) return 0;
	if(end<0) end=nshused;
	if(end>nshused) end=nshused;
	if(beg>=end) return 0;
	memmove(sh+beg,sh+end, sizeof(short)*(nshused-end));
	//memmove(sh,sh+beg, sizeof(short)*(end-beg));
	nshused-=(end-beg);
	pcm.fsizel8-=(end-beg)*sizeof(short);
	pcm.dataBsz-=(end-beg)*sizeof(short);
	return end-beg;
}

int  qiimbuf_::inssil	(int len, int at)
{
	if(len<=0)return 0;
	if(nshalloc<(nshused+len)){
		short* nwsh=new short[nshused+len+1];    if(!nwsh) return 0;
		memmove(nwsh, sh, sizeof(short)*nshused);int nwshused=nshused;
		del(); nshused=nwshused;
		sh=nwsh; nshalloc=nwshused+len+1;
	}
	if(nshalloc<(nshused+len)){ return 0; }
	if(at>nshused)at=nshused;
	if(at<nshused)
	memmove(sh+at+len, sh+at, sizeof(short)*(nshused-at) );
	//memmove(sh+nshused, sh+at, sizeof(short)*(nshused-at) );
	memset(sh+at, 0, sizeof(short)*len);
	//memmove(sh+at, sh1, sizeof(short)*len);
	nshused+=len;
	pcm.fsizel8+=len*sizeof(short);
	pcm.dataBsz+=len*sizeof(short);
	return len;
}

int  qiimbuf_::ins  (short* sh1, int len, int at)
{
	if(len<=0)return 0;
	if(nshalloc<(nshused+len)){
		short* nwsh=new short[nshused+len+1];    if(!nwsh) return 0;
		memmove(nwsh, sh, sizeof(short)*nshused);int nwshused=nshused;
		del(); nshused=nwshused;
		sh=nwsh; nshalloc=nwshused+len+1;
	}
	if(nshalloc<(nshused+len)){ return 0; }
	if(at<nshused)
	memmove(sh+nshused, sh+at, sizeof(short)*(nshused-at) );
	memmove(sh+at, sh1, sizeof(short)*len);
	nshused+=len;
	pcm.fsizel8+=len*sizeof(short);
	pcm.dataBsz+=len*sizeof(short);
	return len;
}




int  qiimbuf_::set2 (short* sh1, int nsh1)
{
	if(!reserve(nsh1)) return 0;
	memmove(sh, sh1, sizeof(short)*nsh1);
	nshused=nsh1;	nsheqiim=nsh1;
	setbytesize();//sizeof(short)*nshused);
	adpcm=0;
	return 1;
}


int	 qiimbuf_::set2 (qiimbuf_&buf,int beg, int len)//len==-1 for all
{
	if(!buf.ispcm()) return 0; // do not know what to do
	if(beg<0) beg=0;
	if(beg>=buf.nshused) return 0;
	pcm=buf.pcm;
	if(len<0) len=buf.nshused-beg; else
	if(beg+len>=buf.nshused) len=buf.nshused-beg;
	return set2(buf.sh+beg, len);
}

template<class real>
int	 qiimbuf_::set2be (real*src,int beg, int end)
{
	clear();	if(!src) return 0;
	if(beg<0||end<0||end<=beg) return 0;
	resize(end-beg);
	int n,N=end-beg;
	for(int n=0; n<N; n++)
		sh[n]=src[n+beg];
	return N;
}


int	 qiimbuf_:: downsample(int everyN)
{
	pcmfmt_ pcm1;
	pcm1=pcm;
	if(!candownsample(everyN,1)){
		pcm=pcm1; return 0;
	}
	int nn, NN;
	NN=nshused/everyN;
	for(nn=0; nn<NN; nn++){
		sh[nn]=sh[everyN*nn];
	}
	nshused=NN;
	k=K=nshbsil=nsheqiim=nshesil=0; //nsheqiim includes nshbsil
	adpcm=0;//???
	return everyN;
}

int  qiimbuf_:: candownsample(int everyN, int change_pcm)
{//44k:2/4; 22k:2; 48k:3/6; 32k:2/4; 16k:2
	int sr=pcm.sr();
	int res=0;
	switch(sr){
	case  8000: res=0;
							break;
	case 16000: if     (everyN==2){res=1;if(change_pcm) pcm.set8k();}
							break;
	case 32000: if     (everyN==2){res=1;if(change_pcm) pcm.set16k();}
							else if(everyN==4){res=1;if(change_pcm) pcm.set8k();}
							break;
	case 48000: if     (everyN==3){res=1;if(change_pcm) pcm.set16k();}
							else if(everyN==6){res=1;if(change_pcm) pcm.set8k();}
							break;
	case 64000: if     (everyN==2){res=1;if(change_pcm) pcm.set32k();}
							else if(everyN==4){res=1;if(change_pcm) pcm.set16k();}
							else if(everyN==8){res=1;if(change_pcm) pcm.set8k();}
							break;
	case 22050: if     (everyN==2){res=1;if(change_pcm) pcm.set11k();}
							break;
	case 44100: if     (everyN==2){res=1;if(change_pcm) pcm.set22k();}
							else if(everyN==4){res=1;if(change_pcm) pcm.set11k();}
							break;
	default: 		res=0; break;
	}
	return res;
}

static double partsum(short* sh, int cnt)
{
  double t=0;
  for(int n=0; n<cnt; n++) t+=*sh++;
	return t;
}

short qiimbuf_::maxamp     ()
{
	short mm=0;  short tmp;
	for(int n=0; n < nshused; n++) {
		tmp=sh[n]; if(tmp<0) tmp=-tmp;
		if(tmp>mm) mm=tmp;
	}
	return mm;
}

int qiimbuf_::csbe(int &beg, int &end)//* make sure 0<=beg<=end<=qbsz
{
	int qbsz=ssize();
	if(beg<0) beg=0; if(end<0) end=qbsz;
	if(end<=beg) swap(beg,end);
	if(beg>=qbsz) beg=qbsz; if(end>=qbsz) end=qbsz;
	return 1;
}

double qiimbuf_::mean     ()
{
	double t=0; int inc=32768; int n;
	for(n=0; n+inc <= nshused; n+=inc) {
		t+=partsum(sh+n, inc);
	}
	if(n!=nshused)
		t+=partsum(sh+n, nshused%inc);
	return t/nshused;
}


double qiimbuf_::zeromean ()
{
  double t=mean(); short* st=sh;
	for(int n=0; n<nshused; n++, st++)
		*st= short(*st-t);
  return t;
}

int	 	 qiimbuf_::sub    (int   amnt )
{
	if(!isOK()) return 0;
	for(int n=0;n<nshused; n++)
		sh[n]-=amnt;
	return 1;
}

int	 	 qiimbuf_::hongdua(float emph )
{
	if(!isOK()) return 0;
	for(int n=0;n<nshused; n++)
		sh[n]*=emph;
	return 1;
}

int qiimbuf_::read(char* fn, char* pn)
{
	chars cs; cs.setpfname(fn,pn);
	tyio io; 
	if(io.openNerr(cs.s))
		return 0;
	int res;
	if(cs.ew(".wav")||cs.ew(".WAV"))
		res=readwav(io);
	else
		res=readhtk(io);
	io.close();
	return res;
}

int qiimbuf_::readwav(tyio& io)
{
	if(!pcm.read(io)) { return 0;}
	uint smpsz=pcm.dataBsz/pcm.Bpsmp();
	if(!reserve(smpsz)) return 0;
	//if(nshalloc<int(smpsz)) {
	//	del(); sh=new short[smpsz];
	//	if(!sh)
	//	return 0;
	//	nshalloc=smpsz;
	//}
	int r=io.read(sh,smpsz*sizeof(short));
	if(r/sizeof(short)!=smpsz)
		return 0;
	//htk=pcm;
	nshused=smpsz;
	//nsheqiim=nshused;
	//nshbsil=nshesil=0;
	//k=nshused/nDQS_FSS;
	return smpsz;
}

int	 qiimbuf_::readp			(void* p, int plen)
{
	htkfmt_ htk; int nn;
	nn=htk.readp(p,plen);
	if(nn){
		if(!reserve(htk.totSamp)) return 0;
		memmove(sh,(char*)p+nn,htk.totSamp*sizeof(short));
		nshused=htk.totSamp;
		pcm=htk;
		setbytesize();
		return htk.totSamp;
	}
	nn=pcm.readp(p,plen);
	if(nn){
		uint smpsz=pcm.dataBsz/pcm.Bpsmp();
		if(!reserve(smpsz)) return 0;
		memmove(sh,(char*)p+nn,smpsz*sizeof(short));
		nshused=smpsz;
		return smpsz;
	}
	return 0;
}


int qiimbuf_::readhtk(tyio& io)
{
	htkfmt_ htk;
	if(!htk.read(io)) { return 0;}
	if(!reserve(htk.totSamp)) return 0;
	//if(nshalloc<htk.totSamp) {
	//	del(); sh=new short[htk.totSamp];
	//	if(!sh)
	//		return 0;
	//	nshalloc=htk.totSamp;
	//}
	int r=io.read(sh,htk.totSamp*sizeof(short));
	//io.close();
	if(r/2!=htk.totSamp)
		return 0;
	nshused=r/sizeof(short);
	pcm=htk;
	setbytesize();
	//nsheqiim=nshused;
	//nshbsil=nshesil=0;
	//k=nshused/nDQS_FSS;
	/*
	// now for the label file
	static chars s; static charspp spp, sppf; s.set2(fn); sppf.clear();
	if(!s.endwith(".sp")) return r;
	s.dellastN(3); s.app(".lab");
	if(!lread2gline(s.s, sppf)) return r;
	if(sppf.size()<3) return r;

	spp.set2Nhun(sppf[0]); if(spp.size()!=3) return r;
	int nshbsil1=s2i(spp[1])/10000*16;

	spp.set2Nhun(sppf[1]); if(spp.size()!=3) return r;
	int nsheqiim1=s2i(spp[1])/10000*16;

	spp.set2Nhun(sppf[2]); if(spp.size()!=3) return r;
	int nshesil1=s2i(spp[1])/10000*16-nsheqiim1;
	nshbsil=nshbsil1; nsheqiim=nsheqiim1; nshesil=nshesil1;
	*/
	return r/sizeof(short);
}


int qiimbuf_::writehtklabel(char* label,char* fname, uint nshbsil1,uint nshesil1)
{
	if(nshused<=0) return 0;
	if(label)str_delltspaces(label);if(!(label&&label[0])) return 0;
	if(label[0]=='='&&label[1]==0) return 0;
	if(fname)str_delltspaces(label);if(!(fname&&fname[0])) return 0;
	writer o; o.creat(fname); if(o.isERR()) return 0;
	int bnd=0; char fmt[]="\t%d  ";//nsh/16 is ms, *10000 in 10^-7 for htk
	if(nshbsil1>0) {
		o.write( tos(bnd, fmt));
		bnd=int( nshbsil1*1000./pcm.sr()*10000+0.5 );
		o.write( tos(bnd, fmt) );
		o.writeln("\t#");
		bnd++;
	}
	int nsheqiim1=nshused-nshesil1;
		o.write( tos(bnd, fmt));
		bnd=int( nsheqiim1*1000./pcm.sr()*10000+0.5 );
		o.write( tos(bnd, fmt) );
		o.write("\t"); o.writeln(label);
		bnd++;
	if(nshesil1>0) {
		o.write( tos(bnd, fmt));
		bnd=int( nshused*1000./pcm.sr()*10000+0.5 );
		o.write( tos(bnd, fmt) );
		o.writeln("\t#");
	}
	return 1;
}


int qiimbuf_:: write		(char* fn, char* pn)//htk or wav? judge by .ext
{
	if(str_endwith(fn,".sp")) return writehtk(fn,pn);
	return writewav(fn,pn);
}

int qiimbuf_:: write		(int beg, int len, char* fn, char* pn)//htk or wav? judge by .ext
{
	if(str_endwith(fn,".sp")) return writehtk(beg, len, fn,pn);
	return writewav(beg, len, fn,pn);
}

int qiimbuf_::write(int beg, int len, char* fn, char* pn, int writewav)
{
	tyio io;
	if(!io.creat(fn,pn))	return 0;
	int r=write(beg, len, io, writewav);
	io.close();
	return r;
}

int  qiimbuf_::write		(char* fn, char* pn, int writewav)
{
	tyio io;
	if(!io.creat(fn,pn))	return 0;
	int r=write(io, writewav);
	io.close();
	return r;
}

int  qiimbuf_::write(int beg, int len, tyio& io, int writewav)
{
	pcmfmt_ spcm; spcm=pcm;
	spcm.setbytesize(len*sizeof(short));
	if(writewav) {
		if(!spcm.write(io)) return 0;
	}else{
		htkfmt_ htk;
		htk=spcm;
		if(!htk.write(io)) return 0;
	}
	io.write(sh+beg,len*sizeof(short));
	return 1;
}


int  qiimbuf_::write(tyio& io, int writewav)
{
	setbytesize();
	if(writewav) {
		if(!pcm.write(io)) return 0;
	}else{
		htkfmt_ htk;
		htk=pcm;
		if(!htk.write(io)) return 0;
	}
	io.write(sh,(nshused)*sizeof(short));
	return 1;
}


int qiimbuf_::
wincut(short* x, float* win, int pmark1, int pmark2, int pmark3)//* assume size of x[] win[] are least pmark3-pmark1+1
{
  int n,N=pmark3-pmark1+1;
  int beg=pmark1;
  if(pmark1<0 ){beg=-pmark1;memset(x,0,sizeof(short)*N);}
  if(N+pmark1>nshused){N  =nshused-pmark1;memset(x,0,sizeof(short)*N);}
  for(n=0; n<N; n++){
    x[n]=sh[beg+n]*win[n];
  }
  return 1;
}

int qiimbuf_::
wincut(vector<short>&x, float* win, int pmark1, int pmark2, int pmark3)//* assume size of x[] win[] are least pmark3-pmark1+1
{
  x.resize(pmark3-pmark1+1);
  return wincut(&(x[0]),win, pmark1,pmark2,pmark3);
}


int qiimbuf_::
hanningwincut(short* x, int pmark1, int pmark2, int pmark3)//* assume size of x[] win[] are least pmark3-pmark1+1
{
  vector<float> hw;
  ::gethanning(hw, pmark1, pmark2, pmark3);
  if((int)hw.size()<pmark3-pmark1+1)
    return 0;
  return wincut(x,&(hw[0]),pmark1,pmark2,pmark3);
}

int qiimbuf_::
hanningwincut(vector<short>&x, int pmark1, int pmark2, int pmark3)//* assume size of x[] win[] are least pmark3-pmark1+1
{
  x.resize(pmark3-pmark1+1);
  if((int)x.size()<pmark3-pmark1+1)
    return 0;
  return hanningwincut(&(x[0]), pmark1,pmark2,pmark3);
}

int qiimbuf_::
hanningwincut(vector<short>&x, vector<float>& win, int pmark1, int pmark2, int pmark3)//* assume size of x[] win[] are least pmark3-pmark1+1
{
  ::gethanning(win, pmark1, pmark2, pmark3); if((int)win.size()<pmark3-pmark1+1) return 0;
  x.resize(pmark3-pmark1+1);                 if((int)  x.size()<pmark3-pmark1+1) return 0;
  return wincut(&(x[0]),&(win[0]), pmark1,pmark2,pmark3);
}


int qiimbuf_::
addx(short* x, int nx, int beg)//* will reize() if ness.,& if nx, beg<10MB
{
  if(beg<0||nx<=0) return 0;
  if(nx+beg>nshused)
    if(nx<10000000&&beg<10000000)
      resize(nx+beg);
  if(nx+beg>nshused) return 0;
  for(int n=0; n<nx; n++)
    sh[beg+n]+=x[n];
  return 1;
}







int	 feabuf_::	init2nsamples(int nsamples, int nfloatsPerSample)
{//nfloatsPerSample>=12
	if(nfloatsPerSample<12) nfloatsPerSample=12;
	int res=init2(nsamples*nfloatsPerSample);
	nftpersamp=nfloatsPerSample;
	hh.sizePerSamp=nfloatsPerSample*sizeof(float);
  nftused=nftpersamp*nsamples;
  setTTCC();
	return res;
}

int  feabuf_::init2(int nfloats)
{
	if(nfloats<=0)return 0;
	if(ft&&(nfloats<=nftalloc)) return 1;
	del();
	ft=new float[nfloats];
	if(ft){ nftused=0; nftalloc=nfloats; }
	return((ft)?1:0);
}


int feabuf_::read(char* fn)
{
	tyio io; if(io.openNerr(fn))return 0;
	int r=io.read(&hh, sizeof(hh));
	if(!r) { io.close(); return 0;}
	if(nftalloc<hh.totSamp) {
		del();
		if(!init2(hh.sizePerSamp/sizeof(float)*hh.totSamp)) return 0;
	}
	r=io.read(ft,hh.sizePerSamp*hh.totSamp);
	io.close();
	if(r!=int(hh.sizePerSamp*hh.totSamp))
		{ hh.totSamp=nftused=0; return 0; }
	nftused=r/sizeof(float);

  setTTCC();
  
	return r;
}


//*********************************************************************
//**  END of class DQShdrbuf
//*********************************************************************
//*********************************************************************





//*********************************************************************
//*********************************************************************
//**  BEG of hEvents for speechio
//*********************************************************************

static HANDLE
		hEvent_PlayEnd
	, hEvent_class_ow_PlayEnd
;

static struct adfjkdfljf { adfjkdfljf(){
	hEvent_PlayEnd						=CreateEvent(NULL,FALSE,FALSE,NULL);
	hEvent_class_ow_PlayEnd		=CreateEvent(NULL,FALSE,FALSE,NULL);
}}___F___jd__safhfhak___;


//*********************************************************************
//**  END of hEvents for speechio
//*********************************************************************
//*********************************************************************



//*********************************************************************
//*********************************************************************
//**  BEGIN of  class owave_
//*********************************************************************

class owave0_ { public:// the real worker for out-wave
	HWAVEOUT        hwo; // handle to the oepned input device
	//WAVEFORMATEX  wfx; // struct for (querying?) supportted data format
	pcmfmt_			    wfx; // struct for (querying?) supportted data format
	MMRESULT        res;
	WAVEHDR         hdr;
	MMTIME					mmt;
	int bOpened;
	static int bBangImDiong;
	HWAVEOUT operator()() { return hwo; }
	static void CALLBACK	waveOutProc
	(HWAVEOUT hwo,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);
public:
	//owave0_():bOpened(0),bBangImDiong(0),sh0(0),shsize0(0),pcm0(0){ wfx.set4wfex(); res=ispcmsupported(); }
	owave0_():bOpened(0),sh0(0),shsize0(0),pcm0(0){ wfx.set4wfex(); }//res=ispcmsupported(); }
 ~owave0_(){ if(bOpened) close(); }
public:
	int open		 (pcmfmt_* wfmt1=0){WAVEFORMATEX*fmt=(wfmt1)?&(wfmt1->wfex):&(wfx.wfex);//?????
																res=waveOutOpen(&hwo,WAVE_MAPPER,fmt, (DWORD)
																						waveOutProc,0,CALLBACK_FUNCTION);
																bOpened=(!res);return bOpened;	}
	int openfail (pcmfmt_* wfmt1=0) { if(!bOpened)open(wfmt1); return !bOpened;}
	int close		 (){ /*if(!bBangImDiong)return 0;*/
									 if(bBangImDiong) reset();
									 bOpened=0; return waveOutClose(hwo); }
	int reset		 (){ /*if(!bBangImDiong)return 0; */
									 res= waveOutReset(hwo);
									 //if(res!=MMSYSERR_NOERROR)
									 // owave0junk++;
									 //uint err=MMSYSERR_INVALHANDLE;
									 //if(res==err)
										//owave0junk++;
									 Sleep(10); return res; }
	int stopclose() { int r;
		r=reset();
		if(r==MMSYSERR_NOERROR)
			r=close();
    SetEvent(hEvent_PlayEnd);
    return r;}
public:
	int ispcmsupported(); int owave0junk;
public: short* sh0; int shsize0; pcmfmt_* pcm0;
	int play  (short*sh, int shsize, pcmfmt_* pcm=0);
  int thplay(short*sh, int shsize, pcmfmt_* pcm=0);
public:
	threader1_  threader;
  void    thclear(){sh0=0;shsize0=0;pcm0=0;}
  static void splay(void* pv){
                    if(!pv)return;owave0_&ow=*((owave0_*)pv);
                    if(!(ow.sh0&&ow.shsize0>0&&ow.pcm0)) return;
                    ow.play(ow.sh0,ow.shsize0,ow.pcm0);
  }
};
int owave0_::bBangImDiong=0;
static void splay(void* vp);


owave0_ owdef0;

void CALLBACK owave0_::
waveOutProc(HWAVEOUT hwo,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	switch (uMsg) {
	case WOM_DONE:
    bBangImDiong=0;
    SetEvent(hEvent_PlayEnd);
		//spmsgStatus("WOM_DONE");
	}
}

#include <conio.h>

int owave0_::
play(short* dt, int shsize, pcmfmt_* pcm)
{
	if(bBangImDiong) return 0;
  reset();close();
	bBangImDiong=1;
	if( (!dt) ||(shsize<=0) || openfail(pcm)) {
		//spmsgStatus("play err\n\n"); Sleep(10);
		bBangImDiong=0;
		SetEvent(hEvent_class_ow_PlayEnd);
		return 0;
	}
  //int junk=0;
	hdr.lpData = (LPSTR)dt;
	hdr.dwBufferLength = shsize*2; // length in bytes rather in short
	hdr.dwBytesRecorded= shsize*2; // length in bytes rather in short
	hdr.dwFlags = WHDR_BEGINLOOP|WHDR_ENDLOOP;
	hdr.dwLoops = 1L;
	res=waveOutPrepareHeader(hwo, &hdr, sizeof(hdr) );
	//spmsg.ostatus("          ��...");
	int sleep10=pcm->nsh2ms(shsize)/10+1;
	res=waveOutWrite(hwo, &hdr, sizeof(hdr) );
	while(1){
		Sleep(10);sleep10--;if(sleep10<0)break;
    if(!bBangImDiong){ //bBangImDiong could be set at waveOutProc
      //junk++;
      break;
    }
    /*
		mmt.wType=TIME_BYTES;
		res=waveOutGetPosition(hwo,&mmt,sizeof(mmt));
		if(res!=MMSYSERR_NOERROR)break;
    if(uint(mmt.u.cb)==0){
      //junk++;
      break;
    }
		if(mmt.u.cb>uint(shsize*2-1))break;
    */
	}
	//WaitForSingleObject(hEvent_PlayEnd, shsize/8+10);
	//WaitForSingleObject(hEvent_PlayEnd, shsize/16+10);
	//WaitForSingleObject(hEvent_PlayEnd, INFINITE);
	res=
	reset();
  waveOutUnprepareHeader(hwo, &hdr, sizeof(hdr) );
  //if(res==MMSYSERR_NOERROR)
    res=close();
	//close(); //Sleep(100);
	bBangImDiong=0;
	//spmsg.ostatus("");
	//SetEvent(hEvent_class_ow_PlayEnd);
	return 1;
}

int owave0_::
thplay(short* sh, int shsize, pcmfmt_* pcm)
{
	//stopclose();
  reset();
	if(bBangImDiong) {//stopclose();Sleep(20);}
    int nwait=0;
    while(1){
      if(!bBangImDiong)break;
      //stopclose();//Sleep(20);
      reset();
      //close();
      nwait++; if(nwait>5) break;
    }
  }
  if(bBangImDiong) return 0;
	//if(!mfb.mfr.isOK()) mfb.open(mfname.s);
	//if(mfb.mfr.isERR()) return;
	//stopclose();
	//if(!stopped){Sleep(10 );stopclose();}
	//if(!stopped){Sleep(100);stopclose();}
	//if(!stopped) return;
	//stopped=stopall=0;
	if(threader.hnd) return 0;
	if(!threader.del()) return 0;
	//spprng.set2Nhun(s);
	//spprng.set2Nhunhanlor(s);
  sh0=sh;shsize0=shsize;pcm0=pcm;
	threader.start(splay, this);
  return 1;
}

int owave0_::
ispcmsupported()
{
  res=waveOutOpen(NULL,WAVE_MAPPER, (LPWAVEFORMATEX)&wfx, NULL, NULL, WAVE_FORMAT_QUERY);
	return MMSYSERR_NOERROR==res;
}

//*********************************************************************
//**  END of class owave_
//*********************************************************************
//*********************************************************************



//*********************************************************************
//*********************************************************************
//**  BEGIN of  class ospeech
//*********************************************************************

owave_ owdef;

int owave_::play (short* sh, int sz, pcmfmt_* pcm)
{return owdef0.play(sh,sz,pcm);}

int owave_::open (pcmfmt_* wfmt1)
{return owdef0.open (wfmt1);}

int owave_::close( )
{return owdef0.close();}

int owave_::isplaying()
{ return owdef0.bBangImDiong;}

void owave_::wait2end()
{ WaitForSingleObject(hEvent_class_ow_PlayEnd,INFINITE);}

int  owave_::stopclose()
{
	if(owdef0.bBangImDiong) {
		owdef0.reset();    owdef0.close(); //Sleep(5);
		//owdef0.bBangImDiong=0;
	}else
		owdef0.close();
	return 1;
}

int owave_::thplay(short* sh, int sz, pcmfmt_*fmt)
{
  return owdef0.thplay(sh,sz,fmt);
}



class playthread_ { public:
	HANDLE      hnd()  { return threader.hnd;  }
	threader1_  threader;
	qiimbuf_* 	qiimbuf;
	static void play(void*pv){
                    if(!pv)return;
                    qiimbuf_* qb=((playthread_*)pv)->qiimbuf;
                    if(!qb)return;
                    qb->play();
  }
  void        start(qiimbuf_* qbuf);
};

void playthread_::start(qiimbuf_* qbuf1)
{
	owdef.stopclose();
	if(!threader.del()) return;
	if(threader.hnd) return;
  qiimbuf=qbuf1;
	threader.start(play, this);
}

static playthread_ playthreaddef;

void threadplay(qiimbuf_*qbuf)
{
  if(!qbuf) return;
  playthreaddef.start(qbuf);
}




void playrange0_::stopclose()
{
	stopall=1;
	owdef.stopclose();
	int n=0;while(!stopped){stopall=1;Sleep(10);n++; if(n>2) break; }
	//if(!stopped){CloseHandle(threader.hnd); threader.hnd=0;}
	owdef.stopclose();
}

void playrange0_::start(char* fnames, char* pname1)
{
		stopclose();
		if(!stopped){Sleep(10);stopclose();}//if(!stopped) return;}
		if(!stopped){Sleep(100);stopclose();if(!stopped) return;}
		stopped=stopall=0;
		if(!threader.del()) return;
		if(threader.hnd) return;
		pname=(pname1)?pname1:"";
		if(pname.isG())if(!pname.ew("\\"))pname+="\\";
		spprng.set2Nhunhanlor(fnames);
		threader.start(play, this);
}
static int playjunk;
void playrange0_::endplay(int ith, qiimbuf_& qbuf)
{
	//if(stopped)
	//	playjunk++;
}
void playrange0_::begplay(int ith, qiimbuf_& qbuf)
{
	//if(stopped)
	//	playjunk++;
}

void playrange0_::vplay()
{
	//if(!pv) return;	playrange0_* p=	(playrange0_*)pv;
	stopped=0; int pause;
	static chars s;// int noplay=0;
	for(int i=0; i<spprng.size(); i++) {
		if(stopall) break;
		s=pname;
		s+=spprng[i];
		if(s.bw("#")) {
			pause=s2i(s.s+1);
			Sleep(pause);
			continue;
		}
		if(stopall) break;
		//if(!s.ew(".sp")) s+=".sp";
		if(!ckfname(s)) continue;
		if(!(s.ew(".wav")||s.ew(".sp")))
			s.app(".wav");
		if(!qbuf.read(s.s  ))
			if(!qbuf.read(s.s+2)) {
				s.deleif(".wav");s.appifen(".sp");
				if(!qbuf.read(s.s))
					if(!qbuf.read(s.s+2))
						continue;
			}
		if(stopall) break;
		begplay(i, qbuf);
		if(stopall) break;
		qbuf.play();
		if(stopall) break;
		endplay(i, qbuf);
		if(stopall) break;
	}
	stopped=1;
}

void playdaiqi_::vplay()
{
	//if(!pv) return;	playrange0_* p=	(playrange0_*)pv;
	stopped=0; int pause;
	static chars s, cs1;// int noplay=0;
	float emph;
	for(int i=0; i<spprng.size(); i++) {
		if(stopall) break;
		cs1=spprng[i];
		if(cs1.bw("#")) {
			pause=s2i(cs1.s+1);
			Sleep(pause);
			continue;
		}
		if(stopall) break;
		csfname4play1daiqi(cs1,emph);
		s=pname; s+=cs1;
		if(stopall) break;
		if(!qbuf.read(s.s  ))
		if(!qbuf.read(s.s+2)) {
			if(s.ew(".sp")) s.dele(3);
			if(isdigit(s.eB())) continue; // not the problem of no sianndiau
			s+="1.sp";
			if(!qbuf.read(s.s))
			if(!qbuf.read(s.s+2)) continue;
		}
		if(stopall) break;
		if(emph>0)
			qbuf.hongdua(emph);
		if(stopall) break;
		begplay(i, qbuf);
		if(stopall) break;
		qbuf.play();
		if(stopall) break;
		endplay(i, qbuf);
		if(stopall) break;
	}
	stopped=1;
}






void playbase::stopclose(int sleepms)
{
	stopall=1;
	owdef.stopclose();
	int n=0;while(!stopped){stopall=1;Sleep(10);n++; if(n>2) break; }
	owdef.stopclose();
	if(sleepms>0) Sleep(sleepms);
}





void	mftts_::	play	(char* s)
{
	if(!mfb.mfr.isOK()) mfb.open(mfname.s);
	if(mfb.mfr.isERR()) return;
	static charspp cspp; static chars cs;  static qiimbuf_ qb;
	char* t; int len;
	cspp.set2Nhunhanlor(s);
	for(int n=0; n<cspp.size(); n++){
		cs=cspp[n];
		if(!cs.ewdigit()) cs+="1"; cs.appifen(".sp");
		int n=mfb.ndx(cs.s);//dzb.bfind(cs.s);
		if(stopall) break;
		if(n<0) continue;
		t=mfb.sfbeg(n); len=mfb.sfsize(n);
		qb.readp(t,len);
		if(stopall) break;
		qb.play();
		if(stopall) break;
	}
}

void mftts_::stopclose()
{
	stopall=1;
	owdef.stopclose();
	int n=0;while(!stopped){stopall=1;Sleep(10);n++; if(n>2) break; }
	owdef.stopclose();
}

void mftts_::thplay(char* s)
{
	if(!mfb.mfr.isOK()) mfb.open(mfname.s);
	if(mfb.mfr.isERR()) return;
	stopclose();
	if(!stopped){Sleep(10 );stopclose();}
	if(!stopped){Sleep(100);stopclose();}
	if(!stopped) return;
	stopped=stopall=0;
	if(!threader.del()) return;
	if(threader.hnd) return;
	//spprng.set2Nhun(s);
	spprng.set2Nhunhanlor(s);
	threader.start(splay, this);
}


void mftts_::vplay()
{
	stopped=0; int pause;  int nn;
	static chars cs;
	for(int i=0; i<spprng.size(); i++) {
		if(stopall) break;
		cs=spprng[i];
		if(cs.bw("#")) {
			pause=s2i(cs.s+1);
			Sleep(pause);
			continue;
		}
		if(stopall) break;
		if(!ckfname(cs)) continue;
		//cs.appifen(".sp");
		nn=mfb.ndx(cs.s);
		if(nn<0) continue;
		qbuf.readp(mfb.sfbeg(nn), mfb.sfsize(nn));
		if(stopall) break;
		begplay(i, qbuf);
		if(stopall) break;
		qbuf.play();
		if(stopall) break;
		endplay(i, qbuf);
		if(stopall) break;
	}
	stopped=1;
}

void daiqimftts_::vplay()
{
	stopped=0; int pause; int nn;
	static chars cs, cs1;// int noplay=0;
	float emph;
	for(int i=0; i<spprng.size(); i++) {
		if(stopall) break;
		cs1=spprng[i];
		if(cs1.bw("#")) {
			pause=s2i(cs1.s+1);
			Sleep(pause);
			continue;
		}
		if(stopall) break;
		csfname4play1daiqi(cs1,emph);
		cs=cs1;
		if(stopall) break;
		nn=mfb.ndx(cs.s);
		if(nn<0) continue;
		qbuf.readp(mfb.sfbeg(nn), mfb.sfsize(nn));
		if(stopall) break;
		if(emph>0)
			qbuf.hongdua(emph);
		if(stopall) break;
		begplay(i, qbuf);
		if(stopall) break;
		qbuf.play();
		if(stopall) break;
		endplay(i, qbuf);
		if(stopall) break;
	}
	stopped=1;
}




//*********************************************************************
//**  END of class ospeech
//*********************************************************************
//*********************************************************************


float*iwhdrbuf_::dnsmp2spt(ehfs_& ehfs, int nFS, int dnsmp, int dboff)
{
	int n,dn;
	for(n=0, dn=0; n<nFS; n+=dnsmp, dn++) shs[dn]=sh[n];
	nFS=nFS/dnsmp;
	if(dboff){
		int sum=0;
		for(dn=0; dn<nFS; dn++) sum+=shs[dn];sum=sum/nFS;
    for(dn=0; dn<nFS; dn++) shs[n]-=sum;
  }
  ehfs.fs1(shs, nFS, fts);
  return fts;
}



void    iwetc_::  setiwhb(int iwhb_uselen)
{
  int m;
  for(m=0; m<MIB; m++) {
    iwhb[m].hdr20();
    iwhb[m].set2(m, shallhb+1024*m);
    iwhb[m].hdr.dwBufferLength=iwhb_uselen*sizeof(short);
    //iwhb[m].dwRecordLength=iwhb_uselen*sizeof(short);
  }
}

void    iwetc_::setpcm (pcmfmt_& pcm)
{
	pcm.set4wfex(); pcm.set2(nsrt, nchl, nBps*8);
}


void    iwetc_::set4(int iwcase1)
{
  csbe(iwcase1,int(sr08K), int(sr44K)+1);
  if(iwcase==iwcase1) return;
  iwcase=iwcase1;
  nchl=1;nBps=2; adaptset=0;
  switch(iwcase){
	case sr08K:
			nsrt=8000;nspd=1250;
			nFS=128; //nSS=64;    // 16ms per frame
			//dnsmp=1; nFFT=128;
			dnsmp=2; nFFT=64;
			break;
	case sr16K:
			nsrt=16000;nspd=625;
			nFS=256; //nSS=128;   // 16ms per frame
			//dnsmp=2; nFFT=128;
			dnsmp=4; nFFT=64;
			break;
	case sr32K:
			nsrt=32000;nspd=312;
			nFS=512; //nSS=256;   // 16ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=8; nFFT=64;
			break;
	case sr48K:
			nsrt=48000;nspd=208;
			nFS=1024; //nSS=256;   // 21.3ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=16; nFFT=64;
			break;
	case sr64K:
			nsrt=64000;nspd=156;
			nFS=1024; //nSS=256;   // 16ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=16; nFFT=64;
			break;
	case sr11K:
			nsrt=11025;nspd=907;
			nFS=128; //nSS=64;    // 11.6ms per frame
			//dnsmp=1; nFFT=128;
			dnsmp=2; nFFT=64;
			break;
	case sr22K:
			nsrt=22050;nspd=456;
			nFS=256; //nSS=128;   // 11.6ms per frame
			//dnsmp=2; nFFT=128;
			dnsmp=4; nFFT=64;
			break;
	case sr44K:
			nsrt=44100;nspd=227;
			nFS=1024; //nSS=256;   // 23.2ms per frame
			//dnsmp=4; nFFT=128;
			dnsmp=16; nFFT=64;
			break;
	}
	setiwhb(nFS);
}

int  iwetc_::ssc         (iwhdrbuf_& iwhb, int forbegin)// always w/ dboff, and dnsample
{
	float* spt=iwhb.dnsmp2spt(ehfs, nFS, dnsmp, 1 );
	int n, NN=nFFT/2, cnt=0; float* cut=(forbegin)?cutb:cute;
  for(n=1; n<NN; n++) if(spt[n]>cut[n]) cnt++;
	return cnt;
}

int     iwetc_::readsetadapt   (char* fn,char*pn)// if(0) use "4adapt.sp"
{
	if(!fn) fn="4adapt.sp";
  if(!adbuf.read(fn, pn))return 0;
  if(adbuf.ssize()<256)return 0;
  return setadapt(&adbuf);
}


int     iwetc_::setadapt    (qiimbuf_* qb1)// if(0) use in-class qbuf, else copy
{
  qiimbuf_ &qb=(qb1)?(*qb1):adbuf;
  if(!qb.rmb(nFS)) return 0;
  int dnsmporg=dnsmp; int nFSorg=nFS; int qbsr=qb.pcm.sr();
	if(qbsr!=nsrt) {
    int tt=qbsr/nsrt;
    if(tt*nsrt != qbsr) return 0;
    dnsmp=tt*dnsmp; nFS=nFS*tt;
  }
	dbbias=qb.mean();
  float     spt [MFRMSZ ]; // spt: spectrogram
  float     avg [HMFRMSZ]; // the mean vector of the background noise
  float     var [HMFRMSZ]; // the variance vector of the background noise
  //qb-=dbbias;
  memset(avg,0,sizeof(short)*nFSorg/4);
  memset(var,0,sizeof(short)*nFSorg/4);
  //int n, NN=nframes(qb), m, M=nFFT/2;
  int n, NN, m, M=nFFT/2;
  NN=qb.nshused/(nFS);
  for(n=0; n<NN; n++) {
    //sh2spt(qb.sh+beg4nthframe(n), nFS, spt, nFFT, dnsmp);
		//sh2spt(qb.sh+nFS*n, nFS, spt, nFFT, dnsmp);
    sh2spt_woff(qb.sh+nFS*n, nFS, spt, nFFT, dnsmp);
    for(m=0; m<M; m++){
      avg[m]+=spt[m];
      var[m]+=spt[m]*spt[m];
		}
  }
  for(m=0; m<M; m++){
    avg[m]=avg[m]/NN;
    var[m]=var[m]/NN-avg[m]*avg[m];
    if(var[m]<0) var[m]=0;
    var[m]=sqrt(var[m]);
  }
  int gaps[]=     {0,    M/4,   M*4/5,  M};
  float bstimes[]={ 3,      3,        3};
  float estimes[]={ 2.5,    2.5,      2};
  for(int g=0; g<sizeof(gaps)/sizeof(int)-1; g++) {
	for(m=gaps[g]; m<gaps[g+1]; m++){
    //cutb[m]=var[m]*bsigmatimes;
    //cute[m]=var[m]*esigmatimes;
    cutb[m]=(avg[m]+var[m]*bstimes[g]);
    cute[m]=(avg[m]+var[m]*estimes[g]);
	}
  }
  nFS=nFSorg; dnsmp=dnsmporg;
  adaptset=1;
  return 1;
}








HANDLE lokim1_::hEventLokimEnd;
HANDLE lokim3_::hEventLokimEnd;


// return qbuf1.ssize() if success,
// this can illustrate the process of doing wave-in in simple situ
// will hang the system for qbuf1.ms()
int lokim1_::startlokim(qiimbuf_ & qbuf, int nsh)
{
  qbuf.reserve(nsh);
  ResetEvent(hEventLokimEnd);
      //[1] waveopen, fill-in wfx first
  //HWAVEIN hwi;
  WAVEFORMATEX wfx; wfx=qbuf.pcm.wfex; // or set it yourself, mainly sampling rate
 	res= waveInOpen(&hwi,WAVE_MAPPER,(LPWAVEFORMATEX)&(wfx),
									(DWORD)waveInProc,(DWORD)this,	CALLBACK_FUNCTION);
                  //(DWORD)this will be arg to waveInProc,
                  // not used here, but useful elsewhere
	bOpened=(res==MMSYSERR_NOERROR);
  if(!bOpened) return 0;
			//[2]  prepare the wavein buf, fill-in WAVEHDR first
  WAVEHDR hdr; memset(&hdr,0,sizeof(hdr));
  hdr.lpData=(LPSTR)(qbuf.sh);
  hdr.dwBufferLength=nsh*sizeof(short);
  res= waveInPrepareHeader(hwi,   &hdr,  sizeof(WAVEHDR) );//should check res
      //[3] addwavein buf
  res= waveInAddBuffer    (hwi,   &hdr,  sizeof(WAVEHDR) );//should check res
      //[4] start recording
  res= waveInStart(hwi);// should check result
      //[5]  wait for wavein to return
  WaitForSingleObject(hEventLokimEnd, nsh/8);//INFINITE);// change to 2*qbuf.ms()
      //[6]  unprepare wavein buf
	qbuf.nshused=hdr.dwBytesRecorded/sizeof(short);
	qbuf.setbytesize();
	res= waveInUnprepareHeader(hwi,   &hdr,  sizeof(WAVEHDR) );//should check res
			//[7]  stop will only cause current buf done
	res=waveInStop(hwi);// not necessary?
			//[8]  reset will cause all buf's done
			//since end normally, no reset is required here, but call it anyway
	res=waveInReset(hwi);
			//[9]  close waveinv
	res=waveInClose(hwi);// should check res
	return qbuf.ssize();
}

void CALLBACK lokim1_::
waveInProc(HWAVEIN hwi,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	switch (uMsg) {
	case WIM_OPEN:
		break;
	case WIM_CLOSE:
		break;
	case WIM_DATA:
    SetEvent(hEventLokimEnd);
		break;
	}
}

int  lokim2_::startth(qiimbuf_& qbuf1, int nsh1, VFNV callback1)
{
  p2qbuf=&qbuf1; nsh=nsh1; callbackfn=callback1;
  p2qbuf->reserve(nsh);
  lokimstop();
  thrd.start(thrdfunc, this);
  return 1;
}

void lokim2_::thrdfunc(void* arg)
{
  lokim2_&tt=*((lokim2_*)arg);
  tt.startlokim(*(tt.p2qbuf), tt.nsh);
	tt.thrd.del();
  if(tt.callbackfn) (*(tt.callbackfn))();
  else tt.callback();
}






//static
void lokim3_::threadfn(void*pv)
{
  lokim3_&tt=*((lokim3_*)pv);
	tt.startlokim();
  tt.thrd.del();
  if(tt.callbackfn) (*(tt.callbackfn))();
	else tt.callback();
}

void CALLBACK lokim3_::
waveInProc(HWAVEIN hwi,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	iwhdrbuf_* p2whb; lokim3_ *p2iw;
	switch (uMsg) {
	case WIM_OPEN:
		break;
	case WIM_CLOSE:
		p2iw =(lokim3_*) dwInst;
    p2iw->ended=1;
    SetEvent(hEventLokimEnd);
		break;
	case WIM_DATA:
	  p2whb=(iwhdrbuf_  *) dwPrm1;
		p2iw =(lokim3_*) dwInst;
		//p2whb->adjust_bias();
		p2iw->wavein(p2whb);
		p2iw->set2idle(p2whb->id);
		break;
	}
}

int   lokim3_::wavein  (iwhdrbuf_* p2whb)
{
  int res=0; int len=p2whb->size();
  if(p2qbuf->hasroom4ins  (len)) {
		p2qbuf->app(p2whb->sh, len);
		res=1;
	}else ended=1;
	return res;
}



int   lokim3_::  startth(qiimbuf_& qbuf1, int nsh1, VFNV callback1)
{
	lokimstop();
	thrd.del();
	lokimstop();
	p2qbuf=&qbuf1; nsh=nsh1; callbackfn=callback1;
	p2qbuf->reserve(nsh1);
	thrd.start(threadfn, this);
	return 0;
}


int   lokim3_::  startth(qiimbuf_& qbuf1, int nsh1, feabuf_& fbuf1, int nthset1)
{ //fbuf1/nthset1 is not used, just 4 conven.
	lokimstop();
	thrd.del();
	lokimstop();
	p2qbuf=&qbuf1; nsh=nsh1;
	p2fbuf=&fbuf1; nthset=nthset1; callbackfn=0;
	p2qbuf->reserve(nsh1);
	thrd.start(threadfn, this);
	return 0;
}


int   lokim3_::  startlokim ()
{
	int sleeptime=iwe.nFS*1000./iwe.nsrt/1.5;//20;// should set it to time for 1 frame
  res=waveInReset(hwi);
	res=waveInStop(hwi);

  ResetEvent(hEventLokimEnd);
	reset4be(); //beged=0; ended=0;

  pcmfmt_ pcm; iwe.setpcm(pcm);//pcm.set4wfex();
 	res= waveInOpen(&hwi,WAVE_MAPPER,(LPWAVEFORMATEX)&(pcm.wfex),// &wfx,
              		(DWORD)waveInProc,(DWORD)this,	CALLBACK_FUNCTION);
                  //(DWORD)this will be arg to waveInProc,
	bOpened=(res==MMSYSERR_NOERROR);
  if(!bOpened) return 0;

  iwe.setiwhb(iwe.nFS);
  idlesprp();
  idlesadd();
  showstatus(IW_DAN);
	res= waveInStart(hwi);// should check result

  while(!ended){
    Sleep(sleeptime);
		dowhenidle ();
  }

  res=waveInReset(hwi);
  res=waveInStop(hwi);// not necessary?

  idlesunp();
  all2idle();

	res=waveInClose(hwi);// should check res
  if(p2qbuf) p2qbuf->setbytesize();
  showstatus(IW_TING);

  return 1;
}



int     lokim4_::  init4be   (iwetc_& iwe1 )
{ // inited one time
  nbDUR=3; neDUR=30; nBLURB=3;
  nbSIL=5; neSIL=10;
	//nbTDUR=nbDUR+nbSIL;
  nbBUFS=MBB;//-(nbTDUR);
  //nbDURc=nBEGBUF-(nbTDUR);
  //begbuf=begbuf0+(nbTDUR+1)*iwe1.nFS;
  //begbuf=begbuf0+(nbTDUR+1)*256;//iwe1.nFS;
  bTHRS=10; eTHRS=4;
  return 0;
}

void    lokim4_::  reset4be  ()
{ // reset for each lokim
  beged=ended=nbbnxt=nbdur=nedur=nblurb=nbsil=0;
  begbuf=begbuf0+(1)*iwe.nFS;
	//begbuf=begbuf0+(nbTDUR+1)*iwe.nFS;
}

int     lokim4_::  forbeg(iwhdrbuf_* p2whb)
{
	if(beged) return 0;
  int res=forbegssc(p2whb);
  if(res) nbdur++; else nbdur=0;
  if(nbdur>=nbDUR) beged=1;
  p2whb->copy2(begbuf+nbbnxt*iwe.nFS);
  nbbnxt++; if(nbbnxt>=nbBUFS) { nbbnxt=0; }
  nbsil++;  if(nbsil>nbSIL) nbsil=nbSIL;
  if(!beged) {
		return 1;
  }
  //fill qbuf at front;
	p2qbuf->nshused=0; int TBEG=nbsil+nbDUR;
  if      (nbsil < nbSIL){//happen if user speaker too early
		p2qbuf->app(begbuf, TBEG*iwe.nFS);
  }else if(nbbnxt>=TBEG ){
    p2qbuf->app(begbuf+(nbbnxt-TBEG)*iwe.nFS, TBEG*iwe.nFS);
  }else{
    p2qbuf->app(begbuf+(MBB-(TBEG-nbbnxt))*iwe.nFS, (TBEG-nbbnxt)*iwe.nFS);
    if(nbbnxt>0)
    p2qbuf->app(begbuf, nbbnxt*iwe.nFS);
  }
	//p2qbuf->app(p2whb->sh, iwe.nFS);
  //p2qbuf->app(begbuf+(nbbnxt-nbTDUR)*iwe.nFS, nbTDUR*iwe.nFS);
  showstatus(IW_LOK);
  return 1;
}


int     lokim4_::  forend(iwhdrbuf_* p2whb)
{
	if(ended) return 0;
  int res=forendssc(p2whb);// ssc under some level
	if( res ) {
  	nedur++; nblurb=0;
  }else{
  	nblurb++; if(nblurb>nBLURB) { nedur=0; nblurb=0; }
  }
  p2qbuf->app(p2whb->sh, p2whb->size());
	if(nedur>=neDUR) { ended=1; return 0; }
  if(!p2qbuf->hasroom4ins(p2whb->size())){ ended=1; return 0; }
	return 1;
}

int   lokim4_::wavein  (iwhdrbuf_* p2whb)
{
  if(ended) return 0;
  if(iwe.dboff)p2whb->sub(iwe.dbbias);
  int res=(beged)?forend(p2whb):forbeg(p2whb);
  if(res) return 1;
  return 0;
}




/*
int     lokim4_::  forbeg(iwhdrbuf_* p2whb)
{
	if(beged) return 0;
	p2whb->copy2(begbuf+nbbnxt*iwe.nFS);
  if(nbbnxt>=nbDURc)
  p2whb->copy2(begbuf+(nbbnxt-nbTDUR)*iwe.nFS);
  //p2whb->copy2(begbuf+(nbbnxt-nBEGBUF)*iwe.nFS);
  nbbnxt++; if(nbbnxt>=nBEGBUF) {nbsil=nbSIL; nbbnxt=0; }
  int res=forbegssc(p2whb);
  if(res) nbdur++; else nbdur=0;
  if(nbdur>=nbDUR) beged=1;
  if(!beged) return 1;
  //fill qbuf at front;
  p2qbuf->nshused=0;
  p2qbuf->app(begbuf+(nbbnxt-nbTDUR)*iwe.nFS, nbTDUR*iwe.nFS);
  showstatus(IW_LOK);
  return 1;
}

int     lokim4_::  forbeg(iwhdrbuf_* p2whb)
{
	if(beged) return 0;
  int res=forbegssc(p2whb);
  if(res) nbdur++; else nbdur=0;
  if(nbdur>=nbDUR) beged=1;
  if(!beged) {
    p2whb->copy2(begbuf+nbbnxt*iwe.nFS);
    nbbnxt++; if(nbbnxt>=nbBUFS) { nbbnxt=0; }
    nbsil++;  if(nbsil>nbSIL) nbsil=nbSIL;
    return 1;
  }
  //fill qbuf at front;
  p2qbuf->nshused=0;
  if(nbbnxt<nbTDUR){
    p2qbuf->app(begbuf+(nBEGBUF-(nbTDUR-nbbnxt))*iwe.nFS, (nbTDUR-nbbnxt)*iwe.nFS);
    p2qbuf->app(begbuf, nbbnxt*iwe.nFS);
  }else{
		p2qbuf->app(begbuf+(nbbnxt-nbTDUR+1)*iwe.nFS, (nbTDUR-1)*iwe.nFS);
  }
  p2qbuf->app(p2whb->sh, iwe.nFS);
  //p2qbuf->app(begbuf+(nbbnxt-nbTDUR)*iwe.nFS, nbTDUR*iwe.nFS);
  showstatus(IW_LOK);
  return 1;
}


*/

















#ifdef DQSOLDOLDOLD

//*********************************************************************
//*********************************************************************
//**  BEG of class winwavehdrdata
//*********************************************************************

short wavinhdrbuf_::dbbias=1;


int wavinhdrbuf_::
init(short Lnorm1)
{
	memset(this, 0, sizeof(*this));
  Lnorm=Lnorm1;
	id=0;
	dwBufferLength=nDQS_FSS*nDQS_BYTES;
	lpData = (LPSTR)sh;
	dwFlags = 0L;
	dwLoops = 0L;
	return 1;
}

//FFT_<1024> wavinhdrbuf_::fft;
rcfft_ wavinhdrbuf_::fft;

float wavinhdrbuf_::fftoff(int from, double off)
{
	if(!sh) return 0;
  float fsig[1024];
  int nn;
  fft.sh2ft(fsig, sh, nDQS_FSS);
  //fft.short2float(fsig, sh, nDQS_FSS);
	//fft.rfft1(fsig-1, nDQS_FSS/2); // -1 since 1-based
	fft.rfft1(fsig-1, nDQS_FSS); // -1 since 1-based
	//fft.rfft(fsig, nDQS_FSS);
  double tot=0;
  int cnt=nDQS_FSS/2;
	for(nn=from; nn<cnt/4; nn++) {
  	if(fsig[nn]>off) tot+=(fsig[nn]-off);
  }
	for(nn=cnt/4; nn<cnt*2/3; nn++) {
  	if(fsig[nn]>off) tot+=(fsig[nn]-off)*4;
  }
  //for(nn=nn<cnt*2/3; nn<cnt; nn++) {
  for(nn=cnt*2/3; nn<cnt; nn++) {
  	if(fsig[nn]>off) tot+=(fsig[nn]-off)*2;
  }
  return float(tot);
}

float wavinhdrbuf_::fftoff(int from, float* off)
{
	if(!sh) return 0;
  float fsig[1024];
  int nn;
  fft.sh2ft(fsig, sh, nDQS_FSS);
  //fft.short2float(fsig, sh, nDQS_FSS);
	//fft.rfft1(fsig-1, nDQS_FSS/2); //-1, since 1-based
	fft.rfft1(fsig-1, nDQS_FSS); //-1, since 1-based
	//fft.rfft(fsig, nDQS_FSS);
  float tot=0;
  int cnt=nDQS_FSS/2;

  for(nn=from; nn<cnt/16; nn++) {
  	if(fsig[nn]>off[nn])
    	tot+=(fsig[nn]-off[nn]);
  }
  for(nn=cnt/16; nn<cnt/4; nn++) {
  	if(fsig[nn]>off[nn])
			tot+=(fsig[nn]-off[nn])*3;
  }
  for(nn=cnt/4; nn<cnt*2/3; nn++) {
  	if(fsig[nn]>off[nn])
    	tot+=(fsig[nn]-off[nn])*4;
	}
  //for(nn=nn<cnt*2/3; nn<cnt; nn++) {
  for(nn=cnt*2/3; nn<cnt; nn++) {
  	if(fsig[nn]>off[nn])
    	tot+=(fsig[nn]-off[nn])*3;
  }
  return tot;
}

float wavinhdrbuf_::
fftoff(float* off, float* offlmtwghts, int Nlmtwghts)
{
	if(!sh) return 0;
  float fsig[1024];
  fft.sh2ft(fsig, sh, nDQS_FSS);
	//fft.rfft1(fsig-1, nDQS_FSS/2); //-1, since 1-based
	fft.rfft1(fsig-1, nDQS_FSS); //-1, since 1-based
	//fft.short2float(fsig, sh, nDQS_FSS);
  //fft.rfft(fsig, nDQS_FSS);
  float tot=0;
  //int cnt=nDQS_FSS/2;

  int nn=0; int L, W;
	for(int NN=0; NN<Nlmtwghts; NN++) {
  	L=int(offlmtwghts[NN*2]);// odd num elem's are limits
    W=int(offlmtwghts[NN*2+1]);	// even num elem's are weights
  	for( ; nn<L; nn++) {				// last limits must be nDQS_FSS/2
			if(fsig[nn]>off[nn])
    	tot+=(fsig[nn]-off[nn])*W;
	  }
  }
  return tot;
}


float wavinhdrbuf_::
avgenergy()
{
	if(!sh) return 0;
  double tot=0;
  short* ps=sh;
	int sz=bsize()/sizeof(short);
  for(register i=0; i<sz;i++)
  if(Lnorm==1){	if(*ps>0) tot += *ps; else tot -= *ps; ps++; }
  else 				{ tot+= (*ps)*(*ps); ps++; }
  return (float)tot/sz;
}

float wavinhdrbuf_::
bias()
{
	if(!sh) return 0;
  int tot=0;
  short* ps=sh;
	int sz=bsize()/sizeof(short);
  for(register i=0; i<sz;i++)
	tot += *ps++;
  return float(tot)/sz;
}

void wavinhdrbuf_::
adjust_bias()
{
  if(dbbias==0) return;
	if(!sh) return ;
  short* ps=sh;
	int sz=bsize()/sizeof(short);
  for(register i=0; i<sz;i++)
	*ps++ -= dbbias;
}

//*********************************************************************
//**  END of class winwavehedrbuf
//*********************************************************************
//*********************************************************************
#endif //#ifdef DQSOLDOLDOLD



#ifdef DQSOLDOLDOLD


/*
void rcfft_:: cfftf(float *data, int nn, int isign)
{ //data: nn complex points, 1-based, faster version
	int n, mmax, m, j, istep, i;
	double wtemp, wr, wpr, wpi, wi, theta;
	double tempr, tempi;
	int sndx;

	n=nn<<1;

	if( (lastN!=nn)||(lastisign!=isign) ) {
		mmax=2; sndx=0;
		while(n>mmax) {
			theta=6.28318530717959/(isign*mmax);
			sinhalftheta[sndx]=sin(0.5*theta);
			sintheta    [sndx]=sin(theta);
			sndx++; mmax*=2;
		}
		if(lastN!=nn) { memset(bitrev, 0, sizeof(bitrev));
			j=1;
			for(i=1;i<n;i+=2) {
				if(j>i) bitrev[i]=(short)j;
				m=n>>1;
				while(m>=2 && j>m) { j -= m; m>>= 1; }
				j+=m;
			}
		}
		lastN=nn;lastisign=isign;
	}

	for(i=1; i<n; i+=2) { float ttt; // doing rearrangement
		if( (j=bitrev[i]) >0 ) {
			ttt=data[j  ]; data[j  ]=data[i  ]; data[i  ]=ttt;
			ttt=data[j+1]; data[j+1]=data[i+1]; data[i+1]=ttt;
		}
	}
	mmax=2; sndx=0;
	while(n>mmax) {
		istep=2*mmax;
		//theta=6.28318530717959/(isign*mmax);
		wtemp=sinhalftheta[sndx];//sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sintheta[sndx];//sin(theta);
		sndx++;
		wr=1.0;
		wi=0.0;
		for(m=1; m<mmax; m+=2) {
			for(i=m; i<=n; i+=istep) {
				j=i+mmax;
				tempr=wr*data[j  ]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j  ] =float(data[i  ]-tempr);
				data[j+1] =float(data[i+1]-tempi);
				data[i  ]+=float(tempr);
				data[i+1]+=float(tempi);
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}

void rcfft_:: cfftg(float *data, int nn, int isign)
{ //data: nn complex points, 1-based, arbitrary size
	int n, mmax, m, j, istep, i;
	double wtemp, wr, wpr, wpi, wi, theta;
	double tempr, tempi;
	n=nn<<1;
	j=1;
	for(i=1;i<n;i+=2) {
		if(j>i) {	float ttt;
			ttt=data[j  ]; data[j  ]=data[i  ]; data[i  ]=ttt;
			ttt=data[j+1]; data[j+1]=data[i+1]; data[i+1]=ttt;
		}
		m=n>>1;
		while(m>=2 && j>m) {
			j -= m;
			m>>= 1;
		}
		j+=m;
	}
	mmax=2;
	while(n>mmax) {
		istep=2*mmax;
		theta=6.28318530717959/(isign*mmax);
		wtemp=sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sin(theta);
		wr=1.0;
		wi=0.0;
		for(m=1; m<mmax; m+=2) {
			for(i=m; i<=n; i+=istep) {
				j=i+mmax;
				tempr=wr*data[j  ]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j  ] =float(data[i  ]-tempr);
				data[j+1] =float(data[i+1]-tempi);
				data[i  ]+=float(tempr);
				data[i+1]+=float(tempi);
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}

void rcfft_:: rfft1(float *data, int N, int isign)
{// data has 2N real points, 1-based
	int i, i1, i2, i3, i4, n2p3;
	double c1=0.5, c2, h1r, h1i, h2r, h2i;
	double wr, wi, wpr, wpi, wtemp, theta;
	//theta=3.141592653589793/(double)N;
	theta = 6.28318530717959 / (2.0 * N);
	if(isign==1) { c2=-0.5; cfft1(data, N, 1);}
	else         { c2= 0.5; theta=-theta;     }
	wtemp=sin(0.5*theta);
	wpr = -2.0*wtemp*wtemp;
	wpi=sin(theta);
	wr=1.0+wpr;
	wi=wpi;
	n2p3=N*2+3;
	for(i=2;i<N/2;i++){
		i4=1+(i3=n2p3-(i2=1+(i1=i+i-1)));
		h1r= c1*(data[i1]+data[i3]);
		h1i= c1*(data[i2]-data[i4]);
		h2r=-c2*(data[i2]+data[i4]);
		h2i= c2*(data[i1]-data[i3]);
		data[i1]= float(h1r+wr*h2r-wi*h2i);
		data[i2]= float(h1i+wr*h2i+wi*h2r);
		data[i3]= float(h1r-wr*h2r+wi*h2i);
		data[i4]=float(-h1i+wr*h2i+wi*h2r);
		wr=(wtemp=wr)*wpr-wi*wpi+wr;
		wi=wi*wpr+wtemp*wpi+wi;
	}
	if(isign==1) {
		data[1]=(h1r=data[1])+data[2];
		data[2]=float(h1r-data[2]);
	}else{
		data[1]=c1*((h1r=data[1])+data[2]);
		data[2]=float(c1*(h1r-data[2]));
		cfft1(data, N, -1);
	}
}

class   rcfft_ {
public: rcfft_():lastN(0),lastisign(0) {}
	void rfft0(float *x, int N, int isign=1){rfft1(x-1,N,isign);}//0based 2Nreals
	void cfft0(float *x, int N, int isign=1){cfft1(x-1,N,isign);}//0based Ncmplxs
	void rfft (float *x, int N, int isign=1){rfft1(x-1,N,isign);}//0based 2Nreals
	void cfft (float *x, int N, int isign=1){cfft1(x-1,N,isign);}//0based Ncmplxs
public:
	void rfft1(float *x, int N, int isign=1);//x: 2N reals,     1-based
	void cfft1(float *x, int N, int isign=1) //x:  N complexes, 1-based
						{if(N>512) cfftg(x,N,isign); else cfftf(x,N,isign);}
public:
	void sh2ft(float* x, short* sh, int N){float *f=x; short*s=sh;
						 for(int n=0;n<N;n++)	*f++ = float(*s++);	}
private:
	int 	lastN, lastisign;
	short bitrev[1025]; double sinhalftheta[9], sintheta[9]; //2^9=512
	void cfftf(float *x, int N, int isign=1);// faster version
	void cfftg(float *x, int N, int isign=1);// general version
};

void rcfft_:: cfftf(float *data, int nn, int isign)
{ //data: nn complex points, 1-based, faster version
	int n, mmax, m, j, istep, i;
	double wtemp, wr, wpr, wpi, wi, theta;
	double tempr, tempi;
	int sndx;

	n=nn<<1;

	if( (lastN!=nn)||(lastisign!=isign) ) {
		mmax=2; sndx=0;
		while(n>mmax) {
			theta=6.28318530717959/(isign*mmax);
			sinhalftheta[sndx]=sin(0.5*theta);
			sintheta    [sndx]=sin(theta);
			sndx++; mmax*=2;
		}
		if(lastN!=nn) { memset(bitrev, 0, sizeof(bitrev));
			j=1;
			for(i=1;i<n;i+=2) {
				if(j>i) bitrev[i]=(short)j;
				m=n>>1;
				while(m>=2 && j>m) { j -= m; m >>= 1; }
				j+=m;
			}
		}
		lastN=nn;lastisign=isign;
	}

	for(i=1; i<n; i+=2) { float ttt; // doing rearrangement
		if( (j=bitrev[i]) >0 ) {
			ttt=data[j  ]; data[j  ]=data[i  ]; data[i  ]=ttt;
			ttt=data[j+1]; data[j+1]=data[i+1]; data[i+1]=ttt;
		}
	}
	mmax=2; sndx=0;
	while(n>mmax) {
		istep=2*mmax;
		//theta=6.28318530717959/(isign*mmax);
		wtemp=sinhalftheta[sndx];//sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sintheta[sndx];//sin(theta);
		sndx++;
		wr=1.0;
		wi=0.0;
		for(m=1; m<mmax; m+=2) {
			for(i=m; i<=n; i+=istep) {
				j=i+mmax;
				tempr=wr*data[j  ]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j  ] =float(data[i  ]-tempr);
				data[j+1] =float(data[i+1]-tempi);
				data[i  ]+=float(tempr);
				data[i+1]+=float(tempi);
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}

void rcfft_:: cfftg(float *data, int nn, int isign)
{ //data: nn complex points, 1-based, arbitrary size
	int n, mmax, m, j, istep, i;
	double wtemp, wr, wpr, wpi, wi, theta;
	double tempr, tempi;
	n=nn<<1;
	j=1;
	for(i=1;i<n;i+=2) {
		if(j>i) {	float ttt;
			ttt=data[j  ]; data[j  ]=data[i  ]; data[i  ]=ttt;
			ttt=data[j+1]; data[j+1]=data[i+1]; data[i+1]=ttt;
		}
		m=n>>1;
		while(m>=2 && j>m) {
			j  -= m;
			m >>= 1;
		}
		j+=m;
	}
	mmax=2;
	while(n>mmax) {
		istep=2*mmax;
		theta=6.28318530717959/(isign*mmax);
		wtemp=sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sin(theta);
		wr=1.0;
		wi=0.0;
		for(m=1; m<mmax; m+=2) {
			for(i=m; i<=n; i+=istep) {
				j=i+mmax;
				tempr=wr*data[j  ]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j  ] =float(data[i  ]-tempr);
				data[j+1] =float(data[i+1]-tempi);
				data[i  ]+=float(tempr);
				data[i+1]+=float(tempi);
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}


void rcfft_:: rfft1(float *data, int N, int isign)
{// data has 2N real points, 1-based
	int i, i1, i2, i3, i4, n2p3;
	double c1=0.5, c2, h1r, h1i, h2r, h2i;
	double wr, wi, wpr, wpi, wtemp, theta;
	//theta=3.141592653589793/(double)N;
	theta = 6.28318530717959 / (2.0 * N);
	if(isign==1) { c2=-0.5; cfft1(data, N, 1);}
	else         { c2= 0.5; theta=-theta;     }
	wtemp=sin(0.5*theta);
	wpr = -2.0*wtemp*wtemp;
	wpi=sin(theta);
	wr=1.0+wpr;
	wi=wpi;
	n2p3=N*2+3;
	for(i=2;i<=N/2;i++){
		i4=1+(i3=n2p3-(i2=1+(i1=i+i-1)));
		h1r= c1*(data[i1]+data[i3]);
		h1i= c1*(data[i2]-data[i4]);
		h2r=-c2*(data[i2]+data[i4]);
		h2i= c2*(data[i1]-data[i3]);
		data[i1]= float(h1r+wr*h2r-wi*h2i);
		data[i2]= float(h1i+wr*h2i+wi*h2r);
		data[i3]= float(h1r-wr*h2r+wi*h2i);
		data[i4]=float(-h1i+wr*h2i+wi*h2r);
		wr=(wtemp=wr)*wpr-wi*wpi+wr;
		wi=wi*wpr+wtemp*wpi+wi;
	}
	if(isign==1) {
		data[1]=(h1r=data[1])+data[2];
		data[2]=float(h1r-data[2]);
	}else{
		data[1]=c1*((h1r=data[1])+data[2]);
		data[2]=float(c1*(h1r-data[2]));
		cfft1(data, N, -1);
	}
	//data[2]=0;  // for htk's ???, this will be same as matlab
							// data[0,1] should cor2 X[0], which has 0 img part
}

*/

//*********************************************************************
//*********************************************************************
//** BEG of class idlebuf_
//*********************************************************************

void idlebuf_::
init(HWAVEIN hwi)   // those need hwi
{
  for(int i=0; i<nDQS_MAXIDLEBUF; i++) {
		buf[i].prep(hwi);
		buf[i].add (hwi);
		idles[i]=0;
	}
}

void idlebuf_::
initidle ()
{
	for(int i=0;i<nDQS_MAXIDLEBUF;i++)
		{buf[i].init();buf[i].id=i;idles[i]=1;}
  n0=n1=nDQS_MAXIDLEBUF-1;
}

void idlebuf_::
all2driver (HWAVEIN hwi)
{
  int i;
  for(i=0;i<nDQS_MAXIDLEBUF;i++) {
    if(idles[i]) {
      buf[i].add(hwi);
      idles[i]=0;
    }
  }
}

//*********************************************************************
//** END of class idelbuf_
//*********************************************************************
//*********************************************************************

//*********************************************************************
//*********************************************************************
//** BEG of class iwavethread_
//*********************************************************************

int      iwavethread_::nblock=0;
idlebuf_ iwavethread_::bufs;

int iwavethread_::
stopclose()
{ int r;
	if(bOpened)	{
		r=stop();
		r=reset(); Sleep(10);
		all2idle();
	}
	bOpened=0;
	r=reset();   Sleep(10);
	all2idle();
	r=close();
	return r;
}


void iwavethread_::
dele_iwave()
{
	stopclose();
}

int iwavethread_::
open()
{
	nblock=0;
	res=waveInOpen(&hwi,WAVE_MAPPER,(LPWAVEFORMATEX)&wfx,
		(DWORD)waveInProc,(DWORD)this,	CALLBACK_FUNCTION);
	bOpened=(res==0);
	//if(!bOpened) { spthmsgDBG("\nopen fail\n"); }
	//if(!bOpened) { spthmsgDBG("\nspeech open fail\n"); }
	if(!bOpened) { spmsg.debug("\nspeech open fail\n"); }
	//else { spthmsgDBG("\nspeech open success\n"); }
	idle_init();
	return bOpened;
}


void CALLBACK iwavethread_::
waveInProc(HWAVEIN hwi,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	wavinhdrbuf_* p2whb; iwavethread_ *p2iw;
	switch (uMsg) {
	case WIM_OPEN:
		break;
	case WIM_CLOSE:
		break;
	case WIM_DATA:
		nblock++;
	  p2whb=(wavinhdrbuf_*) dwPrm1;
		p2iw =(iwavethread_*) dwInst;
		p2whb->adjust_bias();
		p2iw->VTIVSwavein(p2whb);
		p2iw->set2idle(p2whb->id);
		break;
	}
}

int iwavethread_::
setpcm(int nsamples, int nbits)
{
	//PCMWAVEFORMAT fmt; is superceded by wfx
	wfx.wFormatTag     =WAVE_FORMAT_PCM;
	wfx.nChannels      =1;
	wfx.nSamplesPerSec =nsamples;//16000L;
	wfx.nAvgBytesPerSec=nsamples*(nbits/8);
	wfx.nBlockAlign    =(WORD)((nbits==8)?1:2);
  wfx.wBitsPerSample =(WORD)nbits;
  wfx.cbSize         =0; // not really needed for WAVE_FORMAT_PCM
  return 1;
}

int iwavethread_::
ispcmsupported()
{
	res=waveInOpen(NULL,WAVE_MAPPER, (LPWAVEFORMATEX)&wfx, NULL, NULL, WAVE_FORMAT_QUERY);
	return MMSYSERR_NOERROR==res;
}



//*********************************************************************
//** END of class iwavethread_
//*********************************************************************
//*********************************************************************




//*********************************************************************
//*********************************************************************
//** BEG of class qiimbuf_
//*********************************************************************
//WTS_ wts(4.0, 4.0,3.0);




int WTS2_::
be4truncate(int nshort)
{
	CUTCNT=0;
	memset(cut, 0, sizeof(float)*nhrfft);
	memset(ct2, 0, sizeof(float)*nhrfft);
  if(nshort<=0) return 1;
	return init2(nshort);
}
/*
getfftcutoff(float* fftcut, float timessigma)
{
	int i,j; double ss; float t;
	for(j=0;j<nDQS_FSS/2;j++) {
		fftcfs[10][j]=0; ss=0;
		for(i=0; i<10; i++) {
			t=fftcfs[i][j];
			fftcfs[10][j]+=t;
			ss+=t*t;
		}
		fftcfs[10][j]/=10.0;
		fftcfs[10][j]+=float(sqrt(ss)/10.0*timessigma);
	}
	for(j=0;j<nDQS_FSS/2;j++)
		fftcut[j]=fftcfs[10][j];
	return 1;
}
*/
int WTS2_::
en4truncate()
{
	if(initERR()) return 0;
	int n;
	for(n=0;  n<nhrfft;  n++) cut[n] /=float(CUTCNT); // mean

	for(n=0; n<nhrfft; n++)	{
		ct2[n]=( ct2[n]/CUTCNT -cut[n]*cut[n] );
		ct2[n]=float( (ct2[n]>0)?sqrt(ct2[n]):0.0 ); // std
	}
	n=0;
	for(; n<nhrfft/4; n++)
		//{	cut[n]= cut[n]*sigmatimes ; }		// cutoff vector
		{	cut[n]= cut[n]+ct2[n]*sigmatimes/3 ;
		//{	cut[n]= cut[n]+ct2[n]*sigmatimes/2.5 ;
			if(cut[n]<0) cut[n]=0;}// cutoff vector
			//if(cut[n]<0) cut[n]=1;}// cutoff vector
	for(; n<nhrfft; n++)
		//{	cut[n]= cut[n]*sigmatimes ; }		// cutoff vector
		{	cut[n]= cut[n]+ct2[n]*sigmatimes ; }		// cutoff vector

	float scale1=0; //scale*b(e)times will be threshhold for beg(end)
	for(n=1; n<nhrfft; n++)	scale1 += ct2[n];// 0 is energy
  //scale1=sqrt(scale1);///(nhrfft*1.0);
  setscale(scale1, -1, -1);
	//bthresh=btimes*scale;
	//ethresh=etimes*scale;
	return 1;
}
void WTS2_::
setscale(float scale1,float btimes1, float etimes1)
{
	scale=scale1;
	if(btimes1>0)btimes=btimes1;
  if(etimes1>0)etimes=etimes1;
	bthresh=btimes*scale;
	ethresh=etimes*scale;
}


int WTS2_::
__4truncate(short* sh)
{
	if(initERR()) return 0;
  CUTCNT++;
  if(qbuf) {	if(CUTCNT*nobs< qbuf->nshalloc ){
			memmove(&(qbuf->sh[(CUTCNT-1)*nobs]), sh, sizeof(short)*nobs);
      qbuf->nshused=nobs*CUTCNT; qbuf->k=CUTCNT;qbuf->K=CUTCNT;
    }
  }
	conv2spec(flt, sh);// data is good for ft[0:nhrfft], squared
	float * f, *f1, *f2; int n;
	for(f=flt, f1=cut, f2=ct2, n=0; n<nhrfft; n++, f++) {
		*f1++ += *f;
		*f2++ += (*f)*(*f);
	}
	return 1;
}

void WTS2_::
conv2spec(float* ft, short* sh)
{ // data is good for ft[0:nhrfft]
	// put spec on ft, ft should have size 2*nhrfft, but spec have only nhrfft
	rcfft.sh2ft(ft,sh,nobs); 	int nrfft=nhrfft*2;
	if(nrfft>nobs)
		memset(ft+nobs, 0, sizeof(float)*(nrfft-nobs));
	rcfft.rfft1(ft-1, nhrfft); //-1, since 1-based
	//rcfft.rfft(ft, nhrfft);
	float *f1=ft, *f2=ft;
	for(int n=0; n<nhrfft; n++, f1++, f2+=2)
		f1[0] = f2[0]*f2[0]+f2[1]*f2[1];
}

int WTS2_::
convNtrunc(short* sh)
{
	if(!sh) return 0;
	conv2spec(flt, sh);// data is good for ft[0:nhrfft]
	float *f=flt, *c=cut; int n;
	for(n=0; n<nhrfft; n++, f++, c++) {
		if(*f>*c) *f -= *c; else *f=0;
	}
	return 1;
}

float WTS2_::
wts(short* sh, float* lws, int nlws)
{
	if(initERR()) return 0;
	convNtrunc(sh);
	float tot=0; float *f=flt; int L; float W;
	int nn, NN;
	nn=1; // !!! exclude nn=0
	for(NN=0; NN<nlws; NN+=2) {
		L=int(lws[NN]); W=lws[NN+1];
		for( ; nn<L; nn++) tot+= (*f++)*W;
	}
	return tot;
}

void WTS2_::
del()
{
	if(flt) delete[] flt;
	if(spc) delete[] spc;
	if(cut) delete[] cut;
	if(ct2) delete[] ct2;
	flt=spc=cut=ct2=0; nobs=0; nhrfft=0; initOK_=0;
}

int WTS2_::
init2(int nshort)
{
	if(nshort==nobs) return 1;
	if(nshort != nobs) {
		del();
		int t=2; while(t<nshort) t*=2; nhrfft=t/2;
		flt=new float[nhrfft*2];
		spc=new float[nhrfft];
		cut=new float[nhrfft];
		ct2=new float[nhrfft];
    if(!(flt&&spc&&cut&&ct2)){initOK_=0; return 0;}
    initOK_=1;
	}
	nobs=nshort;
	setbelws();
	if(flt&&spc&&cut&&ct2) return 1;
	return 0;
}

void WTS2_ ::
setbelws() //nshort: sizeof the short speech frame
{
	int fs=nhrfft;

	blws[0]=1.0;						elws[0]=1.0;
	blws[1]=0.0;						elws[1]=0.0;

	blws[2]=float(fs/16);		elws[2]=float(fs/16);
	blws[3]=1.0;						elws[3]=6.0;

	blws[4]=float(fs/4);		elws[4]=float(fs/4);
	blws[5]=3.0;						elws[5]=3.0;

	blws[6]=float(fs*2/3);	elws[6]=float(fs*2/3);
	blws[7]=4.0;						elws[7]=3.0;

	blws[8]=float(fs);			elws[8]=float(fs);
	blws[9]=3.0;						elws[9]=3.0;

	nblw=10; nelw=10;
}


/*
void qiimbuf_::saveHTKheader(tyio& o)
{
	int itemp; short stemp;
  itemp=nDQS_FSS*(k-nesil); o.write(&itemp, 4);	// in samples, not in bytes
  itemp=625; 								o.write(&itemp, 4); //=625 for 16K
  stemp=2; 									o.write(&stemp, 2);	//=2   2bytes per sample
  stemp=0; 									o.write(&stemp, 2);	//=0;  wavedata, HTK convention
  // total 12 bytes of header according to HTK
}

void qiimbuf_::saveHTK(char* fname, char* pname)
{
 	tyio o;	o.creat(fname,pname); if(o.isERR()) return;
  saveHTKheader(o);
	o.write(buf, sizeof(short)*nDQS_FSS*(k-nesil));
  o.close();
}
*/

//*********************************************************************
//** END of class qiimbuf_
//*********************************************************************
//*********************************************************************


//*********************************************************************
//*********************************************************************
//**  BEGIN of  class endpoint0_ and endpoint_
//*********************************************************************

void endpoint_::setDUR(int nkbDUR1, int nkeDUR1)
{
	if(nkbDUR1<0) nkbDUR= 4;else nkbDUR=nkbDUR1;
	if(nkeDUR1<0) nkeDUR=50;else nkeDUR=nkeDUR1;
	if(nkbsil>nDQS_MAXIDLEBUF-nkbDUR) nkbsil=nDQS_MAXIDLEBUF-nkbDUR;
 	if(nkesil>nkeDUR) { nkesil=nkeDUR; }
	//while( nkbDUR*nDQS_FSS < 8*160) nkbDUR++; //160 points for 10ms
	//while( nkeDUR*nDQS_FSS <40*160) nkeDUR++; //160 points for 10ms
	//nkbDUR=4;nkeDUR=40;
	//nkbDUR=nkbeg; nkeDUR=nkend;
}

void endpoint_::setsil(int nkbsil1, int nkesil1)
{
	if(nkbsil1>nDQS_MAXIDLEBUF-nkbDUR) nkbsil1=nDQS_MAXIDLEBUF-nkbDUR;
	nkbsil=nkbsil1;
	if(nkesil>nkeDUR) { nkesil1=nkeDUR; }
  nkesil=nkesil1;
}

void endpoint_::init4def(int bDBoff)
{
	//endpnter->init4def(bDBoff);
  buf=buf0+1;						//+1 4easier pre-emphasis
  bblurb=eblurb=0;
}

int endpoint_:: fillfront()
{
	fillfrontdone=0;
	int bfsize=nDQS_FSS*sizeof(short);
	memmove(allbuf,   buf+nxt *bfsize/2, (nkfront()-nxt)*bfsize);
	memmove(allbuf+ (nkfront()-nxt)*bfsize/2,  buf,   nxt *bfsize);
	fillfrontdone=1;
	return 1;
}

char* endpoint_:: status()
{
	static chars s; s.clear();
	s.appln ();
	s.apptab(tos(nkbdur));
	s.appln (tos(nkedur));
	return s.s;
}


int endpoint_::
forbeg0(wavinhdrbuf_* p2whb)
{
	if(beged) return 0;
	p2whb->copy2(buf+nxt*nDQS_FSS);
	nxt++; if(nxt>=nkfront()) nxt=0;
  if(forbeg(p2whb) ) nkbdur++; else nkbdur=0;
	if(nkbdur>=nkbDUR) beged=1;
	if(!beged) return 1;
	fillfront();// may need a thread to copy buf data
	return 1;
}

int endpoint_::
forend0(wavinhdrbuf_* p2whb, int* p2k)
{
	if(ended) return 0;
	//if( forend(p2whb) ) nkedur++; else nkedur=0;
	if( forend(p2whb) ) {
  	nkedur++; eblurb=0;
  }else{
  	eblurb++; if(eblurb>3) { nkedur=0; eblurb=0; }
	}
  p2whb->copy2(allbuf+(*p2k)*nDQS_FSS);  (*p2k)++;
	if(nkedur>=nkeDUR) { ended=1; return 0; }
	return 1;
}




void beL12_::
settimes(double dbtimes1, double detimes1)
{
	dbtimes=dbtimes; detimes=detimes1;
	setbackground(dback);
}

void beL12_::
setbackground(double dback1)
{
  dback=dback1;
  setthreshes( dback*dbtimes, dback*detimes );
}

void beL12_::
setthreshes(double dbeg, double dend)
{
	dbthresh=dbeg;  dethresh=dend;
}

void beL12_::init4def(int bDBoff)
{
	//endpoint_::init4def(bDBoff);
  if(bDBoff){ dbtimes=  9;   detimes= 36; }
  else		 	{ dbtimes=1.3;   detimes=1.5;	}
	//if(bDBoff){ fbtimes=(float)  3;   fetimes=(float)  7; }
  //else							{ fbtimes=(float)1.3;   fetimes=(float)1.5;	}
  //if(bDBoff){ fbtimes=(float)  5;   fetimes=(float)  7; }
  //else							{ fbtimes=(float)1.3;   fetimes=(float)1.7;	}
  setbackground(100);
}





int adaptation2_::
VTIVSwavein(wavinhdrbuf_* p2whb)
{
	if(k>=K) return 0;
  if(k<K){
		wts->__4truncate(p2whb->sh);
		k++;
	}
	if(k>=K) wts->en4truncate();
	return 1;
}

void adaptation2_::
VTVVwave()
{
	int sleeptime=20;
	init();
	openstart(); // Sleep(sleeptime);
	spmsg.istatus("  �վA��...");//Sleep(900);
	nblock=0;
	while (k<K) {
		if(k>=K) break;
		dowhenidle();
		Sleep(sleeptime);
	}
	stopclose(); all2idle(); Sleep(50);
	spmsg.istatus("");   Sleep(50);
	if(getsok) (*getsok)();
}



//*********************************************************************
//**  END of  class endpoint0_ and endpoint_
//*********************************************************************
//*********************************************************************

//static endpointL12_ endpt;
//static siuqiim2_    siuqiim2(100,&endpt);

int siuqiim2_::VTIVSwavein(wavinhdrbuf_* p2whb)
{
	if(k>=K) { endpt->ended=1;  return 1; } // so don't have to worry overflow
  if(endpt->wavein(p2whb, &k)) return 1;
  if(endpt->ended) return 0;
	void compute_start(short* sha1, int times1);
  //compute_start(buf+k*nDQS_FSS, 10);
	return 1;
}

void siuqiim2_::VTVVwave()
{
	int sleeptime=20;
  while(1) {
  	if(doneloop()) break;
    if(!stopper._4exit)
    	beg1cu(NULL);
		stopper._1cu=0;
   	init4kaisi();
	  if(!stopper._4exit)showstatus(); Sleep(20);
	  openstart();
	  while (!done1cu()) {
			Sleep(sleeptime);
			if(!stopper._4exit)
      	showstatus ();
      else break;
      if(done1cu ()) break;
      if(doneloop()) break;
			dowhenidle ();
	  }
	  stopclose(); all2idle(); Sleep(50);
    setnextbuf();
		if(!stopper._4exit) spmsg.istatus(""); Sleep(50);
		if(!stopper._4exit) {
			if( (complete1cu())||(done1cu()) ){
				end1cu(NULL);//will set the correct buf at the call
				//if(iwclient->bopt.brcg )	iwclient->rcg ();
			}
		}
	}
	if(!stopper._4exit) spmsg.istatus("");
	stopper.loop=0;
}

int siuqiim2_::		showstatus	()
{
	if			(!endpt->beged) spmsg.istatus("   ������...    ");
	else if	(!endpt->ended) spmsg.istatus("      dehť��...");
	else										spmsg.istatus("    ��lo");
	return 1;
}

void siuqiim2_::setnextbuf()
{
	qiimbuf[nth].k				=k;
	qiimbuf[nth].nshused	=qiimbuf[nth].frmsz()*k;
	qiimbuf[nth].nshbsil	=qiimbuf[nth].frmsz()*endpt->nkbsil;
	qiimbuf[nth].nsheqiim =qiimbuf[nth].frmsz()*(k-endpt->nkeDUR);
	qiimbuf[nth].nshesil	=qiimbuf[nth].frmsz()*endpt->nkesil;
	nth++;
	if(nth>=NTH) nth=0;
	buf=qiimbuf[nth].sh;
	endpt->initallbuf(buf);
}

void siuqiim2_:: init4def()
{
}





int siuqiim3_::VTIVSwavein(wavinhdrbuf_* p2whb)
{
	if(k>=K) { endpt->ended=1;  return 1; } // so don't have to worry overflow
	if(endpt->wavein(p2whb, &k)) return 1;
	if(endpt->ended) return 0;
	return 1;
}

void siuqiim3_::VTVVwave()
{
	int sleeptime=20;
	stopped=0;
	buf=qiimbuf.sh;
	endpt->initallbuf(buf);
	beg();
	init4kaisi();
	showstatus(); Sleep(20);
	openstart();
	//static int i=0;
	//while(i<20) {i++;
	while (!done()) {
		dowhenidle ();
		showstatus ();
		Sleep(sleeptime);
	}
	stopclose(); all2idle(); Sleep(50);
	//spmsg.istatus(""); Sleep(50);
	int fsz=qiimbuf.frmsz();
	qiimbuf.k					=k;
	qiimbuf.nshused		=fsz*k;
	qiimbuf.nshbsil		=fsz*endpt->nkbsil;
	qiimbuf.nsheqiim 	=fsz*(k-endpt->nkeDUR);
	qiimbuf.nshesil		=fsz*endpt->nkesil;
	end();
}

int siuqiim3_::		showstatus	()
{
	if			(!endpt->beged) spmsg.istatus("   ������...    ");
	else if	(!endpt->ended) spmsg.istatus("      dehť��...");
	else										spmsg.istatus("    ��lo");
	return 1;
}

void siuqiim3_:: init4def()
{
}

/*
WTS_ 						qiimpack2_::wts(nDQS_FSS, 7, 2, 3);
beL12_  				qiimpack2_::beL12;
beWTS_ 					qiimpack2_::beWTS(&wts);
endpoint_ 			qiimpack2_::endpt(&beWTS);
adaptation2_  	qiimpack2_::adapttn(0, &wts, 100);
extern VFNqiim fn_end1cu;
siuqiim3_      	qiimpack2_::siuqiim(100, &endpt, fn_end1cu);
*/












void spmsgRcgOut(char *s1, char*s2, char*s3, char*s4)
{
	if(s1) msgbox(s1);
	if(s2) msgbox(s2);
	if(s3) msgbox(s3);
	if(s4) msgbox(s4);
}

void spmsgStatus(char *s1, char*s2, char*s3, char*s4)
{
	if(s1) msgbox(s1);
	if(s2) msgbox(s2);
	if(s3) msgbox(s3);
	if(s4) msgbox(s4);
}

void spmsgDebug (char *s1, char*s2, char*s3, char*s4)
{
	if(s1) msgbox(s1);
	if(s2) msgbox(s2);
	if(s3) msgbox(s3);
	if(s4) msgbox(s4);
}

#endif //#ifdef DQSOLDOLDOLD


#endif //#ifndef SPEECHIO_CPP




#ifdef SPEECHIO_H_OLDOLDOLD
//*********************************************************************
//*********************************************************************
//**  BEGIN of  class owave_
//*********************************************************************

class owave0_ { public:// the real worker for out-wave
  HWAVEOUT        hwo; // handle to the oepned input device
  WAVEFORMATEX    wfx; // struct for (querying?) supportted data format
  MMRESULT        res;
  WAVEHDR         hdr;
  int bOpened;
  int bBangImDiong;
  HWAVEOUT operator()() { return hwo; }
 	static void CALLBACK	waveOutProc
  (HWAVEOUT hwo,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);
public:
  owave0_():bOpened(0),bBangImDiong(0){ setpcm(); res=ispcmsupported(); }
 ~owave0_(){ if(bOpened) close(); }
  int openfail() {  if(!bOpened) open(); return !bOpened; }
  int open(){ res=waveOutOpen(&hwo,WAVE_MAPPER,(LPWAVEFORMATEX)&wfx,
                              (DWORD)waveOutProc,0,CALLBACK_FUNCTION);
              bOpened=(!res);return bOpened;}
  int close(){ bOpened=0; return waveOutClose(hwo); }
  int reset(){ res= waveOutReset(hwo); Sleep(10); return res; }
	int stopclose() { reset(); return close(); }
public:
  int setpcm (){ return setpcm(16000, (nDQS_BYTES==1)?8:16); }
  int setpcm  (int nsamples, int nbits);
  int ispcmsupported();
public: short* dt; int size;
  int play(short* dt, int shsize);
};

owave0_ owdef0;

void CALLBACK owave0_::
waveOutProc(HWAVEOUT hwo,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
  switch (uMsg) {
  case WOM_DONE: SetEvent(hEvent_PlayEnd);
		//spmsgStatus("WOM_DONE");
	}
}



int owave0_::
play(short* dt, int shsize)
{
  if(bBangImDiong) return 0;
  bBangImDiong=1; reset();close();
  if( (!dt) ||(shsize<=0) || openfail()) {
		//spmsgStatus("play err\n\n"); Sleep(10);
    SetEvent(hEvent_class_ow_PlayEnd);
    bBangImDiong=0;
    return 0;
  }
  hdr.lpData = (LPSTR)dt;
  hdr.dwBufferLength = shsize*2; // length in bytes rather in short
  hdr.dwBytesRecorded= shsize*2; // length in bytes rather in short
  hdr.dwFlags = WHDR_BEGINLOOP|WHDR_ENDLOOP;
  hdr.dwLoops = 1L;
  res=waveOutPrepareHeader(hwo, &hdr, sizeof(hdr) );
  //spmsgStatus("          ��...");
  spthmsgOSTT("          ��...");
  res=waveOutWrite(hwo, &hdr, sizeof(hdr) );
  //WaitForSingleObject(hEvent_PlayEnd, shsize/8+10);
  WaitForSingleObject(hEvent_PlayEnd, INFINITE);
  res=waveOutUnprepareHeader(hwo, &hdr, sizeof(hdr) );
  reset();
  close(); Sleep(100);
  bBangImDiong=0;
  //spmsgStatus("");
  spthmsgOSTT("");
  SetEvent(hEvent_class_ow_PlayEnd);
  return 1;
}


int owave0_::
setpcm(int nsamples, int nbits)
{
  //PCMWAVEFORMAT fmt; is superceded by wfx
  wfx.wFormatTag     =WAVE_FORMAT_PCM;
  wfx.nChannels      =1;
  wfx.nSamplesPerSec =nsamples;//16000L;
  wfx.nAvgBytesPerSec=nsamples*(nbits/8);
  wfx.nBlockAlign    =(WORD)((nbits==8)?1:2);
  wfx.wBitsPerSample =(WORD)nbits;
  wfx.cbSize         =0; // not really needed for WAVE_FORMAT_PCM
  return 1;
}

int owave0_::
ispcmsupported()
{
  res=waveOutOpen(NULL,WAVE_MAPPER, (LPWAVEFORMATEX)&wfx, NULL, NULL, WAVE_FORMAT_QUERY);
  return MMSYSERR_NOERROR==res;
}

//*********************************************************************
//**  END of class owave_
//*********************************************************************
//*********************************************************************


#endif //#ifdef SPEECHIO_H_OLDOLDOLD




