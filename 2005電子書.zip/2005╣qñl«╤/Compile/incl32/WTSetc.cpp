//
//	file WTSetc.cpp
//  etc for WTS
//	a copy of the struct is in the speechio.h
//	content of this file is intended to be included in speechio.cpp eventually
//


struct WTSetc_ {
	float sigmatimes;	// for setting fft-cutoff
  int		btimes;			// beg threshhold times
  int		etimes;			// end threshhold times
  float	scale;			// scale*b(e)times will be threshhold for beg(end)
  float*blws;		 		// array of limit-weights for beg
  float*elws;		 		// array of limit-weights for end
  int nblw;
  int nelw;
};
extern WTSetc_ WTSetc;

#define CNT 256/2
static float blw[]={1,0, CNT/16,1, CNT/4,3, CNT*2/3,4, CNT,3};
static float elw[]={1,0, CNT/16,6, CNT/4,3, CNT*2/3,3, CNT,3};
#undef CNT

WTSetc_ WTSetc={
	4.0,
  4,
  3,
  40000.0, //40.0
  blw,
  elw,
  sizeof(	blw	)/(2*sizeof(float)),
  sizeof(	elw	)/(2*sizeof(float))
};


//WTSetc_::WTSetc_()
//{
  // nDQS_FSS=256, remember to change this if nDQS_FSS changed
/*
	sigmatimes	=3.0;		// for setting fft-cutoff
  btimes			=2;			// beg threshhold times
  etimes			=2;			// end threshhold times
  scale				=35.0;	// scale*b(e)times will be threshhold for beg(end)
//}
*/

/*
#define fWTSsigmatimes
#define fWTSthreshscale 35.0
#define  nWTSbtimes			2
#define  nWTSetimes			2
*/



