//
// file speechio.h
// copyright 1998 Gang, IrngZin
//


#ifndef SPEECHIO_H
#define SPEECHIO_H
// for VC++6.0
// speechio needs
//  1. set _MT switch in C/C++ compiler
//  2. add winmm.lib in link/library
//  3. add LIBCMT.LIB(static release)/LIBCMTD.LIB(static debug) or MSVCRT.LIB(dll) to link
// MT is for multithread

#include <windows.h>
#include <mmsystem.h>
#include <process.h>
#ifndef DIBASE_H
#include <di5base.h>
#endif //#ifndef DIBASE_H
#ifndef DI5VP_H
#include <di5vp.h>
#endif //#ifndef DI5VP_H

//#include <spmsg.h>
//#include <rcfft.h>
//#include <realfft.h>
//#include "crealfft.h"

//#ifndef TPC(X)
#ifndef TPC
// first a macro for a shorter name,
// remember spaces after TPC(X)
#define TPC(X)			template<class X>
#define TPC1(X)			template<class X>
#define TPC2(X,Y)		template<class X, class Y>
#define TPC3(X,Y,Z)		template<class X, class Y, class Z>
#define TPCI(X)			template<class X> inline
#define TPCI1(X)		template<class X> inline
#define TPCI2(X,Y)		template<class X, class Y> inline
#define TPCI3(X,Y,Z)	template<class X, class Y, class Z> inline
//vitr means iterator of vector/valarray/array, or random acess iterator
#endif //#ifndef TPC(X)


typedef unsigned long ulong;

const	int	nDQS_IDLEBUFSIZE=	256;
const	int	nDQS_MAXIDLEBUF=	10;
//#define nDQS_MAXIDLEBUF	60
#ifdef  DQS_PCM8
	#define nDQS_BYTES		1
	#define nDQS_FSS			256
#else
	#define nDQS_BYTES		2
	#define nDQS_FSS			256
#endif

// Here we design two ways a thread can be created:
// 1. derive from threader2_, and
//		implement VTVVSthread w/arg= void* that can be casted into "this"
// 2. defineNset client w/func of tye VFNVS, use the VS to get "this", as in 1.
//    use threader1_
// Note that BCB requires? its VCL acess thru its own TThread, so use it if BCB

class 	crtsection{	public:	CRITICAL_SECTION cs; int noleave;
public:	crtsection():noleave(0)	{InitializeCriticalSection(&cs);}
		  ~crtsection()	{leave();DeleteCriticalSection(&cs);}
	void	enter()			{EnterCriticalSection(&cs);noleave=1;}
	void	leave()			{if(noleave){noleave=0;LeaveCriticalSection(&cs);}}
};

struct eventhandle{ HANDLE h;
		eventhandle	(){create();}
	   ~eventhandle	(){close ();}
	HANDLE	create	(){ h=CreateEvent(NULL,FALSE,FALSE,NULL);return h;}
	void	reset	(){ ResetEvent(h);	}
	void	set		(){ SetEvent(h);	}
	void	close	(){CloseHandle(h);	}
};


typedef void (*VFNV )(void );
typedef void (*VFNVS)(void*);
typedef void (*VFNS) (char*);

typedef void (*VFV )(void );
typedef void (*VFVS)(void*);

class threader1_ { public:HANDLE hnd; uint id;  int priohigh;
						VFNVS client, onterminate; void* arg;
	threader1_():hnd(NULL),id(0),client(NULL),onterminate(NULL),priohigh(0){  }
   ~threader1_(){if(hnd) CloseHandle(hnd);}
public://caution to use wait2end: the one that calls will sleep
	int  del	 (){int r=1; if(hnd){r=CloseHandle(hnd);if(r)hnd=0;}
							return r;}
//	int  del	 (){int r=1; if(hnd){_endthreadex(id);if(r)hnd=0;}
//							return r;}
	void wait4end(int wtime=INFINITE)
								{ WaitForSingleObject(hnd,wtime); }
	void start   (VFNVS client1=NULL, void*arg1=NULL, VFNVS onterminate1=NULL){
									if(hnd) return;
									if(hnd)CloseHandle(hnd);
									client=client1; arg=arg1;	onterminate=onterminate1;
									//hnd=CreateThread(NULL,0,staticthread,this,0,&id);
									//hnd=(HANDLE)(_beginthreadex(NULL,0,staticthread,this,0,&id));
									hnd=(HANDLE)(_beginthreadex(NULL,0,staticthread,this,CREATE_SUSPENDED,&id));
									if(priohigh)
										SetThreadPriority(hnd,THREAD_PRIORITY_HIGHEST);
									ResumeThread(hnd);
	}
protected:
static uint WINAPI staticthread(void*pv) {
			threader1_*t=(threader1_*)pv;
			if(t->client			)(*(t->client))(t->arg);
			if(t->onterminate	)(*(t->onterminate))(t->arg);
			if(t->hnd) { CloseHandle(t->hnd); t->hnd=0; }
			return 0;
	}
};

class threader2_{ public:HANDLE hnd; uint id;
	threader2_():hnd(NULL),id(0){}
   ~threader2_(){dele();}
public://caution to use wait2end: the one that calls will sleep
	virtual void VTVVthread  () { }
	void dele    (){if(hnd) CloseHandle(hnd);hnd=0;}
//	void dele    (){_endthreadex((unsigned)hnd);}
	void wait4end(int wtime=INFINITE) { WaitForSingleObject(hnd,wtime); }
//	void start(){dele();hnd=(HANDLE)_beginthreadex(NULL,0,thethread,this,0,&id);}
	void start(){dele();hnd=(HANDLE)_beginthreadex(NULL,0,thethread,this,0,&id);}
//	void start(){hnd=(HANDLE)_beginthreadex(NULL,0,thethread,this,0,&id);}
	void kaisi   (){start();}
	static uint WINAPI thethread(void*pv)
//		{	threader2_*t=(threader2_*)pv;	t->VTVVthread(); return 0; }
		{	threader2_*t=(threader2_*)pv;	t->VTVVthread(); t->dele();	return 0; }
};

/*
uint WINAPI thethreader3(void*pv);
//uint WINAPI thethread3(void*pv)
//{	threader3_*t=(threader3_*)pv;	t->VTVVthread(); t->dele();	return 0; }
class threader3_{ public:HANDLE hnd; uint id;
	threader3_():hnd(NULL),id(0){}
   ~threader3_(){dele();}
public:
	virtual void VTVVthread  () { }
	void dele	(){if(hnd)	CloseHandle(hnd);	hnd=0;}
	void start	(){dele(); hnd=(HANDLE)_beginthreadex(NULL,0,thethreader3,this,0,&id);}
	void kaisi	(){start();}
};
*/
/*////////////////////////////////////////////////////
This is what really happened/should be using in calling begin(...)
class some{
	thinthread thd;
	static uint WINAPI sfunc(void*obj){some*p=(some*)obj; p->...;}
	void thdbegin(){thd.begin(sfunc, this);}
};
*////////////////////////////////////////////////////


class  spmsgcase {// must use thread to implement this
public:spmsgcase(int asdef=1){ setasdef(asdef); }
	void  setasdef(int asdef);// { spmsg.set2(this, asdef);   }
	chars s;
	void set2s(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{s.clear();
						 if(s1)s+=s1;if(s2)s+=s2;if(s3)s+=s3;if(s4)s+=s4; }
	virtual void rcg0    (cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	virtual void debug0  (cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	virtual void ostatus0(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	virtual void istatus0(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	//void rcg    (char *s1,char*s2=0,char*s3=0,char*s4=0){rcg0    (s1,s2,s3,s4);}
	//void debug  (char *s1,char*s2=0,char*s3=0,char*s4=0){debuf0  (s1,s2,s3,s4);}
	//void ostatus(char *s1,char*s2=0,char*s3=0,char*s4=0){ostatus0(s1,s2,s3,s4);}
	//void istatus(char *s1,char*s2=0,char*s3=0,char*s4=0){istatus0(s1,s2,s3,s4);}
};

class  spmsg_ {	spmsgcase * c;
public:spmsg_() {c=NULL; }
	void set2(spmsgcase* c1, int asdef=1)
		{
			if(asdef) c=c1;
			else if(!c)
				c=c1;
		}
	void rcg(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->rcg0(s1,s2,s3,s4);}
	void debug(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->debug0(s1,s2,s3,s4);}
	void ostatus(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->ostatus0(s1,s2,s3,s4);}
	void istatus(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->istatus0(s1,s2,s3,s4);}
};
extern spmsg_ spmsg;
extern spmsgcase spmsgNULL;


/////////////////////////////////////////////////////////////////////////
#ifndef RCFFT_H
#define RCFFT_H

extern const double pi;//=3.141592653589793;
extern const double twopi;//=2*pi;
int 	twopowerbound(int N);
size_t	next2pow(uint t);  //similar to above

TPC(R) void dopreem(R* obs, int nobs, float preem);
TPC(R) void dopreem(R* obs, int nobs, float preem, float prevvalue);


TPC(T) int gethanning(T* win, 		int pmark1, int pmark2, int pmark3);//*center at pmark2-pmark1+1, total len=pmark3-pmark1+1, first/last is 0
TPC(T) int gethanning(vector<T>&win,int pmark1, int pmark2, int pmark3);//*center at pmark2-pmark1+1, total len=pmark3-pmark1+1, first/last is 0
TPC(T) int gethanning(T* win, 		int nwin);//* win[] has len >= nwin
TPC(T) int gethanning(vector<T>&win,int nwin);//*center at pmark2-pmark1+1, total len=pmark3-pmark1+1, first/last is 0

// rfft will return N/2 complexes, no reduncdancy
// cfft wiil return N complexes, half of which is redundant
class   rcfft_ {
public: rcfft_():lastCN(0),lastisign(0) {}
	void rfft0(float *x, int N, int isign=1);//* 0based Nreals
	void cfft0(float *x, int N, int isign=1);//* 0based Ncmplxs
	void rfft1(float *x, int N, int isign=1);//x: N reals,     1-based
	void cfft1(float *x, int N, int isign=1);//x: N complexes, 1-based
public:
	void	sh2ft(float* x, short* sh, int N);//* copy short to float
public:
	void rspt0(float*x,  int N);//*replace x (len 2^K) w/its spectrum, only N/2 is useful, 0-based
private:
	int 	lastCN, lastisign; //* last Complex N
	short 	bitrev[1025]; double sinhalftheta[10], sintheta[10];
private:
	int  twopowerbound(int N){return ::twopowerbound(N);}
	int  twopowerUB   (int N){return ::twopowerbound(N);}
	void cfftf(float *x, int N, int isign=1);//* a little faster version
	void cfftg(float *x, int N, int isign=1);//* general version
};
extern rcfft_ rcfft;

class   ehfs_ {
public: ehfs_ (double preem1=0.975)
				{	init20(); preem=(float)preem1; set4FRMSZ(512); }
public:
	rcfft_ 	fft;
	int	 	lastfftRN(																	){return lastRN4FFT;}
	float* 	cpy    (short* sh, int nsh, float* res1);
	float* 	eh     (short* sh, int nsh, float* res1=0, int preem=1);
	float* 	hf     (short* sh, int nsh, float* res1=0);
	float* 	ehf    (short* sh, int nsh, float* res1=0, int preem=1);
	float* 	ehfs   (short* sh, int nsh, float* res1=0, int preem=1);
	float* 	ehfps  (short* sh, int nsh, float* res1=0, int preem=1);
	float* 	ehfs1  (short* sh, int nsh, float* res1=0, int preem=1);
	float* 	fs     (short* sh, int nsh, float* res1=0);
	float* 	fps    (short* sh, int nsh, float* res1=0);
	float* 	fs1    (short* sh, int nsh, float* res1=0);
	float* 	fs1off (short* sh, int nsh, float* res1=0);
public:  // dnsmp: down sample, so only nsh/dnsmp is actually used
	short* 	downsample(short* osh,int nosh, int dnsmp);//ret: dnsh:down-sampled array
	float* 	dhf    (short* sh,  int nsh, int dnsmp, float* res1=0);
	float* 	dehf   (short* sh,  int nsh, int dnsmp, float* res1=0, int preem=1);
	float* 	dehfps (short* sh,  int nsh, int dnsmp, float* res1=0, int preem=1);
	float* 	dehfs  (short* sh,  int nsh, int dnsmp, float* res1=0, int preem=1);
	float* 	dehfs1 (short* sh,  int nsh, int dnsmp, float* res1=0, int preem=1);
	float* 	dfs1   (short* sh,  int nsh, int dnsmp, float* res1=0);
	float* 	dfs1off(short* sh,  int nsh, int dnsmp, float* res1=0);
public:
	float  	preem;
	void   	dopreem(float* obs);
	void   	dopreem(float* obs, float prevvalue);
public:
private: int lastFRMSZ, lastRN4FFT, allcFRMSZ, allcRN4FFT;
	int    	alloc4work(int FRMSZ1);
	int		set4FRMSZ (int FRMSZ1);
public:
	float  *xdef; // default working array
	float  *ham;
	short  *dnsh; // down sampled short array
	//int	 ge2pow(int t){float tt=t-0.05;int rr=1;while(rr<tt)rr*=2;return rr;}
	void	init20(){lastFRMSZ=lastRN4FFT=allcFRMSZ=allcRN4FFT=0;xdef=ham=0;dnsh=0;}
public:
	void	initham();
	void	doham  (float* obs);
};

/////////////////////////////////////////////////////////////////////////

/*
class qiimbuf_;
// calculate spectrum : from speech buf into a matrix of spectrum
TPC(real) int calspec__ 	(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem);
TPC(real) int calspec__ 	(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs){return calspec(mm,qb,frmsz,sftsz,ehfs,0.975);}
TPC(real) int calspec__		(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz);
TPC(real) int calspec_ms__	(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs, float preem);
TPC(real) int calspec_ms__	(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs){return calspec_ms(mm,qb,frmms,sftms,ehfs,0.975);}
TPC(real) int calspec_ms__	(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms);


// calculate power spectrum : from speech buf into a matrix of power spectrum
TPC(real) int calpspec__	(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem);
TPC(real) int calpspec__	(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs){return calpspec_(mm,qb,frmms,sftms,ehfs,0.975);}
TPC(real) int calpspec__	(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz);
TPC(real) int calpspec_ms__	(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs, float preem);
TPC(real) int calpspec_ms__	(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs){return calpspec_ms(mm,qb,frmms,sftms,ehfs,0.975);}
TPC(real) int calpspec_ms__	(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms);

//* fps only, no preem, and no hamming
// calculate power spectrum : from speech buf into a matrix of power spectrum
TPC(real) int calpspec0__	(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs);
TPC(real) int calpspec0__	(vecvec<real>& mm, qiimbuf_ &qb, int frmsz, int sftsz);
TPC(real) int calpspec0_ms__(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs);
TPC(real) int calpspec0_ms__(vecvec<real>& mm, qiimbuf_ &qb, int frmms, int sftms);
*/
TPC(T) chars& operator<<(chars& cs, vecvec  <T>& vv);
#endif //#ifndef RCFFT_H


/////////////////////////////////////////////////////////////////////////
class wavhdr_ :public WAVEHDR { public: // this header is for speech io
			wavhdr_() { init0(); }
	void clear(){ memset(this,0,sizeof(*this)); }
	void init0() { clear(); }
	void init4def() { }
	//int  read (tyio& i);//with checking
	//int  write(tyio& o){return o.write(this,sizeof(*this));}
public:
	int  	size() {return dwBufferLength; }
	void operator=(const wavhdr_&rhs){memmove(this,&rhs,sizeof(*this));}
};

inline bool isthesame(WAVEFORMATEX&t, WAVEFORMATEX& r)
{
	if(
	(t.wFormatTag		==r.wFormatTag)&&
	(t.nChannels		==r.nChannels)&&
	(t.nSamplesPerSec	==r.nSamplesPerSec)&&
	(t.nAvgBytesPerSec	==r.nAvgBytesPerSec)&&
	(t.nBlockAlign		==r.nBlockAlign)&&
	(t.wBitsPerSample	==r.wBitsPerSample)
	)return true; else return false;
}
#include <stdio.h>
struct	waveformatex : public WAVEFORMATEX
{		waveformatex(){cbSize=sizeof(*this);}
	int		PCM  	() { return 1;				}//i.e.,WAVE_FORMAT_PCM
	int		ADPCM  	() { return 2;				}
	WORD &	fmt  	() { return wFormatTag;		}//1st field of WAVEFORMATEX
	WORD &	ch   	() { return nChannels;		}//2nd field
	DWORD&	sr   	() { return nSamplesPerSec;	}//3rd
	DWORD&	Bpsec	() { return nAvgBytesPerSec;}//4th
	WORD &	Bpsmp	() { return nBlockAlign;	}//bytes per sample in nChannels
	WORD &	bpsmp	() { return wBitsPerSample;	}//bits per sample in 1 Chanel
	WORD &	cbsize	() { return cbSize;			}//7th

	int		ispcmsupported();

	bool	eq		  (WAVEFORMATEX&r){return  isthesame(*this,r);}
	bool	operator==(waveformatex&r){return  isthesame(*this,r);}
	bool	operator!=(waveformatex&r){return !isthesame(*this,r);}
	void	operator =(waveformatex&r){memmove(this,&r,sizeof(r));}
	void	operator =(WAVEFORMATEX&r){memmove(this,&r,sizeof(r));}
//	bool operator==(waveformatex&r){return ((fmt()==r.fmt()&&ch()==ch()
//						&&sr()==r.sr()&&Bpsec()==r.Bpsec()&&Bpsmp()==r.Bpsmp()
//						&&bpsmp()==r.bpsmp()&&cbsize()==r.cbsize())?1:0);}
//	bool operator!=(waveformatex&r){return !(this->operator==(r));}
};

inline int waveformatex::
ispcmsupported()
{
	MMRESULT  res=waveOutOpen
		(NULL,WAVE_MAPPER,(LPWAVEFORMATEX)this, NULL, NULL, WAVE_FORMAT_QUERY);
	return MMSYSERR_NOERROR==res;
}

class htkfmt_;

class	pcmfmt_ { public:
		pcmfmt_() { memset(this, 0, sizeof(*this)); set4wfex(); set16k(); }
		~pcmfmt_() { }//if(extra) delete[] extra; }
public:
	char 	ccriff[4]; uint fsizel8; char ccwave[4]; char ccfmt[4];
	uint 	wfexsz;
	waveformatex wfex;
//	WAVEFORMATEX wfex;
	char 	extra[32]; // .wav header, 32 for ADPCM
	char 	ccdata[4]; uint dataBsz;
		// dataBsz and filesz may be wrong, should be computed when save
public:
	int		isPCM	() { return fmt()==1;				}//WAVE_FORMAT_PCM;	}
	int		isADPCM	() { return fmt()==2; 				}//WAVE_FORMAT_ADPCM;	}
	WORD	PCM  	() { return WAVE_FORMAT_PCM;		}
	WORD &	fmt  	() { return wfex.wFormatTag;		}//1st field of WAVEFORMATEX
	WORD &	ch   	() { return wfex.nChannels;			}//2nd field
	DWORD&	sr   	() { return wfex.nSamplesPerSec;	}//3rd
	DWORD&	Bpsec	() { return wfex.nAvgBytesPerSec;	}//4th
	WORD &	Bpsmp	() { return wfex.nBlockAlign;		}//bytes per sample in nChannels
	WORD &	bpsmp	() { return wfex.wBitsPerSample;	}//bits per sample in 1 Chanel
	WORD &	cbsize	() { return wfex.cbSize;			}//7th
	void *	xtr		() { return extra;					}
public:
	int  isconsistent();
	int  eq4owave	(pcmfmt_&f);//i.e., a limited '=='
	int  eq			(pcmfmt_&f){return eq4owave(f);}
	void set44k		()	{set2(44100,1);}
	void set22k		()	{set2(22050,1);}
	void set11k		()	{set2(11025,1);}
	void set8k 		()	{set2( 8000,1);}
	void set16k		()	{set2(16000,1);}
	void set32k		()	{set2(32000,1);}
	void set48k		()	{set2(48000,1);}
	void set64k		()	{set2(64000,1);}
	int  set2(DWORD samppsec, WORD channels=1, WORD bitspsamp=16);// only for PCM
public:
	void set4wfex 	(					);//*	{set16k();			}
	int	 setbytesize(int   databytesize	);
	int  readp 		(void* p,int plen=-1);//read and check if WAVE_FORMAT_PCM
	int  read 		(tyio& i			);//checking if WAVE_FORMAT_PCM
	int  write		(tyio& o, int databytesize=-1);//-1 if setdatasize called before
	int  operator=	(htkfmt_& htk		); //ret: success or not
	void operator=	(pcmfmt_& pcm		){memmove(this,&pcm,sizeof(pcm));}
	uint ms2nsh     (uint ms			){return uint(ms/1000.*sr()+0.6);}
	uint nsh2ms     (uint nsh			){return uint(nsh*1000./sr()+0.6);}
};

class	htkfmt_ { public:
		htkfmt_() { init0(); }
	void init0() { memset(this,0,sizeof(*this)); }
	int	 readp(void* p, int plen=-1);	//* read and check
	int  read (tyio& i);				//* with checking
	int  write(tyio& o){return o.write(this,sizeof(*this));}
public:
	void  init2def(){sampPeriod=625;sizePerSamp=2;fileDataKind=0;}
	int   totSamp;		//* speech data in samples,not in bytes,excluding header
	int   sampPeriod;	//* =625 per 10^-7 second for 16K (10^7/16k)
	short sizePerSamp;	//* =2;   2 byte per sample
	short fileDataKind;	//* =0;   wavedata, according HTK convention
public:
	int  	size		(			) {return totSamp; }
	int 	operator=	(pcmfmt_&pcm); //* ret: success or not
	int		operator=	(htkfmt_&r	); //* ret 1
};

//class owave_
//close() should go with unprepare(), thus should be called from WaveProc
//			auto-called inside waveProc
//use reset()/stop() only, without close();
//waveOutReset(.) should not called more than necessary, or program blocked
//			reset() has been safe-guarded
class owave_ {	// the waveout agent, real worker is owave0_
public: 		// iwave0_ is in the .cpp file
	int		open	 (pcmfmt_* wfmt1=0);
	int		reset	 ();
	int		close	 ();
	int		thplay	 (short* sh, int sz,pcmfmt_*pcm);
	int		play	 (short* sh, int sz,pcmfmt_*pcm);
	int		playclose(short* sh, int sz,pcmfmt_*pcm){int r=play(sh,sz,pcm);stopclose();return r;}
	int		stopclose();//bad function to call. use reset() w/o close(), close() should be handled auto-ly
	int		isplaying();
	void	wait2end ();
	HWAVEOUT operator()();
	__int64	position ();//by num_samples
}; extern owave_ owdef;



int frmcenter(vector<int>& v, int qiimsz, int frmsz, int sftsz);



class qiimbuf_{ public:
	 ~qiimbuf_(						 ) { del(); }
	  qiimbuf_(int nshorts=0):sh(0),nshused(0),nshalloc(0) { init0();reserve(nshorts); }
	  qiimbuf_(char* fname  ):sh(0),nshused(0),nshalloc(0) { init0();read(fname); }
public:
	pcmfmt_ pcm;
	short*  sh;		int nshused, nshalloc;
	int k, K;
	int nshbsil, nsheqiim, nshesil; //nsheqiim includes nshbsil
	int	 adpcm;
	void clear(){ nshused=0; adpcm=0; pcm.setbytesize(0);}//memset(this,0,sizeof(*this)); }
	void init0(){ clear();   }
	void clearvalues(){memset(sh,0,sizeof(short)*nshused);}
	int	 ispcm(){ return !adpcm; }
	int  isOK (){ return (sh!=0);}
	int	 inbnd_ms(uint ms){return((int)ms2nsh(ms)<=size())?true:false;}
	int	 inbnd_ms( int ms){return((int)ms2nsh(ms)<=size())?true:false;}
public:
//int  init2  (int nshorts					);//change name to reserve
//int  init2ms(int nmssecs					){return init2( pcm.ms2nsh(nmssecs) );}
	int  resize    (int nshorts					);
	int  resize2ms (int nmssecs					){return resize( pcm.ms2nsh(nmssecs) );}
	int  reserve   (int nshorts					);
	int  reserve2ms(int nmssecs					){return reserve( pcm.ms2nsh(nmssecs) );}
	void del    (      		  					){if(sh) {delete[] sh; sh=0; nshused=nshalloc=0;} }
public:
	int  hasroom4ins(int len){return (nshused+len)<=nshalloc; }
	int  inssil	(int len, int at=0);
	int  ins  	(short* sh1, int len, int at=0);
	int  app  	(short* sh1, int len  ){return ins(sh1, len, nshused);}
	int  app  	(qiimbuf_& qb){return (nshused<=0)?set2(qb):app(qb.sh,qb.nshused);}
	int  app  	(qiimbuf_* qb){return app(*qb);}
	int  rmb  	(int nsh              );// remove at beg nsh samples
	int  rme  	(int nsh              );// remove at end nsh samples
	int  rm   	(int beg, int end=-1  );// remove from beg to end samples
	int  rmbesil();
public:                             // end=-1 if from beg to nshused
	int	 set2 (qiimbuf_& buf				);//{return set2(buf, 0, -1); }
	int	 set2 (qiimbuf_* buf				){return set2(*buf);}
	int	 set2 (short* sh1,  int nsh1);
	int	 set2 (short* sh1,  int beg, int len){return set2(sh1+beg, len);}
	int	 set2 (qiimbuf_&buf,int beg, int len=-1);//-1 for all
	TPC(R) int	 set2be		(R*src,  int beg, int end);
	TPC(R) int	 set2be16k	(R*src,  int beg, int end){set16k();set2be(src,beg,end);}
	TPC(R) int	 set2be8k	(R*src,  int beg, int end){set8k ();set2be(src,beg,end);}
	TPC(R) int	 get2be		(vector<R>& trg,  int beg=-1, int end=-1);
	TPC(R) int	 get2be_ms	(vector<R>& trg,  int beg=-1, int end=-1);
	TPC(R) int	 copyfrm	(vector<R>& trg, int nth, int frmsz, int sftsz);
	TPC(VEC) uint copyseg	(VEC& trg, uint beg,   uint end);
	TPC(VEC) uint copyseg_ms(VEC& trg, uint begms, uint endms);
	int	frmcenter(vector<int>&v, int frmsz, int sftsz){return ::frmcenter(v,ssize(),frmsz,sftsz);}
public:
	int	 downsample(int everyN);   //return 0 if can not downsample
	int  candownsample(int everyN, int change_pcm=0);
	//44k:2/4; 22k:2; 48k:3/6; 32k:2/4; 16k:2
public:
	void  set44k(){pcm.set44k();}
	void  set22k(){pcm.set22k();}
	void  set11k(){pcm.set11k();}
	void  set48k(){pcm.set48k();}
	void  set32k(){pcm.set32k();}
	void  set16k(){pcm.set16k();}
	void  set8k (){pcm.set8k ();}
	void  setbytesize(){pcm.setbytesize(nshused*sizeof(short));}
public:
	int	 readwav	(tyio& io);
	int  readhtk	(tyio& io);
	int  read		(char* fn, char* pn=0);
//	int	 read		(mfreader& rd, int offset){return readp((char*)(rd.p)+offset, rd.fsz-offset);}
	int	 readp		(void* p, int plen=-1);
public:
	int  write		(char* fn, char* pn=0);//htk or wav? judge by .ext
	int  writehtk	(char* fn, char* pn=0){return write(fn,pn,0);}
	int  writewav	(char* fn, char* pn=0){return write(fn,pn,1);}
	int  write		(int beg, int len, char* fn, char* pn=0);//htk or wav? judge by .ext
	int  writehtk	(int beg, int len, char* fn, char* pn=0){return write(beg,len,fn,pn,0);}
	int  writewav	(int beg, int len, char* fn, char* pn=0){return write(beg,len,fn,pn,1);}
public:
	int  write		(tyio& io, int writewav  );
	int  write		(char* fn, char* pn, int writewav);
	int  write		(int beg, int len, tyio& io, int writewav  );
	int  write		(int beg, int len, char* fn, char* pn, int writewav);
public:
	int  writehtklabel   (char* label, char* fname);
	int  writehtklabel   (char* label, char* fname, uint nshbsil1,uint nshesil1);
public:
	int  	 operator=(qiimbuf_&r){return set2(r);}
public:
  //* wincut(...)/addx(...) for performing psola
  int           wincut(       short* x, float* win, int pmark1, int pmark2, int pmark3);//* assume size of x[] win[] are least pmark3-pmark1+1
  int    hanningwincut(       short* x, int pmark1, int pmark2, int pmark3);//* assume size of x[] are least pmark3-pmark1+1
  int    hanningwincut(vector<short>&x, int pmark1, int pmark2, int pmark3);
  int    hanningwincut(vector<short>&x, vector<float>& win, int pmark1, int pmark2, int pmark3);
public:
  int    hanwincut(       short* x, int pmark1, int pmark2, int pmark3){return hanningwincut(x,pmark1,pmark2,pmark3);}//* assume size of x[] are least pmark3-pmark1+1
  int    hanwincut(vector<short>&x, int pmark1, int pmark2, int pmark3){return hanningwincut(x,pmark1,pmark2,pmark3);}
  int       wincut(vector<short>&x, float* win, int pmark1, int pmark2, int pmark3);
  int    hanwincut(vector<short>&x, vector<float>& win, int pmark1, int pmark2, int pmark3){return hanningwincut(x,win,pmark1,pmark2,pmark3);}
  int    addx(short* x, int nx, int beg);//* will reize() if ness.,& if nshalloc+beg<10MB
public:
	int		hongdua    (float emph );
	int		sub        (int   amnt );
	int		operator+= (int   amnt ){return sub(-amnt); }
	int		operator-= (int   amnt ){return sub( amnt); }
	int		operator*= (float emph ){return hongdua( emph); }
	int		operator/= (float emph ){return hongdua( 1.0/emph); }
	double	L1		 (int beg=-1, int end=-1);
	double	mean     ();
	double	zeromean ();
	short	maxamp   ();//max amplitute
	int		csbe(int &beg, int &end);//* check/set 2make sure 0<=beg<=end<=ssize()
public:
	void	thplay	(int bskip=0, int eskip=0);
	void	play	(int bskip=0, int eskip=0);
	void	thplaybe(int beg, int end);
	void	playbe	(int beg, int end);
	void	setbe0	(int&beg, int&end);//* correct beg/end if wrong
	short*	wdata	(					){ return sh;					}
	uint	ms		(					){return pcm.nsh2ms(nshused);	}
	uint	nsh2ms	(uint nsh   		){return pcm.nsh2ms(nsh);		}
	uint	ms2nsh	(uint  ms   		){return pcm.ms2nsh(ms);		}
	uint	ms2nsh	(uint &ms1,uint& ms2){ms1=pcm.ms2nsh(ms1);ms2=pcm.ms2nsh(ms2);return 2;}
	int		ms2nsh	( int &ms1, int& ms2){ms1=pcm.ms2nsh(ms1);ms2=pcm.ms2nsh(ms2);return 2;}
	int		bsize	(					){ return nshused*2;			}
	int		ssize	(					){ return nshused;				}
	int		size	(					){ return nshused;				}
	int		frmsz	(					){ return nDQS_FSS; 			}
	int		nspec	(int frmsz, int shftsz	){ if(shftsz<=0) return nshused; return((nshused-frmsz)/shftsz+1);}
	int		nfrm	(int frmsz, int shftsz	){ if(shftsz<=0) return nshused; return((nshused-frmsz)/shftsz+1);}
	void	play	(char*fname,char*pname=0){ if(read(fname,pname)) play(); }
	short&	OP[]	(int ith				){ return sh[ith]; }
};



class	feabuf_{ public:
	   ~feabuf_(			 )								{ del(); }
		feabuf_(int nfloats=0):ft(0),nftused(0),nftalloc(0) { clear();init2(nfloats); }
		feabuf_(char* fname  ):ft(0),nftused(0),nftalloc(0) { clear(); read(fname);		}
public:
	float*  ft;
	int nftused, nftalloc;
	int	nftpersamp;
  int TT,CC;
	htkfmt_ hh;
	void 	clear		() { nftused=0; TT=CC=nftpersamp=0;}
  //void	init0hh	() { hh.sizePerSamp=39*sizeof(float); }
	void 	init0		() { clear(); nftpersamp=39; }
public:
	void 	del  (      		  ){if(ft){delete[]ft;ft=0;nftused=nftalloc=0;}clear();}
	int  	init2(int nfloats);
	int	 	init2nsamples(int nsamples, int nfloatsPerSample);//nfloatsPerSample>=12
	int	 	init2nsamples(int nsamples)
						{return init2nsamples(nsamples,hh.sizePerSamp/sizeof(float));}
public:
	int		nfrm(					){return TT;}//nftused/nftpersamp;}
	int		ncmp(					){return CC;}
	float	OP	(					)(int tt,int cc){return ft[tt*CC+cc];}
	float	v   (int tt, 	  int cc){return ft[tt*CC+cc];}
TPC(R) int	copy(vector<R>&v, int tt); //* copy tt sample(frame) to v
public:
	int		read	(char* fn);
	int		write (char* fn, char* pname);
public:
	int		shiftmsec		(		){return hh.sampPeriod/10000;}//badname in htk's part
	int		nsamples 		(		){return hh.totSamp;}
	int 	nfloatsPerSample(		){return nftpersamp;}
	float*	nthsample		(int nth){return ft+nth*nftpersamp;}
	float*	operator[]		(int nth){return ft+nth*nftpersamp;}
protected:
	void	setTTCC			(		){CC=nftpersamp;  TT=nftused/CC;}
};



////////////////////////////////////////////////////////
class	calsp_ { public: char ver[21];
//TPC(P)	size_t	zc	 	(P beg, P end);//zero crossing
//TPC(P)	size_t	nlocmax	(P beg, P end);
//TPC(P)	size_t	nlocmin	(P beg, P end);
public:
//* LAGKIND=0, 1,   2,   3,   4
//* for   all, 1/2, 2/3, 3/4, 4/5
//* acf : divided by (N)
TPC2(VEC,P)	size_t	acf		(VEC& v, P src, size_t slen, int LAGKIND=0);
TPC2(VEC,P) size_t	acf12	(VEC& v, P src, size_t slen){return acf(v,src,slen,1);}
TPC2(VEC,P) size_t	acf23	(VEC& v, P src, size_t slen){return acf(v,src,slen,2);}
TPC2(VEC,P) size_t	acf34	(VEC& v, P src, size_t slen){return acf(v,src,slen,3);}
TPC2(VEC,P) size_t	acf45	(VEC& v, P src, size_t slen){return acf(v,src,slen,4);}
//* acff : divided by (N-lag), sort of flat
TPC2(VEC,P)	size_t	acff	(VEC& v, P src, size_t slen, int LAGKIND=0);
TPC2(VEC,P) size_t	acff12	(VEC& v, P src, size_t slen){return acff(v,src,slen,1);}
TPC2(VEC,P) size_t	acff23	(VEC& v, P src, size_t slen){return acff(v,src,slen,2);}
TPC2(VEC,P) size_t	acff34	(VEC& v, P src, size_t slen){return acff(v,src,slen,3);}
TPC2(VEC,P) size_t	acff45	(VEC& v, P src, size_t slen){return acff(v,src,slen,4);}
public:
TPC(R) int spec_np 	(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem=0.975);
TPC(R) int spec_ms	(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs, float preem=0.975);
TPC(R) int spec_np	(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz);
TPC(R) int spec_ms	(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms);
public:
TPC(R) int pspec_np	(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem=0.975);
TPC(R) int pspec_ms	(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs, float preem=0.975);
TPC(R) int pspec_np	(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz);
TPC(R) int pspec_ms	(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms);
public:
TPC(R) int pspec0_np(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz);
TPC(R) int pspec0_np(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs);
TPC(R) int pspec0_ms(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms, ehfs_& ehfs);
TPC(R) int pspec0_ms(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms);
};
extern calsp_ calsp;


////////////////////////////////////////////////////////
//*example: vecvec<float> vv; calsp.spec_ms(vv,qbuf, frmms, sftms); rct<<spec_ms(v);

class	vv4spec : public vecvec<float> {public: int qbsz, frmsz, sftsz, smprate;
		vv4spec (){}
		vv4spec (qiimbuf_& qb, int frmms, int sftms){spec(qb,frmms, sftms);}
	int spec	(qiimbuf_& qb, int frmms, int sftms);//*call calsp.spec, in .cc
};







class	wplaysound{public:char* t;uint nallc, nused;
		wplaysound():t(0), nallc(0), nused(0) {}
	   ~wplaysound(){del();}
	void del(){if(t) delete[]t;t=0;nallc=nused=0;}
	void clear(){nused=0;}
public:
	int   operator=	(qiimbuf_ &qb);
	BOOL  thplay	(qiimbuf_&qb){*this=qb; return thplay();}
	BOOL   	play	(qiimbuf_&qb){*this=qb; return   play();}
public:
	BOOL thplay(       );
	BOOL play  (       );
	BOOL thplay(char*fn);
	BOOL play  (char*fn);
	BOOL stop  (       );
};

class	wtts_{public:
		wtts_():addsil4ptkh(0),pname_("c:\\daiim\\dihim\\daiqi\\"),ename_(".sp"){}
public://for general playing
	BOOL thplay (charspp& spp, char*ext, char* pname);
	BOOL thplay (char*    fns, char*ext, char* pname);
	BOOL stop   (){return wps.stop();}
public://for playint qiim
	BOOL tqplay (charspp& spp, char*ext, char* pname);
	BOOL tqplay (char*    fns, char*ext, char* pname);
public://for playint daiqi with bendiau
	BOOL tqplayd(char*    fns, char*ext, char* pname);
	BOOL thplayd(char*    fns, char*ext, char* pname);
public:
	int  dobendiau(charspp& spp, char* fns);
	int  cat (charspp& spp, char*ext, char* pname, char apptoneifnot);
public:
	wplaysound  wps;
	qiimbuf_    qb,  qbt;
	chars       cs,  cst;
	charspp     spp;
public:
	chars pname_, ename_;
	int addsil4ptkh;
public://for general playing
	BOOL thplay (charspp& spp);
	BOOL thplay (char*    fns);
public://for playint qiim
	BOOL tqplay (charspp& spp);
	BOOL tqplay (char*    fns);
public://for playint daiqi with bendiau
	BOOL tqplayd(char*    fns);
	BOOL thplayd(char*    fns);
	BOOL thplayd4ask(char*fns);
};






//void threadplayXXXXXXXXXXXXXXXXXXX(qiimbuf_*qbuf);

class	playrange0_ { public: int stopall, stopped;
		playrange0_():stopall(1), stopped(1){}
	static 	void play (void*pv){if(!pv) return;((playrange0_*)pv)->vplay();
								((playrange0_*)pv)->threader.del(); }
	virtual	void vplay();
	virtual int	 ckfname(chars& cs){return 1;}
	virtual void begplay(int ith, qiimbuf_& qbuf);
	virtual void endplay(int ith, qiimbuf_& qbuf);
	void stopclose();
	void start(char* fnames, char* pname1=0);//will sep fnames into spprng
public:
	HANDLE hnd()  { return threader.hnd;  }
public:
	threader1_ 	threader;
	charspp 	spprng;
	chars 		pname;
	qiimbuf_ 	qbuf;
};

class		playdaiqi_ : public playrange0_ {
public:
	virtual	void vplay  (         );
	virtual	int  ckfname(chars& cs){return csfname4play1daiqi(cs);}
};






class 	playbase {
public:	playbase():stopall(1), stopped(1){}
	int stopall, stopped;
public:
	static 	void splay	(void* pv){	if(!pv)return;playbase*pb=(playbase*)pv;
												pb->vplay();pb->threader.del();			 }
	void 	stopclose	(int sleepms=0);
public:
	virtual	void vplay(){;}
	virtual int	 ckfname(chars& cs){return 1;}
	virtual void begplay(int ith, qiimbuf_& qbuf){}
	virtual void endplay(int ith, qiimbuf_& qbuf){}
public:
	HANDLE 		hnd				(){ return threader.hnd;  }
public:
	threader1_ 	threader;
	qiimbuf_ 	qbuf;
};


class 	mftts_	{
public:	mftts_	(				):stopall(1), stopped(1){mfname="78dpy.dig";}
public:	mftts_	(char *mfn	):stopall(1), stopped(1){mfname=mfn;}
	void	play		(char *s		);
	void	thplay	(char *s		);
	void	setmfname(char *mfname1){mfname=mfname1;}
public:
	int stopall, stopped;
public:
	static 	void splay (void*pv){if(!pv) return;((mftts_*)pv)->vplay();
											((mftts_*)pv)->threader.del(); }
	virtual	void	vplay	 ();
	virtual	int	ckfname(chars& cs){return 1;}
	virtual	void	begplay(int ith, qiimbuf_& qbuf){}
	virtual	void	endplay(int ith, qiimbuf_& qbuf){}
public:
	void		stopclose	();
	HANDLE	hnd			(){ return threader.hnd; }
public:
	mfbuffer		mfb;
	chars 		mfname;
	threader1_	threader;
	charspp		spprng;// chars pname;
	qiimbuf_ 	qbuf;
};

class daiqimftts_ : public mftts_ { public:
		daiqimftts_ (			){}
		daiqimftts_ (char*mfn):mftts_(mfn){}
public:
	virtual	void	vplay();
};




/*
////////////////////////////////////////////////////////

// created 2004, modified 2004-03-12
// note to using owtplayer
// play(...) create/run thread,
//		which in turns call szplay(), really(sitze:sz) play qb
// in the meantime, main thread(program) is free to do other stuff,
// 		and one can call reset/position/isplaying to control the playing thread
// do not call owclose() more than necessary, or will hang
//		actually, do not owclose(), it is auto-ly called only in dtor
class	owtplayer{ public:
		owtplayer(				):p2qb(NULL),bBangImDiong(0),bOpened(0),hwo(NULL){}
		owtplayer(qiimbuf_ &p):p2qb( &p ),bBangImDiong(0),bOpened(0),hwo(NULL){}
	  ~owtplayer(){owdel();}
public:
	int		tplay		();
	int		tplay		(qiimbuf_* qb){p2qb= qb;return tplay();}
	int		tplay		(qiimbuf_& qb){p2qb=&qb;return tplay();}
public:
	virtual	void	szplay	();//thread main
public:
	int		reset	 		(int mswait=0);//stop the wave-playing
	int		owclose		();//owopen will be auto-called in dtor;
__int64		position 	();//by num_samples
	int		isplaying	() { return bBangImDiong;}
	//int		isplaying	() { return th.h&&bBangImDiong;}
public:
static	owtplayer*	newNplay(qiimbuf_& qb){owtplayer*ow=new owtplayer(qb);ow->tplay();return ow;}
public:
	void		owdel		(				){owclose();}
	int		canplay	(int mswait=0);
	int		owopen	(WAVEFORMATEX*fmt);
public:	//the waveout part
	volatile  int	bBangImDiong;
	short				bOpened;
	HWAVEOUT			hwo; // handle to the opened wave output device
	qiimbuf_ 		*p2qb;
	MMRESULT			res;
public:
protected:
	thinthread	th;
	eventhandle	evtplayend;
protected:
			void			thbegin		(){th.begin(THREADfunc,this);}
static	uint WINAPI THREADfunc	(void*pv);
static	void WINAPI WaveOutProc	(HWAVEOUT hwo,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);
};

//*/





//class iwhdrbuf_ :public WAVEHDR { public:
class iwhdrbuf_ { public:
	WAVEHDR hdr;
	short*  sh; // alloc-ed elsewhere, will not own sh, carry real data
	int     id;
	int     ii; //ing-ing, or idle
public: int res;
	int		prep   (HWAVEIN hwi) {return res=waveInPrepareHeader   ( hwi, &hdr, sizeof(WAVEHDR) ); }
	int		unprep (HWAVEIN hwi) {return res=waveInUnprepareHeader ( hwi, &hdr, sizeof(WAVEHDR) ); }
	int		add    (HWAVEIN hwi) {ii=0; return res=waveInAddBuffer ( hwi, &hdr, sizeof(WAVEHDR) ); }
	int		addif  (HWAVEIN hwi) {crtsection cs; cs.enter(); return (ii)?add(hwi):0; }
	int		addifii(HWAVEIN hwi) {crtsection cs; cs.enter(); return (ii)?add(hwi):0; }
public:
	float*	dnsmp2spt(ehfs_& ehfs, int nFS, int dnsmp, int dboff);//return fts
public:
	short   shs[nDQS_IDLEBUFSIZE];// used for compute. Thus after down sample,
	float   fts[nDQS_IDLEBUFSIZE];// frame size must be <=nDQS_IDLEBUFSIZE
	//////  The one that receives iwave data is from outside using set2(...)
public:
	void  hdr20 (           ) {memset(&hdr,0,sizeof(WAVEHDR));}
	int	  bsize (           ) {return hdr.dwBufferLength;  }// byte  size of wavedata
	int	  size  (           ) {return hdr.dwBufferLength/2;}// short size of wavedata
	short*OP()  (           ) {return sh;}
	int	  sub   (int	off ) {return sub((short)off);}
	int   sub   (short  off ) {int m,M=size();for(m=0;m<M;m++)sh[m]-=off;return M;}
	int   copy2 (short* sh1 ) {memmove(sh1, sh, bsize()); return size(); }
	int   copy2 (float* flt ) {int m,M=size();for(m=0;m<M;m++)flt[m]=sh[m];return M;}
	int   dnsmp2(float* flt, int dnsmp){int m,M=size();for(m=0;m<M;m+=dnsmp)flt[m]=sh[m];return M/dnsmp;}
public:
	void  set2  (int id1, short* sh1){id=id1;sh=sh1; hdr.lpData=(LPSTR)(sh); ii=1;}
};


enum {sr08K=0,sr16K,sr32K,sr48K,sr64K, sr11K,sr22K,sr44K};
class samplingrate{public:
	int 	nth2rate	(int 	nth	);
	char*	nth2str		(int 	nth	);//str: "8000"/"16000" etc
	char*	nth2sstr	(int 	nth	);//sstr: short str: "8K"/"16K" etc
	int		rate2nth	(int 	rate);
	char*	rate2str	(int 	rate);
	char*	rate2sstr	(int 	rate);
	int		str2nth 	(char*s		);
	int		str2rate	(char*s		);
private:
	chars cs;
};
extern samplingrate srdef;


class iwetc_ { public:
	enum	{ MIB=10 }; // max idle buf
public:
	double  avgenergy   (short* sh);//no adjustment
	double  bias        (         ){return dbbias;}
//	int     ssc         (short* sh,int forbeg);
	int     ssc         (iwhdrbuf_& iwhb, int forbeg);
public: //significant spectrogram components
public: int res;
	int     nframes     (qiimbuf_& qb){return qb.ssize()/(nFS);}//no shift
	int     beg4nthframe(int      nth){return nth*nFS; }
public:
	int     readsetadapt(char* fn=0, char*pn=0);// if(0) use "4adapt.sp"
	int     setadapt    (qiimbuf_* qb1=0);      // if(0) use in-class qbuf, else copy
	int     frame2spec  (short* sh, float* spt);// dboff, downsample too
	float*  sh2spt(short*sh,int nsh, float* spt,int nspt, int dnsmp,int fb_dboff=0)
				  {return ehfs.dfs1(sh,nsh,dnsmp,spt);}
	float*  sh2spt_woff(short*sh,int nsh, float* spt,int nspt, int dnsmp,int fb_dboff=0)
				  {return ehfs.dfs1off(sh,nsh,dnsmp,spt);}
public:
	void    set4   (int iwcase1 );//iwcase is sampling rate kind
	void    set_08K(            ){set4(sr08K );}
	void    set_16K(            ){set4(sr16K);}
	void    set_32K(            ){set4(sr32K);}
	void    set_48K(            ){set4(sr48K);}
	void    set_64K(            ){set4(sr64K);}
	void    set_11K(            ){set4(sr11K);}
	void    set_22K(            ){set4(sr22K);}
	void    set_44K(            ){set4(sr44K);}
	void    setpcm    (pcmfmt_  & pcm);
	void    setqiimbuf(qiimbuf_ & qb ){setpcm(qb.pcm);}
public:
	iwetc_(): iwcase(-1),adaptset(0),dboff(true),bhd(false),dhdbso(1)
							{set_16K();setiwhb(nFS);}
	ehfs_     ehfs;
	qiimbuf_  adbuf;
public:
  iwhdrbuf_ iwhb[MIB];  int iwhb_uselen;
  void      setiwhb	  (int use_len);
  int       idlebuflen(){return iwhb_uselen; }
  void      idlesprp  (HWAVEIN hwi){for(int m=0;m<MIB;m++)iwhb[m].prep  (hwi);}
  void      idlesunp  (HWAVEIN hwi){for(int m=0;m<MIB;m++)iwhb[m].unprep(hwi);}
  void      all2idle  (           ){for(int m=0;m<MIB;m++)iwhb[m].ii    =1;   }
  void      idlesadd  (HWAVEIN hwi){for(int m=0;m<MIB;m++)iwhb[m].add   (hwi);}
  void      addifidle (HWAVEIN hwi){for(int m=0;m<MIB;m++)iwhb[m].addif (hwi);}
public:
  int       iwcase;	// sampling rate case
  int		adaptset;
  enum 		{MFRMSZ=1024, HMFRMSZ=512};
  float     ads 	[MFRMSZ 		]; // ads: Adjusted/downsampled speech
  float     cutb	[HMFRMSZ		]; // trunctation threshhold for beg
  float     cute	[HMFRMSZ		]; // trunctation threshhold for end
  short     shallhb	[(MIB+1)*MFRMSZ ]; // all the short array for the wave-in hdr buf
  short     Lnorm; 					   // =1(L1-norm) or 2(L2-norm) def2 L2-norm
	int     init	(short Lnorm=1);
public:
  int     nsrt;   // sampling rate, sample per sec
  int     nspd;   // sampling period
  int     nchl;   // num. of channels
  int     nBps;   // num. of Bytes per sample
  void    init0		(		){nsrt=16000;nspd=625;nchl=1;nBps=2;}
  int     nms2nfrm	(int ms ){return int((nsrt/1000.*ms+0.5)/nFS);}
public:
  int     nFS;    // frame size, in sample
  int     nFFT;   // num of points to take FFT
  //int   nSS;    // shift size, in sample
  int     dnsmp;  // 1/2/4, down sample for endpoint
  bool    dboff;
  bool    bhd;    // bool for hongdua
  double  dbbias;
  double  dhdbso; //hongduabueso
  void    init1(){nFS=256;nFFT=128;dboff=1;bhd=0;dnsmp=2;dbbias=0;dhdbso=1;}
};


class lokim1_ { // fix length recording, non-threaded
public:
  int startlokim (qiimbuf_ & qbuf1, int nsh);// return nsh if success
public:
	  lokim1_(   ){hEventLokimEnd=CreateEvent(NULL,FALSE,FALSE,NULL);}
protected:
	int res, bOpened;
	HWAVEIN hwi;
private:
	static HANDLE hEventLokimEnd;
	static void CALLBACK waveInProc	(	HWAVEIN hwi,
										UINT 	uMsg,	DWORD	dwInst,
										DWORD 	dwPrm1, DWORD 	dwPrm2);
};

typedef lokim1_ adaptation_;


class lokim2_ : public lokim1_ {//at-most-length recording, threaded, can stop
public:
	int  startth(qiimbuf_& qbuf1, int nsh1, VFNV callback1);
	int  startth(qiimbuf_& qbuf1, int nsh1){return startth(qbuf1,nsh1,0);}
	int  startth(int nsh1)                 {return startth(qbufd,nsh1,0);}
	int  lokimstop(){ res=waveInReset(hwi);  return res==0; }
	virtual void callback(){}
	qiimbuf_ qbufd;
protected:
	static void thrdfunc(void* arg);
protected:
	threader1_ thrd;
	VFNV callbackfn;
	qiimbuf_* p2qbuf; int nsh;
};



enum iwstatus{ IW_DAN, IW_LOK, IW_TING};

class	lokim3_ {public://sim2 lokim2, at-most-length N, threaded, mainly4 lokim4
		lokim3_(iwetc_& iwe1):iwe(iwe1)
				{ hEventLokimEnd=CreateEvent(NULL,FALSE,FALSE,NULL);
										ResetEvent(hEventLokimEnd); }
public:
	int  startth(qiimbuf_& qbuf1, int nsh1, VFNV callback1);
	int  startth(qiimbuf_& qbuf1, int nsh1, feabuf_& fbuf1, int nthset);//fbuf1/nthset is not used, just 4 conven.
	int  startth(qiimbuf_& qbuf1, int nsh1){return startth(qbuf1,   nsh1,0);}
	int  startth(                 int nsh1){return startth(qbufd,   nsh1,0);}
	int  startth(                         ){return startth(qbufd,4800000,0);}
	int  lokimstop(){ended=1;res=waveInReset(hwi);res=waveInStop(hwi);
									 WaitForSingleObject(hEventLokimEnd,100); return res==0;}
protected:
	int       beged, ended;
	virtual void reset4be(            ){beged=ended=0;}
public:
	virtual int   wavein  (iwhdrbuf_* p2whb);
	//virtual void  showstatus(iwstatus status){return 0;}
	void    showstatus(iwstatus status){}
	virtual void  callback(){}
					VFNV  callbackfn;
	qiimbuf_    qbufd;
	static      HANDLE hEventLokimEnd;
protected:
							HWAVEIN hwi;
	int         res, bOpened;
	iwetc_&     iwe;
	qiimbuf_*   p2qbuf; int nsh;
	feabuf_ *		p2fbuf; int nthset;
	threader1_  thrd;
protected:
	virtual	int           startlokim 	();
	static void CALLBACK  waveInProc	(	HWAVEIN	hwi,
											UINT 	uMsg, 	DWORD dwInst,
											DWORD	dwPrm1,	DWORD dwPrm2);
	static void           threadfn(void*pv);
protected:
	void  set2idle  (int id ){iwe.iwhb[id].ii=1;    }
	void  idlesprp  (       ){iwe.idlesprp(hwi);    }
	void  idlesunp  (       ){iwe.idlesunp(hwi);    }
	void  idlesadd  (       ){iwe.idlesadd(hwi);    }
	void  idle_add  (int id ){iwe.iwhb[id].add(hwi);}
	void  dowhenidle(       ){iwe.addifidle(hwi);   }
	void  all2idle  (       ){iwe.all2idle (   );   }
};

class   lokim4_: public lokim3_ {
public:
		lokim4_(iwetc_& iwe1   ):lokim3_(iwe1){init4be(iwe1);}
public:
	int     wavein    (iwhdrbuf_* p2whb );  // virtual
public:
	enum    { MBB=20 }; // max begbuf, need 20kRAM, good4 20*10.6ms for 48k rate
	int       nbdur, nedur, nblurb, nbsil, nesil;
	int       nbDUR, neDUR, nBLURB, nbSIL, neSIL;//, nbTDUR;
	int       nbbnxt;
	float     bTHRS, eTHRS;
	short*    begbuf; int nbBUFS;  //int nbDURc;
	short     begbuf0[(MBB+2)*1024];
	int       init4be   (             ){return init4be(iwe);}
	int       init4be   (iwetc_& iwe1 );// one time initialization
	void      reset4be  (             );// reset bef each lokim
	void      bb20      (){memset(begbuf0,0,sizeof(short)*(MBB+2)*1024);}
public:
	int       maxnbsil  (             ){return MBB-nbDUR;}
	void      setnbSIL  (int nbSIL1   ){csbe(nbSIL1,1,maxnbsil());nbSIL=nbSIL1;}
	void      setneSIL  (int neSIL1   ){csbe(neSIL1,1,neDUR); neSIL=neSIL1;    }
	void      setneDUR  (int neDUR1   ){neDUR=neDUR1;if(neSIL>neDUR)neSIL=neDUR;}
	void      setneDURms(int neDURms  ){setneDUR(iwe.nms2nfrm(neDURms));}
public:
	int       forbeg    (iwhdrbuf_* p2whb);
	int       forend    (iwhdrbuf_* p2whb);
	int       forbegssc (iwhdrbuf_* p2whb){return iwe.ssc(*p2whb,1)>=bTHRS;}
	int       forendssc (iwhdrbuf_* p2whb){return iwe.ssc(*p2whb,0)< eTHRS;}
};



#include<speechio.cc>
/*
#undef TPC(X)
#undef TPC1(X)
#undef TPC2(X)
#undef TPC3(X)
#undef TPCI(X)
#undef TPCI1(X)
#undef TPCI2(X)
#undef TPCI3(X)
*/
#endif //#ifndef SPEECHIO_H




