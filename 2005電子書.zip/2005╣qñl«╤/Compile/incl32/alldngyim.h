
//
// file alldngyim.h
//

#ifndef ALLDNGYIM_H
#define ALLDNGYIM_H

#include <chars.h>
#include <voids.h>
#include <c3dzb.h>
#include <msgbox.h>

class alldngyim_ { public: r2ic3d_* riden; int MAX;
			alldngyim_(r2ic3d_* riden1, int MAX1=8){riden=riden1;MAX=MAX1;}
		 ~alldngyim_() { }
public:
	charspp spp;
	charspp dngyim;
	int set2(char*s);
	int checkAll1suGood();
	int alldngyim();
	int set2Nalldngyim(char*s) { set2(s); dngyim.clear(); return alldngyim(); }
	int find(char* substr){ return riden->find(substr);}
	char* substr(int beg, int end);
	int emit (short* a, int size);
public:
	int   size() { return dngyim.size(); }
	char* ithdngsu(int i) { return dngyim[i]; }
};

#endif //#ifndef ALLDNGYIM_H



