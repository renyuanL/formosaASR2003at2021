//
// dibase.h
//
// copyright 1994~2k Gang, IrngZin

#ifndef DIBASE_H
#define DIBASE_H

#ifdef FORCOMMENTONLY
  This collects (almost) all functions that proved useful
  _for writing daiim suriphuat and various utilities.
	The following classes are defined

	tos's
	class voids<simple_type>;
	//class sis_; extern sis_ sis; (string is)
	//class wis_; extern wis_ wis; (who is smaller)
	class chars;
	class charss;
	class charpp;
	class charspp;
	class tyio;
	class writer;
	class lreader;
	class inifname;
	struct szmioh;
	struct szmiohs;





#endif //#ifdef FORCOMMENTONLY

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <conio.h>
//#include <memory>
#include <vector>
#undef min
#undef max
#include <valarray>
#include <search.h>
#include <algorithm>
using namespace std;

#pragma warning(disable: 4786) //name too long for STL
#pragma warning(disable: 4244) //double to float
#pragma warning(disable: 4018) //signed/unsigned mismatch
#pragma warning(disable: 4267) //possible of data at conversion
#pragma warning(disable: 4312) //'���O�ഫ' : �N 'int' �ഫ�����j�� 'void *'


const char ch01='\x01';
const char ch02='\x02';
const char ch03='\x03';
const char ch04='\x04';
const char ch05='\x05';
const char ch06='\x06';
const char ch07='\x07';
const char ch08='\x08';
const char ch09='\x09';
const char ch10='\x10';
const char chff='\xff';


typedef unsigned char  UCHAR;
typedef unsigned short USHORT;
typedef unsigned int   UINT;
typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned int   uint;
typedef unsigned int   WPARAM;
typedef const char  cchar;

#define OP				operator
#define MBOKRET(x,y) 	{MessageBox(0,x,y,MB_OK);return;  }
#define MBOKCNT(x,y) 	{MessageBox(0,x,y,MB_OK);continue;}
#define MBOKRETR(x,y,r) {MessageBox(0,x,y,MB_OK);return r;}
#define MBOKONLY(x,y) 	{MessageBox(0,x,y,MB_OK);					}
#define CRFLRET(x) 		{MessageBox(0,x,"cannot create file",MB_OK);return	;}
#define OPFLRET(x) 		{MessageBox(0,x,"cannot open file",  MB_OK);return	;}
#define CRFLRETR(x,r) 	{MessageBox(0,x,"cannot create file",MB_OK);return r;}
#define OPFLRETR(x,r) 	{MessageBox(0,x,"cannot open file",  MB_OK);return r;}


// remember spaces after TPC(X)
#define TPC(X)			template<class X>
#define TPC1(X)			template<class X>
#define TPC2(X,Y)		template<class X, class Y>
#define TPC3(X,Y,Z)		template<class X, class Y, class Z>
#define TPCI(X)			template<class X> inline
#define TPCI1(X)		template<class X> inline
#define TPCI2(X,Y)		template<class X, class Y> inline
#define TPCI3(X,Y,Z)	template<class X, class Y, class Z> inline
//vitr means iterator of vector/valarray/array, or random acess iterator




extern char *tosfmtc,*tosfmts,*tosfmtuh,*tosfmtd,*tosfmtui,*tosfmth,*tosfmtld,*tosfmtf,*tosfmtlf;

inline void tos(char*s, char   v, char* fmt=tosfmtc ){ sprintf(s,fmt,v); }
inline void tos(char*s, char*  v, char* fmt      	){ sprintf(s,fmt,v); }
inline void tos(char*s, USHORT v, char* fmt=tosfmtuh){ sprintf(s,fmt,v); }
inline void tos(char*s, int    v, char* fmt=tosfmtd ){ sprintf(s,fmt,v); }
inline void tos(char*s, uint   v, char* fmt=tosfmtui){ sprintf(s,fmt,v); }
inline void tos(char*s, short  v, char* fmt=tosfmth ){ sprintf(s,fmt,v); }
inline void tos(char*s, long   v, char* fmt=tosfmtld){ sprintf(s,fmt,v); }
inline void tos(char*s, float  v, char* fmt=tosfmtf ){ sprintf(s,fmt,v); }
inline void tos(char*s, double v, char* fmt=tosfmtlf){ sprintf(s,fmt,v); }

char*ntos(char*  v, int   len      ); // copy at most len char's

char* tos(char   v, char* fmt=tosfmtc ); // r: result string[257]
char* tos(char*  v, char* fmt=tosfmts ); // r: result string[257]
char* tos(USHORT v, char* fmt=tosfmtuh); // r: result string[257]
char* tos(int    v, char* fmt=tosfmtd );
char* tos(uint   v, char* fmt=tosfmtui);
char* tos(short  v, char* fmt=tosfmth );
char* tos(long   v, char* fmt=tosfmtld);
char* tos(float  v, char* fmt=tosfmtf );
char* tos(double v, char* fmt=tosfmtlf);

inline int    s2i (cchar* s) { return atoi(s); }
inline long   s2l (cchar* s) { return atol(s); }
inline USHORT s2us(cchar* s) { return (USHORT)atoi(s); }
inline double s2f (cchar* s) { return atof(s); }
inline double s2d (cchar* s) { return atof(s); }

TPC(T) void cslimit(T &t, const T&lo, const T& hi);//*check-set t in limits [lo,hi]
TPC(T) int  cklimit(T  t, const T lo, const T  hi);//*check t in limits [lo,hi]
TPC(T) void cslmt  (T &t, const T&lo, const T& hi);//*check-set t in limits [lo,hi]
TPC(T) int  cklmt  (T  t, const T lo, const T  hi);//*check t in limits [lo,hi]
TPC(T) void csbe   (T &t, const T&be, const T& en);//*check-set t in limits [be,en)
TPC(T) int  ckbe   (T  t, const T be, const T  en);//*check t in limits [be,en)

inline void icslimit(int& t, int lo, int hi){if(t<lo)t=lo;if(t>hi)t=hi;}
inline int  icklimit(int& t, int lo, int hi){return((t<lo)||(hi<t))?0:1;}

// 768 color "levels" as there are 256 grey levels
typedef unsigned long COLORREF;
COLORREF clr768 (int ndx);
inline COLORREF clr768c(int ndx){return clr768(768-ndx);}
inline COLORREF clr01  (float x){return clr768(int(768*x));}
inline COLORREF clr01c (float x){return clr768(int(768*(1.-x)));}



struct charp2 { char *s1, *s2; charp2():s1(0),s2(0){}
charp2(char*p1, char*p2):s1(p1),s2(p2){}
};


//#ifndef MSGBOX_H
//#include <msgbox.h>
//#endif //#ifndef MSGBOX_H
/////////////////////////////////////
enum DI5MSG_MMODE {DI5MSG_MNULL, DI5MSG_MDOS, DI5MSG_MWIN, DI5MSG_MAUTO};
enum DI5NSG_DMODE {DI5MSG_DNULL, DI5MSG_DEBUG};   //up: MAUTO 2 MDOS/MWIN

class  messagebox_ {int mm, dm; // dm is currently not used
public:messagebox_():dm(DI5MSG_DNULL) {mmode_autoset();}
	void mmode_autoset();//set2 MDOS/MWIN 4 defined _CONSOLE or not
	void setmmode(int mmode) { mm=mmode; }
	void setdmode(int dmode) { dm=dmode; }
	char msg     (cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
public:// the fo3 works for DOS mode only, although will show msg
	char pause   (cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
	char ask4quit(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
	char ask4exit(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
};
extern messagebox_ msg;


//char pausebox  (cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
//char messagebox(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);

inline
char msgbox(cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.msg(s1,s2,s3,s4);}
inline
char pause (cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.pause(s1,s2,s3,s4);}

inline
char ask4quit (cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.ask4exit(s1,s2,s3,s4);}

inline
char ask4exit (cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.ask4exit(s1,s2,s3,s4);}

#define VOIDRTN(x1)			{ x1; return  ; }
#define VALRTN(r,x1)		{ x1; return r; }
////////////////////////////////////////////////////

class 	stepmsg_ { public: int i, ntv; //ntv: interval
		stepmsg_(int ntv1=1000){i=0;ntv=ntv1;}
	void inc(); // increment and message if reach multiples of ntv
	void showfull(cchar*pre_str=0, cchar* post_str=0);
	void reset(int ntv1=1000){i=0;ntv=ntv1;}
	void operator++(int) { inc(); }
	int  operator()(   ) { return i; }
};
extern stepmsg_ stepmsg;



class byteswap_ { public:
	int   operator()(int   a){bs4(&a);return a;}
	short operator()(short a){bs2(&a);return a;}
	float operator()(float a){bs4(&a);return a;}
public:
	void  bs4 (void* p);
	void  bs2 (void* p);
};
extern byteswap_ bswap;
// example: int   a; ... ; a=bswap(a); or bswap.bs4(&a);
// example: short a; ... ; a=bswap(a); or bswap.bs2(&a);
// example: float a; ... ; a=bswap(a); or bswap.bs4(&a);



class chars;
typedef const chars cchars;

#ifdef DI5USEMEMPOOL

template<size_t BSZ> // node size, must > 4, where 4=sizeof(charnode*)
struct charnode{ charnode* next; char c[BSZ-4]; };

template<size_t BSZ, size_t PSZ>
class mpool {
public:
	void 	dllc (void*un1, size_t bsz1);
	void*	allc (			size_t bsz1);
public:
   ~mpool	() { dllc_pnodes(); }
	mpool	(): phead(0), uhead(0), psz(PSZ), bsz(BSZ), pn_destroyed(0){}
private:
	typedef charnode<BSZ    > unode; size_t bsz; unode* uhead;
	typedef charnode<BSZ*PSZ> pnode; size_t psz; pnode* phead;
	int pn_destroyed;
	void 		dllc_pnodes();
	int  		allc_pnodes();
};

class capool1_{
public:
	void	dllc(void*p, size_t bsz){free(p);}
	char*	allc(		 size_t bsz){return (char*)malloc(bsz);}
public:
	size_t sz1() { return  64;}
	size_t sz2() { return 256;}
};

class capool2_{ // char array pool
public:
	void 	dllc(void*p,size_t bsz){(bsz==64)? mp1.dllc(p,bsz):mp2.dllc(p,bsz);}
	char*	allc(size_t bsz){return(char*)((bsz==64)?mp1.allc(bsz):mp2.allc(bsz));}
public:
	size_t sz1() { return  64;}
	size_t sz2() { return 256;}
private:
	mpool< 64, 256> mp1;
	mpool<256,  64> mp2;
};

class pppool1_{
public:
	void	dllc(void*p, size_t usz){free(p);}
	char**allc(				 size_t usz){return (char**)malloc(sizeof(char*)*usz);}
public:
	size_t sz() { return  24;}
};

class pppool2_{ // char** array
public:
	void 	dllc(void*p,size_t usz){mp.dllc(p,sizeof(char*)*usz);}
	char**allc(			  size_t usz){return(char**)mp.allc(sizeof(char*)*usz);}
public:
	size_t sz() { return  24;}
private:
	mpool<sizeof(char*)*24, 64> mp;
};

class csspool1_{
public:
	void	dllc(void*p, size_t usz){free(p);}
	chars*allc(				 size_t usz){return (chars*)malloc(sizeof(chars*)*usz);}
};

class csspool2_{//chars* array
	void	dllc(void*p,size_t usz){mp.dllc(p,sizeof(chars*)*usz);}
	chars*allc(				size_t usz){return(chars*)mp.allc(sizeof(chars*)*usz);}
private:
	mpool<sizeof(chars*)*256, 8> mp;
};

typedef capool1_ 	capool;
typedef pppool1_ 	pppool;
typedef csspool1_ csspool;

#endif //#ifdef Di5USEMEMPOOL


template<class T>
class voids { public:
	voids(int size):a(0){ init20();resize(size);}
	voids(		  ):a(0){ init20();				}
   ~voids(		  )		{ destroy(); 			}
public:
	int   own;
	int   allocsize;
	int   asz;
	T*    a;
	void  init20() {a=0;asz=0;allocsize=0; own=0;}
public:
	int  resize(int size);
	uint nextsz(		);
public:
	T*  operator()	(     )			{ return a;		}// or (variable name).s
	T&  operator[]	(int i)const{ return a[i];}// so no app thru this function
	T&  v			(int i)const{ return a[i];}// v: value
	int isgood		(int n)			{ return ( (n>=0)&&(n<size()) )?1:0; }
	int size		(     )			{	return asz; 			}
	T&	last		(     )			{ return a[asz-1];	}
	int push_back	( T t )			{ return app(t);		}
public:
	int 	app		(T t		 );
	int 	ins		(T t, 	int n);
	T   	del		(int n		 );
	T   	rm  	(int n		 );
	void   operator=(voids<T> & r);
public:
	//dn: should free each T, but that add complication, so only simple type
	void destroy()		{ if(own){ free(a); init20();} }
	void clear()		{ asz=0; }
	void reset()		{ asz=0; }
};




ushort big52ser(char* s1);												//ret: ser
ushort ser2big5(unsigned short sernum, char* s);	//s has least 3B, ret 2 if succ
int        inbig5range(char* s, ushort base, int beg, int end);

int		str_rbytes		(cchar* s);//r: 0 null; 2 hanzi; 1 others including ascii
int		str_lbytes		(cchar* s, int at);
int 	str_nexthanlor	(char*s, int& hanlorpunct);//han/lor/lorpunct:1/2/3
int 	str_nexthanlor	(char*s);
int 	str_uzorri 		(char*s);
inline int is012	 (cchar*s){return str_rbytes(s); }
inline int isbig5sicsi(char*s){return inbig5range(s,0x8800,   0,13053);}
inline int isbig5si   (char*s){return inbig5range(s,0x8800,   0, 5401);}
inline int isbig5csi  (char*s){return inbig5range(s,0x8800,5401,13053);}
inline int isEThanri  (char*s){return inbig5range(s,0x8800,   0,13094);}
inline int isbig5huhor(char*s){return inbig5range(s,0x8400,   0,  408);}
//there are 5401 freq-ly used hanri, total of 13053 hanri,
//beyond that, old ET system has 7 more hanri, and 34 table wchar=>13094
//there are 408 huhors etc,
//another set of 365 huhor's seems to disappear in windows



inline int 	istabspace  (char c) { return (c=='\t'||c==' '); }
int 		isbig5punct (char*s); // is head big5punct
int			isdigit2    (char*s); // is big5digit
int			is_tsrn     (char c); // tab space \r \n

char* str_skipheadblank0   		(char* s); //destructive to the array
inline char* str_skiptabsp    	(char* s){return(istabspace(s[0]))?str_skipheadblank0(s):s;}
inline char* str_skiptabspace 	(char* s){return str_skiptabspace(s);}
int str_delfirstN		(char* s, int N);
int str_delleadspaces 	(char* s);
int str_deltrailspaces	(char* s);
int str_delltspaces   	(char* s);

int		str_isin		(char c, char* s);
void	str_tolower		(char* s);
int		str_all1byte	(char* s);
int		str_all2byte	(char* s);
int   	str_alldigits	(char* s);
int   	str_hasdigit	(char* s);
int		str_hastabspace	(char*s);
int   	str_hashanri	(char* s);
int		str_isorset		(char* s); // strict, true if is (...), and no l/t spaces
int		str_hasorset	(char* s); // loose, true if has ( or ) or |
int   	str_mayberi		(char* s);

int   	str_isSS    (char* s); // slash slash at beg or at end
int   	str_isSSEE  (char* s); // slash slash exclamation exclamation
int   	str_isblank (char* s); // is blank, nothing other than tabs/spaces
int		str_isgline	(char* s);
int		str_isrline	(char* s);
int		str_isPBC   (char* s, char c1st, char clast, char c);
int		str_isP_P 	(char* s, char c=0);
int		str_isB_B 	(char* s, char c=0);
int		str_isC_C 	(char* s, char c=0);

int		str_startwith   (char* s, char* match, int N=-1);
int		str_endwith     (char* s, char* match, int N=-1);
int 	str_esfind1	    (char* s, char c); // r:-1 if not find, find c but not \c
int 	str_find1		(char* s, char c); // r:-1 if not find
int 	str_find2		(char* s2, char*match2); // r:-1 if not find
int 	str_findlast    (char* s, char c); // r:-1 if not find
int 	str_findts	    (char* s);         // r:-1 if not find, ts: tabspace
int 	str_findnonts   (char* s);         // r:-1 if not find
int 	str_findtsrn    (char* s);//tab space \r \n
int 	str_findnontsrn (char* s); //tab space \r \n
int		str_find 		(char* s, char* match, int len2match=-1);//-1 for whole match
int   	str_finddigit   (char* s);// find 1stpos that is digit
int		str_findedigits	(char* s);// find begpos of trailing digit str
int   	str_findnondigit(char* s);
//up1: r: startpos of match in s, 0-based		//simple match only

char* orset_1stoption1(char* src);
char* orset_1stoption (char* src);

char*	str_search4			(char* s, char c);
char*	str_search4crnl		(char* s);				//return null if not found
char*	str_search4crORnl	(char* s, int* nbytes_returned);
int		str_countlet		(char* t);


// down:  return num replaced
int		str_replacepunct (char* s, char replacement=0);
int		str_replacedigits(char* s, char replacement=0);
void	str_replacewchar (char*s, char* rt, char r=0);
int		str_replace		 (char*s, char tobereplaced, char replacement=0);
int 	str_replacecrnl	 (char*s, char r);
int		str_trts		 (char* s, char ch2rep); // tr tab/space
int  	str_tr		 	 (char*s, char tbr, char r=0);//inlined
int 	str_nchar		 (char* s, char c); // count num of c in s

int str_isxtag(char* s, char* tag);
int str_rm_esmark(char* s); // be used after spp.set2Neshun and in xtos
//up: change \\ 2 \, \" 2 ", \r \n \t to single char, destructive 2 the str

int str_control_ch2ch1(char* s, char control, char ch, char ch1 );
int str_slashch2ch1  (char*s,char ch, char ch1 );//inlined
int str_bslashch2ch1 (char*s,char ch, char ch1 );//inlined
int str_slash_ch2ch1 (char*s,char ch, char ch1 );//inlined
int str_bslash_ch2ch1(char*s,char ch, char ch1 );//inlined
//transf /ch to ch, ch to ch1, etc

inline void str_rmove    (char* s, int slen, int nbytes);//inline 2 memmove
inline void str_overwrite(char* st, char* ss, int sslen);//inline 2 memmove

int		str_ki2it		 		(char* s);  // destructive
void  str_deldigits		(char* s);  // destructive
void  str_delbutdigits(char* s);  // destructive
void  str_delbutpuncts(char* s);  // destructive
void  str_delbutpunctdigits(char* s);  // destructive
char* orset_1stoption	(char* src);//must bw'(', ew')',&no nested(), or ret src
/////******************************/////
void  str_del4wis  (char* s); //del digits and '-' but not leading digits
/////******************************/////
void  str_del2kauqidiau(char*s);
void  str_del2danridiau(char*s);
char* str_daiqibendiau (char*s);
char* str_daiqidanribendiau(char* danridiau);
void  str_kauqidiau_pos(char*s, voids<int> * p, int checksinglediau=0);
int   str_kauqidiau_pos(char*s, vector<int>& p, int checksinglediau=0);
int   str_danridiau_pos(char*s, vector<int>& p);
void  str_tokendelimpos(char*s, voids<int>* p);

int		str_is1stpi (char* pi, char* ri);
int		str_setpi_ri(char** pi, char** ri, char* s1, char* s2);

int upper			(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ
int lower			(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ
int bfind			(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ
int bfindlast	(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ

// following 5 for binary search: key always on the left when wis is called
int __cdecl wislower (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *)
				);

int __cdecl wisupper (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *)
				);

int __cdecl wislower1 (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
				);

int __cdecl wisupper1 (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
				);

int __cdecl bfind ( // same as bsearch, return -1 if not found
				const void *key,
				const void *base,
				size_t numelem,
				size_t width,
				int (__cdecl *compare)(const void *, const void *)
				);


class wis_ { // who is smaller, -1 for left, 0 for eq, +1 for right
public:
static int pi	(const char** ll, const char** rr);
static int rdpi	(const char** ll, const char** rr);
static int pi	(const char*  ll, const char*  rr);//??
static int rdpi	(const char*  ll, const char*  rr);//??
static int hanzi(const char*   l, const char*   r) {return(l[0]==r[0])?(UCHAR(r[1])-UCHAR(l[1])):(UCHAR(r[0])-UCHAR(l[0]));}
public:
static int sNsp (const void*l, const void*r){	return strcmp((char*)l, *((char**)r)); }
static int spNsp(const void*l, const void*r){	return strcmp(*((char**)l), *((char**)r)); }
};
extern wis_ wis;



class chars { public:
	char* 	s;				//chuli only one strings
	size_t 	allcsize;	// asize(alloc size) in sizeof(char)
public:
	void  show      ();   //show by MessageBox
	void  show      (char* caption);
	char* c_str     ()     { return s; }
	char* operator()(){ return s; } // or (variable name).s
	char& operator[](int i) { return s[i];    }
	char* tosxa	    (char* ki, int begWspace=1);//tos to xml attribute: ki="..."
	int   hassome   () { return ((s)&&s[0]);    }
	int	  hasnone   () { return  !hassome();    }
	int   hashanri  () { return str_hashanri(s);}
	int   isempty   () { return  !hassome();    }
	int   isG       () { return isempty()?0:!(str_isSS(s)||str_isblank(s)); }
	int	  allblank  () { return str_isblank(s); }//* nothing other than tabs/spaces
	int	  isblank   () { return str_isblank(s); }//* nothing other than tabs/spaces
	int	  isgline   () { return str_isgline(s); }
	int	  alldigits () { return str_alldigits(s);}
	int   bwdigit   () { return isdigit(s[0]);   }
	uint  size      () { return strlen(s);      }
	int   usize     () { return charunits();    }
	int   charunits (); // in unit of echar and cchar, not in byte
	int	  charunits (int nthbyte);//num of unit to pass/upto nthbyte
	int	  tolower		();
	int	  toupper		();
public:
   ~chars(		  )      { destroy(); init20(); }
	chars(		  ) :s(0){ init20(); resize(64);  clear(); }
	chars(char* s1) :s(0){ init20(); set2(s1);	}
	chars(char   c) :s(0){ init20(); set2(c);   }
	chars(ushort i) :s(0){ init20(); set2(tos(i));   }
	chars(short  i) :s(0){ init20(); set2(tos(i));   }
	chars(int    i) :s(0){ init20(); set2(tos(i));   }
	chars(long   i) :s(0){ init20(); set2(tos(i));   }
	chars(float  d) :s(0){ init20(); set2(tos(d));   }
	chars(double d) :s(0){ init20(); set2(tos(d));   }
	chars(const chars&cs):s(0){ init20(); set2(cs.s);}
//	chars(int size) :s(0){ init20(); resize(size);clear(); }
public:
	int		has 	(char c		){ return str_find1(s, c)>=0; 	}
	int		has 	(char*sstr	){ return str_find(s, sstr)>=0; }
	int		hascnt	(char c		){ return str_nchar(s,c);			} // count num of c
	int		nchar	(char c		){ return str_nchar(s,c);			} // count num of c
	int		find	(char c		){ return str_find1(s, c); 		}
	int		esfind	(char c, 		uint begfrom);                // find c but not \c
	int		esfind	(char c		){ return str_esfind1(s, c);	} // find c but not \c
	int		find	(char c,	uint begfrom);
	int		find	(char*sstr, uint begfrom);
	int   findlast	(char c    )const		{ return str_findlast(s,c); }
	int   findblank	(          ){ return str_findtsrn(s);}//find 1st tab/space
	int   findblank	(uint bfrom){ return(bfrom<size())?str_findtsrn(s+bfrom):-1;}
	int   finddigit	(          ){ return str_finddigit(s);}//find 1st digit
	int   finddigit	(uint bfrom){ return(bfrom<size())?str_finddigit(s+bfrom):-1;}
	int   findnonblank(          ){ return str_findnontsrn(s);}//find 1st non-digit
	int   findnonblank(uint bfrom){ return(bfrom<size())?str_findnontsrn(s+bfrom):-1;}
	int   findnondigit(          ){ return str_findnondigit(s);}//find 1st non-digit
	int   findnondigit(uint bfrom){ return(bfrom<size())?str_finddigit(s+bfrom):-1;}
public:
	void cpy		(char*s1){ set2(s1);  		}
	void cat		(char*s1){ app (s1);  		}
	void catln		(char*s1){ appln(s1); 		}
	void catln		(		){ app("\r\n");		}
public:
	void set20 		(		   		);//inlined
	void clear 		(				){ set20();}
	int  set2  		(cchar*s1		);
	int  set2  		(cchar*s1, int N);
	int	 set2  		(cchars& cs		){return set2(cs.s);}
public:
	void app        (cchar*s1		);
	void app        (char* s1,int N	);
	void app1       (char  c		);
	void app        (const char c	){ app1(c);}//char s1[2];s1[1]=0;s1[0]=c; app(s1); }
	void app	    (cchar*s1,cchar*s2){ app(s1);app(s2);   }
	void app	    (cchar*s1,cchar*s2,cchar*s3	){ app(s1);app(s2);app(s3);   }
	void app	    (cchar*s1,cchar*s2,cchar*s3,cchar*s4){ app(s1);app(s2);app(s3);app(s4);   }
	void app	    (cchar*s1,cchar*s2,cchar*s3,cchar*s4,cchar*s5){ app(s1);app(s2);app(s3);app(s4);app(s5);   }
	void appifnotew (char*s1          ){ if(!ew(s1))app(s1);}
	void appifen    (char*s1          ){ if(!ew(s1))app(s1);}
	void apptimes	(char c, int times);
public:
	void appsep(cchar*s1,char c='\t'){char s[2];s[1]=0;s[0]=c;app(s1);app(s);}
	void apptab(cchar*s1){ app(s1); app("\t");		}
	void appln (cchar*s1){ app(s1); app("\r\n"); 	}
	void apptab(char c	){ app(c);  apptab(); 		}
	void appln (char c	){ app(c);  appln (); 		}
	void apptab(		){ app("\t"); 						}
	void appln (		){ app("\r\n"); 					}
public:
	int floor  (int  n); // return good char boundary
	int ceiling(int  n); // return good char boundary
	int goodat(int  at);
	int lbytes(int  at); // nbytes of character at left,  0 or 1 or 2
	int rbytes(int  at); // nbytes of character at right, 0 or 1 or 2
	int rbytes(				){return rbytes(int(0));}
	int lbytes(int* at){return lbytes(*at);}
	int rbytes(int* at){return rbytes(*at);}
	int left  (int* at); // nbytes of character at left,  0 or 1 or 2
	int rite  (int* at); // nbytes of character at right, 0 or 1 or 2
	int ins1(int* at, char c );// { char s1[2]=" ";s1[0]=c; return ins(at,s1,1); }
	int ins (int* at, char c ){return ins1(at,c);}// { char s1[2]=" ";s1[0]=c; return ins(at,s1,1); }
	int ins (int* at, char*s1) { return ins(at,s1,strlen(s1)); }
	int ins (int* at, char*s1, int nbytes);
	int ins (int  at, char c ) { return ins(&at, c); }
	int ins (int  at, char*s1) { return ins(&at,s1,strlen(s1)); }
	int ins (int  at, char*s1, int nbytes){return ins(&at, s1, nbytes);}
	int insb(char c, int at_fromb);//{char s[2];s[0]=c;s[1]=0;return insb(s,at_fromb);}
	int insb(char*s, int at_fromb);//if(at>size())then regress2 app
	int inse(char c, int at_frome);//{char s[2];s[0]=c;s[1]=0;return inse(s,at_frome);}
	int inse(char*s, int at_frome);//if(at>size())then regress2 ins at 0
	int del(int* at); // del a character at right, 0 or 1 or 2
	int del(int  at)            { return del(&at); }
	int del(int* at, int nbytes);
	int del(int beg, int end) { /*static int b=beg;*/ return del(&beg, end-beg); }
	int BS (int* at); // BS  a character at left,  0 or 1 or 2
	int BS (int* at, int nbytes);
	int tr(char tobereplaced, char replacement=0){ return str_replace(s,tobereplaced,replacement);}
	int	trcrnl(char replacement=0) {return str_replacecrnl(s,replacement);}
	int trtab (char replacement=0) {return str_replace(s,'\t',replacement);}
	int trdigits(char replacement=0) { return str_replacedigits(s,replacement);}
	int trts(char replacement=0) { return str_trts(s,replacement);}
	int	yimtr_begwy(int& begdeleted	);
	int	yimtr_begwy(								){int d; return yimtr_begwy(d);}
public:
	int inssep4hanlor   (char* sep=0, int hunguao =0);//sep def2 "\t"
	int inssep4tokenizer(char* sep=0, int hunhanri=0);//sep def2 "\t"
	int inssep4012		(char* sep=0);//sep def2 "\t"
public:
	int  dellastbyte 	();
	void dellastdigit	() { if(isdigit(lastbyte())) s[size()-1]=0; }
	char lastbyte    	() { if(s[0]) return s[size()-1]; else return s[0]; }
	char lastbyte1   	();//return non-0 only if last is 1byte;
	char bB 			() {return s[0];}
	char eB				() {return lastbyte();}
	void dellastdiauhor	();
	int	 delfirstN		(int N){return str_delfirstN(s,N);}
	int  dellastN 		(int N);
	int	 delb			(int N){return delfirstN(N);}
	int	 dele			(int N){return dellastN (N);}
	void delbif         (      ){delleadspaces  (); }
	void deleif         (      ){deltrailspaces (); }
	void delbeif        (      ){delltspaces    (); }
	void delbif         (char c){if(bw(c))delb(1);  }
	void deleif         (char c){if(ew(c))dele(1);  }
	void delbif         (char*s){if(bw(s))delb(strlen(s));}
	void deleif         (char*s){if(ew(s))dele(strlen(s));}
	void delbupto		(char c){kidiaupart0(c);}//*delb upto c, including c
	int	 delleadspaces 	(	 ){return str_delleadspaces	(s);}
	int	 deltrailspaces	(	 ){return str_deltrailspaces	(s);}
	int  delltspaces	(	 ){return str_delltspaces		(s);}
	int  dellts			(	 ){return str_delltspaces		(s);}
	int	 trimb 			(	 ){return str_delleadspaces	(s);}
	int	 trime			(	 ){return str_deltrailspaces	(s);}
	int  trimbe			(	 ){return str_delltspaces		(s);}
	void del4wis		(	 ){ str_del4wis(s); }
	void fstoption		(	 );//first option in a or-set
	void tr4wis 		(	 ){fstoption();del4wis();}
	void tr2xml         (    );
	void trfromxml      (    );
	int	 is             (char* str){ return strcmp(s,str)==0; }
	int	 is             (chars str){ return is(str.s); }
	int	 rm_esmark		(	 ){return str_rm_esmark(s);}
public:
	int  laupart0   (			);
	int  laupart0   (char sep   );
	int  kidiaupart0(           );
	int  kidiaupart0(char sep   );
public:
	int	 isxtag 	(char* tg=0);
	int	 isxetag	(char* tg=0);//empty tag, note can have attr
	int	 isxotag	(char* tg=0);//open tag
	int	 isxctag	(char* tg=0);//close tag
	int	 isxcomment	();
	void appx		(char* tg, char*val=0, char sep='\t')
					{app(tg);app("=\"");app(val);app("\"");app(sep);}
public:
	int	 isnl		(			); 									// is \r\n or \n only
	int  isorset	(			)									{ return str_isorset(s); }
	int  startwith	(char* match, int N=-1)	{ return str_startwith(s,match,N);}
	int  endwith  	(char* match, int N=-1)	{ return str_endwith  (s,match,N);}
	int	 bw			(char* match, int N=-1) { return startwith(match,N); }
	int  ew 		(char* match, int N=-1) { return endwith  (match,N); }
	int  bw 		(char  c)				{ if(s) return (s[0]==c)?1:0; return 0;  }
	int  ew 		(char  c)				{ char cs[2];cs[0]=c;cs[1]=0; return ew(cs,1); }
	int  ewdigit	(       )				{ return isdigit(eB());}
	int  ew_nB		(       );//0 if none, 1 if ascii, 2 if hanri
public:
	void operator= (cchars&  cs) { clear();set2(cs.s); }
	void operator= (cchar*   s1) { if(s==s1)return;  clear();set2(s1  ); }
	void operator= (char      c) { clear();char s[2];s[0]=c;s[1]=0; app(s);}
	void operator= (ushort	  i) { clear();app(tos(i)); }
	void operator= (short     i) { clear();app(tos(i)); }
	void operator= (int       i) { clear();app(tos(i)); }
	void operator= (uint      i) { clear();app(tos(i)); }
	void operator= (long      i) { clear();app(tos(i)); }
	void operator= (float     d) { clear();app(tos(d)); }
	void operator= (double    d) { clear();app(tos(d)); }
public:
	void operator+=(const chars   s1) { app( (char*)(s1.s) );}
	void operator+=(const char*   s1) { app( (char*)s1     );}
	void operator+=(char           c) { char t[2];t[0]=c;t[1]=0;app(t);}
	void operator+=(unsigned short i) { app(tos(i)); }
	void operator+=(short          i) { app(tos(i)); }
	void operator+=(int            i) { app(tos(i)); }
	void operator+=(uint           i) { app(tos(i)); }
	void operator+=(long           i) { app(tos(i)); }
	void operator+=(float          d) { app(tos(d)); }
	void operator+=(double         d) { app(tos(d)); }
public:
	char*getfname	()const; // assume chars contains full path name
	char*getpname	()const; // assume chars contains full path name
	char*getename   ()const; // get ext name
	void appfname	(char*fname); // append // if necessary
	int  hasfileext ();
	int  insifnotone(char t=0);// pass t as 0 will make it '1', or tone 1
	int  insifnotone(int  &ptkh, char t);//check if the last byte bef ext is ptkh
	int  set24fep	(char* fname, char* ename, char* pname=NULL);
	int	 setpfname  (char* fname, char* pname=NULL);
	int	 getsetpname(char* s); // s is full path name ( maybe not)
	int	 getsetfname(char* s);
	int	 getsetename(char* s);
	char*delename	();        //del extension name if any
public:
	int  	resize	(size_t size);
private:
	void 	init20	(					){s=0;allcsize=0;}
	size_t 	nextsize(size_t newsize=-1	);
	void 	destroy	(					){free(s); init20(); }
private:
	//static	capool cap;
public:
	friend class charpp;
	friend class charspp;
	friend class charss;
	friend class xmltag;
	friend class xmltagrw;
};

#define TPC(X) template<class X>

struct 	csmanip	{ chars&(*fn )(chars&,int); int K;
			csmanip	( chars&(*fn1)(chars&,int), int K1):fn(fn1),K(K1){}
	chars&operator()(chars& cs){return (*fn)(cs,K);}
};
inline chars& operator<<(chars&cs,  chars&(*fn)(chars&)	){return fn(cs);}//this is a clever device
inline chars& operator<<(chars& cs, csmanip man)		 {man(cs);return cs;}

inline chars& operator<<(chars&cs, char* s){cs+=s;	 return cs;}
inline chars& tab 	(chars& cs){cs+="\t";  			 return cs;}
inline chars& endl	(chars& cs){cs+="\r\n";			 return cs;}
inline chars& endl2	(chars& cs){cs+="\r\n\r\n";	 return cs;}
inline chars& show	(chars& cs){cs.show();			 return cs;}
inline chars& showc	(chars& cs){cs.show();cs.clear();return cs;}
inline chars& flush	(chars& cs){cs.show();cs.clear();return cs;}
inline chars& clear	(chars& cs){			 cs.clear();return cs;}

//TPCI(T) chars& operator<<(chars&cs,	T&				t)	{cs+=t;return cs;}
inline  chars& operator<<(chars&cs, char				v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, short				v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, int				v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, float				v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, double		  	v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, unsigned char	v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, unsigned short	v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, unsigned int	v)	{cs+=v;return cs;}
inline  chars& operator<<(chars&cs, chars&			v)	{cs+=v;return cs;}

TPC(T) chars& operator<<(chars& cs, vector  <T>&  v);
TPC(T) chars& operator<<(chars& cs, valarray<T>&  v);
#undef TPC
//#undef TPC(X)



inline char* tos(chars s) { return tos(s.s); }
chars* getcharsbuf(); // return a chars from a pool

void str_auto_simple_bendiau (chars* im, int lastdanridiau=1);
inline void str_auto_simple_bendiau (chars& im, int lastdanridiau=1){ str_auto_simple_bendiau(&im,lastdanridiau);}
void str_auto_simple_bendiau2(chars* im);
typedef const chars cchars;
inline operator==(cchars& l, cchars& r){return strcmp(l.s,r.s)==0;}
inline operator!=(cchars& l, cchars& r){return strcmp(l.s,r.s);}
inline operator< (cchars& l, cchars& r){return strcmp(l.s,r.s)< 0;}
inline operator> (cchars& l, cchars& r){return strcmp(l.s,r.s)> 0;}
inline operator<=(cchars& l, cchars& r){return strcmp(l.s,r.s)<=0;}
inline operator>=(cchars& l, cchars& r){return strcmp(l.s,r.s)>=0;}

class charpp { 	public: 	// this is essentially voids<char*>
	uint 		sz; 		//num of valid char*
	char** 	pp; 			//chuli a group of strings
	uint 		allcsize;  	//asize in sizeof(char*), not byte size
	static	char* nullstr4charpp;
private:
	void init20				(			){ pp=0;allcsize=0;sz=0; }
	int  resize				(uint size);
	uint nextsize			(uint size);
	int  inbound			(int  i		){ return ((i>=0)&&(i<(int)allcsize)); }
	int  inbound			(uint i		){ return (i<allcsize); 								}
	int  expand				(			){ resize(nextsize(allcsize));return allcsize; }
public:
	char** operator()		(	 		){ return pp; }
	char*  operator[]		(uint i		){ return (i<sz)?pp[i]:nullstr4charpp; }
	char*  last				(			){ return pp[size()-1]; }
	uint   size				(			){ return sz; }
public:
	charpp					(			):pp(0){ init20(); 									}
	charpp					(int size	):pp(0){ init20(); resize(size);		}
 ~charpp					(			)      { destroy(); 								}
public:
	void set20				(			){ sz=0; 			}
	void clear				(			){ sz=0; 			}
	int	 set2				(cchar*	s1	){ set20(); return app(s1); }
	int	 app 				(cchar*	s1	);
private:
public:
	int  delpart			(uint i			);
	int  delparts_bw		(cchar* str		);
	int  startwith			(cchar* str, int N=-1,int from=0);
	int  bw					(cchar* str, int N=-1,int from=0){return startwith(str,N,from);}
	char*part_bw			(cchar* str, int N=-1,int from=0); // bw: begin with
public:
	char* tos				(char*sep, int beg, int end);
	char* tos   			(char sep, int beg, int end){char s[2];s[0]=sep;s[1]=0;return tos(s,beg,end);}
	char* tos				(char sep='\t'						 ){return tos(sep,0, size());}
	char* rtos				(char sep, int beg, int end){char s[2];s[0]=sep;s[1]=0;return rtos(s,beg,end);}
	char* rtos  			(char*sep, int beg, int end); // reverse tos
private:
	//static	pppool ppp;
	void 	destroy			(		){
										free(pp);
										init20();
	}
	//void 		destroy		(					){ ppp.dllc(pp, allcsize); init20();		}
public:
	friend class charspp;
	friend class charss;
	friend class xmltag;
	friend class xmltagrw;
};

int chars_hunNlet  (charpp& pp,chars& ss, int N=100000);
int chars_hunNbohun(charpp& pp,chars& ss, int N=100000, char crnl_replacement=' ');
// last argument means the option that crnl will be replaced with
// use 0 if want to remove all /r /n
int chars_cut(charpp&pp, chars& s, char ch, int N=100000);
int chars_eshun(charpp& pp, chars& ss, int N=100000, char crnl_replacement=' ');
// eshun: text in ".." will be treated as 1 part, \\ 4 \, and \" 4 "
int chars_ccut(charpp&pp, chars& s, char ch, int N);
//ccut, careful cut, tr the and \\ and \ch into  \ and ch

#define MXPT (1000000)
class	charspp {public:
		charspp		() {}
		charspp		(charspp& spp){set2(spp); }
		charspp		(char*  	s){set2Nhun(s);}
		charspp		(chars&	   cs){set2Nhun(cs.s);}
		charspp		(char*	s, char c){set2Ncet(s,c);}
		charspp		(chars&cs, char c){set2Ncet(cs.s,c);}
	   ~charspp		(){destroy();}
public:
		chars  s0;
		charpp pp0;
public:
	void  clear		(){s0.clear();  pp0.clear(); }
	void  reset		(){clear(); }
	int   size 		(){return pp0.size(); }
	void  destroy	(){s0.destroy();pp0.destroy();}
public:
	void  		operator= (const char* s1 ){s0.set2(s1); }
	charspp& 	operator= (charspp&    spp){set2(spp); return *this;}
public:
	int		set2			(charspp&  spp);
	void	set2			(cchar* s1    ){s0.set2(s1);}
	int		insert 			(int n,cchar*s);// insert at n, (stl sense)
	int		insert 			(int n,char  c){char s[2]=" ";s[0]=c;return insert(n,s);}
	int   	app     		(cchar* s	  ){return insert(size(), s); }
	int   	delpart 		(int i		  );//{return pp0.delpart(i); }
	int   	delparts_bw		(cchar* str	  );
	int   	del2kauqidiau	(			  );
	int 	del_kauqidiau	(			  );
	int   	del2kqd			(			  ){return del2kauqidiau();}
	int 	del_kqd			(			  ){return del_kauqidiau();}
public:
	int		atpart (int ip, int toleft=1);
public:
	int   	hun 	(int N=MXPT,char crnlrep=' '){return chars_hunNbohun(pp0,s0,N,crnlrep);}
	int		hun1d	(int N=MXPT					); // hun 1d str: (BYTE(strlen),str}...
	int		hun012	(int N=MXPT					){s0.inssep4012();	return hun(N); }
	int		ccut	(char ch, int N=MXPT		){return chars_ccut(pp0, s0, ch, N);}
	int		cut		(char ch, int N=MXPT		){return chars_cut (pp0, s0, ch, N);}
	int		cet		(char ch, int N=MXPT		){return chars_cut (pp0, s0, ch, N);}
public:
	int   	hunlet 	(int N=MXPT) { return chars_hunNlet(pp0, s0, N); }
	int   	hunrlet	(int N=MXPT); // rlet : non-empty line
	int   	hunglet	(int N=MXPT); // glet : non-enpty and not-commented by //
public:
	int		eshun	 (int N=MXPT) { return chars_eshun(pp0,s0,N,' ');}
	int		rm_esmark(			);
public:
	char* 	s		  ()      	{ return s0(); }
	char* 	operator()()      	{ return s0(); }
	char* 	operator[](int i) 	{ return pp0[i];}
	int		inbnd	  (int n) 	{ return cklmt(n, 0, size()-1); }
	int		goodndx	  (int n) 	{ return cklmt(n, 0, size()-1); }
	char* 	last	  ()		{ return pp0.last(); }
public:
	char* 	toline	  (char sep='\t'){ return toline(sep, 0, -1); }//-1 for upto last
	char* 	toline	  (char sep, int beg, int end); // end==-1 for upto last
	char* 	tos		  (char*sep, int beg, int end);
	char* 	tos		  (char*sep					 )	{return tos(sep,0,size());}
	char* 	tos   	  (char sep, int beg, int end)	{char*s=" ";s[0]=sep;return tos(s,beg,end);}
	char* 	tos		  (char sep='\t'			 )	{return tos(sep,0, -1 );}
	char* 	rtos  	  (char sep, int beg, int end); // reverse tos
public:
	char* 	xtagtos	  ();//return xml empty tag with tagname=pp0[0], and alternating attname/value pairs
	char* 	xtagtos	  (chars& cs);//same as above, but fill the result to cs. Also return cs.s
public:
	char*	xtos	  (char* tagname, charspp& fieldnames, char sep=' ');//do rm_esmark, then tr2xml
	char*	xtos	  (char* tagname, charspp& fieldnames, int* positions, char sep=' ');
public:
	int  	startwith (const char* str, int N=-1, int from=0){return pp0.bw(str,N,from);}
	char* 	part_bw	  (const char* str, int N=-1){return pp0.part_bw(str, N); }
	int		is   	  (int n, char*tt){return (strcmp(pp0[n],tt)==0);}
	int		isnot	  (int n, char*tt){return (strcmp(pp0[n],tt)!=0);}
	int		bw	 	  (int n, char*tt);//is part n bw tt?
	int		ew   	  (int n, char*tt);//is part n ew tt?
public:
	int		set2trNhun(cchar* str, char tobereplaced  ) {set2(str);s0.tr(tobereplaced,' ');return hun();}
public:
	int   	set2Nccut (cchar* str, char ch, int N=MXPT) { s0.set2(str); return ccut(ch, N); }
	int   	set2Nccet (cchar* str, char ch, int N=MXPT) { return set2Nccut(str, ch, N); }
	int   	set2Ncut  (cchar* str, char ch, int N=MXPT) { s0.set2(str); return  cut(ch, N); }
	int   	set2Ncet  (cchar* str, char ch, int N=MXPT) { return set2Ncut(str, ch, N); }
public:
	int   	set2Neshun(cchar* str, int N=MXPT) { s0.set2(str);int r=eshun(N); rm_esmark(); return r;}
public:
	int   	set2Nhun  	(cchar* str, int N=MXPT,char crnlrep=' ') { s0.set2(str); return hun(N,crnlrep); }
	int		set2Nhun1d	(cchar* str								){s0.set2(str);return hun1d(); }
	int		set2Nhun012	(cchar* str								){s0.set2(str);return hun012();}
	int   	set2Nhungu 	(cchar* str, int keeppunct=0, int N=MXPT);
	int   	set2Nhunlet	(cchar* str, int N=MXPT,char crnlrep=' ') { s0.set2(str); return chars_hunNlet(pp0,s0,N);}
	int   	set2Nhunsls	(cchar* str								);//sls 4 soliong su, f.e. 53van
	int   	set2Nhunplus(cchar* str, int N=MXPT,char crnlrep=' ');
	int   	set2Nhunpinim	(cchar* str, int N=MXPT, char crnlrep=' ',int keepdash=0);
	int   	set2Nhunhanlor	(cchar* str, int N=MXPT, char crnlrep=' ',int keepdash=0);
	int   	set2Nhunsentence(cchar* str, int N=MXPT ){ return set2Nhungu(str,N); }
	int   	set2Nhunorset	(cchar* str, int N=MXPT, char crnlrep=' ') { s0.set2(str); return hunorset(N,crnlrep); }
	int		hunorset		(			 int N=MXPT, char crnlrep=' ');
};
#undef MXPT





#define MXPT (10000)
class charss { public: voids<chars*> ss; //int sz;
public:
	charss(int size=12) 	{ ssresize(size); }
   ~charss()				{ destroy(); }
	static chars nullcs;
public:
	void ssdestroy		();
	void ssclear  		();
	void ssreset  		(){ ssclear(); }
	void clearcontent	();
	void destroy		(){	ssdestroy	(); }
	void clear			(){ ssclear		(); }
	void reset			(){ clear(); }
	int	 ssresize		(int newsize);
public:
	chars*	nth			(int n){nullcs.clear(); return inbnd(n)?ss.a[n]:(&nullcs);}
	char*	operator[]	(int n				) { return nth(n)->s;							}
	int		inbnd		(int n				) { return cklmt(n, 0, size()-1); }
	int		goodndx		(int n				) { return cklmt(n, 0, size()-1); }
	int		goodappndx	(int n				) { return cklmt(n, 0, size()	 ); }
	int		size		(					) {	return ss.size(); 						}
	char*	last		(					) { return operator[](size()-1);	}
	int		is   		(int n,char*tt) { return (strcmp(nth(n)->s,tt)==0);	}
	int		isnot		(int n,char*tt) { return (strcmp(nth(n)->s,tt)!=0);	}
	int		fillupto  	(int upto, char*s=0);//resize upto upto, and fill each with s
	int		resize    	(int upto, char*s=0);//resize upto upto, and fill extra chars with s
	int 	push_back	(char* s			) { return app(s); 										}
	int 	app			(char* s			) { return insert(size(), s);					}
	int 	insert		(int n,char* s);// insert s at part n (stl sense)
	int		insert		(int n,char  c){char s[2]=" ";s[0]=c;return insert(n,s);}
	int 	del 		(int n		);
	int		dele		(			){return del(size()-1);}// not acutally del chars
public:
	int		set2	(charspp* spp, int beg=-1, int end=-1);
	int		set2	(int n, const chars* s) { return update(n,s->s,1);}
	int		set2	(int n, const chars& s) { return update(n,s.s, 1);}
	int		set2	(int n, const char * s) { return update(n,s,   1);}
	int		update	(int n, const char * s, int expandss=0);
				//set2 the nth chars, expand if [n] not exist and expandss==1
public:
	char* tos		(char sep='\t'			 ){char s[]=" ";s[0]=sep;return tos(s,0,size());}
	char* tos		(char sep,int beg,int end){char s[]=" ";s[0]=sep;return tos(s,beg,end );}
	char* tos		(char*sep				 ){return tos(sep,0,size());}
	char* tos		(char*sep,int beg,int end);
public:
	int   startwith	(cchar* str, int N=-1, int from=0);
	int   bw		(cchar* str, int N=-1, int from=0){return startwith(str,N,from);}
public:
	int   set2Nhun			(cchar* str, int N=MXPT, char crnlrep=' ') { spp.set2Nhun			(str, N, crnlrep);  return set2(&spp); }
	int   set2Ncut			(cchar* str, char sep,   int N=MXPT				) { spp.set2Ncut			(str, sep, N    );  return set2(&spp); }
	int   set2Ncet			(cchar* str, char sep,   int N=MXPT				) { return set2Ncut   (str, sep, N    );                     }
	int   set2Nhungu		(cchar* str, int keeppunct=0, int N=MXPT ) { spp.set2Nhungu		(str,keeppunct,N);  return set2(&spp); }
	int   set2Nhunlet		(cchar* str, int N=MXPT, char crnlrep=' ') { spp.set2Nhunlet		(str, N, crnlrep);  return set2(&spp); }
	int   set2Nhunplus		(cchar* str, int N=MXPT, char crnlrep=' ') { spp.set2Nhunplus		(str, N, crnlrep);  return set2(&spp); }
	int   set2Nhunpinim		(cchar* str, int N=MXPT, char crnlrep=' ', int keepdash=0) { spp.set2Nhunpinim	(str, N, crnlrep, keepdash);  return set2(&spp); }
	int   set2Nhunhanlor	(cchar* str, int N=MXPT, char crnlrep=' ', int keepdash=0) { spp.set2Nhunhanlor	(str, N, crnlrep, keepdash);  return set2(&spp); }
	int   set2Nhunorset		(cchar* str, int N=MXPT, char crnlrep=' ') { spp.set2Nhunorset	(str, N, crnlrep);	return set2(&spp); }
	int   set2Nhunsls		(cchar* str)			 { spp.set2Nhunsls(str);  return set2(&spp); }//sls 4 soliong su, f.e. 53van
	int   set2Nhunsentence	(cchar* str, int N=MXPT ){ spp.set2Nhunsentence(str, N);  return set2(&spp); }
private: charspp spp; chars cs;
};
#undef MXPT

class pairss: public charspp { int sorted;
public:
	pairss() { sorted=0; }
	static chars nulls;
	int	getndx   (char* lhs);//seq/bin get depends on sorted
	int    set   (char* lhs, char* rhs);//forced set
	int  reset   (char* lhs, char* rhs);
	int  resetset(char* lhs, char* rhs){if(!reset(lhs,rhs))set(lhs,rhs);return 1;}
	char*  get   (char* lhs);// { return (sorted)?bget():sget();}
	int  isend   (char* s) { return (s==nulls.s); }
	int  get2i   (char*lhs,int def=-1){char*t=get(lhs);return(t&&t[0])?s2i(t):def;}
	void qsort   ();
};


class 	echars { public: int ip; chars cs; int dirt, set2isd;// editable chars
public:	echars(int set2isdirty1=0):set2isd(set2isdirty1){ clear(); }
	void 	clear		(		)			{ cs.clear(); ip=0;	dirt=0;}
	void	cksetip		(		)			{ cslimit(ip,0,size());}
	void	setip		(int ip1)			{ ip=ip1;cslmt(ip,0,size());}
	int		set2		(char*s,int ip1=0)	{cs=s;ip=ip1;dirt=(set2isd)?1:0;cslmt(ip,0,size());return cs.s?1:0;}
	int	 	ins			(char*s,int nB	 )	{int ret=cs.ins(&ip,s,nB);	dirt=1; return ret;}
	int	 	ins			(char c	)			{int ret=cs.ins(&ip, c);		dirt=1; return ret;}
	int	 	ins			(char*s	)			{int ret=cs.ins(&ip, s);		dirt=1; return ret;}
	int	 	del			(				)	{int ret=cs.del(&ip); 			dirt=1; return ret;}
	int	 	del			(int nB	)			{int ret=cs.del(&ip, nB);		dirt=1; return ret;}
	int		BS 			(				)	{int ret=cs.BS(&ip);				dirt=1; return ret;}
	int		BS 			(int nB	)			{int ret=cs.BS(&ip,nB);			dirt=1; return ret;}
	int		left		(				)	{return cs.left(&ip);}
	int		rite		(				)	{return cs.rite(&ip);}
	int		home		(				)	{int r=(ip<=0)?0:1; ip=0; return r;}
	int		end 		(				)	{int r,sz=size();r=(ip>=sz)?0:1; ip=sz; return r;}
	char* 	OP()		(				)	{return cs.s;}
	int		size		(				)	{return cs.size();}
	int		isdirty		(				)	{return dirt;}
	int		at  		(				)	{return ip;}
	int		atb			(				)	{return ip<=0;}
	int		ate			(				)	{return ip>=size();}
	char	prevb		(				)	{return (ip>0)?*(cs.s+ip-1):0; 	}
	char	nextb		(				)	{return *(cs.s+ip); 						}
	char	prevb		(char c	)			{return prevb()==c;			 	}
	char	nextb		(char c	)			{return nextb()==c; 			}
	char*	tos1 		(				)	{chars&s=*getcharsbuf();s.app(cs.s,ip);return s.s;}
	char*	tos2 		(				)	{chars&s=*getcharsbuf();s.app(cs.s+ip);return s.s;}
	char*	tosln(char sep=0)		{chars&s=*getcharsbuf();s.app(cs.s,ip);
															if(sep)s.app(sep);s.app(cs.s+ip);return s.s;}
	int		onchar	 (char   c);
	int		onkeydown(WPARAM w);
	int		dell_keep1tspace(); // del lead space, keep only 1 trail space if any
};

class 	mpfe_ { //multiple pfe // // to comment
public: mpfe_(){clear();}//#p:pname to change pname, #e:ename to change ename
	void 	clear(){spp.clear();pn.clear();en.clear();curr=-1;}
	int		set2Nhun		(char*ss,char sep=0); // sep==0 for hun space
	int		set2Nhunlet	(char*ss);
	int		nextall	(){while(1)if(!next())break;return 1;}
	int		next		(){return next0(NULL,fn,NULL);}
	int		nextf		(chars& fn1){return next0(NULL,fn1,NULL);}
	int		nextpf	(chars& pn1,chars& fn1){return next0(&pn1,fn1,NULL);}
	int		nextpfe	(chars& pn1,chars& fn1,chars& en1){return next0(&pn1,fn1,&en1);}
	chars&getpn		(){return pn;}
	chars&getfn		(){return fn;}
	chars&geten		(){return en;}
	chars&getpfe	(){tmp.set24fep(fn.s,en.s,pn.s);return tmp;}
private:
	charspp spp; chars tmp; int curr; chars pn,fn, en;
	int		next0	(chars* pn1, chars& fn1, chars* en1);
};




class istr4line {public:
	char* s; char*now;
	istr4line(char*  s1 ):s(0),now(0) {s=s1;now=s;} // will not own char*
	int hasmore() { return ((s)&&now[0]); }
public: // same as that in tyio8
	int  getline    (chars&buf); //get into outside resizable line recursively
	int  getsentence(chars&buf); // return num of bytes of the last punctuation
	//u2r:2 if juanhing,1 if buannhing,0 if not end with huhor(so check buf[0])
public:
	int  getrline(chars&buf); //rline: nonblank(real) line
	int  getgline(chars&buf); //gline: rline and not startting with //
};

class		curpath {
public:	curpath	():sz(0){init();}
void		init		();
char*	get 		(  int withbackslash=1);
char*	operator()(int withbackslash=1){return get(withbackslash);}
int		isCD		();
chars path; int sz;  uint drivetype;
};

extern curpath exepath;

char*	getexepath(int withbackslah=1);//actually startup path






void* new_pa(long size);
void 	delete_pa(void* pa);
int 	askOK4_file_overwrite(char*fname);

int tyjl_hunNbohun(char** ppt, char* ps, int N);

class tyio{ public:
	int hfile;
	int closable;
	void init_tyio0() { hfile=0; closable=0; }
	int  close();
public:
	tyio() { init_tyio0(); } // so that it will not be closed automatically
	tyio(tyio& io) { init_tyio0(); hfile=io.hfile;}
	tyio(char*fname,char*pname=0) { init_tyio0();open(fname,pname); }
	//~tyio() { if(closable) close(); }
 ~tyio() { close(); }// so closable is obslete
	int operator ()() { return hfile;   }
	int isOK()        { return hfile;   }
	int isERR()       { return !isOK(); }
	int isOK(char* fname);
public:
	int open       (char* fname, int ioflag);
	int open       (char* fname, char *pname=NULL);
	int openMES    (char* fname, char* pname=NULL){return openERRMES(fname,pname);}
	int openERRMES (char* fname, char* pname=NULL);
	int openOWmes  (char* fname, char* pname=NULL, char* mes=NULL);
	int openNerr   (char* fname, char* pname=NULL, char* mes=NULL){return !openOWmes(fname,pname);}
	int open4append(char* fname, char *pname=NULL);
	int creat      (char* fname, int ioflag); // ioflag 0 for normal read/write
	int creat      (char* fname, char *pname=NULL);
	int creatMES   (char* fname, char *pname=NULL){return creatERRMES(fname,pname);}
	int creatERRMES(char* fname, char *pname=NULL);
public:
	int  	exist   (char* fname, char* pname=NULL);
	long 	filesize();
	size_t 	read 	(void * p, size_t len);
	size_t 	write	(void * p, size_t len);
	size_t 	appfile	(char* fn, char* pn=0);
	size_t 	appfile	(tyio& io);
	long 	rmoveto	(long nbytes);//{return _llseek(hfile, nbytes, FILE_CURRENT);}
	long	rewind	();//{return _llseek(hfile,0,FILE_BEGIN);}
public: // dn: so sz must be long
	USHORT readsz (long* pl) { return (USHORT)read ( pl, sizeof(long)); }
	USHORT writesz(long  ll) { return (USHORT)write(&ll, sizeof(long)); }
//	char* readszblock (long* bsz_read_ED=0, int extra=0);//need to be castted
public: // binary write
	uint outs	(char   *p, uint len) { return put((void*)p,len);	}
	uint put	(void   *p, uint len) { return write(p, len); 		}
	uint put	(short  *p) { return put(p, sizeof( short)); }
	uint put	(ushort *p) { return put(p, sizeof(ushort)); }
	uint put	( int   *p) { return put(p, sizeof( int)  ); }
	uint put	(uint   *p) { return put(p, sizeof(uint)  ); }
	uint put	(float  *p) { return put(p, sizeof(float) ); }
	uint put	(double *p) { return put(p, sizeof(double)); }
	uint put	(char   *p) { return put(p, strlen(p)     ); }
	uint outs	(char   *p) { return put(p, strlen(p)     ); }
public: // binary read
	uint get( void  *p, uint len) { return read(p, len); }
	uint get( short *p) { return get(p, sizeof( short)); }
	uint get(ushort *p) { return get(p, sizeof(ushort)); }
	uint get( int   *p) { return get(p, sizeof( int)  ); }
	uint get(uint   *p) { return get(p, sizeof(uint)  ); }
	uint get(float  *p) { return get(p, sizeof(float) ); }
	uint get(double *p) { return get(p, sizeof(double)); }
	uint get(char   *p) { return get(p, strlen(p)     ); }
};


int  lread2gline (char*fn, charspp&buf, int appendit=0);
int  lread2rline (char*fn, charspp&buf, int appendit=0);
int  lread2line  (char*fn, charspp&buf, int appendit=0);
int  lreadNlines (char*fn, chars  &cs,  int N=-1);//N =-1 for all lines
int  lreadNglines(char*fn, chars  &cs,  int N=-1);//N =-1 for all lines

class lreader: public tyio { public:
	int tbuflen; int deletable; int EOF_reached;
	char* tbuf;     //tbuf: new-ed to tbuflen size, seems speedup io
	void init_tbuf0(){ tbuflen=0;deletable=0;EOF_reached=0; tbuf=0; }
	int  init_tbuf(int buflength);
	int  del_tbuf();
	int  fill_tbuf();
	void move_tbuf(char* from);
public:
	lreader()                  { init_tbuf0();init_tbuf(136); }
	lreader(int buflength)     { init_tbuf0();init_tbuf(buflength); }
	lreader(char* fname,char* pname=NULL, int buflength=136)
				 : tyio(fname,pname) { init_tbuf0();init_tbuf(buflength);}
	lreader(tyio &io)          { init_tbuf0();init_tbuf(136); init_tyio0(); hfile=io.hfile; }
	lreader(lreader &lr)       { init_tbuf0();tbuf=lr.tbuf;tbuflen=lr.tbuflen; hfile=lr.hfile;}
   ~lreader() { del_tbuf(); tyio::close();}
public:
	int  open (char* fname, char *pname=NULL);
	int	 close(){EOF_reached=0; tbuf[0]=0; return tyio::close();}
	int  isEOF() { return EOF_reached&&(tbuf[0]==0); }
	int  snEOF() { return !isEOF();                  }
public:
	int  getline_rec    (chars&buf, int clearbuf); //get into outside resizable line recursively
	int  getsentence_rec(chars&buf, int clearbuf); //includes last huhor recursively
	//u2r:2 if juanhing,1 if buannhing,0 if not end with huhor(so check buf[0])
public:
	int  getline    (chars&buf) { buf.set20(); return getline_rec(buf,0);			}
	int  getsentence(chars&buf) { buf.set20(); return getsentence_rec(buf,0); }
	int  getrline		(chars&buf); //rline: nonblank(real) line
	int  getgline		(chars&buf); //gline: rline and not startting with //
public:
	int	 peekline		(chars&buf);//at most 136 due to tbuflen
	int	 lpeek			(chars&buf){return peekline(buf);} //at most 136 due to tbuflen
public:
	int  getrline		(charspp&buf, int appendit=0);
	int  getgline		(charspp&buf, int appendit=0);
	int  getall			(charspp&buf, int appendit=0);
};


typedef lreader linereader;

class writer : public tyio {
	char* f;  int   nlen;// just local
	char  t[137];
public:
	writer() {  }
// ~writer() {  } // close() should not be called automatically
public:
	size_t write   (void* p, int len){ return tyio::write(p, len);	}
	size_t writestr(char* p         ){ return tyio::write(p, strlen(p));}
	size_t write   (char* p         ){ return writestr(p);	}
	size_t write   (char* p,char*p2 ){ int r=writestr(p);return r+write  (p2);}
	size_t write   (char* p,char*p2,char*p3 ){ int r=write(p);r+=write(p2);return r+write  (p3);}
	size_t writeln (       ){ return writestr("\r\n"); }
	size_t writeln (char* p){ nlen=writestr(p);return(nlen+writeln());}
	size_t writeln (char* p,char*p2 ){ int r=writestr(p);return r+writeln(p2);}
	size_t writeln (char* p,char*p2,char*p3 ){ int r=write(p);r+=write(p2);return r+writeln(p3);}
	size_t writetab(       ){ return writestr("\t");			}
	size_t writetab(char* p){ nlen=writestr(p);return(nlen+writetab());}
	size_t writeNbohun  (char** pps, int N, char* separator="\t");
	size_t writelnNbohun(char** pps, int N, char* separator="\t");
	size_t writecharpp  (charpp pp, char* sep="\t"){ return writeNbohun  (pp.pp, pp.sz, sep);      }
	size_t writelncharpp(charpp pp, char* sep="\t"){ return writelnNbohun(pp.pp, pp.sz, sep);      }
public:
	size_t out(char   c					)	{ return tyio::write(&c,1); }
	size_t out(char*  s					)	{ return writestr(s); }
	size_t out(int    v, char* fmt=NULL	)	{ f=(fmt)?fmt:"%d";  sprintf(t,f,v); return out(t); }
	size_t out(long   v, char* fmt=NULL	)	{ f=(fmt)?fmt:"%ld"; sprintf(t,f,v); return out(t); }
	size_t out(float  v, char* fmt=NULL	)	{ f=(fmt)?fmt:"%f";  sprintf(t,f,v); return out(t); }
	size_t out(double v, char* fmt=NULL	)	{ f=(fmt)?fmt:"%lf"; sprintf(t,f,v); return out(t); }
public:
	size_t outtab(		  )  { return tyio::write("\t",1); }
	size_t outtab(char   c)  { nlen =out(c); return (nlen+ outtab()); }
	size_t outtab(char*  s)  { nlen =out(s); return (nlen+ outtab()); }
	size_t outtab(int    v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
//	size_t outtab(long   v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
	size_t outtab(float  v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
	size_t outtab(double v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
public:
	size_t outln(		 )  { return out("\r\n"); }
	size_t outln(char   c)  { nlen =out(c); return (nlen+ outln()); }
	size_t outln(char*  s)  { nlen =out(s); return (nlen+ outln()); }
	size_t outln(int    v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
//	size_t outln(long   v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
	size_t outln(float  v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
	size_t outln(double v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
public:
	size_t out	(charss&ss, char* aftereach="\r\n");
};

class 	srctxt_{
public: srctxt_(){init0();}
public: srctxt_(char* fname){init0();open(fname);}
			 ~srctxt_(){del();}
public:
	virtual int	getgline(chars& cs){return lr.getgline(cs);}
	virtual int	getline (chars& cs){return lr.getline (cs);}
	virtual int isEOF		(){return lr.isEOF();}
	virtual int del			(){return lr.close();}
	virtual int	isOK		(){return lr.isOK();}
					int isERR		(){return !isOK();}
public:
	lreader lr;
	void	initlr(												 ){lr.close();}
	int		set2lr(char*fname, char*pname=0){return open(fname,pname);}
	int 	open  (char*fname, char*pname=0){init0();mode=modelr;return lr.open(fname,pname);}
public:
	enum {modenone=0, modemm=1, modelr=2};
	int 	mode;
	void init0(){mode=modenone; }
};






int spp_hunattr(charspp& spp, char* data=0);
// makes a str of the form att="something" att2="2" into
// spp[0] contains "att", spp[1] has "something", spp[2] has "att2", and so on

extern char* xmlline1alone;
extern char* xmlline1only;
class  	xreader;

class  	xmltag { public:int mpt; chars tg; charspp as; // tag and attributes
				xmltag		(char*data=0){mpt=0;if(data)set2(data);}
			 ~xmltag 		(						){destroy();}
	void	destroy		(						){mpt=0;tg.destroy();as.destroy();}
	void	clear			(						){mpt=0;tg.clear  ();as.clear  ();}
	int  	read			(xreader& r		); //read2 tg
	int		set2Nhun	(cchar* data	);
	int		hun 			(cchar* data=0);
	char* tag 			(						)	{return tg.s;}
	int		tis				(cchar* tag	);// tag is
	char* operator()(						){return tg.s;}
	char* operator[](cchar*att	); //return value for the given att
	char* operator[](int  i  		){return as[2*i+1];}//return value for i-th att
	char*	nth0			(int  n			){return as[n];		 }
	char* attr			(int  n			){return as[2*n];  }
	int		hasattr		(cchar*att	);
	int		size			(							){return as.size()/2; 	}
	int		set2			(char*data		){return tg.set2(data);}
	int		settag		(char* tagname){tg=tagname;return 1;}
	void	setmpttag	(int mpt1=1		){mpt=mpt1;}
	char* tos 			(char  sep='\t');
	char* tos 			(char* sep);
	char* tos 			(charspp& spp, char sep='\t');
};

class		xmltagrw {public:int mpt; chars tg; charss as;//tag and attributes, r/w version
				xmltagrw	(char*data=0){mpt=0;if(data)set2(data);}
			 ~xmltagrw 	()		{destroy();}
	void	destroy		()		{mpt=0;tg.destroy();as.destroy();}
	void	clear			()    {mpt=0;tg.clear();as.clear(); }
	int  	read			(xreader& r			  ); //read2 tg
	int		set2Nhun	(const char* data	){
																			tg.set2(data);
																			return hun();
																			}
	int		hun 			(char* data=0			);
	char* tag 			(									){return tg.s;}
	int		tis				(cchar* tag				); // tag is
  int   issamectag(cchar* tag       ); //* is opening tag (tg) is same as tag?
	char* operator()(									){return tg.s;}
	char* operator[](char*att					);//return value for the given att
	char* operator[](int  i  					){return as[2*i+1];}//ret ith att value
	char*	nth0			(int  n						){return as[n];		 }
	char* attr			(int  n						){return as[2*n];  }
	int		att2ith		(char*att					);
	int		hasattr		(cchar*att				);
	int		size			(									){return as.size()/2; 	}
	int		settag		(char* tagname		){tg=tagname;return 1;}
	void	setmpttag	(int mpt1=1				){mpt=mpt1;}
	int		set2			(char*data				){return tg.set2(data);}
	int		set2			(char*ki, char*val);
	int		set2			(int nth, char*val); //set nth att to val
	int		app 			(char*ki, char*val); //reduced to set2 if ki exists
	char*	tos				(char sep, int dotr2xml);
	char* tos 			(char sep='\t'		){return tos(sep,1);}
	char* tos 			(char* sep, int dotr2xml);
	char* tos 			(char* sep        ){return tos(sep,1);}
	char* tos 			(charspp& spp, char sep='\t');
};
typedef xmltag 		xtag;
typedef xmltagrw 	xtagrw;

class  	xreader :public lreader {
public:	xreader(int keeplnbr=1):kplnbr(keeplnbr){clear();}
				xreader(char*fname,char*pname=0,int keeplnbr=1)
														:kplnbr(keeplnbr){if(fname)open(fname,pname);}
	void  setkeeplnbr	(int keep) { kplnbr=keep; }
	int		open				(char*fname=0,char*pname=0){fn=fname;pn=pname; lnnow=0;
																					return lreader::open(fname,pname);}
  void	clear(){fn.clear();pn.clear();en.clear();nxttmp.clear();nxtln.clear();}
public:
	int		close				(){ clear(); return lreader::close(); }
	int  	isEOF				(){ return ( lreader::isEOF()&&(nxtln[0]==0) ); }
  int   hasmore     (){ return !isEOF(); }
	char* next				();
	int		skip				()						{return skipnext(			 );}
	int		skipnext		()						{return getnext	(nxttmp);}
	int		skipnextdata();
	int		nisotag			(char* tag=0);//* is <tag
	int		nisctag			(char* tag=0);//* is </tag
	int		nistag			(char* tag=0);//* either <tag or </tag
	int		nisln	 			();
	int		nisdata			();
	int		niscommand	();//* is lead with <?
	int		linenow			(){ return lnnow; }
public://xget a tag or text between tags, always keep sharp bracket if any
	int		skip2root		(char* rootname);//return 0 if rootname not match
  int   xmlNroot    (chars& xmlline1, xmltag& root);//*ret: 0 if no ?xml or root
  int   xmlNroot    (chars& xmlline1, chars & root);//*ret: 0 if no ?xml or root
	int		xget				(chars& cs);//get tag or data, whatever it has now
	int		tget				(chars& cs);//get tag only, will skip leading data if any
  int   tgetoce     (chars& cs, char sep, int keepctag=1);//* get empty tag, or otag upto ctag using sep to sep
  int		tgeto				(chars& cs, char* tagname);//get tag with tagname, skip others
	int		tget				(charspp& spp);
	int		getnext			(chars& cs,int keepSB=1, int keepln=0);
	//get each tag into a series of spp, from tag to /tag, assume it start with tag
public:
	int		nextistag		(					){return nistag();		}
	int		nextistag		(char* tag){return nistag(tag);	}
	void	bufdelbif		(){nxtln.delbif();}
	int		matchedtag	(char *btag, char *etag);
	int		matchedtag	(chars&btag, chars&etag){return matchedtag(btag.s,etag.s);}
	int		getnexttag	(chars& cs,int keepSB=1){return getnexttag0(cs,keepSB);}
private:
	int		sametoken		(char* tocheck, char* token);
	int		getnextdta0	(chars& cs);
	int		getnexttag0	(chars& cs, int keppSB=1, int keepln=0 );
	int		getlnbuf		(chars& cs);
	void  testread		();
	void  testread0		(){}
	void  testdel			();
private:
				int kplnbr; int lnnow;
				chars fn,pn,en;
				chars nxttmp, nxtln;
};

int xsaveastag(char* fname, charspp& spp, char* tagname, char* attrname=0, char* rootname=0);
int xsaveastag(char* fname, charss&  ss , char* tagname, char* attrname=0, char* rootname=0);


int xreadNtagname (char* fname, char* tagname, chars& cs, char* sep, int N=-1);
inline
int xreadNtagnames(char* fname, char* tagname, chars& cs, char* sep, int N=-1)
{return xreadNtagname(   fname,       tagname,        cs,       sep,     N);}

inline
int xreadNtagname (char* fname, char* tagname, chars& cs, char  sep0, int N=-1)
{char s[2];s[0]=sep0;s[1]=0;return xreadNtagname(fname,tagname, cs, s,    N);}

inline
int xreadNtagnames(char* fname, char* tagname, chars& cs, char  sep0, int N=-1)
{char s[2];s[0]=sep0;s[1]=0;return xreadNtagname(fname,tagname, cs, s,    N);}



int xreadNtags000(char* fname, chars& cs, char* sep, int N, int keeproot);
//N==-1 fpr all, but watch for mem
//works also for xml without root if keeproot is 0

inline
int xreadNtags   (char* fname, chars& cs, char*sep, int N=-1)//keep xml(line 1) and root
{return xreadNtags000(fname,cs,sep,N,1);}
inline
int xreadiNtags  (char* fname, chars& cs, char*sep, int N=-1)//excl xml(line 1) and root
{return xreadNtags000(fname,cs,sep,N,0);}

inline
int xreadNtags   (char* fname, chars& cs, char sep, int N=-1)//keep xml(line 1) and root
{char s[2];s[0]=sep;s[1]=0;return xreadNtags000(fname,cs,s,N,1);}
inline
int xreadiNtags  (char* fname, chars& cs, char sep, int N=-1)//excl xml(line 1) and root
{char s[2];s[0]=sep;s[1]=0;return xreadNtags000(fname,cs,s,N,0);}

inline
int xreadNtags   (char* fname, chars& cs, int N=-1)//keep xml(line 1) and root
{char*s="\r\n";return xreadNtags000(fname,cs,s,N,1);}
inline
int xreadiNtags  (char* fname, chars& cs, int N=-1)//excl xml(line 1) and root
{char*s="\r\n";return xreadNtags000(fname,cs,s,N,0);}

inline
int xreadNtags   (char* fname, charspp& spp, int N=-1)//keep xml(line 1) and root
{char s[2];s[0]=ch01;s[1]=0;xreadNtags000(fname,spp.s0,s,N,1);return spp.cet(ch01);}
inline
int xreadiNtags  (char* fname, charspp& spp, int N=-1)//excl xml(line 1) and root
{char s[2];s[0]=ch01;s[1]=0;xreadNtags000(fname,spp.s0,s,N,0);return spp.cet(ch01);}


// up: one then can use charspp.set2Nhunlet to get the individual tag


class 	xtsreader{ // xts : xml , text , and multiple-files
public: xtsreader(){}
public: xtsreader(char* fnames){init();open(fnames);}
			 ~xtsreader(){clear();}
public:
	enum { XTS_GLINE, XTS_TGET, XTS_XGET, XTS_RLINE, XTS_LINE};
public:
	virtual int	getgline(chars& cs){return getnext(cs, XTS_GLINE);}
	virtual int	getrline(chars& cs){return getnext(cs, XTS_RLINE);}
	virtual int	getline (chars& cs){return getnext(cs, XTS_LINE );}
	virtual	int	tget		(chars& cs){return getnext(cs, XTS_TGET );}
	virtual	int	xget		(chars& cs){return getnext(cs, XTS_XGET );}
public:										//if sep is 0, is separated by blank
	int		setpenames(char*pname,char*ename){cspname=pname;csename=ename;return 1;}
	int 	open 			(char*fns				 	){return open0(fns, 0,	0);}
	int 	open 			(char*fns,char sep){return open0(fns, sep,0);}
	int 	openByLet (char*fns					){return open0(fns,	0,	1);}
public:
	virtual int isEOF		(){return hasmorefile()?0:xr.isEOF();	}
	virtual int del			(){clear(); return 0;									}
	virtual int	isOK		(){return xr.isOK();									}
					int isERR		(){return !isOK();										}
	//			int	setxmax	(int xmax1=10000);
	//xmax1 in setxmax, used by getnext(..) to limit max strlen when xget and tget
public:
	xreader xr;
	chars		csfnames, cswork; //working path-file name
	chars		cspname,  csename;
	charspp sppfns;		int	nnn; // nnn is the ndx of sppfns that is curr opened
public:
	int		opennext		();
	int		getnext 		(chars& cs, int kind);
	int		hasmorefile	(){return nnn<sppfns.size()-1;}
	void	init				(){clear();}
	void	clear0			(){xr.close();nnn=-1;sppfns.clear();csfnames="";cswork="";}
	void	clear				(){clear0();cspname="";csename="";}
	int 	open0(char*fnames,char sep, int openByLet);
};




class  ze2he { public:char**dt; int N, NSZ; chars s0;  // this to that
	ze2he(char**data1, int N1, int NSZ1):dt(data1),N(N1),NSZ(NSZ1){s0=" ";s0="";}
	int  bfind    (char* s){return ::bfind(s,dt,N,NSZ);}
	int  bfindlast(char* s){return ::bfindlast(s,dt,N,NSZ);}
	int  lower    (char* s){return ::lower(s,dt,N,NSZ);}
	int  upper    (char* s){return ::upper(s,dt,N,NSZ);}
	char*d0       (int   n       ){return dt[n*N  ];}
	char*d1       (int   n       ){return dt[n*N+1];}
	char*dk       (int   n, int k){return dt[n*N+k];}
	char*d1       (char* s){int n=bfind(s);return (n<0)?s0.s:dt[n*N+1];}
	char*dk       (char* s, int k){int n=bfind(s);return (n<0)?s0.s:dt[n*N+k];}
};


class config_ { public: xmltagrw tg; chars curdir; int loadOK; chars inifname;
			config_			(			){tg.setmpttag(1);loadOK=0;getcurpath();}
			config_			(char* fname){inifname=fname; tg.setmpttag(1);loadOK=0;getcurpath();}
	int 	load			(char* fname				);
	int 	save			(char* fname				);
	int 	load			(										){return load(inifname.s);}
	int 	save			(										){return save(inifname.s);}
	int		set2			(char* key, char*val){return tg.set2(key,val);	}
	int		app				(char* key, char*val){return tg.app (key,val);	}
	char* operator[](char* att					){return tg[att];						}
	int		set2Nhun	(char* proto				){return tg.set2Nhun(proto);}
	void	getcurpath(										){curdir=getexepath();			}
};





class madis { //main_arg, dir, ini, script
public:
	madis() :argcini(0), argvini(NULL){ VTIinit(); }
  madis(int argcini1, char* argvini1[]) { initini(argcini1, argvini1); }
	int err(int i){return 0;}
	//typedef map<string, string, less<string> > maps2;
	//typedef maps2::iterator itr;
	//maps2 s2s;
	pairss s2s; //could have used:map<string, string, less<string> >
	chars ss;
public:
	virtual int VTIinit() { return 0; }
	void qsort  () { s2s.qsort(); }
	int reset	  (char* lhs, char* rhs)	{return s2s.reset   (lhs,rhs);}
	int 	set	  (char* lhs, char* rhs)	{return s2s.  set   (lhs,rhs);}
	int resetset(char* lhs, char* rhs)	{return s2s.resetset(lhs,rhs);}
	char* get	  (char* lhs)							{return s2s.  get   (lhs    );}
  int		get2i (char*lhs,int idef=-999999) { char*t=get(lhs);
													return(t&&t[0])?s2i(t):idef; }
public:
	int readscp (char* scpfname);
	int getdirs (); // get various dir
	int setmarg (int argc, char* argv[]);
public:
	int argcini; char** argvini;
	int   initini(int argcini1, char* argvini1[]);
  virtual int VTIwriteini(writer& w) { return 0; }
	int		writepairln(writer&w, char* lhs){if(writepair(w,lhs))w.writeln("");return 1;}
  int		writepair  (writer&w, char* lhs);
	int 	writeiniVTI(char* inifname=NULL);// use inifname in readini
	int 	writeini   (char* inifname=NULL);// use those in argvini
	int 	readini		 (char* inifname);
	char* getinifname(					){return get("inifname");}
	void	setcomment (char*  rhs){if(rhs)set("startcomment",rhs);}
	char* getcomment (					){return get("startcomment"); }
};



class mainarg_ { char fg[64]; chars av[64];  int ac,forhelp,err;
int	ndx(char c){if(isdigit(c))return c-'0';if(isupper(c))return c-'A'+10;
								if(islower(c))return c-'a'+36;
								return (c=='?')?62:63; }
public:
	void	clear() {err=forhelp=ac=0; for(int n=0;n<64;n++){fg[n]=0;av[n].clear();}}
	virtual int preset  () { return 1; }// called before set(argc, argv);
	int		set       (int argc, char* argv[]);
	int		set2      (int argc, char* argv[]){return set(argc,argv);}
	int		set1			(char c, char* v);
	void	reset1		(char c) { fg[ndx(c)]=0; av[ndx(c)]=""; }
	int		is4help		(			 ) { return forhelp;			}
	char* argv			(char c) { return av[ndx(c)].s; }
	char* v					(char c) { return av[ndx(c)].s; }
	int		flag			(char c) { return fg[ndx(c)];	}
	int		argc			(			 ) { return ac;						}
	char* operator()(char c) { return argv(c);			}
};

class lastfname_ : public lreader { public:
			lastfname_ (char* iniprofname1, char* comment1=NULL){clear();iniprofname.set2(iniprofname1);comment.set2(comment1); startup();}
		 ~lastfname_ () { cleanup(); }
	chars iniprofname, comment, ifnlast;
  void  clear()   { iniprofname.clear(); comment.clear(); ifnlast.clear(); }
  void  openpro(char* fnn) { open(fnn); pro(); }
  void  startup() { openpro(iniprofname.s); }
  void  cleanup() { write(iniprofname.s, comment.s); }
	void  set2lastname (char* ifnlast1) { ifnlast.set2( ifnlast1 ); }
	char* lastname  () { return ifnlast.s; }
  int   iniGD     () { return ifnlast.hassome(); }
public:
  int   pro(){  if(!isOK()) return 0;  chars s;
          while(getgline(s)){
						if( s()[1]=='=' && s()[0]=='i' ) { ifnlast.set2(s()+2); continue; }
          }return 1;
        }
	void  write(char* ofname, char* comment=0) { if(!ofname) return;
             writer w; w.creat(ofname); if(w.isERR()) return;
             if(comment){
               if( (comment[0]!='/')||(comment[1]!='/') )w.out("//");
							 w.outln(comment);
						 }
             if(ifnlast.hassome()) { w.out("i="); w.outln(ifnlast.s); }
				}
};


int	 	csfname4play1daiqi(chars& cs); 													// check/set
int	 	csfname4play1daiqi(chars& cs, char* ext); 							// check/set
int	 	csfname4play1daiqi(chars& cs, float& emph); 						// check/set
int	 	csfname4play1daiqi(chars& cs, char* ext, float& emph); 	// check/set



template<int fixsz, int bufsz>
class fixmac { //fixsize malloc fixsz must be >=sizeof(pointer)
	struct bufnode{ bufnode(){next=0;} bufnode* next; char c[bufsz*fixsz];};
	struct fixnode{ fixnode(){next=0;} fixnode* next; };
	bufnode* bhead; fixnode* fhead;
	void freebuf () { bufnode* bn; while(bhead){bn=bhead;bhead=bhead->next;free(bn);}}
	int  allocbuf() { bufnode* bn=(bufnode*)malloc(sizeof(bufnode)); if(!bn)return 0;
				bn->next=bhead;bhead=bn; for(int i=0; i<bufsz;i++)put(&(bn->c[fixsz*i]));
				return bufsz;
	}
public:
 ~fixmac() { freebuf(); }
	fixmac(): bhead(0), fhead(0) {}
	void put(void*fnode){fixnode* fn=(fixnode*)fnode;fn->next=fhead;fhead=fn;}
	void*get(){if(!fhead)	{	if(!allocbuf())				return NULL;			}
									fixnode* fn=fhead;fhead=fhead->next;return (void*)fn;
	}
};

class		tone2diauhing_set1diau_{int ubiau1D_;
public: 
				tone2diauhing_set1diau_():ubiau1D_(1) {set1D(ubiau1D_); }
	int  ubiau1D(					){return ubiau1D_;}
	void set1D	(int ubiau);
};extern tone2diauhing_set1diau_ tone2diauhing_set1diau;

enum diauhing_ {vorbiau=1,gorbenn,diongbenn,gegang,gorgang,gorgau,gorsing,
							  gordiam,gebenn,divor, gordit, degorbenn, dediongbenn, degebenn, degegang, diauhing_end};

int   tone2diauhing   (int tone,char qiqen);
char* diauhing_2markup(diauhing_ dh);


class yimvun_ {
public:
	int ypos2vpos(char*yim,char*vun, int ypos){return yvpos2pos(yim,vun,ypos,1);}
	int vpos2ypos(char*yim,char*vun, int vpos){return yvpos2pos(yim,vun,vpos,0);}
protected:
public:
	int yvpos2pos				(char* yim, char* vun, int srcpos, int srcisyim);
	int spp1pos2spp2pos	(charspp& spp1, charspp& spp2, int pos);
	int insNhun			(chars&csy, chars&csv, charspp&sppy, charspp&sppv, char sepc)
									{return insNhun0(csy,csv,sppy,sppv, sepc, csyy0, csvv0);}
private:
	int insNhun0(	chars&csy,  chars&csv,  charspp&sppy, charspp&sppv, char sepc,
								chars&csyy, chars& csvv);
	chars csyim0, csvun0, csyy0, csvv0;
	charspp sppyim0, sppvun0;
	xmltagrw xtag0;
};
extern yimvun_ yimvun;






#define diTS_UNDERLINE        1
#define diTS_UNDERLINERED     2
#define diTS_UNDERLINEDOT     3
#define diTS_UNDERLINEDASH    4
#define diTS_SUPERSCRIPT      11
#define diTS_SUBSCRIPT				12
#define diTS_GRAYTEXT					13
#define diTS_BOXBEG						21
//#define diTS_BOXEND						22
#define diTS_TONECHAR					23
#define LM_USED 1

struct szmio { long sz; char* pm; // sz is byte-size(bsz) // a nice handy structure
			 szmio(): sz(0),pm(0) {}
		//~szmio() { }//del(); }
	int   write(tyio& io, long size) {io.writesz(size);
										return 4+io.write(pm,size);}
	char* read(tyio& io, int szdef=-1){long res=io.readsz(&sz);
							if(res!=(long)sizeof(long)){ sz=0; return 0;	}
							if(szdef>=0) if(sz!=szdef) {sz=0; return 0; 	}
							pm=new2(sz,0);	res=io.read(pm, sz);
							sz=res; return pm;														}
//	char* read(tyio& io, int extra=0){long res=io.readsz(&sz);
//							if(res!=(long)sizeof(long)){ sz=0; return 0; }
//							pm=new2(sz,extra);	res=io.read(pm, sz); sz=res; return pm;}
  char* readp(char* p, int szdef=-1);//say, read from pointer/resource stream
	void  destroy()    { del(); }
	long  peeksz(tyio& io)
	{long res=io.readsz(&sz);io.rmoveto(-(long)sizeof(long)); return sz; }
	long  size()       { return sz; }
	long	bszasinhdr(); //treat pm as hdr_, return the bsz
	char* operator()() { return pm; }
	void  del(); // reverse of new2
	char* new2(long bsize, int extra=0);
	int		isOK() { return pm!=0; }
};

struct  szmiohs { static int hdrbsz;
			 ~szmiohs(){del();}
	szmio h, s;
  int   readp(char* p);//say, read from pointer/resource stream
	int read (tyio& io) { int bsz;
												bsz=hdrbsz;
												if(!h.read(io, bsz)) return 0;
												bsz=h.bszasinhdr();
												if(!s.read(io, bsz)) return 0;
												return (h.sz+s.sz+8);
											}
	int write(tyio& io) {
												h.write(io,h.sz);
												s.write(io,s.sz);
												return(h.sz+s.sz+8);
											}
	void createnull()   { h.new2(hdrbsz); }
	void del()					{ h.del(); s.del(); }
};


enum rdkind {DIRD_NRK, DIRD_NIT, DIRD_DZB, DIRD_DZB3, DIRD_LAIVE, DIRD_SSL, DIRD_C1SU,DIRD_UNKNOWN};
enum dikey	{DIRDKEY_IM, DIRDKEY_RI };
enum rdidknd{DIRDID_NONE, DIRDID_ZIK, DIRDID_NIT, DIRDID_HH1, DIRDID_HH2 };

rdkind  cs2ridenkind(chars& cs);// return rdkind

struct rdhdr53 { // riden header, note: sizeof(di51rdhdr) is 28, different from previous version 32
	long 		asz;		// size of data in unit of usize (array size)
	long 		bsz;		// size of data in unit of byte  (array size in bytes)
	long 		usz;		// size of each unit, 0 if not const
	char 		idf[7];
	char 		frq; // has frq or not
	char 		qqn,key,col,knd;//qiqen(d/k/h),key(dikey),col(1/2/3),kind(rdkind)
	USHORT 	vM;
	USHORT 	vm;
public:
	rdhdr53					(							 ){setidfv(); setabu(0,0,0); idf[0]=0; 	}
	void 	setidfier (char*s,int n=7){if(n>7)n=7;strncpy(idf,s,n); 				}
	void 	getidfier (char*s        ){strncpy(s,idf,7);s[7]=0; 						}
	void 	peekidfier(tyio& r,char*s){peek(r); getidfier(s);								}
	void 	peek			(tyio& r 			 ){int i; r.read(&i,4); read(r);
																r.rmoveto(-(long)(sizeof(int)+sizeof(*this)));}
	char*	idfier		( ){return idf;}
	void 	setidfv	 	( ){setidfier("dif");vM=5;vm=3;}
	void 	setv	 		(ushort M=5, ushort m=3 ){vM=M;vm=m;}
	void 	setabu		(long asiz,long bsiz,long usiz) //if dzb, usiz is ignored
										{asz=asiz; bsz=bsiz; usz=usiz; }
	void 	setfqkck	(char freq,char qiqen, char key1, char c2c3, char kind)
										{frq=freq; qqn=qiqen; key=key1; col=c2c3; knd=kind; }
	long  read		 	(tyio& r){return r.read (this, sizeof(*this));}
	long  write		 	(tyio& w){return w.write(this, sizeof(*this));}
};
typedef rdhdr53 rdhdr;

struct rikive { char r[2]; ushort k; // cutri and ripkive
			 rikive ( char* r1,  int k1 ) { r[0]=r1[0]; r[1]=r1[1]; k=(ushort)k1;}
			 rikive ( )		{ r[0]=r[1]=0; k=0; }
	int  ishanri( )	{ return (r[0])&&(r[0]!='*'); }
	int  isgood ( ) { return (r[0]&&k); }
};

struct dilaive { ushort n;
			 dilaive ( ushort n1=0 ) : n(n1) { }
			 dilaive ( int    n1   ) : n((ushort)n1) { }
			 void operator=(dilaive& r) { n=r.n; }
};



struct LMU { int l, m, u;
	int 	nff(){return m-l;}// full fit
	int 	npf(){return u-m;}// partial fit
	void	clear() { l=m=u=0; }
};

struct LU	 { int l, u;
	int 	nf (){return u-l;}//fit
	void	clear() { l=u=0; }
};

struct IDLMU { int id, l, m, u; };
struct IDLU	 { int id, l, u; 		};

int __cdecl wisdirikive(const void* l, const void* r);
int __cdecl wisc1su(const void* l, const void* r);


class di53laives {public:
	rdhdr* 	hdrk_;rikive* rkvs; int nRKVS;
	rdhdr* 	hdki_;char* 	kis; 	int nKIS; 	int kilen;
	szmiohs mmrkv, mmki;
public:
 ~di53laives() {del();}
	void del() { mmrkv.del(); mmki.del(); hdrk_=hdki_=0; nRKVS=nKIS=kilen=0;}
	int read(tyio& r );
	//int read(tyio& r ){del();mmrkv.read(r);mmki.read(r);afterread(); return 1; }
	int read(char* fn){tyio io;if(!io.open(fn))return 0;int r=read(io);return r;}
	int afterread();
	int isOK(){return (kis&&rkvs); }
public:
	char* ki		( int n) { dilaive nn=n;return ki  (nn); }
	char* ki0		( int n) { dilaive nn=n;return ki0 (nn); }
	char* ri		( int n) { dilaive nn=n;return ri  (nn); }
	char* line	( int n) { dilaive nn=n;return line(nn); }
public:
	char* ki		( dilaive& n);
	char* ki0		( dilaive& n);
	char* ri		( dilaive& n);
	char* line	( dilaive& n);
public:
	char* ri		(dilaive*a, int K, char sep=0		);
	char* ki		(dilaive*a, int K, char sep='-'	);
	char* ki0		(dilaive*a, int K, char sep=0		);
	char* line	(dilaive*a, int K, char sep='\t');
	char* it		(dilaive*a, int K) { return imtau(a,K); }
	char* imtau	(dilaive*a, int K);
	char* ki_d		(dilaive*a, int K, char sep=0		);
	char* ki_h		(dilaive*a, int K, char sep=0		);
public: // for building other suden
	rikive  torikive(cchar* ri, cchar* ki);	// works for 1 ri/ki
	int   	ndx 		(cchar* ri, cchar* ki);	// works for 1 ri/ki
	int			kindx 	(cchar* ki);					 	// works for 1 ri/ki, in the ki-array
public:
	LU			LU4ri   (cchar* ri);					 	// works for 1 ri/ki
};
typedef di53laives dilaives;
/*
class dilaives {public:
	rikive* rkvs; int nRKVS;
	char* 	kis; 	int nKIS; 	int kilen;
	tyio    io;   szmiohs mmrkv, mmki;
public:
 ~dilaives() {del();}
	void del() { mmrkv.del(); mmki.del(); }
	int read(tyio& r ){del();mmrkv.read(r);mmki.read(r);afterread(); return 1; }
	int read(char* fn){if(!io.open(fn))return 0;int r=read(io);io.close();return r;}
	int afterread();
	int isOK(){return (kis&&rkvs); }
public:
	char* ki		( int n) { dilaive nn=n;return ki  (nn); }
	char* ki0		( int n) { dilaive nn=n;return ki0 (nn); }
	char* ri		( int n) { dilaive nn=n;return ri  (nn); }
	char* line	( int n) { dilaive nn=n;return line(nn); }
public:
	char* ki		( dilaive& n);
	char* ki0		( dilaive& n);
	char* ri		( dilaive& n);
	char* line	( dilaive& n);
public:
	char* ri		(dilaive*a, int K, char sep=0		);
	char* ki		(dilaive*a, int K, char sep='-'	);
	char* ki0		(dilaive*a, int K, char sep=0		);
	char* line	(dilaive*a, int K, char sep='\t');
	char* it		(dilaive*a, int K) { return imtau(a,K); }
	char* imtau	(dilaive*a, int K);
public: // for building other suden
	rikive  torikive(cchar* ri, cchar* ki); // works for 1 ri/ki
	int   	ndx 	(cchar* ri, cchar* ki); 	// works for 1 ri/ki
	int			kindx (cchar* ki);							// works for 1 ri/ki
};
*/


int wstrlenatmost4IME(char *s, int& useall, int LEN=-1);//-1 for default atmost len 80

int pfit1vun  (const char* kiin, const char* rr);
int pfit1py(const char* kiin, const char* rr, int mustfit_diau);
	//pfit1:partial fit, assuem ll is kiin, and shorter
	// r: #bytes in ll that is partially used by rr

class del4wis_ { public:
	static char chku;//kangwun rivor for huaqi kang-un
	static int d(char*src);  //non-p version is destructive to src
	static int h(char*src);  //while p version is non-destructive
	static int dp(char*partki, char*zuanki);
	static int hp(char*partki, char*zuanki);
	static int gp(char*partki, char*zuanki);//{return pfit1py(partki,zuanki,0);}
};
extern del4wis_ del4wis;


struct dilaivesNxtr { di53laives* lv; int usz; int K; };

class di53rd_;
struct di5wis_ { static
									chars ll, rr;
	static
		int byki0		(const void*l, const void*r)
	{
		ll.set2(  (char* )l ); str_del4wis(ll.s);
		rr.set2(*((char**)r)); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static
		int byki		(const void*l, const void*r)
	{
		rr.set2(*((char**)r));
		return strcmp((char*)l,rr());
	}
	static
		int byki0f	 (const void*l, const void*r)
	{
		ll.set2(    (char* )l );     str_del4wis(ll.s);
		rr.set2( (*((char**)r))+5 ); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static
		int bykif		(const void*l, const void*r)
	{
		rr.set2(*((char**)r)+5);
		return strcmp((char*)l,rr());
	}
public:
	static byki0d(const void*l, const void*r)
	{
		//ll.set2(  (char* )l ); del4wis.d(ll.s);
		rr.set2(*((char**)r)); del4wis.d(rr.s);
		//return strcmp(ll.s,rr.s);
		return strcmp((char*)l,rr.s);
	}
	static byki0h(const void*l, const void*r)
	{
		//ll.set2(  (char* )l ); del4wis.h(ll.s);
		rr.set2(*((char**)r)); del4wis.h(rr.s);
		//return strcmp(ll.s,rr.s);
		return strcmp((char*)l,rr.s);
	}
public:
	static
		int nrK  (const void*l, const void*r, dilaivesNxtr* lvx);
	static
		int nrK_d(const void*l, const void*r, dilaivesNxtr* lvx);
	static
		int nrK_h(const void*l, const void*r, dilaivesNxtr* lvx);
	static
		int nit(const void*l, const void*r, di53rd_* 			rd);
};
extern di5wis_ di5wis;




class di53rd_ { public:
	dilaivesNxtr 	lvx;
	di53rd_* 			base4nit;   int K;
	void setlv(di53laives* lv1){lvx.lv=lv1; lvx.K=K; lvx.usz=hd_->usz;}
	void setrd(di53rd_* rd){base4nit=rd;}
protected:
	tyio    io;   szmiohs mm;
	rdhdr* 	hd_;  void*   dt_;
	short 	id;  	char 		s4null[4];
	chars 	cs1;  int     dirdid_knd;
protected: // for dzb, dst_ is alloc-ed
	char**  dst_;
	int 		jumpbyte;
	int 		hsd2, hsd3, hsd4, hsd5;
	void 	setinnr();
	int   dirdid_kind();
	int		cols_is() { return (hd_->col)-'0'; }
protected:
	//int (__cdecl *d4wis)(char *src);
	int (__cdecl *pfit) (char*kiin, char *zuanki);//return nchar fitted, w/0 for not fitted
	int (__cdecl *wis ) (const void *, const void *);
	int (__cdecl *wisx) (const void *, const void *, const void*);
protected:
	char* smd_old(char* s) { static chars ss; if(hd_->key!='i') return s;
												ss=s;
												str_del4wis(ss.s);
												return ss.s;}
	char* smd(char* s);
public:
	int npfit(char*kiin, char*zuanki){return(pfit)?(pfit(kiin,zuanki)):0;}
	int lower(char*s);
	int upper(char*s);
	int	bfind(char*s);// return -1 if not find
	int	lu	 (char*s, int*l, int*u);
	int lmu  (char*s, int*l, int*m, int*u); //r: nonsense
	LU  lu	 (char*s){LU  r;lu (s,&(r.l),&(r.u));return r;}
	LMU lmu	 (char*s){LMU r;lmu(s,&(r.l),&(r.m),&(r.u));return r;}
public:
	di53rd_()				 : hd_(0),dt_(0),wis(di5wis.byki0) {s4null[0]=0; }
	di53rd_(char* fn): hd_(0),dt_(0),wis(di5wis.byki0) {s4null[0]=0; read(fn); }
 ~di53rd_(){del();}
public:
	void 	del() { try{mm.del();}catch(...){}; }
	int 	read(tyio& r ){int rs;del();rs=mm.read(r);if(rs)afterread();return rs;}
	int 	read(char* fn){if(!io.open(fn))return 0;int rs=read(io);io.close();return rs;}
  int   readp(void*p ){int rs;del();rs=mm.readp((char*)p);
                                 if(rs)afterread();return rs;}
                       //say, from a resource stream
	int 	afterread();
	int   createnull()	{mm.createnull();return afterread();}
public:
	int	hasd2		(){ return hsd2; }
	int	hasd3		(){ return hsd3; }
	int	hasd4		(){ return hsd4; }
	int	hasd5		(){ return hsd5; }
	int hasfreq	(){ return hd_->frq; }
	int isnit		(){ return dirdid_knd==DIRDID_NIT;}
	int ishh1		(){ return dirdid_knd==DIRDID_HH1;}
	int ishh2		(){ return dirdid_knd==DIRDID_HH2;}
	int iszik		(){ return dirdid_knd==DIRDID_ZIK;}
	int isnrk		(){return luibet()==DIRD_NRK;}
	int isdzb		(){return luibet()==DIRD_DZB;}
	int isdzb3	(){return luibet()==DIRD_DZB3;}
public:
	int	 	isOK	() { return (hd_&&dt_&&(size()>0))?1:0; }
	uint 	size  () { if(hd_&&dt_)return (uint)(hd_->asz);	return 0;}
	int		ncols	() { return (hd_->col)-'0'; }
	int		maxri	() { return 5; }
	char 	key   () { return hd_->key; }
	char 	qiqen () { return hd_->qqn; }
	char 	luibet() { return hd_->knd; }
	char 	lb		() { return hd_->knd; }
	int  	lb		(rdkind knd) { return knd==hd_->knd; }
	int  	luibet(rdkind knd) { return knd==hd_->knd; }
	char*	idfier() { return hd_->idfier();	}
	int  	keyi  () { return 'i'==key(); }
	int	 	npart	() { return K; }
public:
	char*    ki (USHORT n); // depends on luibet
	char*    ri (USHORT n); // depends on luibet
	char*    ki0(ushort n){cs1=ki(n); str_del4wis(cs1.s); return cs1.s;}
	char*		 im (ushort n);
	char*    im0(ushort n){cs1=im(n); str_del4wis(cs1.s); return cs1.s;}
	char*		 it (ushort n); // only nrK will return imtau, nit should use ki
public:
	char*    ki (USHORT n, int nthpart); // depends on luibet
	char*    ri (USHORT n, int nthpart); // depends on luibet
	char*    ki0(ushort n, int nthpart){cs1=ki(n,nthpart); str_del4wis(cs1.s); return cs1.s;}
	char*		 im (ushort n, int nthpart);
	char*    im0(ushort n, int nthpart){cs1=im(n,nthpart); str_del4wis(cs1.s); return cs1.s;}
public:    // last unit
	char*    eki (USHORT n); // depends on luibet
	char*    eri (USHORT n); // depends on luibet
	char*    eki0(ushort n){cs1=eki(n); str_del4wis(cs1.s); return cs1.s;}
	char*		 eim (ushort n);
	char*    eim0(ushort n){cs1=eim(n); str_del4wis(cs1.s); return cs1.s;}
protected: // for nrk
protected: // for nit
protected: // for laive
protected: // for c1su
//	int   ndx(const char*s) { return bfind(s,dt_,size(),hd_->usz, ???wisc1su_); }
public: //for dzb
	//float freq(USHORT n) { return *( (float*)(*(dst_+n)) ); }
	//int		freq(int n) { return *( (int*)( (*(dst_+n)) -sizeof(int)-1 ) ); }
	int		freq(uint n) { return (n>=size())?0:(*( (int*)( (*(dst_+n))+1 ) )); }
	int		i0	(uint n) { return (n>=size())?0:(*( (int*)( (*(dst_+n))+1 ) )); }
	char* d0	(uint n) { return (n>=size())?s4null:dst_[n]+jumpbyte;	} // d0 is key
	char* d1	(uint n) { if((!hsd2)||n>=size())return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1; }
	char* d2	(uint n) { if((!hsd3)||n>=size())return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1; }
	char* d3	(uint n) { if((!hsd4)||n>=size())return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1; }
	char* d4	(uint n) { if((!hsd5)||n>=size())return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1;}
};
typedef di53rd_ di53rd;
extern  di53rd_ rdnull;

struct ustmio { // usage status, changed to byte-array rather than bit-array
public:
	void		suaned  (USHORT n, USHORT n0, USHORT n9); //[n0,n9):range
	void		unsuaned(          USHORT n0, USHORT n9); //[n0,n9):range
	int			status(USHORT n);
	void		inc(USHORT n);
	//void	dec(USHORT n);
public:
	ustmio() : ph(0), pv(0) { }
 ~ustmio() { del(); }
public:
	typedef	rdhdr53 hust;
	tyio  	io;
	szmio 	h, v;
	hust  	*ph;
	char		*pv;
	void  	init(){ph=0;pv=0;}
	int			read (tyio& io);//{h.read(io);v.read(io);return (h.sz+v.sz);}
	int			write(tyio& io){h.write(io,h.sz); v.write(io,v.sz);//8: for 2 long's
													return(h.sz+v.sz);  }
	int			read(char*fn){io.open(fn);int res=(io.isOK())?read(io):0;io.close();
													return res;}
	void		destroy() { try{h.destroy(); v.destroy();}catch(...){} }
	void		del()     { try{h.destroy(); v.destroy();}catch(...){} }
	int			new2(long asize);
	int			isOK()        {return (pv)?1:0;}
	uint 		size  () 			{return (uint)(ph->asz);			}
	int			isOK(USHORT n){if(!pv)return 0;return((ph->asz>0)&&(n<ph->asz))?1:0;}
};






//**********************************************************************
//**********************************************************************
//**********************************************************************
// an mf file is concatenation of a sequence of files,
//		and intended to be read	via FileMapping.
// it has two parts: header part and subfile-sequence part
// an mf file is organized as follows
// 						( note B==byte, 4B==sizeof(int) )
//HEADER PART
// A1. 4B for total filesize in byte, for checking
// A2. 4B for the header size
// A3. number 32 taking 4B for the max length of the file format idfier,
// A4. string of the file format, 0-padded, thus at most 31B
//	  	  "didzc 1.0" for denzu ceh
//				"78dpy" for 78dpy
//
// A5. 1B 0/1 : each subfile section contains subfile time-stamp
// A6. 1B 0/1 : 'i'/'v'/'b' yim/vun/both iusen at first show of didzc
// A7. 1B 0/1 :
// A8. 1B 0/1 : reserved
// A9. 4B for the number of subfiles
// A10.4B for total subfile-sequence size in byte
//
// A11.number 256 taken 4B for the max length of the "main" script filename,
// A12.filname of the "main" script file, 0-padded, thus at most 255B
//			A10/A11 is optional depends on field A5
// A13.number 32 taking 4B for the max length of subfile extention, including '.'
// A14.extention name of the subfile, lead with '.' if any, 0-padded,at most 30B
//          for uniform file extention
//**********************************************************************
//**********************************************************************
//**********************************************************************
//SUBFILE-SEQUENCE PART
// B1.  4B for sizeof(rdhdr53)
// B2. rdhdr53, this should be dzb riden with 1 freq(int)
// B3. 4B for the size of dzb data
// B4. dzb data (indefinte), each entry contains
//             subfile offset from mf file begin ( store in the freq part)
//             filename of the subfile
// B5. a sequence of subfile content, each is
//    	B5a. 4B for the actual subfile size, that is : only part c
//    	B5b. sizeof(ftime3) that contains the actual file time content
//				 	  this is for later break-up of the subfiles
//					 (optional, indicated by A5)
//    	B5c. the actual subfile content
//    				note that in the dzb data part,
//    				the freq part is the offset to the subfile, and thus
//						this offset add 6a 6b 6c should equal to the offset of next file
// note also that dzb entry contain 1 more than the number of subfiles
// thus the last entry should have subfilename "\ff"
//														with freq=0
// this last extra entry should make easier the manipulation of the mf file
//**********************************************************************
//**********************************************************************
//**********************************************************************
#include <windows.h>

struct point_ :public POINT {	void set2(int x1, int y1) { x=x1; y=y1; }
	point_(							 ){set2( 0,0 ); }
	point_(int x1, int y1){set2(x1,y1); }
	int operator ==(point_ r) { return ((x==r.x)&&(y==r.y))?1:0; }
	void operator+=(point_ r) { x+=r.x; y+=r.y;}
};


class 	mfreader {
public:~mfreader(){close();}
				mfreader():p(0),fsz(0),mfh(0){}
	void* mfopen	(tyio& io, 	char* fn);
	void* open		(char* fn,	char* pn=0);
	int		close		();
	int		isOK 		(){return p!=NULL;}
	int		isERR		(){return !isOK();}
	char*	beg	 		(){return (char*)(p);}
public:
	xreader	io;
	void* 	p;
	HANDLE 	mfh;
	chars		mffn;
	int			fsz;//file size
};


class ftime3{public:    FILETIME ct,at,wt;  int good;
public:ftime3():good(0){}
	int		get(HANDLE ioh){good=GetFileTime(ioh,&ct,&at,&wt);return good;}
	int		set(HANDLE ioh){good=SetFileTime(ioh,&ct,&at,&wt);
												return good;}
	int		get(int		 h){return get(HANDLE(h));}
	int		set(int		 h){return set(HANDLE(h));}
	int		get(char*   fn);
	int		set(char*   fn);
	int		get(tyio& 	io){return get(HANDLE(io()));}
	int		set(tyio& 	io){return set(HANDLE(io()));}
	int		write(tyio& io){return io.write(this,sizeof(FILETIME)*3);}
	int		read (tyio& io){return io.read (this,sizeof(FILETIME)*3);}
	int		readp(void*  p){memmove(this, p, sizeof(FILETIME)*3);good=1;return good;}
	void	clear(				){good=0;}
};

class 	mfheader { public:
public: mfheader(){init();}
public:
	int 	fsize;      //1
	int		strctsz;		//2: size of this class
	int		idflen;     //3: should be 32
	char 	idf[32];   	//4: should be 0-padded
	char	opt[4];			//5,6,7,8
	int 	nSUBF;    	//9 : num of subfiles in the sequence
	int		seqlen;			//10: subfile sequence length in byte
	int 	mflen;   		//11: should be 256
	char 	mfname[256];//12: main script file name, should be 0-padded
	int		extlen;			//13: should be 32
	char	extname[32];//14: should be 0-padded, and lead with '.' if any
public:
	int		write(tyio& io){return io.write(this,sizeof(*this));	}
	int		read (tyio& io){return io.read (this,sizeof(*this));	}
	int		readp(void*  p){int len=sizeof(*this);memmove (this,p,len);return len;}
public:
	void	setidf		(char*s){strncpy(idf,s,32);}
	void	setmfname	(char*s){strncpy(mfname,s,256);}
	void	setextname(char*s){strncpy(extname,s,32);}
public:
	void	setfsize	(int sz1		){fsize=sz1;}
	void	setnSUBF	(int nsubf	){nSUBF=nsubf;}
	void	setseqlen (int seqlen1){seqlen=seqlen1;}
public:
	int		isOK();
	int 	init();
	int		hasftime3(	){return opt[0];}
	int		ftimesize(	){return hasftime3()?sizeof(FILETIME)*3:0;}
};

class 	mfbuffer {public:
public: mfbuffer(){}
			 ~mfbuffer(){close();}
	mfreader 	mfr;
	mfheader 	mfh;
	di53rd 		dzb;
public:
	int			open	(char* fn, char* pn=0);
	void		close	(				){mfr.close();}
	int			size	(				){return dzb.size();}
	char*		sfbeg0(int nth){return mfr.beg()+dzb.freq(nth);}
	char*		sfbeg	(int nth){return mfr.beg()+dzb.freq(nth)+sizeof(int)+mfh.ftimesize();}
	int			sfsize(int nth){return *((int*)(sfbeg0(nth)));  }
	char*		sfname(int nth){return dzb.d0(nth);}
	char*		ft3   (int nth){return mfr.beg()+dzb.freq(nth)+sizeof(int);}
	char*		ft3beg(int nth){return mfr.beg()+dzb.freq(nth)+sizeof(int);}
	int			hasft3(       ){return mfh.hasftime3();}
	int			ndx		(char*fn){return dzb.bfind(fn);}
};
























#ifdef OLDOLDOLDOLDOLD

struct riki {	char r[2]; ushort k; // cutri and ripki
			 riki ( char* r1,  int k1 ) { r[0]=r1[0]; r[1]=r1[1]; k=(ushort)k1;}
			 riki ( )		{ r[0]=r[1]=0; k=0; }
	int  ishanri( )	{
	 return (r[0])&&(r[0]!='*'); }
	int  isgood ( ) { return (r[0]&&k); }
};

struct rikin { ushort n;
			 rikin ( ushort n1=0 ) : n(n1) { }
			 rikin ( int    n1   ) : n((ushort)n1) { }
			 void operator=(rikin r) { n=r.n; }
};


class laivetos {
	riki* ns; int nslen;
	char* kis;int kislen; int WKI;
public:
	char* tos_ki	( int n) { return tos_ki  (rikin(n)); }
	char* tos_ki0	( int n) { return tos_ki0 (rikin(n)); }
	char* tos_ri	( int n) { return tos_ri  (rikin(n)); }
	char* tos_line( int n) { return tos_line(rikin(n)); }
public:
	char* tos_ki	( rikin n);
	char* tos_ki0	( rikin n);
	char* tos_ri	( rikin n);
	char* tos_line( rikin n);
public:
	char* tos_ri		(rikin*a, int K, char sep=0		);
	char* tos_ki		(rikin*a, int K, char sep='-'	);
	char* tos_ki0		(rikin*a, int K, char sep=0		);
	char* tos_line	(rikin*a, int K, char sep='\t');
	char* tos_it		(rikin*a, int K) { return tos_imtau(a,K); }
	char* tos_imtau	(rikin*a, int K);
public: // for building other suden
	riki  toriki(const char* ri, const char* ki);
	int   tondx (const char* ri, const char* ki);
	rikin ton   (const char* ri, const char* ki){return rikin(tondx(ri,ki));}
};

struct laivetosK { laivetos* lv; int K; };

struct di5wis_ {
	static	int i2r		(const void*l, const void*r)
	{
		static chars ll; ll.set2(  (char* )l ); str_del4wis(ll.s);
		static chars rr; rr.set2(*((char**)r)); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static	int r2i		(const void*l, const void*r)
	{
		static chars rr; rr.set2(*((char**)r));
		return strcmp((char*)l,rr());
	}
	static	int i2rf	 (const void*l, const void*r)
	{
		static chars ll; ll.set2(    (char* )l );     str_del4wis(ll.s);
		static chars rr; rr.set2( (*((char**)r))+5 ); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static	int r2if		(const void*l, const void*r)
	{
		static chars rr; rr.set2(*((char**)r)+5);
		return strcmp((char*)l,rr());
	}
public:
	static int c1su(const void*l, const void*r)
	{
		return strcmp((char*)l, (char*)r);
	}
	static int riki1(const void*l, const void*r)
	{
		uchar *ll, *rr; ll=(uchar *)l; rr=(uchar *)r;	int res;
		res=ll[0]-rr[0]; if(res) return res;
		res=ll[1]-rr[1]; if(res) return res;
		return ((riki*)l)->k - ((riki*)r)->k;
	}
public:
	static int i2rnkrK(const void*l, const void*r, laivetosK* lv);
	static int i2rnitK(const void*l, const void*r, laivetosK* lv);
};
extern di5wis_ di5wis;



class di53rd_ { // 2 or 3 column
	laivetosK* lvK;
	di53rd_* base4nit;
protected:
	tyio    io;   szmiohs mm;
	rdhdr* hd_;  void*   dt_;
	short id;  char s4null[4];
protected: // for dzb, dst_ is alloc-ed
	char**  dst_;
	int 		jumpbyte;
	int 		hsd2, hsd3, hsd4, hsd5;
	void 	setinnr();
	int		cols_is() { return (hd_->col)-'0'; }
protected:
	int (__cdecl *wis ) (const void *, const void *);
	int (__cdecl *wisx) (const void *, const void *, const void*);
protected:
	char* smd(char* s) { static chars ss; if(hd_->key!='i') return s;
												ss=s; str_del4wis(ss.s);return ss.s;}
public:
	int lower(char*s) { return (wisx)?
			wislower1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
			wislower (smd(s),dst_,size(),sizeof(char**),wis);
	}
	int upper(char*s) {  return (wisx)?
			wisupper1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
			wisupper (smd(s),dst_,size(),sizeof(char**),wis);
	}
	int lmu  (char*s, int*l, int*m, int*u); //r: nonsense
public:
	di53rd_()				 : hd_(0),wis(di5wis.i2r) {s4null[0]=0; }
	di53rd_(char* fn): hd_(0),wis(di5wis.i2r) {s4null[0]=0; read(fn); }
 ~di53rd_(){del();}
public:
	void 	del() { mm.del(); }
	int 	read(tyio& r ){ del(); mm.read(r ); afterread(); return 1; }
	int 	read(char* fn){ if(!io.open(fn))return 0;read(io);io.close();return 1; }
	int 	afterread();
public:
	int	hasd2()		{ return hsd2; }
	int	hasd3()		{ return hsd3; }
	int	hasd4()		{ return hsd4; }
	int	hasd5()		{ return hsd5; }
	int hasfreq() { return hd_->frq; }
public:
	int	 isOK	 () { return (int)hd_; }
	uint size  () { return (uint)(hd_->asz);			}
	char key   () { return hd_->key; }
	char qiqien() { return hd_->qqn; }
	char luibet() { return hd_->knd; }
	int  luibet(rdkind knd) { return knd==hd_->knd; }
	int  keyi  () { return 'i'==key(); }
public:
	char*    ki (USHORT n); // depends on luibet
	char*    ri (USHORT n); // depends on luibet
	char*    ki0(ushort n){static chars s; s=ki(n); str_del4wis(s.s); return s.s;}
protected: // for nrk
protected: // for nit
protected: // for laive
protected: // for c1su
//	int   ndx(const char*s) { return bfind(s,dt_,size(),hd_->usz, ???wisc1su_); }
public: //for dzb
	float freq(USHORT n) { return *( (float*)(*(dst_+n)) ); }
	char* d1	(USHORT n) { return dst_[n]+jumpbyte;	}
	char* d2	(USHORT n) { if(!hsd2)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1; }
	char* d3	(USHORT n) { if(!hsd3)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1+ strlen(d2(n))+1; }
	char* d4	(USHORT n) { if(!hsd4)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1; }
	char* d5	(USHORT n) { if(!hsd5)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1+ strlen(d4(n))+1;}
};
typedef di53rd_ di53rd;



class dzb53_ { // 2 or 3 column
protected:
	tyio    io;   szmiohs mm;
	rdhdr* hd_;  char*   dt_;  char**  dst_;
	short id; int jumpbyte; char s4null[4]; int hsd2, hsd3, hsd4, hsd5;
	void  setinnr();
	int	cols_is() { return (hd_->col)-'0'; }
	int (__cdecl *wis ) (const void *, const void *);//the wis function
	char* smd(char* s) { static chars ss; if(hd_->key!='i') return s;
												ss=s; str_del4wis(ss.s);return ss.s;}
public:
	int lower(char*s) { return wislower(smd(s),dst_,size(),sizeof(char**),wis);}
	int upper(char*s) { return wisupper(smd(s),dst_,size(),sizeof(char**),wis);}
	int find (char*s) { return bfind   (smd(s),dst_,size(),sizeof(char**),wis);}
	int lmu  (char*s, int*l, int*m, int*u); //r: nonsense
public:
	dzb53_()				:	wis(di5wis.i2r) {s4null[0]=0; }
	dzb53_(char* fn): wis(di5wis.i2r) {s4null[0]=0; read(fn); }
 ~dzb53_(){del();}
public:
	void del() { mm.del(); }
	int read(tyio& r ){ del(); mm.read(r ); setinnr(); return 1; }
	int read(char* fn){ tyio io; if(!io.open(fn))return 0; mm.del();
											mm.read(io);
											setinnr();
											io.close(); return 1; }
public:
	int	hasd2()		{ return hsd2; }
	int	hasd3()		{ return hsd3; }
	int	hasd4()		{ return hsd4; }
	int	hasd5()		{ return hsd5; }
	int hasfreq() { return hd_->frq; }
public:
	int	 isOK	 () { return (int)hd_; }
	uint size  () { return (uint)(hd_->asz);			}
	char key   () { return hd_->key; }
	char qiqien() { return hd_->qqn; }
	char luibet() { return hd_->knd; }
public:
	float freq(USHORT n) { return *( (float*)(*(dst_+n)) ); }
	char* d0	(USHORT n) { return dst_[n]+jumpbyte;	} // d0 is key
	char* d1	(USHORT n) { if(!hsd2)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1; }
	char* d2	(USHORT n) { if(!hsd3)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1; }
	char* d3	(USHORT n) { if(!hsd4)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1; }
	char* d4	(USHORT n) { if(!hsd5)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1;}
};


typedef dzb53_ dzb_;







inline int wisc1su_(const void* l, const void*r) 
{ return strcmp((char*)l,(char*)r); }

class c1su_ {protected: short id; int usz; // size of each unit in byte
	szmiohs mm;  rdhdr* hd_;  char*   dt_;
	void  setinnr(){ hd_=(rdhdr*)(mm.h)(); dt_=(char*)(mm.s)(); usz=hd_->usz; }
public:
  int write(tyio& r ){ int res=mm.write(r);return res; }
	int read (tyio& r ){ int res=mm.read (r); setinnr(); return res; }
public:
  unsigned int  size() { return (unsigned int)(hd_->asz); }
  unsigned int usize() { return (unsigned int)(usz); }
public:
	char* c1(USHORT n) { return dt_+n*usz; }
	int   ndx(const char*s) { return bfind(s,dt_,size(),usz, wisc1su_); }
};

struct int2 { int i1, i2;
int2(int i11=0, int i21=0) { i1=i11; i2=i21; }
};


struct idndx {
  short  i;
	USHORT n;
  idndx() : i(0), n(0) {}
  idndx(short id, USHORT ndx) : i(id), n(ndx) {}
  void set2 (short i1, USHORT n1){ i=i1; n=n1; }
  void set20(                   ){ i=0 ; n=0 ; }
  void clear(                   ){ i=0 ; n=0 ; }
	int  isnull() { return i<=0; }
  int notnull() { return i> 0; }
  void operator = (idndx r) {i=r.i; n=r.n;}
	void operator ++()    { n++; }
  void operator ++(int) { n++; }
  void operator --()    { n--; }
  void operator --(int) { n--; }
  void operator +=(int t) { n+=(short)t; }
  void operator -=(int t) { n-=(short)t; }

	void trimend  (USHORT ubound)   { if(n>ubound) n=ubound; }
  void trimbegin(USHORT lbound=0) { if(n<lbound) n=lbound; }
};

inline int operator < (idndx& l, idndx& r) { return l.n< r.n; }
inline int operator <=(idndx& l, idndx& r) { return l.n<=r.n; }
inline int operator ==(idndx& l, idndx& r) { return (l.i==r.i)&&(l.n==r.n); }


struct idndx2 { idndx l, u;
idndx2() { }
idndx2(idndx  l1, idndx  u1) { l=l1;  u=u1;		}
  void operator = (idndx2 r) { l=r.l; u=r.u;	}
  int count()    { return u.n-l.n;			}
  int    none () { return u.n-l.n <=0;	}
	int hasnone () { return none();				}
	int hassome () { return count();			}
  idndx& begin() { return l;						}
  idndx& end  () { return u;						}
};

struct idndx3 { idndx l, m, u;
idndx3() { }
idndx3(idndx  l1, idndx  m1, idndx  u1) { l=l1;  m=m1;  u=u1; }
	void operator = (idndx3 r)						{ l=r.l; m=r.m; u=r.u;}
	int count   ()	{ return u.n-l.n;			}
	int    none ()	{ return u.n-l.n <=0;	}
	int hasnone ()	{ return none();			}
	int hassome ()	{ return count();			}
	int has1sthalf(){ return m.n-l.n;			}
	int has2ndhalf(){ return u.n-m.n;			}
	idndx& begin()	{ return l;						}
	idndx& end  ()	{ return u;						}
};

#endif //#ifdef OLDOLDOLDOLDOLD


template <class K, int SZ1=701>
class strhash {
	struct node { chars s; K k; node* nxt; };
	node* tbl[SZ1]; int SZ;
public:
	strhash(): SZ(SZ1) { memset(tbl, 0, sizeof(*tbl)*SZ1); }
	int size() { return SZ; }
public:
	uint hval(char* s){uint v=0;for(;*s;s++)v=*s+31*v;return v%SZ;}
	K&   get (char* name, int insert=0);
};

template<class K, int SZ1> K& strhash<K, SZ1>::
get(char* name, int insert)
{
	static K kk;
	node *p; int h=hval(name);
	p = tbl[h];
	if (p==NULL)		// entry empty
		if (insert) { p=tbl[h]=new node; p->s=name; return p->k; }
	while(p!=NULL){ // look for name */
		if(p->s.is(name)) return p->k;
		p=p->nxt;
	};
	// name not found
	if(insert) { p=tbl[h]=new node; p->s=name; return p->k; }
	return kk;
}
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
class pinimexpander { public: charspp output;
	int set2Nexpand(char*s);
	char*operator[](int n)  { return output[n];			}
	int size()							{ return output.size(); }
};

class tcpmlexpander { public: charspp output;
	int set2Nexpand(char*s);
	char*operator[](int n)  { return output[n];			}
	int size()							{ return output.size(); }
};
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////

class segtr_ { charspp tspp, ispp; charspp ospp; 	charspp pspp; //part spp
	di53rd_** wrds; int nwrds; di53rd_* rds[2]; int nrds;
	int maxsu;
public:
	segtr_(){nwrds=nrds=0;}
public:
	void	setrds (di53rd_* rd1						){rds[0]=rd1; nrds=1; setwrds();}
	void	setrds (di53rd_* rd1,di53rd_*rd2){rds[0]=rd1;rds[1]=rd2;nrds=2; setwrds();}
	void	setrds (di53rd_**rds1,int nrds1	){setwrds(rds1,nrds1);}
	void	setwrds(di53rd_**rds1,int nrds1	){wrds=rds1;nwrds=nrds1;setmaxsu(wrds,nwrds);}
	void	setwrds(						 					 	){wrds=&(rds[0]) ;nwrds=nrds; setmaxsu(wrds,nwrds);}
	int		isOK	 (){return nrds>0;}
public:
	int		smmseg(chars& ot, charspp& in, char sep=ch01);
	int		 mmseg(chars& ot, charspp& in, char sep=ch01);
	char*		 seg(char* s, int domm, char sep);
	char*	 mmseg(char* s, char sep='='){return seg(s,1,sep);}
	char*	smmseg(char* s, char sep='='){return seg(s,0,sep);}
public:
	int		smmtr (chars& ocs0,chars& ocs1, charspp& in, char sep=ch01);
	int		 mmtr (chars& ocs0,chars& ocs1, charspp& in, char sep=ch01);
	char*		 tr (char* s, int domm, char sep);
	char*	 mmtr (char* s, char sep='='){return tr(s,1,sep);}
	char*	smmtr (char* s, char sep='='){return tr(s,0,sep);}
	char*		 tr1(char* s, int domm, char sep);//tr with partly hun-su
	char*	tr4ask(char* s, int domm, char sep);//tr with partly hun-su, donot hungu
protected:                                  //4ask: exist one su bw '?'
	int		check4skip(char*s);//check huhor, all digit, pinimri with diaugi
	void	setmaxsu(di53rd_* rds[], int nrds){int n,b;maxsu=0;
										for(n=0;n<nrds;n++)
										{b=rds[n]->maxri();if(b>maxsu)maxsu=b;}
										if(maxsu<=0)maxsu=1;}
	int		 mmseg(chars& ot, charspp& in, int B, int E, int nmsu, char tmpsep);
	int		 mmtr (chars& ocs0,chars& ocs1, charspp& in, int B, int E, int nmsu, char tmpsep);
};

////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////

#include <di5base.cc>
#undef TPC
#undef TPC1
#undef TPC2
#undef TPC3
#undef TPCI
#undef TPCI1
#undef TPCI2
#undef TPCI3
/*
#undef TPC(X)
#undef TPC1(X)
#undef TPC2(X)
#undef TPC3(X)
#undef TPCI(X)
#undef TPCI1(X)
#undef TPCI2(X)
#undef TPCI3(X)
*/
#endif //#ifndef DIBASE_H



