//
// di5mout.h
// 2003-04 (C)IZGang
//

#ifndef DI5MOUT_H
#define DI5MOUT_H

#ifndef DIBASE_H
#include <di5base.h>
#endif //#ifndef DIBASE_H

//* memo1 should be TMemo* of bcb
		int	mout_tie2	(void* memo1);//* call this at Form construction
inline	int	cs_tie2		(void* memo1){return mout_tie2(memo1);}
inline	int	cstie2		(void* memo1){return mout_tie2(memo1);}
inline	int	mouttie2	(void* memo1){return mout_tie2(memo1);}

		chars& memo		(chars&cs);
		chars& moutbox	(chars&cs);//will not show if cs is empty
		chars& hint		(chars&cs);
		chars& mmclear	(chars&cs);
inline 	chars& mmclr	(chars&cs){return mmclear(cs);}

extern	chars mout;

#endif //#ifndef DI5MOUT_H


