//
// file rmel.h
// IZGang 2001-10-9
//

#ifndef RMEL_H
#define RMEL_H

#include <speechio.h>



template<class T>
class 	smpvect {
public: smpvect	(						):a(0), nuse(0), allc(0){}
public: smpvect	(uint nuse1	):a(0), nuse(0), allc(0){init2(nuse1);}
public:~smpvect	(						){del();}
public:
	int		ugaiben	(uint nuse1	){if(nuse1!=nuse){init2(nuse);return 1;} return 0;}
	int   init2		(uint nuse1	);
	T&		OP[]		(uint n			){return a[n];}
	T*		OP()		(						){return a;		}
	void	del			(						){if(a)delete[]a;a=0;nuse=allc=0;}
public:
	T* a; uint nuse, allc;
};

template<class T>
int   smpvect<T>::init2		(uint nuse1)
{
	if(nuse1<allc){memset(a,0,sizeof(T)*allc); nuse=nuse1; return 1;}
	del();
	a=new T[nuse1];
	if(a){allc=nuse1; nuse=nuse1;}
	return 1;
}


class 	hamwin_ { public:
public: hamwin_(){}
public:
	void   	initham();
	void   	doham  (float* obs, int nobs);
public:
	smpvect<float> ham;
};

inline void hamwin_::initham()
{
	if(ham.nuse<2) return;
	float dt=float(twopi/(ham.nuse-1));
	for(uint i=0; i<ham.nuse; i++) ham[i]=float(0.54-0.46*cos(dt*i));
}

inline void hamwin_::doham(float*obs, int nobs)
{
	if(ham.ugaiben(nobs)) initham();
	float*o=obs, *h=ham();
	for(register uint i=0; i<ham.nuse; i++)
		*o++ *= *h++;
}



#define NMAXFEATURES  132
#define MELFLOOR 1.0
enum melkind { MELSPEC, MELBANK, MFCC };
//NBINS is pOrder in HTK
//NCEPS is pParam in HTK

class   realmel_ { public: int smprate;
public: realmel_
						(int  smprate1=16000, double preem1=0.975, int cepLift1=0,
						 double lopass1=-1.0, double hipass1=-1.0, float engscale1=0.1)
						 : ham(0),xdef(0),bins(0),resdef(0),fftndx2bin(0),binwt(0),cfs(0)
{            // also dctmat to init
	initlast20();
	smprate=smprate1;cepLift=cepLift1; preem=(float)preem1;
	lopass=(float)lopass1; hipass=(float)hipass1;	engscale=engscale1;
	//initham(); initbins(); initdct();
	//setFRMSZ(128);
	cepwinlen=0; cepLift=22; init_cepwin(cepLift);	//can be called when used
	setNCEPS(12,26);
	//call setFRMSZ before use, or will be called auto-ly when used
}
public:
	void		setSamplingRate(int smprate1){if(smprate==smprate1)return;
															smprate=smprate1;initbins();					}
public:
	int			nceps		(					){return lastNCEPS; }
	int		 	setNCEPS(int NCEPS1, int NBINS1=-1){return allc4NCEPS(NCEPS1,NBINS1);}
																// NBINS will be 2*NCEPS1 if -1
public:
	float* 	realmel	(short* shobs,int nsho, float* res=0, int melkind=MFCC);
	float* 	rmel		(short* shobs,int nsho, float* res=0)
										{return realmel(shobs,nsho, res,MFCC);}
public:
	// wroking array upto rfft;
	float* 	xdef;//[NRFFT];
	// after rfft, it is bins that holds the needed data
	float* 	bins;//[NBINS];
	// and resdef will be return as cepstrum, if a receiving buf not provided
	float* 	resdef;//[NCEPS+1];
public:
public: 	int lastFRMSZ, lastNRFFT, allcFRMSZ, allcNRFFT;
					int lastNBINS, lastNCEPS, allcNBINS, allcNCEPS;
	void		initlast20(){	lastFRMSZ=lastNRFFT=allcFRMSZ=allcNRFFT=0;
												lastNBINS=lastNCEPS=allcNBINS=allcNCEPS=0;}
	int		 	setFRMSZ	(int newFRMSZ){return allc4FRMSZ(newFRMSZ);}
	int			allc4FRMSZ(int newFRMSZ);
	int 		allc4NCEPS(int newNCEPS, int newNBINS=-1);//-1 for 2*newNCEPS
	int			del4FRMSZ	(int val2return=0);//val2return not used, only as return;
	int			del4NCEPS	(int val2return=0);//val2return not used, only as return;
	int			del				();
public:
public:  	// need frame size before padding (lastFRMSZ)
	float  	preem;
	void   	dopreem(float* obs, int 	nobs);
	void   	dopreem(float* obs, float prevvalue);
public:  	// need frame size before padding (lastFRMSZ)
	float* 	ham;//[FRMSZ];
	void   	initham(int nobs);
	void   	doham  (float* obs, int nobs);
public:
	float 	engscale;
	float  	mfcceng		();
	float  	totaleng	(short* x, int N);
public:
	int		 	cepLift;
	int 		cepwinlen;
	float  	cepwin[NMAXFEATURES];
	void   	init_cepwin	(int cepLiftering);
	void   	weightcep 	(float* c,int start,int count,int cepLiftering);
public:
	int    	locut, 	hicut;
	float 	lopass, hipass;
	int*   	fftndx2bin;	//[NRFFT/2]; // ndx of fft components to go to bin num
	float* 	binwt;			//[NRFFT/2]; // bin weights
	float* 	cfs; 				//[NBINS+1]; // center freq's
	//float*bins;				//[NBINS];   // bins to hold the data
	void   	initbins	();
	float  	mel				(int kth);
	void   	mel2bins	(float* x, float* bins1, int takinglog);
	//up: x is result from rfft, outout2 bins1
public:
	//double 	dctmat[NCEPS][NBINS];
	rmdmat 	dctmat;//[NCEPS,NBINS];
	void   	initdct();
};

class 	wav2mcep {
public:	wav2mcep (){init();}
public:
	realmel_ rmel;
	int wfrmsz, wsftsz; // wave-frame-size  and  wave-shift-size in short
	int	fssize; // feature sample size in float
	//int	wszD, wszA;
  int    setsz(int frmsz1, int sftsz1){wfrmsz=frmsz1;wsftsz=sftsz1;return 1;}
public:
	int			wav2fea	(qiimbuf_& qb, feabuf_& fb, int frmsz, int sftsz){setsz(frmsz,sftsz);return wav2fea(qb,fb);}
	int			wav2fea	(qiimbuf_& qb, feabuf_& fb);
	int			wav2fea	(qiimbuf_* qb, feabuf_* fb){return wav2fea(*qb,*fb);}
	int			w2f			(qiimbuf_* qb, feabuf_* fb){return wav2fea(*qb,*fb);}
	int			w2f			(qiimbuf_& qb, feabuf_& fb){return wav2fea( qb, fb);}
public:
	float*	wav2fea1(short* shobs, int frmsz, float* mcep)
									{return rmel.realmel(shobs,frmsz,mcep);}
	int			normalizelogenergy(feabuf_& fb, float escale);
	int			doDmel	(feabuf_& fb);//D: delta mel
	int			doAmel	(feabuf_& fb);//A: acceleration mel
public:

public:
	void	init(){init16k();}
	void	init16k();
};

#endif //#ifndef RMEL_H


