//
// file bcbhandy.h
//
#ifndef BCBHANDY_H
#define BCBHANDY_H
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "speechio.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

// two parts : spmsgthreads and spthreads
//************************************************************
//************************************************************
// BEG of part 1: spmsgthreads ( of spmsgthreads and spthreads )
//************************************************************

class  TStatusTH : public TThread {  static String s; TEdit*edit;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
	TStatusTH(TEdit *edit1, char*s1): TThread(true)
					{ edit=edit1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
	update() { edit->Text=s; edit->Update();}
};

class  TRcgOutTH : public TThread { static  String s; TMemo*memo;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
	TRcgOutTH(TMemo *memo1, char*s1): TThread(true)
				{ memo=memo1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
	update() {memo->Lines->Append(s);memo->Update();}
};

class  TRcgOutRRTH : public TThread { static  String s; TRichEdit*rr;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
	TRcgOutRRTH(TRichEdit *rr1, char*s1): TThread(true)
				{ rr=rr1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
	update() {rr->Lines->Append(s);rr->Update();}
};

class  TDebugTH : public TThread { static  String s; TMemo*memo;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
	TDebugTH(TMemo *memo1, char*s1): TThread(true)
	{ memo=memo1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
	update() {memo->Lines->Append(s);memo->Update();}
};


class  TEditTH : public TThread { String s; TEdit*edit;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
	TEditTH(TEdit *edit1, char*s1): TThread(true)
				{ edit=edit1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
	update() {edit->Text=s;edit->Update();}
};

class  TMemoTH : public TThread { String s; TMemo*memo;
private: void __fastcall
	Execute (){Synchronize(update);}
public:  __fastcall
	TMemoTH(TMemo *memo1, char*s1): TThread(true)
	{ memo=memo1;s=s1; FreeOnTerminate=true; Resume(); }
public: void __fastcall
	update() {memo->Lines->Append(s);memo->Update();}
};

typedef TStatusTH TIStatusTH;
typedef TStatusTH TOStatusTH;


class  spthmsgbcb: public spmsgcase {// must use thread to implement this
public:spthmsgbcb():rr(0),rm(0){setasdef(1);}	TEdit* oe, *ie; TMemo* rm, *dm;TRichEdit* rr;
			 spthmsgbcb(TEdit* oe1, TEdit* ie1, TMemo* rm1=0, TMemo* dm1=0)
			 :rr(0),rm(0){set(oe1, ie1, rm1, dm1); setasdef(1);}
	void set(TEdit* oe1, TEdit* ie1, TMemo* rm1=0, TMemo* dm1=0)
						{oe=oe1; ie=ie1; dm=dm1; rm=rm1;}
	void set(TRichEdit* rr1){rr=rr1;}
	// the 4 virtual functions
	void rcg0    (cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{
		if(rr){set2s(s1,s2,s3,s4);new TRcgOutRRTH(rr, s.s); return;}
		if(!rm)return;	set2s(s1,s2,s3,s4);new TRcgOutTH(rm, s.s); }
	void debug0  (cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{if(!dm)return;
															set2s(s1,s2,s3,s4);new TDebugTH(dm, s.s); }
	void ostatus0(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{if(!oe)return;
															set2s(s1,s2,s3,s4);new TStatusTH(oe, s.s); }
	void istatus0(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{if(!ie)return;
															set2s(s1,s2,s3,s4);new TStatusTH(ie, s.s); }
};

//************************************************************
// END of part 1: spmsgthreads ( of spmsgthreads and spthreads )
//************************************************************
//************************************************************

class TBangYimBCB :public TThread {
public:  __fastcall
			TBangYimBCB (qiimbuf_* buf1, int wait2end1=1) : TThread(true)
      { buf=buf1; wait2end=wait2end1; FreeOnTerminate=true; Resume();}
private:	void __fastcall
  Execute(){ buf->play();if(wait2end)while(owdef.isplaying()) Sleep(100); }
public:
	int wait2end;
	qiimbuf_* buf;
};


class  TAdaptBCB :public TThread {
public:__fastcall
			 TAdaptBCB (adaptation2_* adapt1, VFNV fn_getsok1=0) : TThread(true)
       { adapt=adapt1; if(fn_getsok1)fn_getsok=fn_getsok1; FreeOnTerminate=true; Resume();}
private:
	void __fastcall Execute(){ adapt->kaisiw(); }
  void __fastcall DoTerminate() { if(fn_getsok) (*fn_getsok)(); }
public:
	adaptation2_* adapt; VFNV fn_getsok;
};


class  TSiuYimBCB :public TThread {
public:TSiuYimBCB(siuqiim2_* siuyim1):TThread(true)
      { siuyim=siuyim1; FreeOnTerminate=true;Resume();}
private:
	void __fastcall Execute(){ siuyim->kaisiw(); }
public:
	siuqiim2_* siuyim;
};







//---------------------------------------------------------------------------
#ifndef fplotbcbH
#define fplotbcbH
//---------------------------------------------------------------------------
//
// file fplotbcb.h
//
#include <windows.h>
//---------------------------------------------------------------------------
class  COLORS256 {
public:COLORS256(int nth=4) { setcolors(nth); }
	COLORREF colors[256];
	COLORREF nthcolor(float x);
	COLORREF operator ()(float x){ return nthcolor(x); }
	void setcolors(int nth=4);
};

class  GREYS : public COLORS256 {
public:GREYS():COLORS256(4){}
};


class fplotbase {
public: fplotbase() { setdotwh(2,2); }
	int ires;// int result, for debugging
	int 	px0, py0, pdx, pdy; // (x0,y0) is left-top
	float lx0, ly0, ldx, ldy;
	float scalex, scaley;
public:
	int  pwidth()										{ return pdx; 	}
	int  pheight() 									{ return pdy; 	}
	int  lwidth()                  	{ return ldx; 	}
	int  lheight()									{ return ldy; 	}
	int  width()                   	{ return ldx; 	}
	int  height()										{ return ldy; 	}
	int    l2px(float lx)  { return int((lx-lx0)/scalex); }
	int    l2py(float ly)  { return int((ly-ly0)/scaley); }
	float  p2lx(int   px)  { return  px*scalex+lx0;  }
	float  p2ly(int   py)  { return  py*scaley+ly0;  }
public:
	void  setlx0(float lx01){lx0=lx01;}
	void  setly0(float ly01){ly0=ly01;}
	void  setldx(float ldx1){ldx=ldx1;}
	void  setldy(float ldy1){ldy=ldy1;}
	void  setpx0(float px01){px0=px01;}
	void  setpy0(float py01){py0=py01;}
	void  setpdx(float pdx1){pdx=pdx1;}
	void  setpdy(float pdy1){pdy=pdy1;}
	float getlx0(					 ){return lx0;}
	float getly0(					 ){return ly0;}
	float getldx(					 ){return ldx;}
	float getldy(					 ){return ldy;}
	float getpx0(					 ){return px0;}
	float getpy0(					 ){return py0;}
	float getpdx(					 ){return pdx;}
	float getpdy(					 ){return pdy;}
public: // (x0,y0) is left-top
	void  setpscale (int px01,int py01, int pdx1, int pdy1)
									{px0=px01;py0=py01; pdx=pdx1; pdy=pdy1;}
	void  setlscale (float lx01,float ly01, float ldx1,float ldy1)
									{  lx0=lx01;  ly0=ly01;   ldx=ldx1;  ldy=ldy1;setlscalexy();}
	void  setlscalexy(){	scalex =  1.0*getldx()/getpdx();
												scaley = -1.0*getldy()/getpdy(); }
public:
	virtual void ptextout(int px,int py, char*str){}//{pc()->TextOut(px,py,str);}
	void  textout(float lx, float ly, char* str){ptextout(l2px(lx),l2py(ly),str);}
	void  textoutlt(char* str){ ptextout(10,10,str); } // lt: left top
public:
	virtual void pmove2(int px, int py) 		{ }//pb->Canvas->MoveTo(px, py); }
	virtual void pline2(int px, int py) 		{ }//pb->Canvas->LineTo(px, py); }
	void  move2(float lx, float ly)	{ pmove2(l2px(lx), l2py(ly)); }
	void  line2(float lx, float ly) { pline2(l2px(lx), l2py(ly)); }
public:
	int  dotw, doth;
	void setdotwh (int w, int h) { dotw=w; doth=h;  }
	virtual void pputdot (int px,int py, int clr){}//{pc()->Pixels[px][py]=TColor(clr);}
	void pputbdot(int px,int py, int clr){int i,j;for(i=0;i<dotw;i++)for(j=0;j<doth;j++)
									pputdot(px+i,py+j,clr);													}
	void  putdot (float lx,float ly,int clr){pputdot (l2px(lx), l2py(ly),TColor(clr)); }
	void  putbdot(float lx,float ly,int clr){pputbdot(l2px(lx),l2py(ly),TColor(clr)); }
public:
	void XORvpline(int px,  TColor cln=clRed);
public:
	TPenMode pm_old; TColor cl_old;
	virtual void pushPenColor (COLORREF clr){}//{cl_old=pc()->Pen->Color;pc()->Pen->Color=cln;}
	virtual void pop_PenColor (            ){}//{                    pc()->Pen->Color=cl_old; }
	virtual void pushPenMode  (TPenMode pmn){}//{pm_old=pc()->Pen->Mode; pc()->Pen->Mode=pmn; }
	virtual void pop_PenMode  (            ){}//{                    pc()->Pen->Mode=pm_old;  }
	virtual void blanknow     (            ){}//{pb->Invalidate();  pb->Update(); }
public:
	int dragX, dragY, dragON; COLORREF dragclr;
	virtual void dragplot(int X, int Y){}
	void dragplot0();//{pushPenMode(pmNotXor);dragplot(dragX,dragY);pop_PenMode();}
	void begdrag(int X, int Y, COLORREF clr=-1);
	void movdrag(int X, int Y){if(!dragON) return; dragplot0(); dragX=X; dragY=Y; dragplot0();}
	void enddrag(int X, int Y){dragplot0(); dragX=X; dragY=Y; dragON=0;}
};

inline void fplotbase:: XORvpline(int px, TColor clr)
{
	pushPenColor(clr); 	pushPenMode(pmNotXor);
	pmove2(px, 0);     	pline2(px, getpdx());
	pop_PenMode();  		pop_PenColor();
}

inline void fplotbase::begdrag(int X, int Y, COLORREF clr)
{
	dragclr=clr;
	dragX=X; dragY=Y; dragON=1;dragplot0();
}

inline void fplotbase::dragplot0()
{
	pushPenMode(pmNotXor);
	if(dragclr>=0) pushPenColor(dragclr);
	dragplot(dragX,dragY);
	if(dragclr>=0) pop_PenColor();
	pop_PenMode();
}

inline COLORREF COLORS256::nthcolor(float x)
{int n=x;if(n>255)n=255;if(n<0)n=0;return colors[n];}

inline void COLORS256:: setcolors(int nth)
{ int i; int bk1=0, bk2=0, bk3=0;
	switch(nth) {
	case  1: for(i=0;i<256;i++)colors[255-i]=RGB(i  ,bk2,bk3);break;
	case  2: for(i=0;i<256;i++)colors[255-i]=RGB(bk1,i  ,bk3);break;
	case  3: for(i=0;i<256;i++)colors[255-i]=RGB(bk1,bk2,i  );break;
	default: for(i=0;i<256;i++)colors[255-i]=RGB(i  ,i  ,i  );break;
	}
}


class Tfplot: public fplotbase {
public:
	TPaintBox* 	pb;
	TCanvas*		pc()									{ return pb->Canvas; }
	void  setPaintBox(TPaintBox* pb1)  { pb=pb1;
					setpscale(0,0,pb->Width,pb->Height);setlscale(0,0,1,1); }
	void  setlscale (float lx01,float ly01, float ldx1,float ldy1)
					{ fplotbase::setlscale(lx01,ly01, ldx1, ldy1); }
public: // there are the first 9 simple virtual functions need to be derived
	virtual void ptextout(int px,int py, char*str){pc()->TextOut(px,py,str);   }
	virtual void pmove2	 (int px,int py) {pb->Canvas->MoveTo(px, py); }
	virtual void pline2  (int px,int py) {pb->Canvas->LineTo(px, py); }
	virtual void pputdot (int px,int py, int clr) {pc()->Pixels[px][py]=TColor(clr);}
	virtual void pushPenColor (COLORREF clr){cl_old=pc()->Pen->Color;pc()->Pen->Color=TColor(clr);}
	virtual void pop_PenColor (            ){                    pc()->Pen->Color=cl_old; }
	virtual void pushPenMode  (TPenMode pmn){pm_old=pc()->Pen->Mode; pc()->Pen->Mode=pmn; }
	virtual void pop_PenMode  (            ){                    pc()->Pen->Mode=pm_old;  }
	virtual void blanknow     (            ){pb->Invalidate();  pb->Update(); }
	virtual void dragplot     (int X, int Y){pmove2(dragX, 0);pline2(dragX, pheight());}
};

//derived from Tfplot (say, override dragplot) to retain the power




extern GREYS greys;

class wavebox_ : public Tfplot{ public: short *ddd;int dddsz;
	wavebox_(): ddd(0) { init4file(); uedodone=1; }
 ~wavebox_() { if(ddd) delete[] ddd; }
public:
	qiimbuf_* qiimbuf; int deltalx; int uedodone;
	void set2( qiimbuf_* qiimbuf1 ){ qiimbuf=qiimbuf1; } // note that wavebox donot own
	void plotwave(TPaintBox* pb1, qiimbuf_* qiimbuf1,int skip=4 );
	char*qiimbufstatus();
	void plotmsg();
public:
	int	 nbqiim, neqiim;
	int  p2wx(int px); // trim wave to a 160short's frame
	int	 roundbeqiim(int nbqiim1, int neqiim1);
public:
	void init4file(){ ddd=NULL; dddsz=0; }
	int  readwrec (char* fname, int checkheader);
};

class specbox_ : public Tfplot { public:
			specbox_() { setdotwh(6,1);specdone=1; nFS=256; nFSS=128;//setcolors();
      							fsig=new float[2048]; }
public:
	emhamfft_<256,256> ehfft;
  qiimbuf_* qbuf;
	float *fsig; int nFS, nFSS;  int specdone;
public:
	void plotspec (TPaintBox* pb1, qiimbuf_* qbuf);
public:
//	void nthfsignal(float* fsignal, int n){ int nn,off=n*nFSS;
//				  		for(nn=0;nn<nFS;nn++) fsignal[nn]=qbuf->sh[nn+off];}
  int  heightneeded(){ return doth*nFS/2+3; }
};

class  specbox2_ : public Tfplot {
public:specbox2_() { setcolors();setdotwh(6,1);specdone=1; nFS=256; nFSS=128;
										fsig=new float[1600]; scale=-1; setetc(); }
public:
	COLORREF color4s[4][256];
	void setcolors(){//Tfplot::setcolors();
							int i; int bk1=0, bk2=0, bk3=0;
							for(i=0;i<256;i++)color4s[0][255-i]=RGB(i  ,bk2,bk3);
							for(i=0;i<256;i++)color4s[1][255-i]=RGB(bk1,  i,bk3);
							for(i=0;i<256;i++)color4s[2][255-i]=RGB(bk1,bk2,  i);
							for(i=0;i<256;i++)color4s[3][255-i]=RGB(  i,  i,  i);
	}
	//emhamfft_<256,256> ehfft;     float ftemp[1025];
	ehfs_ ehfs;
	qiimbuf_* qbuf;
	float *fsig; int nFS, nFSS;  int specdone;
	float scale;
	int   cetdi; int B12,B23,B34, BC1,BC2,BC3,BC4; int FrameSize, ShiftSize;
public:
	void  		setscale   (float scale1);
	//int   		specscaled (int jth);
	COLORREF 	scaledcolor(int jth);
	void 			setetc     (pairss* etc);
	void			setetc(){cetdi=60; B12=14;B23=24;B34=50;BC1=0;BC2=1;BC3=2;BC4=3;
											FrameSize=256; ShiftSize=64;scale=1.6; }
public:
	void  plotspec  (TPaintBox* pb1, qiimbuf_* qbuf);
public:
	int  heightneeded(){ return doth*nFS/2+3; }
};






#endif //#ifndef fplotbcbH




#endif //#ifdef BCBHANDY_H

