//
// ivhdc.h
//
// for imvun draw 9/22/2k IZGang
//

#ifndef IVHDC_H
#define IVHDC_H



#include <vwin.h>
#include <di5base.h>

const char SSmark=0x01; 			// SuperScript mark
const char DHmark=0x02; 			// DiauHing mark
const char SGmark=0x03;       // SuGap mark
extern char* fontBiauKaiTe;   // �з���
extern char* fontSinSeVingTe; // �s�ө���
extern char* fontSeVingTe;    // �ө���

//enum diaugi_ {vorbiau=0,gorbenn,diongbenn,gegang,gorgang,gorgau,gorsing,
//							gordiam,gebenn,divor, gordit};


class  ivfont_ { HFONT f; int hite;
public:ivfont_ (					): f(0) {}
			~ivfont_ (					){destroy();}
	int 	height	(					){return hite; }
	HFONT operator()(				){return f; }
	HFONT select	(HDC hdc	){return (HFONT) SelectObject(hdc, f); }
	void  destroy (					){if(f) DeleteObject(f); f=0; }
	void  create	(int height, char* fontname=fontSinSeVingTe);
	// warning: create will destroy prev font 1st,
	// make sure this font is not selected into hdc
};




class  ivhdc_ { 	HDC 	hdc;  HFONT of; ivfont_ nf; COLORREF oc; int goc;LOGBRUSH lb;
public:ivhdc_():hdc(0), of(0),oc(0), goc(0){setlb();}
			~ivhdc_(){popf();popc();}
public:
	HDC 	operator()(        ){return hdc;}
	void 	setHDC		(HDC hdc1, int totwip=1){ hdc=hdc1;if(totwip)set2twip(hdc); }
	void 	set2twip	(HDC hdc1);
public:
	void  del			(						){if(hdc)DeleteDC(hdc);hdc=0;						}
	void	setlb		(						){lb.lbStyle=BS_SOLID;									}
	void	push		(ivfont_& f0){popf(); of=f0.select(hdc); 						}
	void	popf		(				 		){if(hdc&&of)SelectObject(hdc,of);of=0;	}
	void	pushc		(COLORREF nc){popc();oc=GetTextColor(hdc);SetTextColor(hdc,nc);goc=1;}
	void	popc		(				 		){if(hdc&&goc)SetTextColor(hdc,oc);goc=0;	}
public:
	int		ew (char s){SIZE sz;GetTextExtentPoint32(hdc,&s,1,&sz);return sz.cx;}
	int		ew (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,1,&sz);return sz.cx;}
	int		hw (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,2,&sz);return sz.cx;}
	int		eh (char s){SIZE sz;GetTextExtentPoint32(hdc,&s,1,&sz);return sz.cy;}
	int		eh (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,1,&sz);return sz.cy;}
	int		hh (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,2,&sz);return sz.cy;}
	SIZE	esz(char s){SIZE sz;GetTextExtentPoint32(hdc,&s,1,&sz);return sz;		}
	SIZE	esz(char*s){SIZE sz;GetTextExtentPoint32(hdc, s,1,&sz);return sz;		}
	SIZE	hsz(char*s){SIZE sz;GetTextExtentPoint32(hdc, s,2,&sz);return sz;		}
public:
	SIZE	tsz(char* s,ivfont_& ef,ivfont_& hf,int len=-1);
	int		w	 (char* s,ivfont_& ef,ivfont_& hf,int len=-1){return tsz(s,ef,hf,len).cx;}
public:
	void	eo (char*s,int x,int y){TextOut(hdc, x, y, s, 1);}
	void	ho (char*s,int x,int y){TextOut(hdc, x, y, s, 2);}
	int		o	 (char*s,int x,int y, ivfont_& ef,ivfont_& hf, int len=-1);
	void	o	 (char*s,int x,int y, int len=-1);
public:
	int   ew (char s, ivfont_&f) {push(f); return ew(s); }
	int   ew (char*s, ivfont_&f) {push(f); return ew(s); }
	int   hw (char*s, ivfont_&f) {push(f); return hw(s); }
	int   eh (char s, ivfont_&f) {push(f); return eh(s); }
	int   eh (char*s, ivfont_&f) {push(f); return eh(s); }
	int   hh (char*s, ivfont_&f) {push(f); return hh(s); }
	SIZE	esz(char s, ivfont_&f) {push(f); return esz(s);}
	SIZE	esz(char*s, ivfont_&f) {push(f); return esz(s);}
	SIZE	hsz(char*s, ivfont_&f) {push(f); return hsz(s);}
	void	eo (char*s,int x,int y, ivfont_&f){push(f);TextOut(hdc, x, y, s, 1);}
	void	ho (char*s,int x,int y, ivfont_&f){push(f);TextOut(hdc, x, y, s, 2);}
public:
	char* SStext	 (char* s);  //    superscript text
	char* NONSStext(char* s);  // nonsuperscript text
	int		ngapim	 (char* s);  // num of gapim, which is two superscriptmark
	SIZE	yvsubsz	 (char* s,ivfont_&ef,ivfont_&hf, int bSStext=0);
	SIZE	SSsz		 (char* s,ivfont_&ef,ivfont_&hf){return yvsubsz(s,ef,hf,1);}
	SIZE	NONSSsz	 (char* s,ivfont_&ef,ivfont_&hf){return yvsubsz(s,ef,hf,0);}
public:
	SIZE	yvsz(						 char* s, ivfont_&ef,ivfont_&hf, ivfont_&efu,ivfont_&hfu,char qiqen,int gapim);
	int		yvw (						 char* s, ivfont_&ef,ivfont_&hf, ivfont_&efu,ivfont_&hfu,char qiqen,int gapim);
	int		yvo (int x,int y,char* s, ivfont_&ef,ivfont_&hf, ivfont_&efu,ivfont_&hfu,char qiqen,int gapim);
public:
	static void 	set1D(int ubiau);
	void	setdiaupoints(point_* pt, int * npt,int diau, int xb,int yb,int xe,int ye,int lw);
	void	drawdiau(int x,int dx,int base,char c,char diau,
								int selected,char qiqen, int height);
public:
	void  move2(int x, int y) { MoveToEx(hdc, x, y, NULL); }
	void	line2(int x, int y) { LineTo  (hdc, x, y      ); }
};


class  imzet1_ {
public:imzet1_(){clear();}
	void clear(){s=g=q=p=r=d=hasd=0;im[0]=0;}
	int  len()  {return s+g+q+p+r+d; }
	int  cumu() { hasd=d; int ns=s; g+=s; q+=g; p+=q; r+=p; d+=r; s-=ns;g-=ns;q-=ns;p-=ns;r-=ns;d-=ns;return 1;}
	int  imzet1to6parts(char* im1);
	int  checkset4unvor_m (char* imsub);
	int  checkset4unvor_ng(char* imsub);
	int  isgood () { hasd=d; return (imsz==len()); }
	int  isin(char c, char* in){while(*in)if(c==*in++)return 1;return 0;}
	//int  isin(char c, char* in){return str_isin(c,in);} //while(*in)if(c==*in++)return 1;return 0;}
	int  is_aeiou(char c){static char s[]="aeiou";return isin(c,s);}
	char*to4ivdraw( int nn_ben, int d_move, char qiqen);
	char*to5gaidiau( char d, char qiqen);
	void nrhtransform(char* t ); // transform t when \n\r\h;
	int  idqtransform(char* im, chars& iwork, char qiqen, int kauqidiau, int diaugi, int supn);
	int  vdqtransform(char* im, chars& iwork); // transform im to vwork;
private:
	int  s, g, q, p, r, d, hasd;//siann, gaiim, quanim, pinn,rip,diau, hasdiau
	char im[20]; int imsz; // remember the im1 to im
};






struct	ivetc_ 	{
public:	ivetc_	():qq('d')
									,kdiau(1)
									,diaugi(1)
									,gitimes(0.1)
									,ivgaptimes(0.2)
									,sugaptimes(0.5)
									,jbox(0 )
									,jbln(-1)
									,jblnhd(-1)
								{	}
	char 		qq; 		// qiqen;
	char		kdiau; 	// kauqi diau
	char		diaugi;	// diaygi
	double	gitimes;// gapim times wrt heightS(), def2 0.1
	int 		jbox, jbln, jblnhd;//justification 4 box,bline,and blineheaad:-1/0/1
	ivfont_	efu, efs, efl, hfu, hfs, hfl;//upper/small/large fonts, English/Hanri
	double	ivgaptimes; 	// wrt heightS, def2 0.2
	double  sugaptimes;   // wrt heightS, def2 0.5
	//
	int			sfheight, lfheight;
	//double 	heighttimes; // def2 1.8
public:
	void	setfset  (int ithset,int ithefn=0, int ithhfn=0);
	int		heightL	 (				){return hfl.height();}
	int		heightS	 (				){return hfs.height();}
	int		heightU	 (				){return hfu.height();}
public:
	int		gapim		 (				){return heightS()*gitimes; 			}
	int		ivgap		 (				){return heightS()*ivgaptimes;		}
	int		sugap		 (				){return heightS()*sugaptimes;		}
	int		etop2htop(				){return heightS()*(1+ivgaptimes);}
	int		boxheight(				){return etop2htop()+heightU(); 	}
};

class 	ivbase {
public:	ivbase(int ithfset=10){setfset(ithfset);}
// the following calling sequence should be used:
// set various att's of etc, such as qiqen, gapim, setfset(),
//													 by calling ivbase.etc....(...)
// setHDC()  : right before at actual use of yvo(...)
// settmdc() : before using yvsz, yvw,
//						 note: if(!tmdc()) setHDC() will call settmdc(todc())
public: 		ivetc_ etc;
						ivhdc_ tmdc, todc;	// textmet and textout dc
						imzet1_ iz;
	void	setfset  (int ithset,int ithefn=0, int ithhfn=0);
	void  settmdc  (HDC hdc	);
	void  deltmdc  (				);
	void  setHDC   (HDC hdc1);
	int		try2tmdc (				);//try to create tmdc from todc if !tmdc()
public:
	SIZE	yvysz (						 	char* s);
	int		yvyw  (						 	char* s);
	int		yvyo  (int x,int y, char* s);
	SIZE	yvvsz (						 	char* s);
	int		yvvw  (						 	char* s);
	int		yvvo  (int x,int y, char* s);
public:
	SIZE	yvysz (						 	char* s, HDC hdc){setHDC(hdc);return yvysz(    s);}
	int		yvyw  (						 	char* s, HDC hdc){setHDC(hdc);return yvyw (    s);}
	int		yvyo  (int x,int y, char* s, HDC hdc){setHDC(hdc);return yvyo (x,y,s);}
	SIZE	yvvsz (						 	char* s, HDC hdc){setHDC(hdc);return yvvsz(    s);}
	int		yvvw  (						 	char* s, HDC hdc){setHDC(hdc);return yvvw (    s);}
	int		yvvo  (int x,int y, char* s, HDC hdc){setHDC(hdc);return yvvo (x,y,s);}
public:
	char*	yimtr (char*im ); // danyim transform
	char*	vuntr (char*vun); // danvun transform
};

class 	ivbox: public ivbase {
public:	ivbox(){}
public:
	SIZE	yvbsz(						 char* yim, char*vun);
	int		yvbw (						 char* yim, char*vun);
	int		yvbo (int x,int y, char* yim, char*vun);
public:
	SIZE	yvbsz(						 char* yim, char*vun, HDC hdc){setHDC(hdc);return yvbsz(    yim,vun);}
	int		yvbw (						 char* yim, char*vun, HDC hdc){setHDC(hdc);return yvbw (    yim,vun);}
	int		yvbo (int x,int y, char* yim, char*vun, HDC hdc){setHDC(hdc);return yvbo (x,y,yim,vun);}
};


class		ivboxline: public ivbox {
public:	ivboxline(){}
public:
	SIZE	yvlnsz(						 char* yim, char*vun);
	int		yvlnw (						 char* yim, char*vun);
	int		yvlno (int x,int y,char* yim, char*vun);
public:
	SIZE	yvlnsz(						 char* yim, char*vun, HDC hdc){setHDC(hdc);return yvlnsz(    yim,vun);}
	int		yvlnw (						 char* yim, char*vun, HDC hdc){setHDC(hdc);return yvlnw (    yim,vun);}
	int		yvlno (int x,int y,char* yim, char*vun, HDC hdc){setHDC(hdc);return yvlno (x,y,yim,vun);}
private:
	int		set2Nhun(char *yim, char *vun);
	char*	nthy(int n);
	char* nthv(int n);
	charspp sppy, sppv; int nITEMS;
	static char nullstr[4];
};









#endif //#ifndef IVHDC_H


