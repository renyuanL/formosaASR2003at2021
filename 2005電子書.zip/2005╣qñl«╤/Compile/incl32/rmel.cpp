//
// file rmel.cpp
// IZGang 2001-10-9
//

#ifndef RMEL_CPP
#define RMEL_CPP

#include <rmel.h>


int realmel_::allc4FRMSZ(int newFRMSZ)
{
	if(newFRMSZ<=allcFRMSZ) {
		lastFRMSZ=newFRMSZ; lastNRFFT=next2pow(lastFRMSZ);
		initham(lastFRMSZ);
		initbins(); initdct();
		return 1;
	}
	del4FRMSZ();
	allcFRMSZ=lastFRMSZ=newFRMSZ;	allcNRFFT=lastNRFFT=next2pow(allcFRMSZ);
	ham			=new float[lastFRMSZ]; 		if(!ham) 				return del4FRMSZ(0);
	xdef		=new float[lastNRFFT]; 		if(!xdef) 			return del4FRMSZ(0);
	fftndx2bin=new int[lastNRFFT/2]; 	if(!fftndx2bin) return del4FRMSZ(0);
	binwt		=new float[lastNRFFT/2]; 	if(!binwt) 			return del4FRMSZ(0);
	initham(lastFRMSZ);
	initbins(); initdct();
	return 1;
}

int realmel_::allc4NCEPS(int newNCEPS, int newNBINS)
{
	if(newNCEPS<=0) return 0;
	if(newNBINS<=0) newNBINS=2*newNCEPS;
	if(newNCEPS<=allcNCEPS) {
		if(newNBINS<=allcNBINS){
			if( (newNCEPS!=lastNCEPS)||(newNBINS!=lastNBINS) ){
				initbins(); initdct();
			}
			return 1;
		}
	}
	del4NCEPS();
	allcNCEPS=lastNCEPS=newNCEPS;	allcNBINS=lastNBINS=newNBINS;
	bins		=new float[lastNBINS]; 		if(!bins)				return del4NCEPS(0);
	cfs			=new float[lastNBINS+1];	if(!cfs) 				return del4NCEPS(0);
	resdef	=new float[lastNCEPS+1]; 	if(!resdef) 		return del4NCEPS(0);
	if(!dctmat.init2(lastNCEPS, lastNBINS)) return del4NCEPS(0);
	initbins();
	initdct();
	return 1;
}


int realmel_::del4FRMSZ(int retval)
{
	if(ham				){delete[]ham; 				ham 			=0;}
	if(xdef				){delete[]xdef;				xdef			=0;}
	if(fftndx2bin	){delete[]fftndx2bin;	fftndx2bin=0;}
	if(binwt			){delete[]binwt;			binwt			=0;}
	lastFRMSZ=lastNRFFT=allcFRMSZ=allcNRFFT=0;
	return retval;
};


int realmel_::del4NCEPS(int retval)
{
	if(bins	 		){delete[]bins;				bins			=0;}
	if(resdef		){delete[]resdef;			resdef		=0;}
	if(cfs	 		){delete[]cfs;				cfs				=0;}
	lastNBINS=lastNCEPS=allcNBINS=allcNCEPS=0;
	return retval;
};




void realmel_::
initbins()
{
	if(lastNBINS<=0) return;
	if(lastNRFFT<=0) return;
	int M=lastNBINS+1; int m,n,bin;
	// find locut hicut
	locut=2; hicut=lastNRFFT/2;
	if(lopass>=0.0) {
		locut=int(lopass/(float)smprate*lastNRFFT/2+0.5);
		if(locut<2) locut=2;
	}
	if(hipass>=0.0) {
		hicut=int(hipass/(float)smprate*lastNRFFT/2+0.5);
		if(hicut>lastNRFFT/2) hicut=lastNRFFT/2;
	}
	// find cfs
	float ms=mel(lastNRFFT/2);
	for(m=0; m<M; m++) cfs[m]=float((m+1.0)/M*ms);
	// find fftndx2bins
	memset(fftndx2bin,0,sizeof(int)*lastNRFFT/2);
	for(n=1, bin=0; n<lastNRFFT/2; n++) {
		float mel4n=mel(n);
		while(cfs[bin]<mel4n) bin++;
		fftndx2bin[n]=bin;
	}
	// find binwt
	static int junkbinwt=0;
	memset(binwt,0,sizeof(float)*lastNRFFT/2);
	for(n=0; n<lastNRFFT/2; n++) {
		int b=fftndx2bin[n];
		if(n<locut-1||n>=hicut) {binwt[n]=0;continue;}
		if(b>0) binwt[n]=(cfs[b]-mel(n))/(cfs[b]-cfs[b-1]);
		else    binwt[n]=(cfs[0]-mel(n))/(cfs[0]);
		junkbinwt++;
	}
}

float realmel_::
mel(int kth)
{
	//float f1d700=(float)((float)smprate/(lastNRFFT)/700.0);
	float f1d700=(float)(10000000./(((int)(10000000./smprate))*lastNRFFT*700.));
	//up: make it closer to HTK's training data
	return (float)(1127 * log(1 + (kth)*f1d700));
}

void realmel_::
mel2bins(float* x, float* bins1, int takinglog)
{ //too much globals
	float t1,t2, ek; int bin;
	memset(bins1, 0, sizeof(float)*lastNBINS); // clear bins
	for(int n=locut-1; n<hicut; n++) { 		// fill bins: compute mel spec
		t1=x[2*n]; t2=x[2*n+1];
		ek=float(sqrt(t1*t1+t2*t2));
		t1=binwt[n]*ek;
		bin=fftndx2bin[n];
		if(bin>0) bins1[bin-1] += t1;
		if(bin<lastNBINS) bins1[bin] += ek-t1;
	}
	if(takinglog) {	// taking log for computing MELBANK
		for(bin=0; bin<lastNBINS; bin++) {
			t1=	bins1[bin]; if(t1<MELFLOOR) t1=MELFLOOR;
			bins1[bin]=float(log(t1));
		}
	}
}

void realmel_::
initdct()
{
	if(lastNBINS<=0) return;
	if(lastNCEPS<=0) return;
	double dctconst=sqrt(2.0/(float)lastNBINS);
	for(int n=0; n<lastNCEPS; n++)
		for(int b=0; b<lastNBINS; b++)
		dctmat(n,b) =cos(pi*(n+1)/(float)lastNBINS*(b+0.5))*dctconst;
	//dctmat[n][b]=cos(pi*(n+1)/(float)lastNBINS*(b+0.5))*dctconst;
}



void realmel_::
init_cepwin(int cepLiftering)
{
	if(cepLiftering<=0) return;
	cepwinlen=cepLiftering; int i;
	float a=(float)(pi/cepwinlen); float lift2=(float)(cepwinlen/2.0);
	for(i=0;i<NMAXFEATURES;i++)cepwin[i]=float(1.0+lift2*sin((i+1)*a));
}

void realmel_::
weightcep (float* c, int start, int count, int cepLiftering)
{
	if (cepwinlen != cepLiftering) init_cepwin(cepLiftering);
	int j = start;
	for (int i=0;i<count;i++)	c[j++] *= cepwin[i];
}

void realmel_::
dopreem(float* obs, int nobs)
{
	for(int i=nobs-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] *=float(1.0-preem);
}

void realmel_::
dopreem(float* obs, float prevvalue)
{
	for(int i=lastFRMSZ-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] -=prevvalue*preem;
}

void realmel_::
initham(int nFRMSZ)
{
	float dt=float(twopi/(nFRMSZ-1));
	for(int i=0; i<nFRMSZ; i++) ham[i]=float(0.54-0.46*cos(dt*i));
}

void realmel_::
doham(float*obs, int nobs)
{
	if(nobs!=lastFRMSZ)
		initham(nobs);
	float*o=obs, *h=ham;
	for(register int i=0; i<nobs; i++)
		*o++ *= *h++;
}

float realmel_::
totaleng	(short* x, int N)
{
	float te=0;
	for(int n=0;n<N;n++)te+=x[n]*x[n];
		return log(te);
}

float realmel_::
mfcceng()
{
	float te=0;
	float root2ovN=float(sqrt(2.0/lastNBINS));
	for(int i=0;i<lastNBINS;i++) te+=bins[i];
	return float(te*root2ovN*engscale);
}


float* realmel_::
realmel(short* shobs, int nsho, float* res, int melkind)
{
	int i,j,n;
	if(res==0) res=resdef;
	if(nsho!=lastFRMSZ){
		if(!allc4FRMSZ(nsho)) return res;
	}
	float* x=xdef;
	for(i=0; i<lastFRMSZ; i++) x[i]=shobs[i];
	//float te=totaleng();
	dopreem(x, lastFRMSZ);
	doham(x, lastFRMSZ);
	if((lastNRFFT-lastFRMSZ)>0)
		memset(x+lastFRMSZ, 0, (lastNRFFT-lastFRMSZ)*sizeof(float));//zero-padding
	rcfft.rfft0(x, lastNRFFT);
	//rcfft.rfft(x-1, NRFFT/2); // real fft, -1:since 1-based
	x[1]=0; // [1] is the freq content for pi

	int takinglog=(melkind!=MELSPEC);
	mel2bins(x, bins, takinglog);
	//compute MELSPEC if takinglog==0, compute MELBANK if takinglog==1

	if(melkind!=MFCC) {										// result 4 MELSPEC or MELBANK
		for(n=0; n<lastNCEPS;n++) res[i]=bins[i];
	}else{																// result 4 MFCC
		//res[lastNCEPS]=(mfcceng());
		res[lastNCEPS]=(totaleng(shobs, lastFRMSZ));
		for(n=0; n<lastNCEPS; n++){					// for computing MFCC (use dct)
			//double* w=&(dctmat[n][0]), cum=0.0;
			double* w=dctmat.row(n), cum=0.0;
			for(j=0;j<lastNBINS;j++) cum+= bins[j]*w[j];
			res[n]=float(cum);
		}
		if(cepLift>0) weightcep(res,0,lastNCEPS,cepLift);
	}
	return res;
}



void	wav2mcep::
init16k()
{
	wfrmsz=320;//20ms
	wsftsz=160;
	fssize=39;
}

int			wav2mcep::
wav2fea	(qiimbuf_& qb, feabuf_& fb)
{
	fb.clear(); if(qb.nshused<wfrmsz) return 0;
	int nsmpl=(qb.nshused-wfrmsz)/wsftsz+1;
	if(!fb.init2nsamples(nsmpl, fssize)) return 0; // return 0 if init2 not succeed
	for(int n=0; n<nsmpl; n++){
		wav2fea1(qb.sh+n*wsftsz, wfrmsz, fb[n]);
	}
	fb.hh.totSamp=nsmpl;
	normalizelogenergy(fb, rmel.engscale);
	doDmel(fb);
	doAmel(fb);
  //fb.nftused=nsmpl*fb.nftpersamp;
  fb.setTTCC();
	return nsmpl;
}

int			wav2mcep::normalizelogenergy(feabuf_& fb, float escale)
{
	int n, N=fb.nsamples();
	float max=0, *ft;
	for(n=0;n<N;n++) if(max<fb[n][12]) max=fb[n][12];
	for(n=0;n<N;n++) fb[n][12]=(fb[n][12]-max)*escale+1.0;
	return N;
}

int			wav2mcep::doDmel		(feabuf_& fb)//D: delta mel
{
	int n, N=fb.nsamples();
	float* ft=fb.ft; float fdenom=2*(1*1+2*2);
	int k,K=13, n1set=39; float ff; float *ll,*l,*c0,*r,*rr;

		n=0;
		ll=ft+n1set*(n-2);l=ft+n1set*(n-1);c0=ft+n1set*n; r=ft+n1set*(n+1);rr=ft+n1set*(n+2);
		ll=c0; l=c0;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
		n=1;
		ll=ft+n1set*(n-2);l=ft+n1set*(n-1);c0=ft+n1set*n; r=ft+n1set*(n+1);rr=ft+n1set*(n+2);
		ll=l;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
	for(n=2;n<N-2;n++){
		ll=ft+n1set*(n-2);l=ft+n1set*(n-1);c0=ft+n1set*n; r=ft+n1set*(n+1);rr=ft+n1set*(n+2);
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
	}
		n=N-2;
		ll=ft+n1set*(n-2);l=ft+n1set*(n-1);c0=ft+n1set*n; r=ft+n1set*(n+1);rr=ft+n1set*(n+2);
		rr=r;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
		n=N-1;
		ll=ft+n1set*(n-2);l=ft+n1set*(n-1);c0=ft+n1set*n; r=ft+n1set*(n+1);rr=ft+n1set*(n+2);
		r=c0;rr=c0;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
		return N;
}

int			wav2mcep::doAmel		(feabuf_& fb)//A: acceleration mel
{
	int n, N=fb.nsamples();
	float* ft=fb.ft; // +13: so that doing accel
	float fdenom=2*(1*1+2*2);
	int k,K=13, n1set=39; float ff; float *ll,*l,*c0,*r,*rr;

		n=0;
		ll=ft+n1set*(n-2)+K;l=ft+n1set*(n-1)+K;c0=ft+n1set*n+K; r=ft+n1set*(n+1)+K;rr=ft+n1set*(n+2)+K;
		ll=c0; l=c0;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
		n=1;
		ll=ft+n1set*(n-2)+K;l=ft+n1set*(n-1)+K;c0=ft+n1set*n+K; r=ft+n1set*(n+1)+K;rr=ft+n1set*(n+2)+K;
		ll=l;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
	for(n=2;n<N-2;n++){
		ll=ft+n1set*(n-2)+K;l=ft+n1set*(n-1)+K;c0=ft+n1set*n+K; r=ft+n1set*(n+1)+K;rr=ft+n1set*(n+2)+K;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
	}
		n=N-2;
		ll=ft+n1set*(n-2)+K;l=ft+n1set*(n-1)+K;c0=ft+n1set*n+K; r=ft+n1set*(n+1)+K;rr=ft+n1set*(n+2)+K;
		rr=r;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
		n=N-1;
		ll=ft+n1set*(n-2)+K;l=ft+n1set*(n-1)+K;c0=ft+n1set*n+K; r=ft+n1set*(n+1)+K;rr=ft+n1set*(n+2)+K;
		r=c0;rr=c0;
		for(k=0;k<K;k++){ff=(r[k]-l[k]);ff+=2*(rr[k]-ll[k]);c0[k+13]=ff/fdenom;}
		return N;
}

#endif //#ifndef RMEL_CPP

