
// alt2std.h

#ifndef ALT2STD_H
#define ALT2STD_H

#define NULL 0

struct charstar2 { char*s1; char* s2; charstar2(char*t1,char*t2):s1(t1),s2(t2){}};
charstar2 dqalt_bfinds  (char*alts, char sep=' ', int* len2complete=NULL);
charstar2 hqalt_bfinds  (char*alts, char sep=' ', int* len2complete=NULL);
charstar2 alt2std_bfinds(char*alts, char sep=' ', int* len2complete=NULL, char qiqen='d');
charstar2 alt2std				(char*alts, char sep=' ', char qiqen='d');
// example: charstar2 t2=alt2std(logyim); // logyims will be sep-ed by ' '
// s1 : standardized str, remember copying before use
// s2 : alts str, but separated by sep, remember copying before use

#endif //#ifndef ALT2STD_H
