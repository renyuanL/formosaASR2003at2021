//
// vwin.h
//

#ifndef VWIN_H
#define VWIN_H

#include <windows.h>
//#include <voids.h>
//#include <chars.h>
#include <di5base.h>

#define LM_USED 1

LRESULT CALLBACK WndProc4vwin(HWND hwnd,UINT imsg,WPARAM wpar,LPARAM lpar);
extern HINSTANCE vwinhinst; 


struct event {
		  event(){}
		  event(HWND hwnd,UINT imsg,WPARAM wpar,LPARAM lpar)
				    :  h(hwnd),  i(imsg),    w(wpar),    l(lpar){}
public:
  int				x() { return (short)LOWORD(l);	} // for mouse position
  int				y() { return (short)HIWORD(l);	} // for mouse position
  int			llo() { return (short)LOWORD(l);	}
  int			lhi() { return (short)HIWORD(l);	}
	WPARAM	key() { return w;									}
	char		ch () { return (char)w;						}
public:
  LRESULT todefault(){return DefWindowProc(h,i,w,l); }
public:
  HWND   h;
  UINT   i;
  WPARAM w;
  LPARAM l;
};


/*
struct point_ :public POINT {	void set2(int x1, int y1) { x=x1; y=y1; }
	point_(							 ){set2( 0,0 ); }
	point_(int x1, int y1){set2(x1,y1); }
	int operator ==(point_ r) { return ((x==r.x)&&(y==r.y))?1:0; }
};
// point_ move to di5base.h
*/

struct rect_ :public RECT {
	rect_(												) { setltrb(0,0,0,0); }
	rect_(int l,int t,int r,int b	) { setltrb(l,t,r,b); }
	int  toregular(){ int t,r=0;if(left>right){t=left;left=right;right=t;r=1;}
										if(top>bottom){t=top;top=bottom;bottom=t;r=1;}return r;}
	void getclient(event& evn){GetClientRect(evn.h,this);};
	void getclient(HWND  hwnd){GetClientRect(hwnd ,this);};
	RECT*operator	()() { return (RECT*)this; }
	long& x0(){ return left;  }
	long& y1(){ return bottom;}
	long& x1(){ return right; }
	long& y0(){ return top;   }
	int  dx(){ return x1()-x0();}
	int  dy(){ return y0()-y1();}
	void setdx	(int dx) { right=left+dx; }
	void setdy	(int dy) { bottom=top+dy; }
	void setdxdy(int dx, int dy) { setdx(dx); setdy(dy); }
	void setdxdy(POINT pt) { setdx(pt.x); setdy(pt.y); }
	void setlt(int left1,	 int top1   ) { left=left1; top=top1; }
	void setrb(int right1, int bottom1) { right=right1;bottom=bottom1; }
	void setlt(POINT pt)	{ setlt(pt.x, pt.y); }
	void setrb(POINT pt)	{ setrb(pt.x, pt.y); }
	void setltrb(int l, int t, int r, int b){ left=l; top=t; right=r;bottom=b;}
	void hshift(int dx) { left+=dx; right+=dx; }
	void rshift(int dy) { top+=dy; bottom+=dy; }
	void operator = (RECT& r ){left=r.left;top=r.top;right=r.right;bottom=r.bottom;}
	void operator +=(POINT pt){left+=pt.x;right+=pt.x;top+=pt.y;bottom+=pt.y;}
	void operator ++(				){right++;bottom++;}
	void operator --(				){right--;bottom--;toregular();}
	void   shrinkby(int  n){left+=n;top+=n;right-=n;bottom-=n;toregular();}
	void  xshrinkby(int  n){left+=n;			 right-=n;				  toregular();}
	void  yshrinkby(int  n){				top+=n;				  bottom-=n;toregular();}
	void dxshrinkby(int  n){right-=n;	toregular();}
	void dyshrinkby(int  n){bottom-=n;toregular();}
	void    shiftby(int  n){left+=n;top+=n;right+=n;bottom+=n;}
	void   xshiftby(int  n){left+=n;			 right+=n;					}
	void   yshiftby(int  n){				top+=n;				  bottom+=n;}
};

struct cPAINTER {
  HDC  dc;
  PAINTSTRUCT ps;
  HWND h;
  HDC  begin(event evn){ return begin(evn.h); }
  HDC  begin(HWND hwnd){ h=hwnd;return dc=BeginPaint(h, &ps); }
  void end() { EndPaint(h, &ps); }
  HDC  hdc() { return dc; }
  HDC  operator()() { return dc; }
};

struct cHDC {
  HDC h;
  HDC operator()() { return h; }
  HDC operator=(HDC hdc) { return h=hdc; }
  cHDC(HDC hdc) { h=hdc; }
};


struct WNDCLASSEX4vwin : public WNDCLASSEX {	chars clsname;
WNDCLASSEX4vwin(): registed(0), inited(0) { } int registed; int inited;
  void registerex( HINSTANCE hinst=vwinhinst, WNDPROC wproc=WndProc4vwin)
  { 
		if(registed) return; 
		if(!inited) initregister(); 
		hInstance=hinst; lpfnWndProc=wproc; lpszClassName=clsname.s; 
		registed=RegisterClassEx(this); 
		//registed=1; 
	}
  void initregister() { inited=1; // set this flag if no call to this func
		cbSize=sizeof(WNDCLASSEX);
		//style=CS_IME|CS_HREDRAW|CS_VREDRAW,//CS_HREDRAW|CS_VREDRAW;
		style=CS_HREDRAW|CS_VREDRAW,//CS_HREDRAW|CS_VREDRAW;
    cbClsExtra=0;
		cbWndExtra=0;
    hIcon=LoadIcon(NULL,IDI_APPLICATION);
    hCursor=LoadCursor(NULL,IDC_ARROW);
		hInstance=0;
    hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
		lpszMenuName=NULL;
		hIconSm=LoadIcon(NULL,IDI_APPLICATION);
  }
};



class vwin  { public: HWND hwnd; HWND prevfocus;
	static WNDCLASSEX4vwin wcls; chars classname; chars capname;
	int x,y, dx,dy; int childid, exstyle, style;
public:
	vwin(char* clsname1=0, char*capname1=0);//set def args for create
public:
	void	precreate0(){x=y=0; dx=dy=100; childid=0;
											style=WS_POPUP|WS_BORDER;
											exstyle=WS_EX_TOPMOST|CS_HREDRAW|CS_VREDRAW;
	}
	virtual	void	precreate   ()	 { }//called before create
	int		create(HWND parent=NULL);//set various val's in precreate();
public:
  void	show(int iCmdShow=SW_SHOWNORMAL, int update2=1) { ShowWindow(hwnd,iCmdShow); if(update2)update();}
	void	hide() { show(SW_HIDE); }
  void	update		() { 
												UpdateWindow(hwnd); }
	void	invalid		() { 
												InvalidateRect(hwnd,NULL,TRUE); }
	void	repaint		() { invalid(); update(); }
  void	move(int x0,int y0,int dx1,int dy1,int repaint){ x=x0;y=y0;dx=dx1;dy=dy1;MoveWindow(hwnd,x,y,dx,dy,repaint); }
	void	move(rect_ &r, int REPNT=true){x=r.left;y=r.top;dx=r.dx();dy=r.dy();MoveWindow(hwnd, r.left,r.top,r.dx(),r.dy(),REPNT);}
public:
	RECT	rect		 (    ) { static RECT r;GetWindowRect(hwnd,&r);return r;}
	int		postquit (int res=0) { PostQuitMessage(0); return LM_USED; }
	void  setxydxdy(int x1,int y1,int dx1,int dy1){x=x1;y=y1;dx=dx1;dy=dy1;}
public:
	virtual int		oncreate		(event &evn) { return !LM_USED; }
	virtual int		onsize			(event &evn) { return !LM_USED; }
	virtual int		onkeydown		(event &evn) { return !LM_USED; }
	virtual int		onchar			(event &evn) { return !LM_USED; }
	virtual int		onsetfocus	(event &evn) { return !LM_USED; }
	virtual int		onoutfocus	(event &evn) { return !LM_USED; }
	virtual int		onmouseld		(event &evn) { return !LM_USED; }
	virtual int		onmouserd		(event &evn) { return !LM_USED; }
	virtual int		onmouselu		(event &evn) { return !LM_USED; }
	virtual int		onmouseru		(event &evn) { return !LM_USED; }
	virtual int		onmousemv		(event &evn) { return !LM_USED; }
	virtual int		onmousedc		(event &evn) { return !LM_USED; }
	virtual int		ondestroy		(event &evn) { PostQuitMessage(0);return !LM_USED; }
public:
	virtual int		onpaint			(event &evn,cPAINTER &pntr){return !LM_USED;}
	virtual int		oncommand		(event &evn) { return !LM_USED; }
	virtual int		onothers		(event &evn) { return !LM_USED; }
public:
	int						main(HINSTANCE hinst,HINSTANCE pi,PSTR cl,int ishow);
};

struct cMSG : public MSG {
void loop() { while (GetMessage(this, NULL, 0,0)){
     TranslateMessage(this); DispatchMessage (this);} }
};

// a macro for WinMain, example usage:
// WINMAIN(ivdraw, "ivdrawclassname");
// where ivdraw is a class instance derived from vwin, and "ivdrawclassname" is the class name

#define WINMAIN_(x)				\
int WINAPI WinMain(HINSTANCE hinst,HINSTANCE pi,PSTR cl,int ishow) \
{	return x.main(hinst, pi, cl,ishow); }


#ifdef EXAMPLE_USAGE
static vwin vw;
WINMAIN_(vw);
#endif //#ifdef EXAMPLE_USAGE


#define WINMAIN1_(x, classname)				\
int WINAPI WinMain(HINSTANCE hinst,HINSTANCE pi,PSTR cl,int ishow) \
{																			\
  static char app[]=classname;				\
	x.wcls.clsname=classname;						\
  x.wcls.registerex(hinst);						\
  x.create();													\
	x.show(SW_SHOWNORMAL);							\
	x.update();													\
	cMSG cmsg;													\
	cmsg.loop();												\
  return cmsg.wParam;									\
}

//	x.precreate();										






struct hwndNvwin { HWND h; vwin* w; hwndNvwin(){}hwndNvwin(HWND h1,vwin*w1){h=h1;w=w1;}};

class thepair_ :public voids<hwndNvwin>{public:thepair_(){lastvwin=0;}
																										vwin* lastvwin;
vwin* getvwin(HWND hwnd) { for(int i=0;i<size();i++)if(hwnd==a[i].h)return a[i].w;return NULL;}
void  app(HWND hwnd, vwin*w1){voids<hwndNvwin>::app(hwndNvwin(hwnd,w1));w1->hwnd=hwnd;}
void  app(HWND hwnd) {if(lastvwin) {app(hwnd,lastvwin);lastvwin=0;} }
};
extern thepair_ thepair;




class wdebug0_ : public vwin { public: rect_ therect; HWND hwndedit;
	wdebug0_(char* cls, char* cap):vwin(cls,cap) {}
	void	precreate() {	childid=0; exstyle=WS_EX_TOPMOST|CS_HREDRAW|CS_VREDRAW; style=WS_OVERLAPPEDWINDOW;}//WS_POPUP|WS_VISIBLE|WS_BORDER //|WS_DISABLED
	int		create(HWND hwndprnt) { return vwin::create(	hwndprnt );}
	int		oncreate  (event& evn);
	int		onsize	  (event& evn);
	int		clear();
	int		app		(char* m1, char* m2=NULL, char* m3=NULL, char* m4=NULL);
	int		appln	(char* m1, char* m2=NULL, char* m3=NULL, char* m4=NULL)
							{ app(m1,m2,m3,m4); app("\r\n"); return 1;}
	int nlines();
};
extern wdebug0_ wdebug0;


#endif //#ifndef VWIN_H

