//
// file di5rand.h
//

#ifndef DI5RAND_H
#define DI5RAND_H

#include<stdlib.h>
#include<math.h>
#include<vector>
using namespace std;
//#define pi (3.1415926525)

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
class unif_{public:virtual float operator()()=0;};

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
class congru_: public unif_{
	float operator()(){ return float(_lrand())/float(LRAND_MAX);}
};

extern congru_ congru;

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
class  uuni_ : public unif_{
public:uuni_(int i1=12, int j1=34, int k1=56, int l1=78)
	  {init (    i1,        j1,        k1,        l1);}// 1~168, not all 1
	float operator()(); // return a unif(0,1) RN
	void init(int i1, int j1, int k1, int l1);
private:
	float U[97]; float C, CD, CM;
	int I, J;
};
extern uuni_ uuni;
void uuni_re_init(int i1, int j1, int k1, int l1);

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
//the scale parameter always use the form of /beta (dev by beta) in the pdf
class rn_ {
public:
	double	BM		(unif_& unif=uuni);
	double	expo	(unif_& unif=uuni){return -log(unif());}
	double	laplace	(unif_& unif=uuni);
	double lognormal(unif_& unif=uuni){return exp(normal(unif));}
	double	normal	(unif_& unif=uuni){return BM(unif);	}
	float	uni		(unif_& unif=uuni){return unif();	}
public:
	double	expo	(			 double theta,	unif_& unif=uuni){return -theta*log(unif());}
public:
	double	beta	(double alfa,double beta,	unif_& unif=uuni);
	double	gamma	(double alfa,double beta,	unif_& unif=uuni){return stdgamma(alfa,unif)*beta;}
public:
	double	BM		(double mu,  double sigma, 	unif_& unif=uuni){return BM(unif)*sigma+mu;	}
	double	cauchy	(double alfa,double theta,	unif_& unif=uuni){return alfa-theta/tan(3.1415926535*unif());}
	double	weibull	(double alfa,double beta,	unif_& unif=uuni){return beta*pow(expo(unif),1.0/alfa);}
	double	laplace	(double alfa,double theta,	unif_& unif=uuni){return laplace(unif)*theta+alfa;}
	double lognormal(double mu,  double sigma, 	unif_& unif=uuni){return exp(normal(mu,sigma,unif));}
	double	normal	(double mu,  double sigma, 	unif_& unif=uuni){return BM(mu,sigma,unif);	}
	float	uni		(double a,   double b, 		unif_& unif=uuni){return unif()*(b-a)+a;	}
	double	gammaL1	(double alfa,	unif_& unif=uuni);
	double	gammaG1	(double alfa,	unif_& unif=uuni);
	double	stdgamma(double alfa,	unif_& unif=uuni){if(alfa==1.0)return expo(unif);return(alfa<1.0)?gammaL1(alfa,unif):gammaG1(alfa,unif);}
};
extern rn_ rn;

struct spcn_{//sequential pdf cdf ndx
	double pdf, cdf; int ndx;
	void set2(double p1, double c1, int n1){pdf=p1;cdf=c1;ndx=n1;}
};


template<class  spcf_> //* pcn: do not change into &,so that pcn can be re-used
int		inverse_transform(spcf_& spcf, spcn_ pcn, double y, int frombegin=1)
{
	if(frombegin)
		spcf.init(pcn);
	while(1){
		if(y<=pcn.cdf) return pcn.ndx;
		spcf.next(pcn);
	}
}
inline	int		bs_cdfndx(vector<double>& v, double y)
{
	unsigned int lo,hi,mid;
	lo=0, hi=v.size(); if(hi<=1) return 0;
	--hi;
	if(y< v[lo]) return 0;
	if(y>=v[hi]) return hi;//sdbe checked beforehand, but return hi anyway
	mid=(lo+hi)/2;
	while(mid!=lo){
		if(y<v[mid])hi=mid;
		else 		lo=mid;
		mid=(lo+hi)/2;
	}
	return hi;
}


template<class spcf_>
class	tabsit_ { public:
		tabsit_(spcf_& spcf1, int TABSZ, int CDFSZ):spcf(spcf1){init(TABSZ,CDFSZ);}
public:
	int		operator()(unif_& unif=uuni);
public:
	int		init(int TABSZ, int CDFSZ);
protected:
	spcf_ 		   &spcf;
	vector<int> 	tab;
	vector<double>	rmdr;
	double			tabprob;
	double			trprob;//
	spcn_			pcn;
	//* pcn: serve 2 purposes:
	//* 1. arg to iterate 4 init
	//* 2. start pcn 4 it()(thus:make a copy in it(), or as a value-copy arg).
protected:
	clear(){tab.clear();rmdr.clear();pcn.set2(0,0,0);tabprob=trprob=0;}
	int		init0();
};

template<class  spcf_>
int		tabsit_<spcf_>::	operator()(unif_& unif)
{
	double u=unif();
	//try fast table lookup
	int ndx=tab[(unsigned int)(u*tab.size())];
	if(ndx>=0) return ndx;
	//try log(N) bs
	if(u<=trprob)
		return bs_cdfndx(rmdr,u-tabprob);
	//try slowest and cdbe-infinite-range it
	int frombegin=0;
	return inverse_transform(spcf, pcn, u, frombegin);
}

template<class  spcf_>
int		tabsit_<spcf_>::	init(int TABSZ, int CDFSZ)
{
	clear();
	if(TABSZ<1||CDFSZ<1) return 0;
	tab .resize (TABSZ,-1); rmdr.reserve(CDFSZ);
	spcf.init(pcn);
	rmdr.push_back(pcn.pdf);
	int n=0; double cp, cpprev=0;
	for(n=1; n<CDFSZ; n++){
		cp=spcf.next(pcn);
		if(cp!=1.0||cp!=cpprev){
			rmdr.push_back(pcn.pdf);
			cpprev=pcn.cdf;
		}
		else
			break;
	}
	trprob=cpprev;//pcn.cdf;
	return init0();
}

template<class  spcf_>
int		tabsit_<spcf_>::	init0()
{
	int tabndx=0;int TABSZ=int(tab.size());
	unsigned int n,N=rmdr.size();
	//fill up table, and adjust prob.'s in rmdr
	for(n=0; n<N; n++){
		int 	imul=rmdr[n]*TABSZ;
		for(int nn=0;nn<imul; ++nn){
			tab[tabndx++]=n;
		}
		double prob=double(imul)/TABSZ;
		rmdr[n] -=prob;
	}
	tabprob=double(tabndx)/TABSZ;
	//find the cdf in rmdr to enable binsearch
	for(n=1; n<N; ++n)
		rmdr[n]+=rmdr[n-1];
	return tabndx;
}




/*
template<class  spcf_>
int		tabsit_<spcf_>::	operator()()
{
	typedef unsigned int uint;
	double u=uuni();
	//try fast table lookup
	int ndx=tab[uint(u*tab.size())];
	if(ndx>=0) return ndx;
	//try log(N) bs
	if(u<trprob)
		ndxbs(rmdr,u-tabprob);
	//try slowest and cdbe-infinite-range it
	return it(spcf, pcn, u);
}
template<class  spcf_>
int		tabsit_<spcf_>::	ndxbs(vector<double>& v, double y)
{
	uint lo=0, hi=v.size(); if(hi<=1) return 0;
	--hi;
	if(y< v[lo]) return 0;
	if(y>=v[hi]) return hi;//sdbe checked beforehand, but return hi anyway
	uint mid=(lo+hi)/2;
	while(mid!=lo){
		if(y<v[mid])hi=mid;
		else 		lo=mid;
		mid=(lo+hi)/2;
	}
	return hi;
}

template<class  spcf_>
int		tabsit_<spcf_>::	it(spcf_& spcf, spcn_ pcn, double y)
{
	while(1){
		if(y<=pcn.cdf) return pcn.ndx;
		spcf.next(pcn);
	}
}
*/
//#undef pi



class 	spcf_binomial{public:
		spcf_binomial(int n1=12,double p1=0.5){n=n1;p=p1;}
	double	init(spcn_& pcn){double t=pow(1-p,n);pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					if(ndx<n)
						{pdf=pdf*(n-ndx)*p/((ndx+1)*(1-p)); cdf+=pdf;  ndx++;}
					else
						{pdf=0;cdf=1;ndx=n+1;}
					return cdf;
				}
public:
	int		n;
	double	p;
};

//typedef tabsit_<spcf_binomial	> tabbinomial;
//typedef tabsit_<spcf_poisson 	> tabpoisson;
//typedef tabsit_<spcf_negbinomial> tabnegbinomial;
//typedef tabsit_<spcf_geometric	> tabgeometric;

class 	spcf_poisson{public:
		spcf_poisson(double lamda1=1){lamda=lamda1;}
	double	init(spcn_& pcn){double t=exp(-lamda);pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					{pdf=pdf*lamda/(ndx+1); cdf+=pdf;  ndx++;}
					return cdf;
				}
public:
	double	lamda;
};

class 	spcf_geometric{public:
		spcf_geometric(double p1=0.5){p=p1;}
	double	init(spcn_& pcn){double t=p;pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					{pdf=pdf*(1-p); cdf+=pdf;  ndx++;}
					return cdf;
				}
public:
	double	p;
};

class 	spcf_negbinomial{public:
		spcf_negbinomial(int r1=1,double p1=0.5){r=r1;p=p1;}
	double	init(spcn_& pcn){double t=pow(p,r);pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					{pdf=pdf*(1-p)*(r+ndx)/(ndx+1); cdf+=pdf;  ndx++;}
					return cdf;
				}
public:
	int		r;
	double	p;
};

class 	it3bino {
public:	it3bino (int n, double p, int TABSZ=256, int CDFSZ=32)
				:spcf(n,p),rn(spcf, TABSZ,CDFSZ){}
public:
	double operator()(unif_&unif=uuni){return rn(unif);}
public:
	spcf_binomial spcf;
	tabsit_<spcf_binomial> rn;
};

class 	it3pois {
public:	it3pois (double lamda, int TABSZ=256, int CDFSZ=32)
				:spcf(lamda),rn(spcf, TABSZ,CDFSZ){}
public:
	double operator()(unif_&unif=uuni){return rn(unif);}
public:
	spcf_poisson spcf;
	tabsit_<spcf_poisson> rn;
};

class 	it3geom {
public:	it3geom (double p, int TABSZ=256, int CDFSZ=32)
				:spcf(p),rn(spcf, TABSZ,CDFSZ){}
public:
	double operator()(unif_&unif=uuni){return rn(unif);}
public:
	spcf_geometric spcf;
	tabsit_<spcf_geometric> rn;
};

class 	it3nbin {
public:	it3nbin (int r, double p, int TABSZ=256, int CDFSZ=32)
				:spcf(r,p),rn(spcf, TABSZ,CDFSZ){}
public:
	double operator()(unif_&unif=uuni){return rn(unif);}
public:
	spcf_negbinomial spcf;
	tabsit_<spcf_negbinomial> rn;
};


#endif //#ifndef DI5RAND_H


