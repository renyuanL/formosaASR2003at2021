//
// ivhdc.cpp
//
// for imvun draw 9/22/2k IZGang
//

#ifndef IVHDC_CPP
#define IVHDC_CPP
#include <ivhdc.h>
#include <di5base.h>
#include <math.h>


static int fontsizeU[]={ 6, 6, 8, 8, 8, 9, 9,10,10,12,12,12,13,14,16,18,20,24,40,48, 60 };
static int fontsizeS[]={ 8, 8,10,10,10,11,12,12,12,14,16,16,18,20,24,28,32,40,60,72, 96 };
static int fontsizeL[]={ 8,10,10,11,12,12,12,13,14,16,16,18,20,24,28,32,36,48,72,96,128 };
static char *hfontnames[]={
	"�s�ө���"
	,"�з���"
	,"�ө���"
};

static char *efontnames[]={
	"Times New Roman"
	,"Arial"
	,"Courier New"
};

char *fontBiauKaiTe="�з���";
char *fontSinSeVingTe="�s�ө���";
char *fontSeVingTe="�ө���";

void  ivfont_::create	(int height, char* fontname)
{
	destroy();
	f=CreateFont(		 height,0,0,0,FW_NORMAL,
									 FALSE,FALSE,FALSE,
									 //CHINESEBIG5_CHARSET,
									 DEFAULT_CHARSET,
									 OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
									 DEFAULT_QUALITY,FF_DONTCARE,
									 fontname
							);
	hite=height;
}

void 	ivetc_::setfset(int ithset, int ithefn, int ithhfn)
{
	int twipscale=1440/72;
	icslimit(ithset, 0, sizeof( fontsizeL)/sizeof(int)  -1);
	icslimit(ithefn, 0, sizeof(efontnames)/sizeof(char*)-1);
	icslimit(ithhfn, 0, sizeof(hfontnames)/sizeof(char*)-1);
	char* efn1=efontnames[ithefn];
	char* hfn1=hfontnames[ithhfn];
	efu.create(fontsizeU[ithset]*twipscale, efn1);
	efs.create(fontsizeS[ithset]*twipscale, efn1);
	efl.create(fontsizeL[ithset]*twipscale, efn1);
	hfu.create(fontsizeU[ithset]*twipscale, hfn1);
	hfs.create(fontsizeS[ithset]*twipscale, hfn1);
	hfl.create(fontsizeL[ithset]*twipscale, hfn1);
}


void	ivbase::setfset  (int ithset,int ithefn, int ithhfn)
{etc.setfset(ithset,ithefn, ithhfn);}

void  ivbase::settmdc  (HDC hdc	)
{tmdc.setHDC(CreateCompatibleDC(hdc));}

void  ivbase::deltmdc  (				)
{ if(tmdc())tmdc.del(); }

void  ivbase::setHDC   (HDC hdc1)
{ if(!tmdc()) settmdc(hdc1); todc.setHDC(hdc1); }

int		ivbase::try2tmdc (				)//try to create tmdc from todc if !tmdc()
{
	if(tmdc()) return 1;
	if(!tmdc()) if(todc()) {settmdc(todc()); return 1;}
	return 0;
}

char* 	ivbase::yimtr (char*im)
{
	static chars cs; cs=im;
	iz.idqtransform(im,cs,etc.qq,etc.kdiau,etc.diaugi,1);
	//iz.idqtransform(im,cs,qiqen(),diauhing(),1);
	return cs.s;
}

char* 	ivbase::vuntr (char*vun)
{
	static chars cs; cs=vun;
	iz.nrhtransform(cs.s);
	return cs.s;
}

SIZE	ivbase::yvysz(						 char* s)
{ return tmdc.yvsz(		yimtr(s),etc.efs,etc.hfs,etc.efu,etc.hfu,etc.qq,etc.gapim());}

int		ivbase::yvyw (						 char* s)
{ return tmdc.yvw(		yimtr(s),etc.efs,etc.hfs,etc.efu,etc.hfu,etc.qq,etc.gapim());}

int		ivbase::yvyo (int x,int y, char* s)
{ return todc.yvo(x,y,yimtr(s),etc.efs,etc.hfs,etc.efu,etc.hfu,etc.qq,etc.gapim());}

SIZE	ivbase::yvvsz(						 char* s)
{ return tmdc.yvsz(		vuntr(s),etc.efl,etc.hfl,etc.efu,etc.hfu,etc.qq,etc.gapim());}

int		ivbase::yvvw (						 char* s)
{ return tmdc.yvw(		vuntr(s),etc.efl,etc.hfl,etc.efu,etc.hfu,etc.qq,etc.gapim());}

int		ivbase::yvvo (int x,int y, char* s)
{ return todc.yvo(x,y,vuntr(s),etc.efl,etc.hfl,etc.efu,etc.hfu,etc.qq,etc.gapim());}


SIZE	ivbox::yvbsz(						 char* yim, char*vun)
{
	static SIZE sz00;
	if(!try2tmdc()) return sz00; // cannot have tmdc, so do nothing
	SIZE szy, szv;
	szy=yvysz(yim); szv=yvvsz(vun);
	szv.cy+=etc.etop2htop();
	if(szv.cx<szy.cx) szv.cx=szy.cx;
	return szv;
}

int		ivbox::yvbw (						 char* yim, char*vun)
{
	SIZE sz=yvbsz(yim,vun);
	return sz.cx;
}

int		ivbox::yvbo (int x,int y, char* yim,char*vun)
{
	int w,wy,wv;
	if(etc.jbox<0) {
		wy =yvyo(x,y,yim);
		wv =yvvo(x,y+etc.etop2htop(), vun);
		w=(wy>wv)?wy:wv;
	}else{
		wy=yvyw(yim);
		wv=yvvw(vun);
		w=(wy>wv)?wy:wv;
		if(etc.jbox==0) {
			yvyo(x+(w-wy)/2, y, yim);
			yvvo(x+(w-wv)/2, y+etc.etop2htop(), vun);
		}else{
			yvyo(x+(w-wy), y, yim);
			yvvo(x+(w-wv), y+etc.etop2htop(), vun);
		}
	}
	return w;
}


char ivboxline::nullstr[4]="";

int		ivboxline::set2Nhun(char *yim, char *vun)
{
	int Ny,Nv;
  char c4sg=SGmark;
  if     (str_find1(yim, SGmark)>=0 || str_find1(vun, SGmark)>=0 ) c4sg=SGmark;
  else if(str_find1(yim, '='   )>=0 || str_find1(vun, '='   )>=0 ) c4sg='=';
  else c4sg=' ';
	Ny=(c4sg!=' ')?sppy.set2Ncut(yim,c4sg):sppy.set2Nhun(yim);
	Nv=(c4sg!=' ')?sppv.set2Ncut(vun,c4sg):sppv.set2Nhun(vun);
	//Ny=(str_find1(yim,'=')>=0)?sppy.set2Ncut(yim,'='):sppy.set2Nhun(yim);
	//Nv=(str_find1(vun,'=')>=0)?sppv.set2Ncut(vun,'='):sppv.set2Nhun(vun);
	//Ny=sppy.set2Ncut(yim,'=');
	//Nv=sppv.set2Ncut(vun,'=');
	nITEMS=(Ny>Nv)?Ny:Nv;
	return nITEMS;
}

char*	ivboxline::nthy(int n)
{
	if(n<sppy.size()) return sppy[n];
	return nullstr;
}

char* ivboxline::nthv(int n)
{
	if(n<sppv.size()) return sppv[n];
	return nullstr;
}


SIZE	ivboxline::yvlnsz(						 char* yim, char*vun)
{
	static SIZE sz00;
	if(!try2tmdc()) return sz00; // cannot have tmdc, so do nothing
	SIZE sz; int w=0;
	set2Nhun(yim,vun);
	int sugap=etc.sugap();
	sz.cy=etc.boxheight();
	for(int n=0; n<nITEMS; n++) {
		w+=yvbw(nthy(n),nthv(n));
		w+=sugap;
	}
	if(nITEMS>0) w-=sugap;
	sz.cx=w;
	return sz;
}

int		ivboxline::yvlnw (						 char* yim, char*vun)
{
	SIZE sz=yvlnsz(yim,vun);
	return sz.cx;
}

int		ivboxline::yvlno (int x,int y, char* yim,char*vun)
{
	int w=0; int sugap=etc.sugap();
	set2Nhun(yim,vun);
	for(int n=0; n<nITEMS; n++){
		w+=yvbo(x+w, y, nthy(n), nthv(n));
		w+=sugap;
	}
	if(nITEMS>0) w-=sugap;
	return w;
}




















void 	ivhdc_::set2twip	(HDC hdc1)
{
	if(!hdc1)return;
	SetBkMode(hdc, TRANSPARENT);
	SetMapMode(hdc, MM_ANISOTROPIC);
	SetWindowExtEx(hdc, 1440,1440,NULL); // always use logical "twip"
	SetViewportExtEx(hdc, GetDeviceCaps(hdc,LOGPIXELSX),
												GetDeviceCaps(hdc,LOGPIXELSY),NULL);
}

SIZE		ivhdc_::tsz(char* s, ivfont_& ef, ivfont_& hf, int len)
{
	if(len<0) len=strlen(s);
	int n012; char* t=s; int nx=0, ny=0; SIZE sz;
	while(*t&&(t-s)<len) {
		n012=is012(t);
		switch(n012) {
		case 2:
			push(hf);	GetTextExtentPoint32(hdc, t, n012, &sz);
			nx+=sz.cx; if(ny<sz.cy) ny=sz.cy; break;
		case 1:
		default:
			push(ef);	GetTextExtentPoint32(hdc, t, n012, &sz);
			nx+=sz.cx; if(ny<sz.cy) ny=sz.cy; break;
		}
		t+=n012;
	}
	sz.cx=nx; sz.cy=ny;
	popf();
	return sz;
}


void		ivhdc_::o(char* s, int x, int y, int len)
{
	if(len<0) len=strlen(s);
	TextOut(hdc, x, y, s, len);
}

int		ivhdc_::o(char* s, int x, int y, ivfont_& ef, ivfont_& hf, int len)
{
	if(len<0) len=strlen(s);
	int n012; char* t=s; int nx=x;
	while(*t&&(t-s)<len) {
		n012=is012(t);
		switch(n012) {
		case 2:
			push(hf);	ho(t,nx,y); nx+=hw(t); break;
		case 1:
		default:
			push(ef);	eo(t,nx,y); nx+=ew(t);break;
		}
		t+=n012;
	}
	popf();
	return nx;
}

int		ivhdc_::ngapim	 (char* t)  // num of gapim, which is two superscriptmark
{
	int n012; int n=0;
	while(*t) {
		n012=is012(t);
		if( (n012==1) ) {
			if( *t==SSmark ) {
				if(t[1]==SSmark) n++;	 t+=2; continue;
			}else if( *t==DHmark ) { t+=2; continue; }
		}
		t+=n012;
	}
	return n;
}

char* ivhdc_::SStext		(char* t)
{
	static chars s; s.clear();
	int n012;
	while(*t) {
		n012=is012(t);
		if( (n012==1) ) {
			if( *t==SSmark ) {
				if(t[1]==SSmark){s.app("");}else{ s.app(t+1,1);}
				//if(t[1]==SSmark){s.app(" ");}else{ s.app(t+1,1);}
				t+=2; continue;
			}else if( *t==DHmark ) { t+=2; continue; }
		}
		t+=n012;
	}
	return s.s;
}

char* ivhdc_::NONSStext(char* t)
{
	static chars s; s.clear();
	int n012;
	while(*t) {
		n012=is012(t);
		if( (n012==1) && ( (*t==SSmark)||(*t==DHmark) ) ) {
			t+=2; continue;
		}
		s.app(t,n012);
		t+=n012;
	}
	return s.s;
}

SIZE ivhdc_::	yvsubsz(char* s,ivfont_& ef,ivfont_& hf, int bSStext)
{
	SIZE sz; sz.cx=0; sz.cy=0;
	char *t; t=s; if(!t||!t[0]) return sz;
	if( (t[0])&&(t[0]=='(')&&(t[1])&&(t[1]==')') ) return sz;
	if(bSStext)	{t=   SStext(t); }
	else				{t=NONSStext(t); }
	sz=tsz(t,ef,hf);
	return sz;
}

SIZE	ivhdc_::
yvsz(char* s, ivfont_&ef,ivfont_&hf, ivfont_&efu,ivfont_&hfu,char qiqen,int gapim)
{
	SIZE sz, szu;
	int ngi=ngapim(s);
	sz=SSsz(s,efu,hfu); szu=NONSSsz(s,ef,hf); //gapim should be considered!!!!!!!!
	if(szu.cy>0) { sz.cy+= (szu.cy-sz.cy/8); }
	sz.cx+=szu.cx;
	sz.cx+=ngi*gapim;
	return sz;
}

int	ivhdc_::
yvw (char* s, ivfont_&ef,ivfont_&hf, ivfont_&efu,ivfont_&hfu,char qiqen,int gapim)
{
	SIZE sz;
	sz=yvsz(s,ef,hf, efu,hfu, qiqen, gapim);
	return sz.cx;
}

int	ivhdc_:: // return width
yvo (int x,int y,char* s, ivfont_& ef,ivfont_& hf, ivfont_& efu,ivfont_& hfu,char qiqen,int gapim)
{
	int hite=ef.height();
	int base =y+hite*1.35;
	int SSoff=  hite/8;
	char* t=s; int n012; int nx=x, dx=0;   SIZE sz;
	while(*t){
		n012=is012(t);
		if( (n012==1)&&( (*t==SSmark)||(*t==DHmark) ) ) {
			if((*t==SSmark)) {	t++;
				if(isdigit(*t)||(*t=='n')){
					push(efu);sz=esz(t);eo(t,nx, y-SSoff);
				} else {
					if(*t==SSmark)
						sz.cx=gapim;
						//if(etc->get_diauhing()<=1) sz.cx=etc->gapim;
				}
			} else {
				if(*t==DHmark){ t++; sz.cx=0;
					if(isdigit(*t)||(*t=='h')||(*t=='r'))
						drawdiau(nx-dx,dx*0.9,base,t[-2],t[0],0,qiqen,hite);
						//drawdiau(hdc, xi0, dx0, base, t[-2], t[0],selected, etc->qiqen);
				}
			}
		}else{
			if(n012==1) {push(ef);sz=esz(t);eo(t,nx, y);}
			else        {push(hf);sz=hsz(t);ho(t,nx, y);}
		}
		nx+=sz.cx;dx=sz.cx;//dx=sz.cx; dx0=dx; xi0=xi; xi+=dx;
		t+=n012;
	}
	popf();
	return nx-x;
}




static int daiqi	[]={	vorbiau,gorbenn,vorbiau,gegang ,gorgang, gorgau ,
												gorgang,vorbiau,gegang ,gorsing										};
static int kehqi	[]={	vorbiau,gorgang,gorsing,gebenn ,gorbenn, gorbenn,
												vorbiau,vorbiau,gegang ,vorbiau										};
static int miaulik[]={	vorbiau,gorsing,gorgang ,gorbenn, gebenn, gebenn ,
												vorbiau,vorbiau,gorbenn,vorbiau										};
//static int kehqi	[]={	vorbiau,gorgang,gorsing,gebenn ,gorbenn, gorbenn,
//												vorbiau,vorbiau,gegang ,vorbiau										};
//static int miaulik[]={	vorbiau,gorsing,gegang ,gorbenn,gegang,  gebenn ,
//												vorbiau,vorbiau,gorbenn,vorbiau										};
static int huaqi	[]={	gordiam,gorbenn,gorsing,gorgau ,gorgang, gordiam,
												vorbiau,gordit ,divor  ,vorbiau,vorbiau						};
//static int gauhue	[]={	vorbiau,vorbiau,gorgang,gorsing ,vorbiau, divor,
//                        vorbiau,gorbenn,gordit ,vorbiau,vorbiau						};

void ivhdc_::set1D(int ubiau)
{
	if(ubiau){
		daiqi[1]=gorbenn;		daiqi[2]=vorbiau;
		kehqi[4]=gorgang;		kehqi[5]=gorbenn; kehqi[7]=vorbiau;
		miaulik[2]=gorgang; miaulik[3]=gorbenn;	miaulik[8]=gorgang;
		huaqi[1]=gorbenn;

	} else {
		daiqi[1]=vorbiau;		daiqi[2]=gorbenn;
		kehqi[4]=vorbiau;		kehqi[5]=vorbiau; kehqi[7]=gorbenn;
		miaulik[3]=vorbiau;	miaulik[8]=vorbiau;
		huaqi[1]=vorbiau;
	}
}
/*
void ivhdc_::set1D(int ubiau)
{
	if(ubiau){
		daiqi[1]=gorbenn;		daiqi[2]=vorbiau;
		kehqi[4]=gorgang;		kehqi[5]=gorbenn; kehqi[7]=vorbiau;
		miaulik[3]=gorbenn;	miaulik[8]=gorgang;
		huaqi[1]=gorbenn;

	} else {
		daiqi[1]=vorbiau;		daiqi[2]=gorbenn;
		kehqi[4]=vorbiau;		kehqi[5]=vorbiau; kehqi[7]=gorbenn;
		miaulik[3]=vorbiau;	miaulik[8]=vorbiau;
		huaqi[1]=vorbiau;
	}
}
*/
void ivhdc_::
setdiaupoints(point_* pts,int *npt,int diau,int xb,int yb,int xe,int ye,int lw)
{
	*npt=0; int dx, dy; double dxx, dy1; int P,P_1,PP, i;
	double sinx;
	switch (diau) {
	case vorbiau:  return;
	case gorbenn:
	case gebenn:		ye=yb;
	case gorgang:
	case gorsing:
		pts[0].set2(xb, yb);    pts[1].set2(xe, ye);
		pts[3].set2(xb, yb+lw);	pts[2].set2(xe, ye+lw);
		pts[4].set2(xb, yb);
		*npt=5; return;
	case gordit:
		pts[0].set2(xb, yb);    pts[1].set2(xb+lw, yb);
		pts[3].set2(xb, ye);	pts[2].set2(xb+lw, ye);
		pts[4].set2(xb, yb);
		*npt=5; return;
	case gegang: P=10; // lenght of points must have at least 2*P+3
		dxx=(xe-xb)/3.0; dy1=ye-yb; PP=P*2+2; P_1=P-1;
		for(i=0; i<P; i++) {
			sinx=sin(i*3.1415926/4/P);
			sinx=sqrt(sinx)+0.2;
			pts[i		  ].set2(int(xb+dxx*i/(P_1)), int(yb+dy1*sinx)   );
			pts[PP-i-1].set2(int(xb+dxx*i/(P_1)), int(yb+dy1*sinx)+lw);
		}
		pts[P  ].set2(xe, ye);
		pts[P+1].set2(xe, ye+lw);
		pts[PP ].set2(xb,yb);
		*npt=PP+1; return;
	case gorgau: dx=xe-xb; dy=ye-yb; if(dy<2) dy=2;
		pts[0].set2(xb, yb+dy*2/5   ); pts[1].set2(xb+dx*2/5,ye);    pts[2].set2(xe, yb);
		pts[5].set2(xb, yb+dy*2/5+lw); pts[4].set2(xb+dx*2/5,ye+lw); pts[3].set2(xe, yb+lw);
		pts[6].set2(xb, yb+dy*2/5		);
		*npt=7; return;
	case divor:	dx=xe-xb; dy=ye-yb; if(dy<2) dy=2;
		pts[0].set2(xb, ye   ); pts[1].set2(xb+dx/2,yb);    pts[2].set2(xe, ye);
		pts[5].set2(xb, ye+lw); pts[4].set2(xb+dx/2,yb+lw); pts[3].set2(xe, ye+lw);
		pts[6].set2(xb, ye);
		*npt=7; return;
	}
}


void ivhdc_::
drawdiau( int x,int dx,int base, char c, char diau,
					int selected, char qiqen, int height)
{
	if(!( isdigit(diau)||(diau=='h')||(diau=='r')) ) return;
	int lnwid=height/20.0; if(lnwid<=0) lnwid=1;
	int xbeg, xend;
	//static POINT pnt[4];
	if(c=='i'){ xbeg=x+dx/12;dx=dx*10/12;	 	xend=xbeg+dx+1;}
	else 			{ xbeg=x+dx/6; dx=dx*4/6;  		xend=xbeg+dx+1;}
	//int y=int(base-etc->sfheight*1.2);
	int y=int(base-height*1.2);
	int dy;
	int dg=diau-'0';
	if((diau=='h')||(diau=='r')) dg=divor;	else
	switch(qiqen) {
		case 'd': dg=daiqi	[diau-'0'];break;
		case 'k': case 's': dg=kehqi	[diau-'0'];break;
		case 'v': case 'm': dg=miaulik[diau-'0'];break;
		case 'h': dg=huaqi	[diau-'0'];break;
		default : dg=daiqi	[diau-'0'];break;
	}
	HRGN hrgn; point_ pts[23]; int npts;
	HBRUSH hbrush; HPEN hpen;
	int lw=lnwid;//etc->lw;
	if( (c=='i') ) {
	if( (dg==gorbenn)||(dg==gorgang)||(dg==gorgau)||(dg==gorgau)||(dg==divor)||(dg==gordit) ) {
		//int ty=int( y - etc->sfheight*0.03);
		int ty=int( y - height*0.03);
		SaveDC(hdc);
		if(selected){SetROP2(hdc,R2_COPYPEN);}
		else				{SetROP2(hdc,R2_NOTMASKPEN);}
		pts[0].set2(xbeg, ty); pts[1].set2(xend,ty);
		pts[2].set2(xend,int(ty+lw*1.5)); pts[3].set2(xbeg,int(ty+lw*1.5));
		pts[4].set2(xbeg,ty);
		hrgn=CreatePolygonRgn((POINT*)pts, 5, ALTERNATE);
		hbrush=(HBRUSH)GetStockObject(BLACK_BRUSH);
		FillRgn(hdc, hrgn, hbrush);
		//Polygon(hdc,(POINT*)pts, npts);
		DeleteObject(hrgn);
		RestoreDC(hdc,-1);
	}
	}
	SaveDC(hdc);
	//if(selected) {SetROP2(hdc, R2_NOTMASKPEN);}
	if(selected) {SetROP2(hdc, R2_NOTCOPYPEN);}
	//else         {SetROP2(hdc, R2_XORPEN);}
	int xc, yc, b;  npts=0;
	switch (dg) {
	case vorbiau:
		break;
	case gorbenn:
		//y -= int(etc->sfheight*0.015); y--;
		y -= int(height*0.015); y--;
		//setdiaupoints(pts,&npts, gorbenn, xbeg,y, xend,y, etc->lw);
		setdiaupoints(pts,&npts, gorbenn, xbeg,y, xend,y, lw);
		break;
	case gegang:
		y =int(base-height*0.6);
		dy=int(height*0.08); if(dy<2) dy=2;
		setdiaupoints(pts,&npts, gegang, xbeg,y, xend,y+dy, lw);
		break;
	case gebenn:
		y =int(base-height*0.5);
		//dy=int(etc.sfheight*0.08); if(dy<2) dy=2;
		setdiaupoints(pts,&npts,gebenn, xbeg,y, xend,y, lw);
		break;
	case gorgang:
		dy=int(height*0.125); if(dy<2) dy=2;
		y-=dy/3;y-=2;
		setdiaupoints(pts,&npts, gorgang, xbeg,y, xend,y+dy, lw);
		break;
	case gorsing:
		dy =int(height*0.12); if(dy<2) dy=2;
		y -=dy*7/10;
		setdiaupoints(pts,&npts, gorsing, xbeg,y+dy, xend,y, lw);
		break;
	case gordit:
		dy =int(height*0.2); if(dy<2) dy=2;
		y -=dy*7/14;
		setdiaupoints(pts,&npts, gordit,(xbeg+xend-lw)/2,y+dy,
																		(xbeg+xend-lw)/2,y,		lw);
		break;
	case gorgau:
		dy=int(height*0.11); if(dy<2) dy=2;
		y-=dy/2;
		setdiaupoints(pts,&npts, gorgau, xbeg,y, xend,y+dy, lw);
		break;
	case divor:  //case 'h':  //case 'r':
		dy=int(height*0.12); if(dy<2) dy=2;
		y-=dy/2;
		setdiaupoints(pts,&npts, divor, xbeg,y, xend,y+dy, lw);
		break;
	case gordiam:
		y -= int(height*0.015); //if(dy<2) dy=2;
		xc=(xbeg+xend)/2;
		yc=y;
		//b=etc->lw*2/3;
		b=lw*2/3;
		if(!selected) { /*SaveDC(hdc);*/ SetROP2(hdc, R2_BLACK);}
		Pie(hdc, xc-b, yc-b, xc+b, yc+b, 0,0,0,0);
		//if(!selected) { RestoreDC(hdc,-1);}
		break;
	}
	RestoreDC(hdc,-1);
	if(npts>0) {
		hrgn=CreatePolygonRgn((POINT*)pts, npts, ALTERNATE);
		//hrgn=CreatePolygonRgn((POINT*)pts, npts, WINDING);
		COLORREF cl=GetTextColor(hdc);
		if(cl==0) {
			hbrush=(HBRUSH)GetStockObject(BLACK_BRUSH);
			hpen  =(HPEN	)GetStockObject(BLACK_PEN);
		}	else{
			//lb.lbColor=cl;hbrush=CreateBrushIndirect(&lb);
			hpen=CreatePen(PS_SOLID, 1, cl);
			hbrush=CreateSolidBrush(cl);
		}
		FillRgn(hdc, hrgn, hbrush);
		SaveDC(hdc);
		SelectObject(hdc,hpen);
		Polyline(hdc,pts, npts);
		//SelectObject(hdc,hbrush);
		//Polygon(hdc,pts, npts);
		RestoreDC(hdc,-1);
		if(cl) DeleteObject(hbrush);
		if(cl) DeleteObject(hpen);
		DeleteObject(hrgn);
	}
	//if(selected) {RestoreDC(hdc,-1);}
}

/*
int  imzet1_ ::isin(char c, char* in)
{
	return str_isin(c,in);
} //while(*in)if(c==*in++)return 1;return 0;}
*/
void  imzet1_ ::nrhtransform( char* t ) // transform t when \n\r\h;
{
	int n012;
	while(*t) {
		n012=is012(t);
		if( (n012==1)&&(*t=='\\') ){
			if((t[1]=='r')||(t[1]=='h')) *t=DHmark;
			else *t=SSmark;
		}
		t+=n012;
	}
}



char* imzet1_ :: to5gaidiau( char d, char qiqen)
{
	static chars ss; ss.clear();
	switch (qiqen) {
	case 'h':
		switch(d){
		case '1': ss.app(" 5 5");break;
		case '2': ss.app(" 1 5");break;
		case '3': ss.app(" 2 1 5");break;
		case '4': ss.app(" 5 1");break;
		case '5': ss.app(" 3 0");break;
		}break;
	case 'k':
		switch(d){
		case '1': ss.app(" 5 1");break;
		case '2': ss.app(" 2 4");break;
		case '3': ss.app(" 1 1");break;
		case '4': ss.app(" 5 5");break;
		case '5': ss.app(" 5 5");break;
		case '7': ss.app(" 3 3");break;
		case '8': ss.app(" 2 1");break;
		}break;
	case 'm':
		switch(d){
		case '1': ss.app(" 2 4");break;
		case '2': ss.app(" 3 1");break;
		case '3': ss.app(" 5 5");break;
		case '4': ss.app(" 3 1");break;
		case '5': ss.app(" 1 1");break;
		case '8': ss.app(" 5 5");break;
		}break;
	case 'd':  default:
		switch(d){
		case '1': ss.app(" 5 5");break;
		case '2': ss.app(" 3 3");break;
		case '3': ss.app(" 2 1");break;
		case '4': ss.app(" 5 1");break;
		case '5': ss.app(" 2 1 5");break;
		case '6': ss.app(" 5 4");break;
		case '7': ss.app(" 4 3");break;
		case '8': ss.app(" 2 1");break;
		case '9': ss.app(" 2 5");break;
		}
	}
	str_replace(ss.s, ' ', SSmark);
	return ss.s;
}

char* imzet1_ :: to4ivdraw( int nn_ben, int diauhing, char qiqen)
{
	static	chars ss; ss.clear();
	ss.app(im, s);
	int n;//=q;
	//ss.app(im+s+g, 1);
	if( (diauhing==1)&&(hasd==1) ){
		if(qiqen=='d'){ n=g+q;
			ss.app(im+s,1);
			ss.app(DHmark); ss.app(im+s+g+q+p+r, d);
			ss.app(im+s+1, n-1);
		}else{ n=q;
			ss.app(im+s, g+1);
			ss.app(DHmark); ss.app(im+s+g+q+p+r, d);
			ss.app(im+s+g+1, n-1);
		}
	}else
		ss.app(im+s, g+q);
//	if( (diauhing==1)&&(hasd==1) ){ss.app(DHmark); ss.app(im+s+g+q+p+r, d);}
//	ss.app(im+s+1, n-1);
	n=s+g+q;
	if( (nn_ben)&&(im[n]=='n')&&(im[n+1]=='n') )
		{ ss.app(SSmark); ss.app("n"); }
	else { ss.app(im+n,p); }
	n+= p;
	ss.app(im+n,r);
	n+= r;
	if( (diauhing==2)&&(hasd) ){ss.app(SSmark); ss.app(im+n,  1);	}
	if( (diauhing==3)&&(hasd) ){ss.app(to5gaidiau(*(im+n), qiqen));}
	nrhtransform(ss.s);
	strcpy(im, ss.s);
	return im;
}



int imzet1_ :: imzet1to6parts(char* im1)
{
	imsz=strlen(im1);
	if(imsz>12) return 0; // too long to be imzet1
	clear();
	strcpy(im, im1);
	static char siann[]="bpmvfdtlgkqzcsrh";
	char* t=im;
	if(*t=='m') { if(checkset4unvor_m (im)) return isgood(); }
	if(*t=='n') { if(checkset4unvor_ng(im)) return isgood(); }
	if(*t=='n') { if((t[1])&&(t[1]=='q')) { s=2; t+=2; } else {s=1;t+=1;} }
	if( isin(*t, siann) ) { s++; t++; }
	if( *t=='h' ) { s++; t++; }
	//for gaiyim and huaqi y/w
	switch(*t){
	case 'w': g=1; t++; break;
	case 'i':	if( (t[1]!='i')&&is_aeiou(t[1]) ) { g=1; t++; } break;
	case 'u':	if(is_aeiou(t[1])) { g=1; t++; } break;
	case 'y': if(t[1]=='u')
							if(is_aeiou(t[2])){g=2; t+=2;}
							else { g=1; t++; } // yu must be quanyim
						else { g=1; t++; }
						break;
	}
	//if( (*t=='y')||(*t=='w') ) { g=1; t++; }
	// now for unvor except the yu- case
	if(*t=='m') { if(checkset4unvor_m (t)) return isgood(); }
	if(*t=='n') { if(checkset4unvor_ng(t)) return isgood(); }
	int ll=0;
	//int ll=q;
	while(is_aeiou(t[ll])) ll++;
	if(t[ll]=='r') ll++;
	if(t[ll]=='r') ll++;
	else if(t[ll]=='\\') ll+=2; // for \h \r hat
	q=ll;
	t+=ll;
	// now for pinnvue
	if(*t=='m') p=1;  else
	if(*t=='n') {
		if((t[1])&&t[1]=='n') { p=2; } else
		if((t[1])&&t[1]=='g') { p=2; } else
		p=1;
	}
	t+=p;
	// now for rip-vue
	if( (r<=0)&&( (*t=='p')||(*t=='t')||(*t=='k')||(*t=='h') ) ){ r=1; t++; }
	// now for sianndiau
	if(isdigit(*t)) d=1;
	if((t[1])&& (isdigit(t[0])) )d++;
	hasd=d;
	return isgood();
}


int imzet1_::  // transform im to iwork;
idqtransform(char* im, chars& iwork, char qiqen, int kauqidiau, int diaugi, int supn)
{
	//imzet1_ iz1;
	int para=0;
	iwork.clear(); static charspp temp; static chars ss;
	if(im[0]=='(') { // considering cases like "(a1)"
		ss.set2(im+1);
		if(ss.lastbyte()==')') { para=1; ss.dellastbyte(); }
	}else ss.set2(im);
	temp.set2Nhunhanlor(ss.s); char* t;
	if(para){ iwork.app('('); }
	for(int n=0, NN=temp.size(); n<NN; n++) {
		t=temp[n];
		if( str_hashanri(t)||(*t=='-')||ispunct(*t) )
			{ iwork.app(t); continue; }
		//if( (etc->qiqen=='d')&&(etc->get_diauhing()==1) )
		if( (qiqen=='d')&&(kauqidiau) )//diauhing==1) )
			str_del2kauqidiau(t);
		else	str_del2danridiau(t);
		//if(!iz1.imzet1to6parts(t))
		if(!imzet1to6parts(t))
			{ iwork.app(t);continue;} //something wrong in im
		//iwork.app(iz1.to4ivdraw(etc->get_sn(),etc->get_diauhing(), etc->qiqen));
		iwork.app(to4ivdraw(supn,diaugi,qiqen));
		if(n<NN-1) { iwork.app(SSmark); iwork.app(SSmark);}//4 gapim
	}
	if(para){iwork.app(')');}
	return 1;
}


int imzet1_ :: checkset4unvor_m(char* imsub)
{
	char* t=imsub;
	if(*t=='m') {
		t++;
		if(t[0]&&(t[0]=='h')) { q=1; r=1; t++; }
		if( (t[0]) && (isdigit(t[0])) )
				{ q=1; d=1; if((t[1])&& (isdigit(t[0])) )d++; return 1; }
		if(q>0) return 1;
	}
	return 0;
}

int imzet1_ :: checkset4unvor_ng(char* imsub)
{
	char* t=imsub;
	if( (*t=='n')&&(t[1])&&(t[1]=='g') ){
		t++; t++;
		if(t[0]&&(t[0]=='h')) { q=2; r=1; t++; }
		if( (t[0])&&(isdigit(t[0])) )
				{ q=2; d=1; if((t[1])&& (isdigit(t[0])) )d++; return 1; }
		if(q>0) return 1;
	}
	return 0;
}





#endif //#ifndef IVHDC_CPP

