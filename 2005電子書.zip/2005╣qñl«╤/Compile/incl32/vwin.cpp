//
// vwin.cpp
//

#ifndef VWIN_CPP
#define VWIN_CPP

#include <vwin.h>
HINSTANCE vwinhinst; 
thepair_ thepair;
WNDCLASSEX4vwin vwin::wcls; // static member


#ifdef EXAMPLE_USAGE
static vwin vw;
WINMAIN_(vw);
#endif //#ifdef EXAMPLE_USAGE


int vwin::
main(HINSTANCE hinst,HINSTANCE pi,PSTR cl,int ishow)
{
	vwinhinst=hinst;
	wcls.clsname=classname.s;
  wcls.registerex(hinst);
  create();
	show(ishow);
	update();
	cMSG cmsg;
	cmsg.loop();
  return cmsg.wParam;
}

vwin::vwin(char* clsname1, char*capname1)
{
	prevfocus=0;
	classname=(clsname1)?clsname1:"VWIN";
	wcls.clsname=classname.s;
	capname=(capname1)?capname1:"VWIN";
	x=y=dx=dy=CW_USEDEFAULT;
	childid=0;
	exstyle=WS_EX_OVERLAPPEDWINDOW;
	style=WS_OVERLAPPEDWINDOW;
}

int vwin::
create(HWND parent)//, int childid, int exstyle,int style)
{
	if(!wcls.registed) wcls.registerex(vwinhinst);
	thepair.lastvwin=this;
	precreate();
  HWND hw=CreateWindowEx(  exstyle, wcls.clsname.s,	 capname.s,   style,
     x, y, dx, dy, parent,	 (HMENU)childid,	 vwinhinst, 	 NULL	);
	return (int)hw;
}


LRESULT CALLBACK WndProc4vwin(HWND hwnd,UINT imsg,WPARAM wpar,LPARAM lpar)
{
	event evn(hwnd,imsg,wpar,lpar); 
	vwin* w= thepair.getvwin(hwnd); 
	if(!w) { if(thepair.lastvwin) thepair.app(hwnd);
		w=thepair.getvwin(hwnd); 
	}
	if(!w) return evn.todefault();
  cPAINTER pntr; int res;
  switch (evn.i) {
  case WM_CREATE:	if(LM_USED==w->oncreate(evn))	return LM_USED; break;
  case WM_SIZE:		if(LM_USED==w->onsize	 (evn))	return LM_USED; break;
  case WM_PAINT:	pntr.begin(evn);
			res=w->onpaint(evn,pntr);
			pntr.end();				if(LM_USED==res)	return LM_USED; break;
	case WM_KEYDOWN:			if(LM_USED==w->onkeydown (evn))return LM_USED; break;
	case WM_CHAR:					if(LM_USED==w->onchar    (evn))return LM_USED; break;
	case WM_COMMAND:			if(LM_USED==w->oncommand (evn))return LM_USED; break;
	case WM_SETFOCUS:			if(LM_USED==w->onsetfocus(evn))return LM_USED; break;
	case WM_KILLFOCUS:		if(LM_USED==w->onoutfocus(evn))return LM_USED; break;
	case WM_LBUTTONDOWN:	if(LM_USED==w->onmouseld (evn))return LM_USED; break;
	case WM_RBUTTONDOWN:	if(LM_USED==w->onmouserd (evn))return LM_USED; break;
	case WM_LBUTTONUP  :	if(LM_USED==w->onmouselu (evn))return LM_USED; break;
	case WM_RBUTTONUP  :	if(LM_USED==w->onmouseru (evn))return LM_USED; break;
	case WM_MOUSEMOVE  :	if(LM_USED==w->onmousemv (evn))return LM_USED; break;
	case WM_LBUTTONDBLCLK:if(LM_USED==w->onmousedc (evn))return LM_USED; break;
	case WM_DESTROY:			if(LM_USED==w->ondestroy (evn))return LM_USED; break;
	default:							if(LM_USED==w->onothers  (evn))return LM_USED; break;
  }
  return evn.todefault();
}



wdebug0_ wdebug0("wdebug0", "wdebug0");

int wdebug0_::oncreate  (event& evn)
{
	int x0=600, y0=10, dx=400, dy=500;
	HINSTANCE hinst=((LPCREATESTRUCT)evn.l)->hInstance;
	CreateWindow("wdebug_",NULL,WS_POPUP|WS_VISIBLE|WS_BORDER,x0,y0,dx+10,dy+10,NULL,NULL,hinst,NULL);
	hwndedit=CreateWindow("edit",NULL,
		ES_MULTILINE|WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOVSCROLL,
		10,10,dx,dy,hwnd,NULL,hinst,NULL);
	move(x0,y0,dx+10,dy+10,1);
	show(SW_SHOWNOACTIVATE);
	return LM_USED;
}

int wdebug0_::onsize  (event& evn)
{
	MoveWindow(hwndedit,0,0,LOWORD(evn.l),HIWORD(evn.l),TRUE);
	return LM_USED;
}

int wdebug0_::nlines()
{
	return SendMessage(hwndedit, EM_GETLINECOUNT, 0, 0);
}

int wdebug0_::clear()
{
	char n[]="";SendMessage(hwndedit, WM_SETTEXT, 0, (LPARAM)n);
	return 1;
}

int wdebug0_::app(char* m1, char* m2, char* m3, char* m4)
{
	static chars s; if(m1)s=m1;if(m2)s+=m2;if(m3)s+=m3;if(m4)s+=m4;s+="\r\n";
	SendMessage(hwndedit, EM_REPLACESEL,0,(LPARAM)s.s); return 1;
}

#include <wdebug.h>

wdebug_ wdebug;
void wdebug_ ::show(int style){ wdebug0.show(style);}
void wdebug_ ::move  (int x0, int y0, int dx, int dy, int repaint){wdebug0.move(x0,y0,dx,dy,repaint);}
int  wdebug_ ::clear(){return wdebug0.clear();}
int  wdebug_ ::nlines(){return wdebug0.nlines();}
int  wdebug_ ::app(char* m1, char* m2, char* m3, char* m4)
{	if(!wdebug0.hwnd) return 0;	return wdebug0.app(m1,m2,m3,m4);}



#endif //#ifndef VWIN_CPP

