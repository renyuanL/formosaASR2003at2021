//
// file spiobcb.cpp
//

// IngZin Gang 2k

#ifndef SPIOBCB_CPP
#define SPIOBCB_CPP
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <spiobcb.h>
//---------------------------------------------------------------------------
//#pragma package(smart_init)

String TStatusTH::s;
String TRcgOutTH::s;
String TRcgOutRRTH::s;
String TDebugTH ::s;
chars thmsgmsg;

void spdbttn_up(TObject *Sender)
{
	if(Sender)((TSpeedButton*)Sender)->Down=false;
}



#ifndef boxes_CPP
#define boxes_CPP
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
//#include "boxes.h"
//#include <realfft.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//rcfft_ specbox_::fft;
GREYS greys;

int wavebox_:: p2wx(int px)
{// so that wave is trimmed to a 160shorts frame
	int res=p2lx(px); return (res+80)/160*160;
	//return int(p2lx(px));
}
int	wavebox_:: roundbeqiim(int nbqiim1, int neqiim1)
{
	int sz=nDQS_FSS; int t; float ft;
  if(!qiimbuf) return 0;
  float wx=qiimbuf->nsheqiim+qiimbuf->nshesil;
	if(nbqiim!=nbqiim1) {
		ft=p2lx(nbqiim1);
    t=ft*wx;
	  t=(t+sz/2+1)/sz*sz;
    qiimbuf->nshbsil=t;
		ft=float(t/wx);
    nbqiim=l2px(ft);
  }
  if(neqiim!=neqiim1) {
		ft=p2lx(neqiim1);
    t=ft*wx;
		t=(t+sz/2+1)/sz*sz;
    qiimbuf->nsheqiim=t;
    qiimbuf->nshesil=qiimbuf->nshused-t;
		ft=float(t/wx);
    neqiim=l2px(ft);
  }
  if(nbqiim>neqiim) {
  	t=nbqiim; nbqiim=neqiim; neqiim=t;
		t=qiimbuf->nshbsil;
    qiimbuf->nshbsil=qiimbuf->nsheqiim;
		qiimbuf->nsheqiim=t;
    qiimbuf->nshesil=qiimbuf->nshused-t;
  }
  return 1;
}
char*wavebox_ ::
qiimbufstatus()
{
  static chars s; s.clear(); s+=" ";
  //if(qiimbuf->nshbsil >0)
  s+=tos( double(qiimbuf->nshbsil)/16000., "%.3fsec + ");
  s+=tos( double(qiimbuf->nsheqiim -qiimbuf->nshbsil)/16000., "%.3fsec");
	//if(qiimbuf->nshesil >0)
  s+=tos( double(qiimbuf->nshesil)/16000., " + %.3fsec");
  if(s.s[0]) s +=" will be saved";
  s+=" (R:";
	if(deltalx>0)s+=tos(int((double(nDQS_FSS)/deltalx*getpdx())));s+="pts/frame)";
  return s.s;
}

void wavebox_ ::
plotmsg()
{
	char* s=qiimbufstatus();
  textoutlt( s );
}


void wavebox_ ::
plotwave( TPaintBox* pb, qiimbuf_* qiimbuf1, int skip)
{
	setPaintBox(pb);
	if( qiimbuf1 )  set2(qiimbuf1);
	if( (!qiimbuf) )return;
	//if( (!qiimbuf)||(qiimbuf->k<=0) )return;
	//spmsgStatus("  deh�e��...");
	//spthmsgOSTT("  deh�e��...");
	uedodone=0;
	//int dx=qiimbuf->k*nDQS_FSS;
	int dx=deltalx; if(dx<1) dx=qiimbuf->nsheqiim*2;
//try{
	setlscale(0., 32768., dx, 65537.  );
	dx=qiimbuf->nshused-1;
//}catch(Exception &exception){
//  MessageBox(NULL, "","something wrong in plotting wave: qiimbuf not valid",IDOK);
//}
	pushPenColor(clRed);
	pushPenMode(pmNotXor);
//try{
	move2( 0,  0           );  line2(dx,  0     );
	//move2( 0,  wds->endpt.fbthresh ); line2(dx,  wds->endpt.fbthresh);
	//move2( 0, -wds->endpt.fbthresh ); line2(dx, -wds->endpt.fbthresh);
	float x00=qiimbuf->nshbsil;
	move2(x00,32767.); line2(x00,-32767.);
	nbqiim=l2px(x00);
	float x11=(qiimbuf->nsheqiim);
	move2(x11,32767.); line2(x11,-32767.);
	neqiim=l2px(x11);
	float x22=(x11+qiimbuf->nshesil);
	move2(x22,32767.); line2(x22,-32767.);
//}catch(Exception &exception){
//  MessageBox(NULL, "","something wrong in plotting wave: frame",IDOK);
//}
	pop_PenMode();
	pop_PenColor();

	short* itr=qiimbuf->sh;
	int i;
//try{
		move2(0.0, float(*itr));
		//for( i=1; i<dx-3; i+=4, itr+=4) {
		for( i=1; i<dx-skip+1; i+=skip, itr+=skip) {
			line2(float(i),float(*itr));
		}
//}catch(Exception &exception){
//  MessageBox(NULL, "","something wrong in plotting wave",IDOK);
//}
	//plotmsg();
	//spmsgStatus("");
  //spthmsgOSTT(tos(i-1));
	uedodone=1;
}


int breakhere=0;
void specbox_::plotspec(TPaintBox* pb1,qiimbuf_* qbuf1)
{
	//Form1->mm4debug1_->Lines->Append(tos(breakhere++));
	setPaintBox(pb1);
	//setHDC(pb);
	if( (!qbuf1)||(qbuf1->nshused<=0) )return;
	specdone=0;
	qbuf=qbuf1;
	int x0=0, y0=0;
	int shiftsz=nFS/2;
	int cnt=qbuf->nshused/shiftsz-nFS/shiftsz+1;
	int kk;
	try{
		for(kk=0; kk<cnt; kk++) {
			//nthfsignal (fsig, kk);
			//MessageBox(NULL, tos(kk),"try",IDOK);
			//fft.sh2ft(fsig, qbuf->sh+kk*nFSS, nFS);
			//fft.rfft(fsig-1,nFS/2);
			ehfft.zor(qbuf->sh+kk*shiftsz, fsig,0);
			//fft.short2float(fsig, qbuf->sh+kk*nFSS, nFS);
			//fft.rfft(fsig,nFS);
			//breakhere+=100;
			//Form1->mm4debug1_->Lines->Append();
			for(int j=2; j<nFS/2;j+=2) {
				pputbdot(x0+(kk+1)*dotw, y0+doth*(nFS/2-j-1),
									greys(  int(abs(fsig[j])+abs(fsig[j+1]))/100.  )  );
									//nthcolor(  int(abs(fsig[j])+abs(fsig[j+1]))/100.  )  );
									//nthcolor(  (fsig[j]*fsig[j]+fsig[j+1]*fsig[j+1])/323767.*1.1)    );
			}
		}
	}catch(Exception &exception){
		MessageBox(NULL, tos(kk),"something wrong in plotting spec",IDOK);
	}
	specdone=1;
}

//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////

void specbox2_::setetc     (pairss* etc)
{
	char* t;
	t=etc->get("cetdi");  if(t&&t[0]) cetdi=s2i(t);
  t=etc->get("SpecScale");  if(t&&t[0]) scale=s2i(t);//10.0;
  t=etc->get("FrameSize");  if(t&&t[0]) FrameSize=s2i(t);
  t=etc->get("ShiftSize");  if(t&&t[0]) ShiftSize=s2i(t);
	t=etc->get("BC1");  if(t&&t[0]) BC1=s2i(t);
  t=etc->get("BC2");  if(t&&t[0]) BC2=s2i(t);
	t=etc->get("BC3");  if(t&&t[0]) BC3=s2i(t);
  t=etc->get("BC4");  if(t&&t[0]) BC4=s2i(t);
  t=etc->get("B12");  if(t&&t[0]) B12=s2i(t);
	t=etc->get("B23");  if(t&&t[0]) B23=s2i(t);
  t=etc->get("B34");  if(t&&t[0]) B34=s2i(t);
}

void specbox2_:: setscale  (float scale1)
{
	//if(FrameSize>0) scale=sqrt(scale1)/(FrameSize*128);else scale=1;
	//scale=(1.2);
	//spthmsgDBG(tos(scale1,"specscale %f"));Sleep(100);
	spmsg.debug(tos(scale1,"specscale %f"));Sleep(100);
	//spthmsgDBG(tos(scale,"specscale %f"));
}


COLORREF specbox2_::scaledcolor (int jth)
{
	float t=(fsig[jth]);
  //if(t>0) t=(sqrt(t));//(abs(fsig[jth])+abs(fsig[jth+1]))/100.;
  //if(t>0) t=(sqrt(t));//(abs(fsig[jth])+abs(fsig[jth+1]))/100.;
	//scale=1;
  if(scale<0.0) return int(t);  t/=scale;
  int k=cetdi;  t-=k;
  int cth=int(t); if(cth<0) cth=0; else { cth+=k; if(cth>255) cth=255; }
	if(!cth) return color4s[3][0];
  int ith;
  if(jth<B12) ith=BC1; else
  if(jth<B23) ith=BC2; else
  if(jth<B34) ith=BC3; else
	ith=BC4;
	if(ith<0) ith=0; if(ith>3) ith=3;
  return color4s[ith][cth];
}


void specbox2_::plotspec(TPaintBox* pb1,qiimbuf_* qbuf1)
{
	setPaintBox(pb1);
	if( (!qbuf1)||(qbuf1->nshused<=0) )return;
  specdone=0;
	qbuf=qbuf1;
	int x0=0, y0=0;
	int shiftsz=ShiftSize;
	int framesz=FrameSize;
	chars sss;  sss="spec ploting";
	sss+=framesz;sss+=" ";sss+=shiftsz;spmsg.debug(sss.s);
	int cnt=qbuf->nspec(framesz,shiftsz);
	int kk;
	try{
		for(kk=0; kk<cnt; kk++) {
			ehfs.ehfs(qbuf->sh+kk*shiftsz, framesz, fsig,1);
			for(int j=1; j<framesz/2;j++) {
				pputbdot(x0+(kk+1)*dotw, y0+doth*(framesz/2-j-1), scaledcolor(j) );
			}
		}
	}catch(Exception &exception){
		MessageBox(NULL, tos(kk),"something wrong in plotting spec",IDOK);
	}
	specdone=1;
}

#endif //#ifndef boxes_CPP





/*
void spmsgDebugBCB(TMemo*memo, char* msg)
{
	static chars s;if(strcmp(s.s,msg)==0)return;s=msg; new TDebugTH(memo, s.s);
	//new TDebugTH(memo, msg);
}

void spmsgRcgOutBCB(TMemo*memo, char* msg)
{
	static chars s;if(strcmp(s.s,msg)==0)return;s=msg; new TRcgOutTH(memo, s.s);
	//new TRcgOutTH(edit, msg);
}
*/

//************************************************************
// END of part 1: spmsgthreads ( of spmsgthreads and spthreads )
//************************************************************
//************************************************************
#endif //#ifndef SPIOBCB_CPP

