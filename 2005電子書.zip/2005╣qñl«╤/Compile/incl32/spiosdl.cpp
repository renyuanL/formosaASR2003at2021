
#include <spiosdl.h>

rchartf_ rchartf;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

//#include <di5mout.h>
/*
void	playbar_::clearbar(TRChart& rct)
{
	rct.RemoveItemsByClass(clsnum);
	rct.ShowGraf();
}

void	playbar_::update(TRChart& rct,TTimer& tmr,int playbeg, TColor clr)
{
	//uchar
	clsnum=120;//	TColor clr=clRed;
	rct.RemoveItemsByClass(clsnum);
	__int64 newpos=owt->position();
	uchar clsnumold=rct.ClassDefault;	rct.ClassDefault=clsnum;
	TColor   clrold=rct.DataColor;		rct.DataColor=clr;
	if(newpos==0&&playpos==0&&!owt->isplaying()){
		tmr.Enabled=false;
	}
	playpos=newpos;
	if(playpos>0){
		rct.Line(playpos+playbeg,-32300,playpos+playbeg,32300);
		//mout<<"update "<<int(playpos+playbeg)<<memo;
	}
	rct.ShowGraf();
	rct.ClassDefault=clsnumold;
	rct.DataColor=clrold;
}
*/

void	owdefplaybar_::clearbar(TRChart& rct)
{
	rct.RemoveItemsByClass(clsnum);
	rct.ShowGraf();
}

void	owdefplaybar_::update(TRChart& rct,TTimer& tmr,int playbeg, TColor clr)
{
	//uchar
	clsnum=120;//	TColor clr=clRed;
	rct.RemoveItemsByClass(clsnum);
	__int64 newpos=owdef.position();
	uchar clsnumold=rct.ClassDefault;	rct.ClassDefault=clsnum;
	TColor   clrold=rct.DataColor;		rct.DataColor=clr;
	if(newpos==0&&playpos==0&&!owdef.isplaying()){
		tmr.Enabled=false;
	}
	playpos=newpos;
	if(playpos>0){
		rct.Line(playpos+playbeg,-32300,playpos+playbeg,32300);
		//mout<<"update "<<int(playpos+playbeg)<<memo;
	}
	rct.ShowGraf();
	rct.ClassDefault=clsnumold;
	rct.DataColor=clrold;
}


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

static void test(TRChart& rct)
{
	vector<float> fv; ccsccw_ cc;
	rchartf.line(rct,fv,cc);
}


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

int qbmouse_::
ondown(TRChart&rct, qiimbuf_& qb, int capturemouse)
{
	if(qb.ssize()<=0) return 0;
	downed=1; hasbeenmoved=0;
	//if(capturemouse)rct.MouseCapture=true;// not aceessible, private
	int x=rct.MousePosX; begx=endx=x; qb.csbe(begx, endx);
	rchartf.hili(rct,qb,csw,begx,endx);
	rct.ShowGraf();
//	rct.ShowGrafNewOnly();
	return 0;
}

int qbmouse_::
onupup(TRChart&rct, qiimbuf_& qb)
{
	if(downed==0) return 0;
	downed=0;
	int x=rct.MousePosX; endx=x; qb.csbe(begx, endx);
	rchartf.hili(rct,qb,csw,begx,endx);
	rct.ShowGraf();
//	rct.ShowGrafNewOnly();
	return 0;
}


int qbmouse_::
onmove(TRChart&rct, qiimbuf_& qb)
{
	if(downed==0) return 0;
	int x=rct.MousePosX; endx=x;
	int beg=begx, end=endx; qb.csbe(beg, end);//so do not change begx
	if(end-beg>3) hasbeenmoved=1;
	rchartf.hili(rct,qb,csw,beg,end);
	rct.ShowGraf();
//	rct.ShowGrafNewOnly();
	return 0;
}



//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
/*
int wbarmouse_::
closestndx(TRChart&rct, vector<int>& v, int X, int Y, int delta)
{
	uint n,N=v.size(); int x,y;
	for(n=0;n<N;++n){
		rct.R2M(v[n],0, x,y);
		if(abs(x-X)<delta) return n;
	}
	return -1;
}

int wbarmouse_::
ondown(TRChart&rct, vector<int>&v, int X, int Y, int indexbeg, int maxamp1, int capturemouse)
{
	if(v.size()<=0) return 0;
	//if(capturemouse)rct.MouseCapture=true;// not aceessible, private
	nth=closestndx(rct,v,X,Y);
//	if(nth<0) return -1;
	downed=1; hasbeenmoved=0;
	int x=rct.MousePosX; endx=x; begx=v[nth];//qb.csbe(begx, endx);
	ndxbeg=indexbeg; maxamp=maxamp1;
//	rchartf.wavebar(rct,v,maxamp);	rct.ShowGraf();
	return nth;
}

int wbarmouse_::
onupup(TRChart&rct, vector<int>&v)
{
	if(downed==0) return 0;
	downed=0;
	int x=rct.MousePosX;
	v[nth]=x; endx=x;
	rchartf.wavebar(rct,v,ndxbeg,maxamp);	rct.ShowGraf();
	return nth;
}


int wbarmouse_::
onmove(TRChart&rct, vector<int>&v)
{
	if(downed==0) return 0;
	int x=rct.MousePosX;
	v[nth]=x; endx=x;
	if(abs(begx-endx)>3) hasbeenmoved=1;
	rchartf.wavebar(rct,v,ndxbeg,maxamp);	rct.ShowGraf();
	return 0;
}
*/
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////




//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

void rchartf_::csbe(int& b, int &e, int N)//* check/set 0<=b<=e<=N
{
  if(b<0) b=0; if(b>N) b=N;
  if(e<0) e=0; if(e>N) e=N;
  if(e<b) swap(b,e);
}
TRChart& rchartf_::hilims(TRChart& rct, qiimbuf_*p2qb, ccsccw_& csw, int beg, int end)
{
	if(p2qb)	return hilims(rct,*p2qb,csw,beg,end);
	return rct;
}

TRChart& rchartf_::hilims(TRChart& rct, qiimbuf_&  qb, ccsccw_& csw, int beg, int end)
{
  return hili(rct,qb,csw,qb.ms2nsh(beg),qb.ms2nsh(end));
}
TRChart& rchartf_::hili(TRChart& rct, qiimbuf_*p2qb, ccsccw_& csw, int beg, int end)
{
	if(p2qb)	return hili(rct,*p2qb,csw,beg,end);
	return rct;
}
TRChart& rchartf_::hili(TRChart& rct, qiimbuf_&  qb, ccsccw_& csw, int beg, int end)
{
	ccsccwlocal_ cwl(rct,csw);
	if(csw.ccn)
		rct.RemoveItemsByClass(csw.cno);
	qb.csbe(beg,end); if(end-beg<2) {rct.ShowGraf();return rct;}
	int maxy=32768;
	int n;
	n=end;    rct.Line(n,-maxy,n,maxy);
	n=beg;    rct.Line(n,-maxy,n,maxy);
	rct.MoveTo(n,qb[n]);
	for(int n=beg; n<end; n++){
	  rct.DrawTo(n,qb[n]);
	}
//	rct.ShowGraf();
//	rct.ShowGrafNewOnly();
	return rct;
//	return end-beg;
}
TRChart& rchartf_::hili	(TRChart& rct, qiimbuf_&  qb, ccsccw_& csw, int*bnds,uint noseg)
{
	int ccn=csw.ccn;
//	ccsccwlocal_ cwl(rct,csw);
	if(csw.ccn) rct.RemoveItemsByClass(csw.cno);
	csw.ccn=0; uint n;
	for(n=0; n<noseg; n+=2){
		hili(rct,qb,csw,bnds[n],bnds[n+1]);
	}
	csw.ccn=ccn;
	rct.ShowGrafNewOnly();
	return rct;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

TRChart& rchartf_::wave	(TRChart& rct, qiimbuf_*p2qb)
{
	if(p2qb)	return rchartf.wave(rct,*p2qb);
	return rct;
}

TRChart& rchartf_::wave(TRChart& rct, qiimbuf_* p2qb, ccsccw_& csw, int beg, int end, int YScale)
{
	if(csw.cgf) rct.ClearGraf();
	if(p2qb)	return wave(rct,*p2qb,csw,beg,end,YScale);
	return rct;
}

TRChart& rchartf_::csbeNcr	(TRChart& rct, qiimbuf_& qb, ccsccw_& csw, int &beg, int &end)//ret 1 if success, 0 if fail
{
	if(qb.size()<=0) return rct;
	if(csw.cgf)rct.ClearGraf();
	if(csw.ccn) {
		rct.RemoveItemsByClass(csw.cno);
	}
	qb.csbe(beg,end);
	int maxy=(csw.scaley())?qb.maxamp()*1.1: 32768;
	if(csw.scalex()){
		rct.SetRange(0-1,-maxy, end-beg, maxy);
		rct.MoveTo(0.0,0.0);
	}else if(csw.scaley()){
		rct.SetRange(beg-1,-maxy, end, maxy);
		rct.MoveTo(beg,0.0);
	}
	return rct;
}
TRChart& rchartf_::wave(TRChart& rct, qiimbuf_& qb, ccsccw_& csw, int beg, int end, int begtickas0)
{
	csbeNcr(rct,qb,csw,beg,end);
	ccsccwlocal_ cwl(rct,csw);
	int off=(begtickas0)?0:beg;
	int n,N;
	N=end-beg;
	for(n=0; n<N; n++)
		rct.DrawTo(double(n+off),double(qb[n+beg]));
	rct.Line(off,0.0,off+N,0.0);
	rct.ShowGraf();
	return rct;
}

/*
TRChart& bwave	(TRChart& rct, qiimbuf_&  qb, vector<int>& v){cswd.set4new();return bwave(rct,qb, v, cswd, -1,-1);}
TRChart& bwave	(TRChart& rct, qiimbuf_&  qb, vector<int>& v, ccsccw_& csw, int beg, int end, int begtickas0=1);//* -1 4 autoscale
TRChart& rchartf_::bwave	(TRChart& rct, qiimbuf_&  qb, vector<int>& v, ccsccw_& csw, int beg, int end, int begtickas0)//* -1 4 autoscale
{
	csbeNcr(rct,qb,csw,beg,end);
	ccsccwlocal_ cwl(rct,csw);
	int off=(begtickas0)?0:beg;
	int n,N;
	N=end-beg; short mm, MM=0;
	for(n=0; n<N; n++){
		mm=qb[n+beg];
		rct.DrawTo(n+off,mm);
		if(mm<0) mm=-mm; if(mm>MM)MM=mm;
	}
	rct.Line(off,0,off+N,0);
	rct.DataColor=clLime;
	N=(int)v.size();
	for(n=0;n<N;++n){
		rct.Line(v[n],-MM,v[n],MM);
	}
	rct.ShowGraf();
	return rct;
}
*/

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

template<class real> TRChart&
__plotspec__(TRChart& plt, vecvec<real>& mm, int qiimsz, int frmsz, int sftsz)
{
	int frm,cmp,FRM=mm.nfrm(),CMP=mm.ncmp();
	plt.ClearGraf();
//	how many cmps a pixel represent? if >1, must plot only the highest
	int pxlrngy=plt.Height-plt.BRim-plt.TRim;
//	int pxlcmp=1;
	int ncmp_perpxl=CMP/pxlrngy; int yxtr;
	if(ncmp_perpxl==0){//means pxlrngy is more than CMP
		ncmp_perpxl=1;yxtr=pxlrngy-CMP;
	}else{
		yxtr=0;
		if(ncmp_perpxl*pxlrngy!=CMP) yxtr=(double)(ncmp_perpxl+1)*pxlrngy-CMP;
	}

//	real vmax, vmin;	mm.getminmax(vmin,vmax);
	real vmax, vmin;	getminmax(vmin,vmax,mm);
	real vrng=quantile(mm,0.99);//=vmax-vmin;	if(vrng<0.0001) vrng=0.0001;
	chars cs;cs<<endl<<vrng<<endl;
	plt.SetRange(0,0,qiimsz,CMP+yxtr);
	TColor clr, clrd=plt.DataColor, clrf=plt.FillColor; int nlev;
	int offx=(frmsz-sftsz)/2;
	for(frm=0;frm<FRM;frm++){
		//	mm.getminmax(vmin,vmax,frm); vrng=vmax-vmin; if(vrng<0.0001)vrng=0.0001;
		for(cmp=0;cmp<CMP;cmp+=ncmp_perpxl){
			//find hight in a pixel
			real tt=mm.v(frm,cmp);
			for(int nn=1; nn<ncmp_perpxl; nn++)
				if(mm.v(frm,nn)>tt)tt=mm.v(frm,nn);
			//	scale tt
			tt=(tt-vmin)/vrng;
			if(tt>0.00001){tt=std::pow(double(tt),0.3);}
			clr=TColor(clr768(int(tt*768)));
			plt.DataColor=clr;
			plt.FillColor=clr;
			plt.Rectangle(sftsz*frm+offx,cmp,sftsz*(frm+1)+offx,cmp+1);
		}
	}
	plt.DataColor=clrd; plt.FillColor=clrf;
	plt.ShowGraf();
	return plt;
}


TRChart& rchartf_::spec	(TRChart& rct, vecvec<float >&vv,int qbsz, int frmsz,int sftsz)
{	return __plotspec__(rct,vv,qbsz,frmsz,sftsz);	}
TRChart& rchartf_::spec	(TRChart& rct, vecvec<double>&vv,int qbsz, int frmsz,int sftsz)
{	return __plotspec__(rct,vv,qbsz,frmsz,sftsz);	}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////


TRChart&rctpanel::rct(size_t row, size_t col)
{
	if(row>=ROW||col>=COL) {
		chars cs="need to call panel(..); and setrc(ROW,COL);";
		cs.show();
		return *v[0];
	}
	return *v[row*COL+col];
}

void	rctpanel::rim	(char dir, int n)//* dir ='t' 'b' 'l' 'r'
{
	size_t row, col;
	for(row=0;row<ROW;++row)for(col=0;col<COL;++col)
		rim(dir,n,row,col);
}
void	rctpanel::rim	(char dir, int n, size_t row, size_t col)
{
	TRChart& r=rct(row,col);
	switch(dir){
	case 't':case 'T': r.TRim=n;break;
	case 'b':case 'B': r.BRim=n;break;
	case 'l':case 'L': r.LRim=n;break;
	case 'r':case 'R': r.RRim=n;break;
	}
}

void	rctpanel::ndecx(int d)
{
	size_t row, col;
	for(row=0;row<ROW;++row)for(col=0;col<COL;++col)
		ndecx(d,row,col);
}
void	rctpanel::ndecy(int d)
{
	size_t row, col;
	for(row=0;row<ROW;++row)for(col=0;col<COL;++col)
		ndecy(d,row,col);
}
void	rctpanel::ndecx(int d, size_t row, size_t col)
{
	TRChart& r=rct(row,col);
	r.DecPlaceX=d;
}
void	rctpanel::ndecy(int d, size_t row, size_t col)
{
	TRChart& r=rct(row,col);
	r.DecPlaceY=d;
}

bool rctpanel::dele()
{
	for(size_t n=0; n<v.size(); ++n) delete v[n];
	v.clear();
	return true;
}

int	rctpanel::setrange()
{
	if(COL<=0||ROW<=0) return 0;
	int WID=pnl->Width/COL; int HITE=pnl->Height/ROW;
	size_t row,col; int nth=0;
	for(row=0;row<ROW;++row){
	for(col=0;col<COL;++col){
		TRChart& rct=*v[nth];
		rct.Left =WID*col;	rct.Top		=HITE*row;
		rct.Width=WID;		rct.Height	=HITE;
		++nth;
	}}
	return 1;
}
int	rctpanel::setrc(size_t ROW1, size_t COL1)
{
	dele();
	ROW=ROW1; COL=COL1; if(ROW<=0) ROW=1; if(COL<=0) COL=1;
	size_t row,col;
	for(row=0;row<ROW;++row){
	for(col=0;col<COL;++col){
		TRChart* p2rct=new TRChart(Application);
		TRChart& rct=*p2rct; rct.Parent=(pnl);
		v.push_back(p2rct);
	}}
	setrange();
	setmenu();
	return 1;
}
void	rctpanel::setmenu()
{
	if(!menu)return;
	size_t n,N=v.size();
	for(n=0; n<N; ++n){
		v[n]->PopupMenu=menu;
	}
}

void __fastcall rctpanel::PopupMenuItemsClick(TObject *Sender)
{
	chars cs;
	if(!menu)return;
	size_t n,N=v.size(); TRChart* rct=0;
	TComponent* cmp= menu->PopupComponent;
	for(n=0; n<N; ++n){
		if(cmp==v[n]){
			rct=v[n];
			break;
		}
	}
	if(!rct) return;//should not happen
	TMenuItem* mit=dynamic_cast<TMenuItem *>(Sender);
	if(!mit) return;
	switch(mit->Tag){//can check, because MenuItem->Tag was set
	case 0: //cs<<"0-th menuitem clicked"<<show; and so on
			rct->MouseAction=Rchart::maNone;
			break;
	case 1:break;//"-"
	case 2:
			rct->MouseAction=maZoomDrag;
			break;
	case 3:
			rct->MouseAction=Rchart::maPan;
			break;
	case 4:
			rct->MouseAction=maPanHoriz;
			break;
	case 5:
			rct->MouseAction=maPanVert;
			break;
	case 6:
			rct->MouseAction=maZoomWindPos;
			break;
	case 7:
			rct->MouseAction=maZoomWind;
			break;
	case 8:break;//"-"
	case 9:
			rct->CopyToClipboard(false);
			break;
	}
}

void	rctpanel::createmenu()
{
	if(menucnt!=0){
		//need to delete those menu items
	}
	menu=new TPopupMenu(Application);
	TMenuItem *NewItem;

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "����mouse�ʧ@";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "-";
	NewItem->Tag = menucnt++;
//	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "�Y��(ZoomDrag)";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "�|�V����(pan)";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "��������(pan hor)";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "��������(pan ver)";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "��j�|���(ZoomWind)";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "���V��j�|���(ZoomWindPos)";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "-";
	NewItem->Tag = menucnt++;
//	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

	NewItem = new TMenuItem(menu); 	// create the new item
	menu->Items->Add(NewItem);		// add it to the Popupmenu
	NewItem->Caption = "kopi��clipboard";
	NewItem->Tag = menucnt++;
	NewItem->OnClick = this->PopupMenuItemsClick;// assign it an event handler

//	TMenuItem *NewItem = new TMenuItem(PopupMenu1); // create the new item
//	PopupMenu1->Items->Add(NewItem);// add it to the Popupmenu
//	NewItem->Caption = "Menu Item " + IntToStr(index);
//	NewItem->Tag = index;
//	NewItem->OnClick = PopupMenuItemsClick;// assign it an event handler
}

/*
void	rctpanel::menuclick(TObject*Sender)
{
	chars cs;
	if(!men)return;
	TMenuItem* mit=dynamic_cast<TMenuItem *>(Sender);
	if(!mit) return;
	switch(mit->Tag){
	case 0: cs<<"0-th item clicked"<<show;break;
	case 1: cs<<"1-th item clicked"<<show;break;//because MenuItem->Tag was set
	}
//	TComponent* cmpm= mit->GetParentComponent();
//	if(cmpm==men)cs<<clear<<"parent is rudundant"<<show;
	size_t n,N=v.size();
	for(n=0; n<N; ++n){
		TComponent* cmp= men->PopupComponent;//GetParentComponent();
		if(cmp==v[n]){
			cs<<clear<<n<<"-th rchart clicked"<<show;
		}
	}
	cs<<clear<<"showing?"<<show;
}
*/

///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////






