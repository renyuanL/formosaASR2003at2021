//
// daiqi.h
// 2k/12/15 IngZin Gang

#ifndef DAIQI_H
#define DAIQI_H

#include <di5base.h>

class		daiqibendiau_ { chars tpy, tkd, tdd, tmp;
public :
	int		maybegoodpy1	(char* py1); // return 0/1/2
	int		maybegoodpys	(char* pys);
	char*	bpy2					(char* pys){tpy=pys;str_deldigits(tpy.s);return tpy.s;}
	char*	kqd2					(char* pys);
	char*	drd2					(char* pys);
	void	dk2k					(char* dk2){dk2[0]=dk2[1];dk2[1]=dk2[3];dk2[2]=0;}
	void  dk2d					(char* dk2){							dk2[1]=dk2[2];dk2[2]=0;}
	void  smpbd					(chars& tgt, chars& src, int islam=1);
	void  smpbdlam			(chars& tgt, chars& src){return smpbendiau(tgt,src,1);}
	void  smpbdbak			(chars& tgt, chars& src){return smpbendiau(tgt,src,0);}
	void  smpbendiau		(chars& tgt, chars& src, int islam=1){return smpbd(tgt,src,islam);}
	void  smpbendiaulam	(chars& tgt, chars& src){return smpbendiau(tgt,src,1);}
	void  smpbendiaubak	(chars& tgt, chars& src){return smpbendiau(tgt,src,0);}
};

extern daiqibendiau_ dqbendiau;


#endif //#ifndef DAIQI_H

