//
// di5rand.cpp
//

#ifndef DI5RAND_CPP
#define DI5RAND_CPP


#include <di5rand.h>
#include<di5base.h>

static double pi2=2*3.1415926535;
uuni_ 	uuni;
congru_	congru;
rn_ 	rn;

void uuni_re_init(int i1, int j1, int k1, int l1)
{
	uuni.init(i1,j1,k1,l1);
}


////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
double	rn_::	BM		(unif_& unif)
{
	static double z2;
	static bool good=false;	if(good){good=false; return z2;}
	double z1;	double u1=sqrt(-2.0*log(unif())), u2=pi2*unif();
	z1=u1*cos(u2); z2=u1*sin(u2); good=true;
	return z1;
}

double	rn_::	gammaL1	(double alfa,	unif_& unif)
{
	double t,b;
	t=0.07+0.75*sqrt(1-alfa); b=1.0+exp(-t)*alfa/t;
	double u1,u2,v,x,y;
	while(1){
		u1=unif();u2=unif();v=b*u1;
		if(v<=1){
			x=t*pow(v,1/alfa);
			if(u2<=(2-x)/(2+x))
				return x;
			else if(u2<=exp(-x))
				return x;
		}else{
			x= -log( (t*(b-v))/alfa ); y=x/t;
			if( u2*(alfa+y*(1-alfa)) <=1 )
				return x;
			else if(u2<=pow(y,alfa-1))
				return x;
		}
	}
}
double	rn_::	gammaG1	(double alfa,	unif_& unif)
{
	double u1,u2,v;
	while(1){
		u1=unif();u2=unif();
		v=(alfa-1.0/(6.0*alfa))*u1/((alfa-1)*u2);
		if(2*(u2-1)/(alfa-1)+v+1.0/v <=2)
			return (alfa-1)*v;
		else if(2*log(u2)/(alfa-1)-log(v)+v<=1)
			return (alfa-1)*v;
	}
}
double	rn_::	laplace(unif_& unif)
{
	double u=unif()*2;
	bool pos=(u>1.0)?true:false;
	//if(u>1.9999999) return laplace(unif);
	//if(u<0.0000001) return laplace(unif);
	return (pos)?
	(-log(2-u)):
	(log(u));
}
/*
double	rn_::	gamma	(double alfa,double beta,	unif_& unif)
{//Fishman
	alfa-=1;
	double V1, V2;
	while(1){
		V1=expo(unif); V2=expo(unif);
		if(V2>= alfa*(V1-log(V1)-1) )
			return V1*beta;
	}
}
*/
//gamma: Tadikamalla2, see rubinstein p.78
inline double Tadikamalla2g(double alfa, double theta, double x)
{
	double y;
	alfa -= 1;
	y=pow( (theta-1)*x/(theta*alfa) , alfa);
	y *= exp( -x+ ( fabs(x-alfa)-alfa*(theta+1) )/theta );
	return y;
}

/*
//Cheng's version
double	rn_::	gamma	(double alfa,double beta,	unif_& unif)
{
	double y, notdone=1;
	double lamda,mu;
	lamda=std::sqrt(2*alfa-1);mu=pow(alfa, lamda);
	double ln4=log(4.0);
	double u1, u2; int cnt=0;
	while(notdone){
		u1=unif(); u2=unif();
		double V=lamda*log(u1/(1.0-u2));
		y=alfa*exp(V);
		if(exp(alfa-ln4+alfa+1.0/lamda-y)>u1*u1*u2)
			return y*beta;
		cnt++;
	}
	return gamma(alfa,beta,unif);
}double	rn_::	gamma	(double alfa,double beta,	unif_& unif)
{
	double u, gy, y, notdone=1;  double theta=2;//1.1;//alfa;
	int cnt=0;
	while(notdone){
//	while(y<0) y=laplace(alfa-1,beta,unif);
		cnt++;
		y=-1;
		while(y<0) y=laplace(alfa-1,theta,unif);
		u=unif();
//		gy=Tadikamalla2g(alfa, beta, y);
		gy=alfa*theta*Tadikamalla2g(alfa, theta, y);
		if(u<=gy)
			return y*beta;
	}
	return gamma(alfa, beta, unif);
}
double	rn_::	gamma	(double alfa,double beta,	unif_& unif)
{
	double u, gy, y, notdone=1;  double theta=2;//alfa+1;
	int cnt=0;
	while(notdone){
//	while(y<0) y=laplace(alfa-1,beta,unif);
		cnt++;
		y=-1;
		while(y<0) y=laplace(alfa-1,theta,unif);
		u=unif();
//		gy=Tadikamalla2g(alfa, beta, y);
		gy=Tadikamalla2g(alfa, theta, y);
		if(u<=gy)
			return y*beta;
	}
	return gamma(alfa, beta, unif);
}
double	rn_::	gamma	(double alfa,double beta,	unif_& unif)
{
	double y=-1;  double theta=alfa+1;
//	while(y<0) y=laplace(alfa-1,beta,unif);
	while(y<0) y=laplace(alfa-1,theta,unif);
	double u=unif();
//	double gy=Tadikamalla2g(alfa, beta, y);
	double gy=Tadikamalla2g(alfa, theta, y);
	if(u<=gy) return y*beta;
	return gamma(alfa, beta, unif);
}
double	rn_::	beta	(double alfa,double beta,	unif_& unif)
{
	double y1=gamma(alfa,1.0, unif);
	double y2=gamma(beta,1.0, unif);
	double x=y1/(y1+y2);
	return x;
}
*/
double	rn_::	beta	(double alfa,double beta,	unif_& unif)
{
	double y1,y2,x;
	while(1){
		y1=pow(unif(),1.0/alfa);
		y2=pow(unif(),1.0/beta);
		if(y1+y2<=1.0){
			x=y1/(y1+y2);
			return x;
		}
	}
}

//tabsit_ tabsit;

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////

#ifdef COMMENTONLY
class  uuni_ :public unif_{
public:uuni_(int i1=12, int j1=34, int k1=56, int l1=78) {init(i1,j1,k1,l1);}
	float operator()(); // return a unif(0,1) RN
	void init(int i1, int j1, int k1, int l1);
private:
	float U[97]; float C, CD, CM;
	int I, J;
};
#endif //#ifdef COMMENTONLY

float uuni_::operator()()
{
	float uni;
	uni=U[I]-U[J];
	if(uni<0.0) uni+=1.0;
	U[I]=uni;
	I--;   if(I<0) I=96;
	J--;   if(J<0) J=96;
	C-=CD; if(C  <0.0) C  +=CM;
	uni-=C;if(uni<=0.0) uni+=1.0;
//	uni-=C;if(uni<0.0) uni+=1.0;
	return uni;
}

void uuni_::init(int i1, int j1, int k1, int l1)
{
	int m1;
	float s, t;
	for(int ii=0; ii<97; ii++) {
		s=0.0; t=0.5;
		for(int jj=0; jj<24; jj++) {
			m1=( ((i1*j1)%179)*k1 )%179;
			i1=j1;
			j1=k1;
			k1=m1;
			l1=(53*l1+1)%169;
			if( ((l1*m1)%64) >= 32 ) s=s+t;
			t=0.5*t;
		}
		U[ii]=s;
	}
	C =  362436.0/16777216.0;
	CD= 7654321.0/16777216.0;
	CM=16777213.0/16777216.0;
	I=96; J=32;
}

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////



#endif //#ifndef DI5RAND_CPP


