////
//// file simpwio.h
//// a simpler version for wave io
//// copyright2004 IZGang/RHLyu
////	finished 2004/03/31
////
#ifndef SIMPWIO_H
#define SIMPWIO_H

#include<speechio.h>		//// future goal: remove this include
#include<di5mout.h>		//// for debugging purpose

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

typedef uint WINAPI (THREADFUNC)(void*pv);
class	thinthread{ public:HANDLE h; uint id;
		thinthread():h(NULL),id(0){}
	  ~thinthread(){dele();}
public:
	void begin(THREADFUNC f, void* obj)
								{	dele();
									h=(HANDLE)_beginthreadex(NULL,0,f,obj,0,&id);
								}
	void dele (			)
								{
									if(h)
										CloseHandle(h);
									h=0;
								}
};
/*////////////////////////////////////////////////////
This is what really happened/should be using in calling begin(...)
class some{
	thinthread thd;
	static uint WINAPI sfunc(void*obj){some*p=(some*)obj; p->...;}
	void thdbegin(){thd.begin(sfunc, this);}
};
*////////////////////////////////////////////////////

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

/*////////////////////////////////////////////////////////////
2004-03-12 : owplayer/thinwaveout/thinthread
	The owplayer is newer version than an older owplayer,
w/added play(qiimbuf_). So use owplayer only w/o owtplayer is(should be) OK.
	One of the key in design of the tplay() is that,
when close() called, thread maynot exist anymore. Thus, 3 things are done here,
	1. open()/close() is outside thread-life
	2. combine play/tplay since most of the routines are the same
	3. use thinwaveout/thinthread 2 decouple(dis-intermingle) waveout/thread.
		This leads to a much cleaner design
*/////////////////////////////////////////////////////////////
typedef	void WINAPI (OWPROC)	(HWAVEOUT hwo,UINT uMsg,
										 DWORD dwInst,		DWORD dwPrm1,DWORD dwPrm2);

struct owavebase{owavebase():bOpened(0),bBangImDiong(0){}
	~owavebase(){ if(bOpened) close(); }
	HWAVEOUT			hwo;
	waveformatex	wfx; // struct for (querying?) supportted data format
	WAVEHDR			hdr;
	MMRESULT			res;
	volatile   int	bOpened;
	volatile   int	bBangImDiong;
	enum{	hdrsz=sizeof(WAVEHDR) };
	HWAVEOUT		operator()(){return hwo;}

	__int64		position 	();//by num_samples
	int	isplaying(){return bBangImDiong;}

	int open(DWORD  dwInst, OWPROC p, waveformatex*wf=NULL);
	int open(DWORD  dwInst, OWPROC p, WAVEFORMATEX*wf=NULL){return open(dwInst,p,(waveformatex*)wf);}
	int open(waveformatex*wf=NULL) {return open((DWORD)this,OWPdef,wf);}
	int open(WAVEFORMATEX*wf=NULL) {return open((DWORD)this,OWPdef,wf);}
	int open(waveformatex&wf	  ) {return open((DWORD)this,OWPdef,&wf);}
	int open(WAVEFORMATEX&wf	  ) {return open((DWORD)this,OWPdef,&wf);}
	int close(int mswait=0);//threaded version
	int reset(int mswait=0);//threaded version
	int stop (int mswait=0){return reset(mswait);}
	void	 	sethdr(short*data,int shsize);
	MMRESULT prep  (WAVEHDR* hdr1=NULL){return res=waveOutPrepareHeader	(hwo, (hdr1)?hdr1:&hdr, hdrsz);}
	MMRESULT write (WAVEHDR* hdr1=NULL){return res=waveOutWrite				(hwo, (hdr1)?hdr1:&hdr, hdrsz);}
	MMRESULT unprep(WAVEHDR* hdr1=NULL){return res=waveOutUnprepareHeader(hwo, (hdr1)?hdr1:&hdr, hdrsz);}
public:
	static void CALLBACK OWPdef(HWAVEOUT,UINT, DWORD dwInst,DWORD,DWORD);
	OWPROC owproc;
public:
	eventhandle		evtplayend;
	void	wait2end		(		 ){WaitForSingleObject(evtplayend.h,INFINITE);}
	void	reset4wait	(		 ){evtplayend.reset(); }
	void	sleep2end 	(int ms){if(bBangImDiong)sleep2end0(ms);}
	void	sleep2end0	(int ms);
};

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////



//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

class owplayer { public:owplayer():callbackfnc(NULL){}// the real worker for out-wave
	owavebase		ow;
	MMRESULT			res;
	enum 				{nMAXLEN=65};
	char				errtxt[nMAXLEN];
public:
	__int64	position 	(){return ow.position();}//by num_samples
	int		isplaying	(){return ow.isplaying();}//bBangImDiong;}
	int		owclose		(){return ow.close();}//watch out for thread existence
	int		reset	(int mswait=100){return ow.reset(mswait);}
public:
public: short* sh0; int shsize0; pcmfmt_* pcm0;
public:
	int	 play	(short*sh, int shsize, pcmfmt_* pcm=0);
	int	tplay	(short*sh, int shsize, pcmfmt_* pcm=0);
	int	 play	(qiimbuf_& qb){return  play(qb .sh,qb.nshused,&(qb.pcm));}
	int	 play	(qiimbuf_* qb){return  play(*qb);}
	int	tplay	(qiimbuf_* qb){return tplay(*qb);}
	int	tplay	(qiimbuf_& qb){return tplay(qb .sh,qb.nshused,&(qb.pcm));}
public:
	void	setcb	(VFVS fnc,void*arg){callbackfnc=fnc;callbackarg=arg;}
	VFVS				callbackfnc;	//VFNV: void function of void*
	void*				callbackarg;	//arg to the callbackfn
//	virtual void	callback(){}
//	VFNV				callbackfn;		//VFNV void function of void
protected:
	thinthread		thd;
	int sztplay		();
	static uint WINAPI thdf(void*p);//{owplayer&o=*((owplayer*)p);....}
};


inline	void	owavebase:: sethdr(short*dt,int shsize)
{
	hdr.lpData = (LPSTR)dt;
	hdr.dwBufferLength = shsize*2; // length in bytes rather in short
	hdr.dwBytesRecorded= shsize*2; // length in bytes rather in short
	hdr.dwFlags = WHDR_BEGINLOOP|WHDR_ENDLOOP;
	hdr.dwLoops = 1L;
}

inline	void WINAPI owavebase::
OWPdef(HWAVEOUT hwo,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	crtsection cs; cs.enter();
	owavebase* owb=(owavebase*)dwInst;
	switch (uMsg) {//hEvent was placed at arg:dwCallbackInst
	case WOM_OPEN:		owb->bOpened=1;break;
	case WOM_CLOSE:	owb->bOpened=0;break;
	case WOM_DONE:		owb->bBangImDiong=0;owb->evtplayend.set();break;
	default:	break;
	}
	cs.leave();
}

inline 	uint WINAPI  owplayer::
thdf(void*p)
{
	owplayer&o=*((owplayer*)p);
	o.sztplay();
	o.thd.dele();
	if(o.callbackfnc)
		o.callbackfnc(o.callbackarg);
	return 1;
}



//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

class wiomessage{public:
		wiomessage():ended(0),iwmcallback(NULL),owmcallback(NULL),rcgcallback(NULL){thd.begin(thdproc,this);}
	  ~wiomessage(){ended=1;evt.set();}//SetEvent so that the thread can end
	thinthread			thd;
	eventhandle			evt;
	void	iwm				(char*	s){ics=s; doit();}
	void	owm				(char*	s){ocs=s; doit();}
	void	rcg				(char*	s){rcs=s; doit();}
	void	doit				(			 ){evt.set();}
//	void	doit				(			 ){iwcb();}//evt.set();}
	void	iwcb		(	 ){if(iwmcallback&&ics.hassome())iwmcallback(ics.s);}
	void	owcb		(	 ){if(owmcallback&&ocs.hassome())owmcallback(ocs.s);}
	void	rwcb		(	 ){if(rcgcallback&&rcs.hassome())rcgcallback(rcs.s);}
	void	setcbi	(VFVS fn1){iwmcallback=fn1;}
	void	setcbo	(VFVS fn1){owmcallback=fn1;}
	void	setcbr	(VFVS fn1){rcgcallback=fn1;}
	void	wait2end			(		 	 ){WaitForSingleObject(evt.h,INFINITE);}
	void	reset4wait		(		 	 ){evt.reset(); }
protected:
public:
	static uint WINAPI	thdproc(void*p);
	VFVS					iwmcallback;	//VFNV: void function of void*
	VFVS					owmcallback;	//VFNV: void function of void*
	VFVS					rcgcallback;	//VFNV: void function of void*
	volatile	int		ended;
	chars	ics, ocs, rcs;
};

inline uint WINAPI	wiomessage::
thdproc(void*p)
{
	wiomessage&o=*((wiomessage*)p);
	while(!o.ended){
		o.reset4wait();
		o.wait2end();
		if(o.iwmcallback&&o.ics.hassome())o.iwmcallback(o.ics.s);
		if(o.owmcallback&&o.ocs.hassome())o.owmcallback(o.ocs.s);
		if(o.rcgcallback&&o.rcs.hassome())o.rcgcallback(o.rcs.s);
		o.ics.clear();
		o.ocs.clear();
		o.rcs.clear();
	}
	o.thd.dele();
	return 1;
}
extern wiomessage wiom;

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////




//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

typedef	void WINAPI (IWPROC)(HWAVEIN hwi,		UINT uMsg,
										DWORD dwInst,		DWORD dwPrm1,DWORD dwPrm2);

struct	iwavebase {
			iwavebase():bOpened(0),bLokImDiong(0){}
		  ~iwavebase()									 {if(bOpened)close(10);}
public:
	int	open(DWORD  dwInst, IWPROC p,	waveformatex*wf=NULL);
	int	open(DWORD  dwInst, IWPROC p,	WAVEFORMATEX*wf=NULL){return open(dwInst,p,(waveformatex*)wf);}

	int	open(waveformatex*wf=NULL){return open((DWORD)this,IWPdef, wf);}
	int	open(WAVEFORMATEX*wf=NULL){return open((DWORD)this,IWPdef, (waveformatex*)wf);}
public:
	int		close(int mswait=0);
	int		stop (int mswait=0);
	int		reset(int mswait=0);
	__int64	position 	();//by num_samples
public:
	MMRESULT prep  (WAVEHDR* hdr1=NULL){return res= waveInPrepareHeader  (hwi, (hdr1)?hdr1:&hdr, hdrsz);}
	MMRESULT unprep(WAVEHDR* hdr1=NULL){return res= waveInUnprepareHeader(hwi, (hdr1)?hdr1:&hdr, hdrsz);}
	MMRESULT add   (WAVEHDR* hdr1=NULL){return res= waveInAddBuffer		(hwi, (hdr1)?hdr1:&hdr, hdrsz);}
	MMRESULT start (	){nshbeforereset=0;return res= waveInStart(hwi);}
	void	 	sethdr(short*data,int shsize);
public:
	HWAVEIN			hwi;
	waveformatex	wfx; // struct for (querying?) supportted data format
	WAVEHDR			hdr;
	MMRESULT		res;
	volatile  int	bOpened;
	volatile  int	bLokImDiong;
	__int64	nshbeforereset; int isfixthreaded;
	enum{	hdrsz=sizeof(WAVEHDR)	};
public:
	static void CALLBACK IWPdef(HWAVEIN,UINT,  DWORD dwInst,	DWORD,DWORD);
public:
	eventhandle			evtlokimend;
	void	wait2end		(){	WaitForSingleObject(evtlokimend.h,INFINITE);}
	void	reset4wait	(){	evtlokimend.reset(); }
	void	sleep2end 	(int ms){if(bLokImDiong)sleep2end0(ms);}
	void	sleep2end0	(int ms);
};


inline void CALLBACK iwavebase::
IWPdef(HWAVEIN hwi,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	iwavebase* iwb=(iwavebase*)dwInst;
	switch (uMsg) {
	case WIM_OPEN:
		iwb->bOpened=1;break;
	case WIM_CLOSE:
		iwb->bOpened=0;break;
	case WIM_DATA:
		iwb->evtlokimend.set();break;
	}
}

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////



//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

class iwlokim1 {
public:
	int	lokim	 	(qiimbuf_ & qbuf, int nsec);///* fixed   length lokim, non-threaded
	int	tlokim	(qiimbuf_ & qbuf, int nsec);///* at-most length lokim, threaded
	int	lokimstop(){iw.reset(10);return 1;}
public:
	iwavebase	iw;
	MMRESULT		res;
public:
	qiimbuf_* p2qbuf; int shsize;
	thinthread		thd;
	int sztlokim  	();//really(sit-ze) threaded lokim
static uint WINAPI thdf(void*p)	{iwlokim1&o=*((iwlokim1*)p);
											{o.sztlokim();o.thd.dele();return 1;}}
};

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////




//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

class iwhbc { public: //hdr, buf, and compute
	enum		{ MFRMSZ=1024};//, HMFRMSZ=512 }; // MIB: max idle buf
	WAVEHDR	hdr;
	int		nsh;
	short		sh[MFRMSZ];				// reciving data from iwave
	short		shs[MFRMSZ];	// used for compute. Thus after down sample,
	float		fts[MFRMSZ];	// frame size must be <=nDQS_IDLEBUFSIZE
	int		id;
	int		ii; //ing-ing, or idle
public: int res;
	int		prep   (HWAVEIN hwi) {return res=waveInPrepareHeader   ( hwi, &hdr, sizeof(WAVEHDR) ); }
	int		unprep (HWAVEIN hwi) {return res=waveInUnprepareHeader ( hwi, &hdr, sizeof(WAVEHDR) ); }
	int		add    (HWAVEIN hwi) {ii=0; return res=waveInAddBuffer ( hwi, &hdr, sizeof(WAVEHDR) ); }
//	int		addif  (HWAVEIN hwi) {crtsection cs; cs.enter(); return (ii)?add(hwi):0; }
//	int		addifii(HWAVEIN hwi) {crtsection cs; cs.enter(); return (ii)?add(hwi):0; }
	int		addifii(HWAVEIN hwi) {return (ii)?add(hwi):0; }
	int		setidle(		   ) {ii=1;return 1;}
public:
	float*	dnsmp2spt(ehfs_& ehfs, int nFS, int dnsmp, int dboff);//return fts
public:
	//////  The one that receives iwave data is from outside using set2(...)
public:
	void		hdr20 (           ) {memset(&hdr,0,sizeof(WAVEHDR));}
	int		bsize (           ) {return hdr.dwBufferLength;  }// byte  size of wavedata
	int		size  (           ) {return hdr.dwBufferLength/2;}// short size of wavedata
	short*	OP()  (           ) {return sh;}
	int		sub   (int	off ) {return sub((short)off);}
	int   	sub   (short  off ) {int m,M=size();for(m=0;m<M;m++)sh[m]-=off;return M;}
	int   	copy2 (short* sh1 ) {memmove(sh1, sh, bsize()); return size(); }
	int   	copy2 (float* flt ) {int m,M=size();for(m=0;m<M;m++)flt[m]=sh[m];return M;}
	int   	dnsmp2(float* flt, int dnsmp){int m,M=size();for(m=0;m<M;m+=dnsmp)flt[m]=sh[m];return M/dnsmp;}
public:
	void		set2  (int id1, int nsh1)
	{	csbe(nsh1,64,int(MFRMSZ)+1);
		id=id1; ii=1; nsh=nsh1;		memset(&hdr,0,sizeof(WAVEHDR));
		hdr.lpData=(LPSTR)(sh);		hdr.dwBufferLength=nsh*sizeof(short);
	}
};



class	iwhbcs{	public:
	enum	{ MIB=4, MFRMSZ=1024};//, HMFRMSZ=512 }; // MIB: max idle buf
	iwhbc	bs[MIB];
public:
	int	idlebuflen(				 ){return bs[0].nsh; }
	void	idlesprp  (HWAVEIN hwi){for(int m=0;m<MIB;++m)bs[m].prep   (hwi);}
	void	idlesunp  (HWAVEIN hwi){for(int m=0;m<MIB;++m)bs[m].unprep (hwi);}
	void	all2idle  (           ){for(int m=0;m<MIB;++m)bs[m].ii     =1;   }
	void	addifidle (HWAVEIN hwi){for(int m=0;m<MIB;++m)bs[m].addifii(hwi);}
public:
	void	sethbc	 (int 	len ){for(int m=0;m<MIB;++m)bs[m].set2(m,len); }
	int	use_len	 (				 ){return bs[0].nsh;}
};


//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////




//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////100,300,100,200,50

class iwoption	{public:
		iwoption	 (		):iwcase(-1),manual(0),dhdbso(1){initmsg();
								set_16K();setbems(100,500,100,200,50);setbe(10.0,4.0);}
//		iwoption	 (		):iwcase(-1),manual(0){set_16K();setbems(5,30,5,10);setbe(10.0,4.0);initmsg();}
public:
	void	set_8K (          ){set_sr(sr08K);}
	void	set_08K(          ){set_sr(sr08K);}
	void	set_16K(          ){set_sr(sr16K);}
	void	set_32K(          ){set_sr(sr32K);}
	void	set_48K(          ){set_sr(sr48K);}
	void	set_64K(          ){set_sr(sr64K);}
	void	set_11K(          ){set_sr(sr11K);}
	void	set_22K(          ){set_sr(sr22K);}
	void	set_44K(          ){set_sr(sr44K);}
	void	set_sr (int srcase);//iwcase is sampling rate kind
	int	adapt48k(){return (nsrt==48000||nsrt==16000||nsrt==8000)?1:0;}
public://// endpoint detection related
					int msbDUR;	int mseDUR;	int msbSIL;	int mseSIL;	int msBLURB;
void	setbems (int msbDUR1,int mseDUR1,int msbSIL1,int mseSIL1,int msBLURB1=48);
void	setbe	  (int bTHRSH, int eTHRSH){bTHRESH=bTHRSH; eTHRESH=eTHRSH;}
					int bTHRESH;int eTHRESH;
	int	nbDUR	(){return nms2nfrm(msbDUR );}
	int	neDUR	(){return nms2nfrm(mseDUR );}
	int	nbSIL	(){return nms2nfrm(msbSIL );}
	int	neSIL	(){return nms2nfrm(mseSIL );}
	int	nBLURB(){return nms2nfrm(msBLURB);}
public:////
		int	manual;
public://// sampling rate related
	int	iwcase;	// sampling rate case
	int	nsrt;		// sampling rate, sample per sec
	int	nspd;		// sampling period
	int	nchl;		// num. of channels
	int	nBps;		// num. of Bytes per sample
	void	init0		(			){nsrt=16000;nspd=625;nchl=1;nBps=2;}
	int	nms2nfrm	(int ms	){return int((nsrt/1000.*ms+0.5)/nFS);}
	int	nFS;    // frame size, in sample
	int	nFFT;   // num of points to take FFT
	//int	nSS;    // shift size, in sample
	int	dnsmp;  // 1/2/4, down sample for endpoint
public:
	int		copycat;
	double	dhdbso;//honng uda
public:
	static	char	*msgdef;
	char	*msgs[3];
	void	setmsgs(char*s, char sep);
	void	initmsg(){setmsgs(msgdef, ch01);}
};


//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////






//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

class  iwbemanual {
public:
	int		isspeechb	(iwhbc*p2hbc)		{return  1;}//always judge as speech
	int		isspeeche	(iwhbc*p2hbc)		{return  1;}//always judge as speech
public:////junk, simply make it similar to iwbessc, so that template will work
	void		setbeTHRSH	(double bTHRSH, double eTHRSH)			{}
	int		setadapt		(iwoption& opt, char*fn=0,	char*pn=0)	{return 0;}
	int		setadapt		(iwoption& opt, qiimbuf_* qb )			{return 0;}
};


class	iwbessc	{public: iwbessc():adaptset(0),p2opt(0),manual(0),bTHRESH(-1){setbeSSC();setTHRESH(50,50);}
public:
	int		isspeechb	(iwhbc*p2hbc){	return (manual)?1:ssc(*p2hbc,1); }
	int		isspeeche	(iwhbc*p2hbc){	return (manual)?1:ssc(*p2hbc,0); }
public:
	int		setadapt	(iwoption& opt, char*fn=0,char*pn=0);// if(0) use "4adapt.sp"
	int		setadapt	(iwoption& opt, qiimbuf_* qb );		// if(0) use in-class qbuf, else copy
	void		setTHRESH(double bTHRSH, double eTHRSH);//{bTHRESH=bTHRSH; eTHRESH=eTHRSH;setthresh();}
public:
	enum	{ MFRMSZ=1024};//, HMFRMSZ=512 }; // MIB: max idle buf
	double	dbbias;
	float*	sh2spt(short*sh,int nsh, float* spt,int nspt, int dnsmp,int fb_dboff=0)
						{return ehfs.dfs1(sh,nsh,dnsmp,spt);}
	float*	sh2spt_woff(short*sh,int nsh, float* spt,int nspt, int dnsmp,int fb_dboff=0)
						{return ehfs.dfs1off(sh,nsh,dnsmp,spt);}
	int		ssc	(iwhbc&	  hbc, int forbeg);
	float		cutb0	[MFRMSZ]; // trunctation threshhold for beg
	float		cute0	[MFRMSZ]; // trunctation threshhold for end
	float		cutb	[MFRMSZ]; // cutb0*pow(2,bTHRESH-50)
	float		cute	[MFRMSZ]; // cute0*pow(2,eTHRESH-50)
	float		bTHRESH, eTHRESH;
	qiimbuf_		qb;
	ehfs_			ehfs;
	iwoption*	p2opt;
	int			adaptset, manual;
protected:
	void		setbeSSC	(){nbSSC=8; neSSC=4;}
	int		nbSSC, neSSC;
	////nbSSC/nwSSC are kind of older ver. in controlling speechbe; still used.
	////User control speechbe thru bthresh/ethresh instead.
};

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////






//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

class	endpointb	{enum{nBUF=60}; public:
		endpointb	(								){init20();setDUR(5,5);}
		endpointb	(int nbDUR1, int nbSIL1 ){init20();setDUR(nbDUR1,nbSIL1);}
public:
	int	wavein	(iwhbc* p2whbc, int is4bspeech);//return beged
	int	copy2tz	(qiimbuf_  & qb);//copy2 front(tz:tauzing) of qiimbuf_
	int	nframe_tz(					);//tz(TauZing: front)
	int	nshort_tz(					){return frmsz*nframe_tz();}
	int	nshsildur();
	int	nshsil	();
public:
	void	setDUR	(int nbDUR1, int nbSIL1	);
	void	setfrmsz	(int frmsz1	){frmsz=frmsz1;}
	void	reset		(				){init20();}
public:
	int		beged;
	char*		msg;
protected:
	short		buf0[1024*nBUF];////note: always keep nBUF>=nbDUR+nbSIL
	short*	buf;
	int		nbdur,	nbDUR;// maximun of duration
	int		nbsil,	nbSIL;// extra silence at the begining
	int		ncbuf;			// copy2 buf[ncbuf*frmsz,..+frmsz-1] when iwhdbc in
	int		round2,	nbegspeech;
	int		frmsz;
	void	init20(){beged=nbdur=nbsil=ncbuf=round2=nbegspeech=0;buf=buf0;}
};


class	endpointe	{public:
		endpointe	(								){init20();setDUR(30,10);}
		endpointe	(int neDUR1, int neSIL1	){init20();setDUR(neDUR1,neSIL1);}
public:
	int	wavein	(int is4esil	);	//return ended
	int	trimsil	(qiimbuf_& qb, int frontfrms	);
	void	reset		(					){init20();}
	void	setDUR	(int neDUR1, int neSIL1,	int neBLURB1=3);
	void	setfrmsz	(int frmsz1){frmsz=frmsz1;}
public:
	volatile	int	ended;
protected:
//public:
	int		nedur,	neDUR;		// maximun of duration
	int		nesil,	neSIL;		// extra silence at the end
	int		neblurb,	neBLURB;		// duration to judge blurb
	int		ntotal,	nbegsilence;
	int		frmsz;
	void		init20(){ended=nedur=nesil=neblurb=ntotal=nbegsilence=0;}
};

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////




//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////


//#define IWTEMPLATE

#ifdef IWTEMPLATE
#else
//typedef iwbemanual BE; //for non-template testing of the iwlokim
typedef iwbessc BE; //for non-template testing of the iwlokim
#endif

#ifdef IWTEMPLATE
template<class BE>
#endif
class iwlokim { public:
		iwlokim():ended(1),ultimateended(0),qbcompleted(0),callbackfnc(NULL){init48K();setadapt("dqsds48k.wav");}
public:
	int		tlokim	(int nsec_reserved);
	void		lokimstop(int mswait=5000	);//patiently wait for the driver to end
	int		setmanual(int manual1		){opt.manual=manual1;	return manual1;}
	void		setcb		(VFVS fnc,void*arg){callbackfnc=fnc;callbackarg=arg;}
	qiimbuf_&	qb		(						);
public:
	qiimbuf_ 		qbdef;//, *p2qbuf;
	thinthread		thd;
	iwavebase		iw;
	VFVS				callbackfnc;	//VFNV: void function of void*
	void*				callbackarg;	//arg to the callbackfn
	int				sztlokim  	();//really(sit-ze) threaded lokim
	int				finishiwdata();
static void WINAPI	IWProc  (HWAVEIN,UINT,  DWORD dwInst,  DWORD,DWORD);
static uint WINAPI	thdproc (void*p);
public:
	void		init48K	(){	opt.set_48K();}
	void		init16K	(){	opt.set_16K();}
	int		wavein	(iwhbc* p2whbc );
	void		ACD2opt	();//according2 opt
	int		setadapt	(char*fn,char*pn=0)	{return be.setadapt(opt,fn,pn);}
	int		setadapt	(qiimbuf_&qb)			{return be.setadapt(opt,&qb);}
	int		adapt		(int nsec=4);
public:
	endpointb		epb;
	endpointe		epe;
	iwhbcs			hbcs;
	iwoption			opt;
	BE					be;
	MMRESULT			res;
	eventhandle		evtiwrepeat;
volatile  int	ended;
volatile	 int	qbcompleted;
volatile	 int	ultimateended;
};

#ifdef IWTEMPLATE
typedef	iwlokim<iwbessc>	ssclokim;
#else
typedef	iwlokim	ssclokim;
#endif

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////




//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////

#ifdef IWTEMPLATE
template<class BE> void WINAPI iwlokim<BE>::
#else
inline void WINAPI iwlokim::
#endif
IWProc(HWAVEIN hwi,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	iwlokim* li=(iwlokim*)dwInst; if(li==NULL) return;
	iwhbc*p2whbc=(iwhbc *) dwPrm1;
	switch (uMsg) {
	case WIM_OPEN:
		li->iw.bOpened=1;break;
	case WIM_CLOSE:
		li->iw.bOpened=0;break;
	case WIM_DATA:
		if(p2whbc->hdr.dwBytesRecorded>0)
			li->wavein(p2whbc);			//process the iwave frame
		if(li->ended){
			p2whbc->setidle();			//set this frame to idle
		}else{
			p2whbc->setidle();			//set this frame to idle
			p2whbc->add(li->iw.hwi);	//add this (idle) frame to iwave device
			//// SDK document in waveInProc says that
			//// 			[Calling other wave functions will cause deadlock.]
			//// but in the [See Also] section, it lists this WaveInAddBuffer
			//// if not add-in here, some workaround could be tideous at best.
		}
		break;
	}
}

#ifdef IWTEMPLATE
template<class BE> uint WINAPI iwlokim<BE>::
#else
inline uint WINAPI	iwlokim::
#endif
thdproc(void*p)
{
	iwlokim&o=*((iwlokim*)p);
	o.ultimateended=0;
	while(!o.ultimateended){
		o.sztlokim();
		if(o.callbackfnc)
			o.callbackfnc(o.callbackarg);
		if(o.ultimateended)break;
		WaitForSingleObject(o.evtiwrepeat.h, INFINITE);
	}
	o.thd.dele();
	return 1;
}


#ifdef IWTEMPLATE
template<class BE> void iwlokim<BE>::
#else
inline void iwlokim::
#endif
lokimstop(int mswait	)
{	//thd may be still waiting when lokimstop called
	crtsection cs; cs.enter();
	if(iw.bLokImDiong){
		ultimateended=1;epe.ended=1;epb.beged=1;
		////iw.reset(mswait);////I do not understand why calling this will hang
		if(mswait<5000) mswait=5000;////patiently wait for wi to end
		while(mswait>0){if(!iw.bLokImDiong)break;Sleep(10);}
	}else if(!ultimateended){//if(!lokimdiong and not ult-ended, it is waiting
		ultimateended=1;
		evtiwrepeat.set();
	}
	cs.leave();
}

#ifdef IWTEMPLATE
template<class BE> int iwlokim<BE>::
#else
inline int iwlokim::
#endif
tlokim(int nsec_reserved)
{
	if(iw.bLokImDiong) return 1;
	crtsection cs;	cs.enter();
	ACD2opt();
	int nsh=qbdef.ms2nsh(nsec_reserved*1000);
	qbdef.clear();	qbdef.reserve(nsh);
	if(!iw.open((DWORD)this,IWProc,&(qbdef.pcm.wfex))){return 0;}
	ended=0;
	cs.leave();
	if(thd.h&&(!ultimateended)){//the thread is waiting
		evtiwrepeat.set();
	}else{
		thd.begin(thdproc,this);
	}
	return 1;
}

#ifdef IWTEMPLATE
template<class BE> qiimbuf_& iwlokim<BE>::
#else
inline qiimbuf_& iwlokim::
#endif
qb	()
{
	if(!qbcompleted) Sleep(10);
	if(!qbcompleted) Sleep(50);
	return qbdef;
}

#ifdef IWTEMPLATE
template<class BE> int iwlokim<BE>::
#else
inline int iwlokim::
#endif
wavein    (iwhbc* p2whbc )
{
	if(ended) {
		return 0;
	}
	//p2whb->adjust_bias();
	if(!epb.beged){
		int s=be.isspeechb(p2whbc);
		epb.wavein(p2whbc,s);
		if(epb.beged){
			////there are nSH data in epb, reserve space for it, copy it later
			int nSH=epb.nshort_tz();
			qbdef.nshused=nSH;
		}
		return 1;
	}else{
		qbdef.app(p2whbc->sh,p2whbc->hdr.dwBytesRecorded/sizeof(short));
		int s=be.isspeeche(p2whbc);
		epe.wavein(!s);
		if(epe.ended) {
			ended=1;//there're 2 ways to set ended: here, lokimstop()
			iw.evtlokimend.set();
			wiom.iwm(opt.msgs[2]);////"wave done"
		}
		return 1;
	}
}

#ifdef IWTEMPLATE
template<class BE> int iwlokim<BE>::
#else
inline int iwlokim::
#endif
finishiwdata()
{
	epb.copy2tz (qbdef);
	qbdef.nshbsil=epb.nshsil();
	epe.trimsil(qbdef, epb.nframe_tz());
	return 1;
}

#ifdef IWTEMPLATE
template<class BE> int iwlokim<BE>::
#else
inline int iwlokim::
#endif
sztlokim  	()//really(sit-ze) threaded lokim
{
	wiom.iwm(opt.msgs[0]);
	crtsection cs; cs.enter();
	qbcompleted=0;
	////[1] wave open //move waveopen outside the thread
	////if(!iw.open((DWORD)this,IWProc,&(qbdef.pcm.wfex))){return 0;}
	////[2] fill in the hdr/buf's
	hbcs.sethbc(opt.nFS);
	////[3] prepare WAVEHDR hdr/buf's
	hbcs.idlesprp(iw.hwi);
	////[4] addwavein hdr/buf's to hwi
	hbcs.addifidle(iw.hwi);
	////[4a] prepare to start lokim
	iw.evtlokimend.reset();		iw.bLokImDiong=1;
	cs.leave();

	////[5] start recording
	iw.start();	//	showstatus(IW_DAN);
	////[6] wait for reset pressed or auto-endpoint done
	iw.wait2end();				cs.enter();
	////[7]  reset will cause all buf's done, nec. to mark all buf's done
	res=iw.reset(200);
	////[8] (finish to)collect wavein data
	finishiwdata();
	qbcompleted=0;
	////[9]  unprepare wavein buf, move it to IWProc
	hbcs.idlesunp(iw.hwi);
	//hbcs.all2idle();
	////res=iw.stop();//[10]stop cause only current buf done, use reset() instead
	iw.bLokImDiong=0;
	////res=iw.close();//[11] close wavein, //move waveclose outside the thread
	cs.leave();
	return 1;
}

#ifdef IWTEMPLATE
template<class BE> void iwlokim<BE>::
#else
inline void iwlokim::
#endif
ACD2opt	()//according2 opt
{
	epb.reset();epe.reset();
	epb.setDUR(opt.nbDUR(),opt.nbSIL());
	epe.setDUR(opt.neDUR(),opt.neSIL(),opt.nBLURB());
	if(qbdef.pcm.sr()!=(uint)opt.nsrt)
		qbdef.pcm.set2(opt.nsrt);
	be.setTHRESH(opt.bTHRESH,opt.eTHRESH);
	epe.setfrmsz(opt.nFS); epb.setfrmsz(opt.nFS);
	epb.msg=opt.msgs[1];
	be.manual=opt.manual;
}

#ifdef IWTEMPLATE
template<class BE> void iwlokim<BE>::
#else
inline int iwlokim::
#endif
adapt		(int nsec)
{
	//iwoption &opt=wi.opt;
	qiimbuf_ qb; iwlokim1 adapt; int k48=opt.adapt48k();
	if(k48)	qb.set48k();	else		qb.set44k();
	adapt.lokim(qb,4); // use non-threaded version
	if(qb.isOK()){
		if(k48)	qb.write("dqsds48k.wav"); else qb.write("dqsds44k.wav");
		setadapt(qb);
	}
	return 1;
}

//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////
//////////////////////////////////////////////////


#endif	////#ifndef SIMPWIO_H

