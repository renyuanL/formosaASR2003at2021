
//	vecproc.cpp
//	mostly testing routines

#include <di5base.h>

void testkthlargest()
{
  int vs[]={21,22,23,24,25,26,27,28,29,30,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
  int len=31;vector<int>v(&vs[0],&vs[len]);
  int KTH=5;//0-based, so it is actually 1more
  int val=kthlargest(v,0,len,KTH);
  chars cs; cs=val;
  cs.show("kth largest");
}

void test_valarray()
{
  double vs[]={1,2,3,4,5};int n, N=5;
  valarray<double> b,v(vs, N);
  chars cs;
  b=v;       cs=b.sum(); cs.show("should be 15");
  b=sin(v);  cs=b.sum(); cs.show();
  b=(v);     cs=v.sum(); cs.show("should be 15");
}



/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
// old peak
/////////////////////////////////////////////////////////

class peakinfo2_{public:
  vector<int> pos; vector<double>val;
  vector<int>lspan,rspan;
  vector<double>eng1sum, eng1var, eng1snr;
public:
public:
  void clear(){pos.clear();val.clear();lspan.clear();rspan.clear();eng1sum.clear();eng1var.clear();eng1snr.clear();}
public://the following is to be called from vec2peak
  template<class real> int do1(vector<real>&v, int lpos, int ppos, int rpos)
  {
	pos.push_back(ppos); val.push_back(v[ppos]); double tmp;
	lspan.push_back(ppos-lpos); rspan.push_back(rpos-ppos);
	double sum=0; for(int n=lpos; n<=rpos; n++) sum+=v[n];
	eng1sum.push_back( sum-(v[lpos]/2.0)-(v[rpos]/2.0) ); sum/=(rpos-lpos+1);
	double var=0;    for(int n=lpos; n<=rpos; n++) {tmp=v[n]-sum; var+=tmp*tmp;}
	var=var/(rpos-lpos+1-1);eng1var.push_back(var);
	eng1snr.push_back(sqrt(var)/sum);
	return 1;
  }
};
typedef peakinfo2_ peakinfo_;
template<class real>
int vec2peak(peakinfo2_&pki, vector<real>& v)
{
  uint n,N=v.size(); pki.clear();
  int up=1; int lpos=0,ppos;// peakinfo1_ pki;real sum;
  for(n=1; n<N; n++){
	if(up>0){
	  if(v[n-1]<=v[n]){++up;}
	  else{ppos=n-1;up=-1;}
	}else{
	  if(v[n-1]> v[n]){--up;}
	  else{lpos=n-1;up=1;}
	}
	if(up==-1){
	  pki.do1(v,lpos,ppos,n);
	  //apki.push_back(pki);
	}
  }
  if(up>0){ ppos=N-1; }
  pki.do1(v,lpos,ppos,N-1);
  //apki.push_back(pki);
  return 1;
}

/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
// older peak
/////////////////////////////////////////////////////////


struct peakinfo1_{
  int pos; double val;
  int lspan,rspan;
  double eng1sum;
  double eng1var;
  double eng1snr;
public:
  int span(){return lspan+rspan;}
  template<class real>  int do1(vector<real> &v, int lpos, int ppos, int rpos)
  { //input are left pos/ peak pos / right pos
	pos=ppos; val=v[ppos]; double tmp;
	lspan=ppos-lpos; rspan=rpos-ppos;
	double sum=0;    for(int n=lpos; n<=rpos; n++) sum+=v[n];
	eng1sum=sum-(v[lpos]/2.0)-(v[rpos]/2.0); sum/=(rpos-lpos+1);
	double var=0;    for(int n=lpos; n<=rpos; n++) {tmp=v[n]-sum; var+=tmp*tmp;}
	eng1var=var/(rpos-lpos+1-1);
	eng1snr=sqrt(eng1var)/(eng1sum+0.000000000000000001);
	return pos;
  }
};

template<class real>
int vec2peak(vector<peakinfo1_> &apki, vector<real>& v)
{
  uint n,N=v.size(); apki.clear(); if(v.size()<=0) return 0;
  int up=1; int lpos=0,ppos; peakinfo1_ pki;real sum;
  for(n=1; n<N; n++){
	if(up>0){
	  if(v[n-1]<=v[n]){++up;}
	  else{ppos=n-1;up=-1;}
	}else{
	  if(v[n-1]> v[n]){--up;}
	  else{lpos=n-1;up=1;}
	}
	if(up==-1){
	  pki.do1(v,lpos,ppos,n);
	  apki.push_back(pki);
	}
  }
  if(up>0){ ppos=N-1; }
  pki.do1(v,lpos,ppos,N-1);
  apki.push_back(pki);
  return 1;
}



class  	vpeakinfo_ { uint n,N;//temp. for iteration
public:	vpeakinfo_():ovecsz(0){}
//template<class real>
//		vpeakinfo_(vector<real>&v):ovecsz(v.size()){vec2peakinfo(v);}
public:
  template<class real>
  int vec2vpeakinfo(vector<real>&v){ovecsz=v.size();return vec2peak(pks,v);}
  template<class real>
  int get4(vector<real>&v){ovecsz=v.size();return vec2peak(pks,v);}
public:
  public: vector<peakinfo1_> pks;
  uint ovecsz;
//an example usage of the copy functions
//assume vpeakinfo_ vpki; and was vec2vpeakinfo()-ed
//     vector<double> r; vpki.copyval0(r);
//     barvector__(rchart,r);
public://copy function: saves some typing, and facilitate thinking in vector processing
  template<class real> int copypos   (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].pos;       return N;}
  template<class real> int copyval   (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].val;       return N;}
  template<class real> int copyspan  (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].span();    return N;}
  template<class real> int copylspan (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].lspan;     return N;}
  template<class real> int copyrspan (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].rspan;     return N;}
  template<class real> int copy1sum  (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].eng1sum;   return N;}
  template<class real> int copy1var  (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].eng1var;   return N;}
  template<class real> int copy1snr  (vector<real>& r){resize (r); for(n=0;n<N;n++)r[n]=pks[n].eng1snr;   return N;}
public://fill 0 in-between
  template<class real> int copyval0  (vector<real>& r){resize0(r); for(n=0;n<N;n++)r[pks[n].pos]=pks[n].val;       return N;}
  template<class real> int copyspan0 (vector<real>& r){resize0(r); for(n=0;n<N;n++)r[pks[n].pos]=pks[n].span();    return N;}
  template<class real> int copylspan0(vector<real>& r){resize0(r); for(n=0;n<N;n++)r[pks[n].pos]=pks[n].lspan;     return N;}
  template<class real> int copyrspan0(vector<real>& r){resize0(r); for(n=0;n<N;n++)r[pks[n].pos]=pks[n].rspan;     return N;}
  template<class real> int copy1sum0 (vector<real>& r){resize0(r); for(n=0;n<N;n++)r[pks[n].pos]=pks[n].eng1sum;   return N;}
  template<class real> int copy1var0 (vector<real>& r){resize0(r); for(n=0;n<N;n++)r[pks[n].pos]=pks[n].eng1var;   return N;}
  template<class real> int copy1snr0 (vector<real>& r){resize0(r); for(n=0;n<N;n++)r[pks[n].pos]=pks[n].eng1snr;   return N;}
protected:
  template<class real> void resize (vector<real>&r){N=pks.size();r.clear();r.resize(N,0);}
  template<class real> void resize0(vector<real>&r){N=pks.size();r.clear();r.resize(ovecsz,0);}
};

/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////






