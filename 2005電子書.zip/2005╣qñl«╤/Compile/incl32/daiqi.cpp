//
// daiqi.cpp
//
//
// daiqi.h
// 2k/12/15 IngZin Gang

#ifndef DAIQI_CPP
#define DAIQI_CPP
#include <daiqi.h>

struct dqimzet_ {
	char *zg, *di, *twb
};

//struct daiqi_node{
//		 char *id, *ty2, *twb, *di5, *ty;
// };

static dqimzet_ dqsiannvor[]={
 {" " ,"b" ,"b" }
,{" " ,"p" ,"p" }
,{"p" ,"m" ,"m_" }
,{" " ,"v" ,"v" }
,{" " ,"d" ,"d" }
,{" " ,"t" ,"t" }
,{"p" ,"n" ,"n_" }
,{" " ,"l" ,"l" }
,{" " ,"g" ,"g" }
,{" " ,"k" ,"k" }
,{"p" ,"nq","nq_"}
,{" " ,"q" ,"q" }
,{" " ,"z" ,"z" }
,{" " ,"c" ,"c" }
,{" " ,"s" ,"s" }
,{" " ,"r" ,"r" }
,{" " ,"h" ,"h" }
};

static dqimzet_ dqunvor[]={
 {" " ,"a"	,"a"}  		//2-1	,""
,{" " ,"e"	,"e"}  		//2-2	,""   
,{" " ,"i"	,"i"}  		//2-3	,""   
,{" " ,"o"	,"o"}  		//2-4	,""   
,{" " ,"or"	,"or"}  	//2-5	,""
,{" " ,"u"	,"u"}  		//2-6   ,""
,{" " ,"m"	,"_m_"}  		//2-7   ,""
,{" " ,"ng"	,"_ng_"} 		//2-8   ,""
,{" " ,"ai"	,"a i"}  	//3-1   ,""
,{" " ,"au"	,"a u"}  	//3-2   ,""
,{"a" ,"ao"	,"a u"}  	//      ,""
,{" " ,"ia"	,"i a"}  	//3-3   ,""
,{"s" ,"io"	,"i o"}  	//      ,""
,{" " ,"ior"	,"i or"} 	//3-4   ,""
,{" " ,"iu"	,"i u"}  	//3-5   ,""
,{" " ,"iau"	,"i a u"} 	//3-6   ,""
,{" " ,"ua"	,"u a"}  	//3-7   ,""
,{" " ,"ue"	,"u e"}  	//3-8   ,""
,{" " ,"ui"	,"u i"}  	//3-9   ,""
,{" " ,"uai"	,"u a i"} 	//3-10  ,""
,{" " ,"ann"	,"ann"} 	//4-1   ,""
,{" " ,"enn"	,"enn"} 	//4-2   ,""
,{" " ,"inn"	,"inn"} 	//4-3   ,""
,{" " ,"onn"	,"onn"} 	//4-4   ,""
,{"p" ,"ornn"	,"ornn"} 	//      ,""
,{"p" ,"unn"	,"unn"} 	//      ,""
,{" " ,"ainn"	,"ann inn"} 	//4-5   ,""
,{" " ,"aunn"	,"ann unn"} 	//4-6   ,""
,{" " ,"iann"	,"inn ann"} 	//4-7   ,""
,{" " ,"ionn"	,"inn onn"} 	//4-8   ,""
,{" " ,"iunn"	,"inn unn"} 	//4-9   ,""
,{" " ,"iaunn"	,"inn ann unn"}	//4-10  ,""
,{" " ,"uann"	,"unn ann"}  	//4-11  ,""
,{" " ,"uenn"	,"unn enn"}  	//4-12  ,""
,{" " ,"uinn"	,"unn inn"}  	//4-13  ,""
,{" " ,"uainn"	,"unn ann inn"}	//4-14  ,""
,{" " ,"am"	,"a _m"}  	//5-1   ,""
,{" " ,"im"	,"i _m"}  	//5-2   ,""
,{" " ,"om"	,"o _m"}  	//5-3   ,""
,{" " ,"iam"	,"i a _m"} 	//5-4   ,""
,{" " ,"an"	,"a _n"}  	//5-5   ,""
,{" " ,"en"	,"e _n"}  	//5-6   ,""
,{"g" ,"ian"	,"i a _n"}	//      ,""
,{"s" ,"ien"	,"i e _n"}	//      ,""
,{" " ,"in"	,"i _n"}  	//5-7   ,""
,{" " ,"un"	,"u _n"}  	//5-8   ,""
,{" " ,"uan"	,"u a _n"} 	//5-9   ,""
,{" " ,"ang"	,"a _ng"} 	//5-10  ,""
,{" " ,"ing"	,"i _ng"} 	//5-11  ,""
,{"a" ,"irng"	,"i _ng"}	//      ,""
,{"a" ,"iorng"	,"i _ng"}	//      ,""
,{"a" ,"ieng"	,"i _ng"}	//      ,""
,{" " ,"ong"	,"o _ng"} 	//5-12  ,""
,{" " ,"iang"	,"i a _ng"} 	//5-13  ,""
,{" " ,"iong"	,"i o _ng"} 	//5-14  ,""
,{" " ,"uang"	,"u a _ng"} 	//5-15  ,""
};

//	,""

static dqimzet_ dqdikle[]={
 {" " ,"" 	,""}
,{" " ,"ma" 	,"m_ ann"}
,{" " ,"me" 	,"m_ enn"}
,{" " ,"mi" 	,"m_ inn"}
,{" " ,"mo" 	,"m_ onn"}
,{" " ,"mor" 	,"m_ ornn"}
,{" " ,"mu" 	,"m_ unn"}
,{" " ,"mai" 	,"m_ ann inn"}
,{" " ,"mau" 	,"m_ ann unn"}
,{" " ,"mia" 	,"m_ inn ann"}
,{" " ,"mior"	,"m_ inn ornn"	}
,{" " ,"miu" 	,"m_ inn unn"}
,{" " ,"mia" 	,"m_ inn ann"}
,{" " ,"mua" 	,"m_ unn ann"}
,{" " ,"mue" 	,"m_ unn enn"}
,{" " ,"mui" 	,"m_ unn inn"}
,{" " ,"muai"	,"m_ unn ann inn"	}
//
,{" " ,"vann" 	,"m_ ann"}
,{" " ,"venn" 	,"m_ enn"}
,{" " ,"vinn" 	,"m_ inn"}
,{" " ,"vonn" 	,"m_ onn"}
,{" " ,"vornn" 	,"m_ ornn"}
,{" " ,"vunn" 	,"m_ unn"}
,{" " ,"vainn" 	,"m_ ann inn"}
,{" " ,"vaunn" 	,"m_ ann unn"}
,{" " ,"viann" 	,"m_ inn ann"}
,{" " ,"viornn"	,"m_ inn ornn"	}
,{" " ,"viunn" 	,"m_ inn unn"}
,{" " ,"viann" 	,"m_ inn ann"}
,{" " ,"vuann" 	,"m_ unn ann"}
,{" " ,"vuenn" 	,"m_ unn enn"}
,{" " ,"vuinn" 	,"m_ unn inn"}
,{" " ,"vuainn"	,"m_ unn ann inn"	}
//
,{" " ,"na" 	,"n_ ann"}
,{" " ,"ne" 	,"n_ enn"}
,{" " ,"ni" 	,"n_ inn"}
,{" " ,"no" 	,"n_ onn"}
,{" " ,"nor" 	,"n_ ornn"}
,{" " ,"nu" 	,"n_ unn"}
,{" " ,"nai" 	,"n_ ann inn"}
,{" " ,"nau" 	,"n_ ann unn"}
,{" " ,"nia" 	,"n_ inn ann"}
,{" " ,"nior"	,"n_ inn ornn"	}
,{" " ,"niu" 	,"n_ inn unn"}
,{" " ,"nia" 	,"n_ inn ann"}
,{" " ,"nua" 	,"n_ unn ann"}
,{" " ,"nue" 	,"n_ unn enn"}
,{" " ,"nui" 	,"n_ unn inn"}
,{" " ,"nuai"	,"n_ unn ann inn"	}
//
,{" " ,"nqa" 	,"nq_ ann"}
,{" " ,"nqe" 	,"nq_ enn"}
,{" " ,"nqi" 	,"nq_ inn"}
,{" " ,"nqo" 	,"nq_ onn"}
,{" " ,"nqor" 	,"nq_ ornn"}
,{" " ,"nqu" 	,"nq_ unn"}
,{" " ,"nqai" 	,"nq_ ann inn"}
,{" " ,"nqau" 	,"nq_ ann unn"}
,{" " ,"nqia" 	,"nq_ inn ann"}
,{" " ,"nqior"	,"nq_ inn ornn"	}
,{" " ,"nqiu" 	,"nq_ inn unn"}
,{" " ,"nqia" 	,"nq_ inn ann"}
,{" " ,"nqua" 	,"nq_ unn ann"}
,{" " ,"nque" 	,"nq_ unn enn"}
,{" " ,"nqui" 	,"nq_ unn inn"}
,{" " ,"nquai"	,"n1_ unn ann inn"	}
//
,{" " ,"qann" 	,"nq_ ann"}
,{" " ,"qenn" 	,"nq_ enn"}
,{" " ,"qinn" 	,"nq_ inn"}
,{" " ,"qonn" 	,"nq_ onn"}
,{" " ,"qornn" 	,"nq_ ornn"}
,{" " ,"qunn" 	,"nq_ unn"}
,{" " ,"qainn" 	,"nq_ ann inn"}
,{" " ,"qaunn" 	,"nq_ ann unn"}
,{" " ,"qiann" 	,"nq_ inn ann"}
,{" " ,"qiornn"	,"nq_ inn ornn"	}
,{" " ,"qiunn" 	,"nq_ inn unn"}
,{" " ,"qiann" 	,"nq_ inn ann"}
,{" " ,"quann" 	,"nq_ unn ann"}
,{" " ,"quenn" 	,"nq_ unn enn"}
,{" " ,"quinn" 	,"nq_ unn inn"}
,{" " ,"quainn"	,"n1_ unn ann inn"	}
//
};


static dqimzet_ dqimso[]={
 {" " ,"b" 	}
,{" " ,"p" 	}
,{" " ,"m_" 	}
,{" " ,"v" 	}
,{" " ,"d" 	}
,{" " ,"t" 	}
,{" " ,"n_" 	}
,{" " ,"l" 	}
,{" " ,"g" 	}
,{" " ,"k" 	}
,{" " ,"nq_"	}
,{" " ,"q" 	}
,{" " ,"z" 	}
,{" " ,"c" 	}
,{" " ,"s" 	}
,{" " ,"r" 	}
,{" " ,"h" 	}
,{" " ,"a" 	}
,{" " ,"e" 	}
,{" " ,"i" 	}
,{" " ,"o" 	}
,{" " ,"or" 	}
,{" " ,"u" 	}
,{" " ,"_m_" 	}
,{" " ,"_ng_" 	}
,{" " ,"ann" 	}
,{" " ,"enn" 	}
,{" " ,"inn" 	}
,{" " ,"onn" 	}
,{" " ,"ornn" 	}
,{" " ,"unn" 	}
,{" " ,"_m" 	}
,{" " ,"_n" 	}
,{" " ,"_ng" 	}
};



//////////////////////////////////////
//////////////////////////////////////
// class daiqibendiau
      
daiqibendiau_ dqbendiau;


char*	daiqibendiau_::kqd2(char* py2)
{
	tkd=py2;str_delbutdigits(tkd.s);
	smpbendiaubak(tmp, tkd);
	dk2k(tkd.s); dk2k(tmp.s); if(tkd!=tmp) {tkd+=" ";tkd+=tmp;}
	return tkd.s;
}

char*	daiqibendiau_::drd2(char* py2)
{
	tdd=py2;str_delbutdigits(tdd.s);
	dk2d(tdd.s); tmp=tdd; str_tr(tmp.s,'6','7');
	if(tdd!=tmp) {tdd+=" ";tdd+=tmp;}
	return tdd.s;
}


int	daiqibendiau_::maybegoodpy1	(char* py1)
{
	int n012; char* t=py1; if(!(t&&t[0]))return 0;
	while(*t){ n012=is012(t);	if(n012>1) return 0; t++; }
	t=py1;
	while(*t){ if(isdigit(*t)) break;	t++; }
	if(t==py1) return 0; //no base pinim at all
	int nd=0;
	if(isdigit(*t)){
		t++; nd++; if(isdigit(*t)) { t++;nd++;}
		if(t[0]) return 0; // has some after 2 digits
		return nd; // return num of diaugi
	}
	return 0; // has no digits for diau
}

int	daiqibendiau_::maybegoodpys	(char* pys)
{
	charspp spp1, spp2; int nd; int bad=0;
	spp1.set2Ncut(pys,'|');
	for(int i=0; i<spp1.size();i++){
		spp2.set2Nhunhanlor(spp1[i]);
		for(int n=0; n<spp2.size();n++){
			nd=maybegoodpy1(spp2[n]);
			if(!nd){MessageBox(0,"daiqi bendiau: not 2diau",pys, MB_OK);bad++;}
		}
	}
	return bad;
}

void daiqibendiau_::smpbd(chars&tgt, chars&src, int islam)
{ // input must be of the form ang52 or ang52ang55/ang52-ang55
	//if(!tgt||!src) return;
	tgt.clear();
	char* t=src.s; int n012;  char prev;
	while(*t) {
		n012=is012(t);
		if( (t[n012]==0) )
		{tgt.app(t,n012);t+=n012;continue;}
		if( (n012!=1)||(!isdigit(*t)) )
		{tgt.app(t,n012);t+=n012;continue;}
		prev=*t; t++;
		if(!isdigit(*t)) {tgt.clear(); break;}// format not fit
		tgt.app(prev);
		if(*t==prev) {// vor bendiau
			if(prev=='6') tgt.app('7');
			else tgt.app(*t);
			t++; continue;
		}
		char c;
		switch(*t){
		case '1':tgt.app("1"); break;
		case '2':if(prev=='5')c=(islam)?'2':'3';else c='2';tgt.app(c); break;
		case '3':if(prev=='5')c=(islam)?'2':'3';else c='3';tgt.app(c); break;
		case '4':c='4'; tgt.app(c); break;
		case '5':c='5'; tgt.app(c); break; //sould not happen, but do it anyway
		case '6':c='6'; tgt.app(c); break;
		//case '6':c=(prev=='6')?((islam)?'6':'7'):'8'; tgt->app(c); break;
		case '7':tgt.app("7"); break;
		case '8':tgt.app("8"); break;
		default :tgt.app(*t);
		}
		t++;
	}
}
// class daiqibendiau
//////////////////////////////////////
//////////////////////////////////////



class Nbo_   { char**dt_; int SZ; int N; int SZ; char buf[30],im0[30],imt[20];
public:
	Nbo_() { init20(); }
public:
	void sort() {
		qsort(dq, SZ, sizeof(daiqi_node), wis_daiqinode1);
	}
	void  init20() { SZ=sizeof(daiqi)/sizeof(daiqi_node);
				dq = new daiqi_node[SZ];
				for(int sz=0; sz<SZ;sz++) dq[sz]=(daiqi[sz]);
				SZ-=2; sort();
	}
public:
	int	huntone(char* src, char* iz0, char* izt) {
		iz0[0]=0; izt[0]=0;
		int len=strlen(src); if(len>25) return 0;
		int ntone=0; while(isdigit(*src)) ntone++;
		if(ntone>2) return 0;
		char *s, *t;
		s=src; t=iz0;		while(*s){if(!isdigit(*s))*t++=*s; s++;}*t=0;
		s=src; t=izt;		while(*s){if( isdigit(*s))*t++=*s; s++;}*t=0;
		return 1;
	}
	int lower(char* iz1) {	//static char buf[30]; buf[0]=0;
		if(huntone(iz1, im0, imt)==0) return -1;
		int lo=0, up=SZ, md, res=0;
		res=strcmp(im0, dq[0]   .di5); if(res< 0) {return -1;}
		res=strcmp(im0, dq[SZ-1].di5); if(res> 0) {return -1;}
		while(lo<up-1) {
			md=(lo+up)/2;
			if(strcmp(im0,dq[md].di5)<0) up=md;else lo=md;
		}
		if(strcmp(im0,dq[lo].di5)!=0) return -1;
		return lo;
	}
	char* iz12twbat(char* iz1) {	buf[0]=0;
		int lo=lower(iz1);
		if(lo>=0) strcpy(buf, dq[lo].ty);
		if(imt[0]) strcat(buf, imt);
		return buf;
	}
	char* iz12imso(char* iz1, char sep, int keeptone) {	buf[0]=0;
		int lo=lower(iz1);
		if(lo>=0) strcpy(buf, dq[lo].ty);
		char*t=buf; if(sep!='-') while(*t) {if(*t=='-')*t=sep; t++;}
		if(keeptone) if(imt[0]) { *t++=sep; strcat(buf, imt); }
		return buf;
	}
	char* iz12imso1(char* iz1) {	static char buf[30]; buf[0]=0;
		int lo=0, up=SZ, md, res=0;
		res=strcmp(iz1, dq[0]   .di5); if(res< 0) {return buf;}
		res=strcmp(iz1, dq[SZ-1].di5); if(res> 0) {return buf;}
		while(lo<up-1) {
			md=(lo+up)/2;
			if(strcmp(iz1,dq[md].di5)<0) up=md;else lo=md;
		}
		if(strcmp(iz1,dq[lo].di5)==0) strcpy(buf, dq[lo].ty);
		return buf;
	}
}iz12twbat;







#endif //#ifndef DAIQI_CPP



