//
//	di5vp.cc
//	vector processing
//	.h  	contains only prototype and comment only
//	.cc 	contains template implementation, included at end of .h
//	.cpp 	contains other    implementation, add-to project
//

#ifndef DI5VP_HH
#define DI5VP_HH
// to be included directly by di5vp.h

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
TPCI(P) double calm_::L1 	(P beg, P end)
{
	double tot=0;
	for(; beg!=end; ++beg){
		if((*beg)<0) tot-=(*beg); else tot+=(*beg);
	}
	return tot;
}
TPCI(P) double calm_::L22	(P beg, P end)
{
	double tot=0;
	for(; beg!=end; ++beg){tot+=(*beg)*(*beg);}
	return tot;
}
TPCI(P) double calm_::sum	(P beg, P end)
{
	if(end-beg<1) return 0;
	P it; double sum=0;
	for(it=beg; it<end;++it) {
		sum+=(*it);
	}
	return sum;
}
TPCI(R) R	   calm_::max_	(R*beg, R*end)
{
	R val; size_t ndx;	maxndx(beg,end,val,ndx);
	return val;
}
TPCI(R) R	   calm_::min_	(R*beg, R*end)
{
	R val; size_t ndx;	minndx(beg,end,val,ndx);
	return val;
}
TPCI(R) size_t calm_::maxndx	(R*beg, R*end)
{
	R val; size_t ndx;	maxndx(beg,end,val,ndx);
	return ndx;
}
TPCI(R) size_t calm_::minndx	(R*beg, R*end)
{
	R val; size_t ndx;	minndx(beg,end,val,ndx);
	return ndx
}
TPCI(R) bool calm_::maxndx(R*beg, R*end, R&val, size_t& ndx)
{
	size_t n,N=end-beg;if(N<=0) return false;
	R* v=beg;	ndx=0; val=v[0];
	for(n=1;n<N;++n)if(val<v[n]){val=v[n];ndx=n;}
	return true;
}
TPCI(R) bool calm_::minndx(R*beg, R*end, R&val, size_t& ndx)
{
	size_t n,N=end-beg;if(N<=0) return false;
	R* v=beg;	ndx=0; val=v[0];
	for(n=1;n<N;++n)if(val>v[n]){val=v[n];ndx=n;}
	return true;
}
TPCI(P) size_t calm_::npos	(P beg, P end)
{//* num of positive
	size_t n=0; if(end<=beg) return n;
	for(;beg!=end;++beg) if((*beg)>0) ++n;
	return n;
}
TPCI(P) size_t calm_::nneg	(P beg, P end)
{//* num of negative
	size_t n=0; if(end<=beg) return n;
	for(;beg!=end;++beg) if((*beg)<0) ++n;
	return n;
}
TPCI(R) bool   calm_::maxndx(vector  <R>&v, R&val, size_t& ndx){return maxndx	(pbeg(v),pend(v),val,ndx);}
TPCI(R) bool   calm_::minndx(vector  <R>&v, R&val, size_t& ndx){return minndx	(pbeg(v),pend(v),val,ndx);}
TPCI(R) bool   calm_::maxndx(valarray<R>&v, R&val, size_t& ndx){return maxndx	(pbeg(v),pend(v),val,ndx);}
TPCI(R) bool   calm_::minndx(valarray<R>&v, R&val, size_t& ndx){return minndx	(pbeg(v),pend(v),val,ndx);}

TPCI2(P1,P2) double calm_::dot	(P1 beg1, P2 beg2, size_t N)
{
	if(N<=0||!beg1||!beg2) return 0;
	double tmp=0;size_t n;
	for(n=0;n<N;n++)
		tmp+=beg1[n]*beg2[n];
	return tmp;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
template<class vitr> inline int ucCounter::
set(valarray<int>& cnts, valarray<float>&bdry, vitr beg, vitr end, int nbands)
{
//	double mi=di5::min_element(vi),MA=di5::max_element(vi);
	size_t SSZ=end-beg; if(SSZ<=0) return 0;
	double mi=calm.min_(beg,end),MA=calm.max_(beg,end);
	if(nbands<0) {
		nbands=sqrt(SSZ*1.0)*0.75;
		if(nbands<5) nbands=5;
	}
	double delta=(MA-mi+10e-7)/nbands; size_t n,N;
	bdry.resize(nbands+1);N=bdry.size();
	for(n=0;n<N;++n)
		bdry[n]=mi+delta*n;
	cnts.resize(nbands);N=cnts.size();for(n=0;n<N;++n)cnts[n]=0;
	vitr vi=beg;
	N=SSZ;//vi.size();
	for(n=0;n<N;++n)
		{int t=(vi[n]-mi)/delta; cnts[t]+=1;}
	return N;
}

template<class T> inline int frqCounter<T>::
set(map<T,int>& frqs, T* beg, T* end)
{
	size_t SSZ=end-beg; if(SSZ<=0) return 0;
	T* vi=beg;
	size_t n,N=SSZ;//vi.size();
	for(n=0; n<N; ++n){
		frqs[vi[n]]++;
	}
	return N;
}

/*
template<class T> template<class vitr> inline int frqCounter<T>::
set(map<T,int>& frqs, vitr beg, vitr end)
{
	size_t SSZ=end-beg; if(SSZ<=0) return 0;
	vitr vi=beg;
	size_t n,N=SSZ;//vi.size();
	for(n=0; n<N; ++n){
		frqs[vi[n]]++;
	}
	return N;
}


template<class VEC> inline int ucCounter::
set(valarray<int>& cnts, valarray<float>&bdry, VEC &vi, int nbands)
{
//	double mi=di5::min_element(vi),MA=di5::max_element(vi);
	double mi=calm.min(vi),MA=calm.max(vi);
	if(nbands<0) {
		nbands=sqrt(vi.size()*1.0)*0.75;
		if(nbands<5) nbands=5;
	}
	double delta=(MA-mi+10e-7)/nbands; size_t n,N;
	bdry.resize(nbands+1);N=bdry.size();
	for(n=0;n<N;++n)
		bdry[n]=mi+delta*n;
	cnts.resize(nbands);N=cnts.size();for(n=0;n<N;++n)cnts[n]=0;
	N=vi.size();
	for(n=0;n<N;++n)
		{int t=(vi[n]-mi)/delta; cnts[t]+=1;}
	return N;
}

template<class T> template<class VEC> inline int frqCounter<T>::
set(map<T,int>& frqs, VEC &vi)
{
	size_t n,N=vi.size();
	for(n=0; n<N; ++n){
		frqs[vi[n]]++;
	}
	return N;
}


*/
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
template<class real> inline
void partition(vector<real>&v, size_t low, size_t hai, size_t& ndxpivot)
{
  size_t i,j;
  size_t mid=(low+hai)/2; swap(v[low],v[mid]);
  real val=v[low];
  j=low;
  for(i=low+1; i< hai; i++){// i < hai, since 0-based
	if(v[i]<val){
	  j++;
	  swap(v[i],v[j]);
	}
  }
  ndxpivot=j;
  swap(v[low],v[ndxpivot]);
}

//////////////////////////////////////////////////////
template<class real> inline
real kthlargest(vector<real>&v, size_t low, size_t hai, size_t K)
{
  if(low==hai)
	return v[low];
  size_t ndxpivot;
  partition(v,low,hai,ndxpivot);
  if(K==ndxpivot)
	return v[ndxpivot];
  if(K<ndxpivot)
	return kthlargest(v,low,ndxpivot-1,K);
  else
	return kthlargest(v,ndxpivot+1,hai,K);
}

template<class real> inline
real kthlargest(vector<real>&v, size_t K)
{
  return kthlargest(v,0,v.size(),K);
}

//////////////////////////////////////////////////////
template<class real> inline
real quantile(vector<real>&v, float p)
{
  if(p>1) p=1; if(p<0) p=0;  uint K=uint(p*v.size());
  return kthlargest(v,0,v.size(),K);
}

template<class real> inline
int quantile(vector<real>&v, real&vp1, real&vp2, float p1, float p2)
{
  vp1=kthlargest(v,p1);
  vp2=kthlargest(v,p2);
  return 2;
}

template<class real> inline
real quantile(vecvec<real>&vv, float p1)
{
  vector<real> v; v.resize(vv.nfrm()*vv.ncmp(),0); uint pos=0;
  for(uint tt=0;tt<vv.nfrm();tt++)for(uint cc=0;cc<vv.ncmp();cc++)v[pos++]=vv(tt,cc);
  return quantile(v,p1);
}

template<class real> inline
int quantile(vecvec<real>&vv, real& vvp1, real& vvp2, float p1, float p2)
{
  vector<real> v; v.resize(vv.nfrm()*vv.ncmp(),0); uint pos=0;
  for(uint tt=0;tt<vv.nfrm();tt++)for(int cc=0;cc<vv.ncmp();cc++)v[pos++]=vv(tt,cc);
  return quantile(v,vvp1,vvp2,p1,p2);
}






//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
template<class frwditer> inline
int zerocross(frwditer beg, frwditer end)
{
	int cnt=0;
	int sgn; sgn=((*beg)<0)?-1:1;
	for(beg++; beg!=end; ++beg){
		if(sgn<0){
			if((*beg)<0) continue;
			else {sgn=1; ++cnt;}
		}else{
			if((*beg)>0) continue;
			else {sgn=-1;++cnt;}
		}
	}
	return cnt;
}

template<class real> inline
int zerocross(vector<real>& v)
{
	if(v.size()<1)return 0;
	return zerocross(v.begin(),v.end());
}
template<class real> inline
int zerocross(valarray<real>& v)
{
	if(v.size()<1)return 0;
	return zerocross(&v[0],(&v[0])+v.size());
}





//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
template<class vitr> inline
double avgvar(double& mean, double& var, vitr beg, vitr end)
{
	mean=var=0;
	if(end-beg<2) return 0;
	size_t N=end-beg;
	double tmp; vitr it;
	double sum=0; for(it=beg; it<end;++it) { sum+=(*it);		} mean=sum/N;
	double tot=0; for(it=beg; it<end;++it) { tmp =(*it)-mean; tot+=tmp*tmp; }
	var=tot/(N-1);
	return 2;
}

TPC(real)	inline
double avgvar(double& mean, double& var, vector  <real>& v)
{
	return avgvar(mean,var,v.begin(),v.end());
}
TPC(real)	inline
double avgvar(double& mean, double& var, valarray<real>& v)
{
	if(v.size()<2)return 0;
	return avgvar(mean,var, &v[0],(&v[0])+v.size());
}



template<class vitr> inline
double avg(vitr beg, vitr end)
{
	if(end-beg<1) return 0;
	size_t N=end-beg;
	vitr it;	double vg=0;
	double sum=0; for(it=beg; it<end;++it) { sum+=(*it);		}
	vg=sum/N;
	return vg;
}

template<class vitr> inline
double sum(vitr beg, vitr end)
{
	if(end-beg<1) return 0;
	vitr it; double sum=0;
	for(it=beg; it<end;++it) {
		sum+=(*it);
	}
	return sum;
}

template<class vitr> inline
double var(vitr beg, vitr end)
{
	double mn, vr;
	avgvar(mn,vr, beg, end);
	return vr;
}
TPC(real) inline	double sum(vector<real>& v){return sum(v.begin(),v.end());}
TPC(real) inline	double avg(vector<real>& v){return avg(v.begin(),v.end());}
TPC(real) inline	double var(vector<real>& v){return var(v.begin(),v.end());}
TPC(real) inline	double sum(valarray<real>& v){return sum(&v[0],&v[0]+v.size());}
TPC(real) inline	double avg(valarray<real>& v){return avg(&v[0],&v[0]+v.size());}
TPC(real) inline	double var(valarray<real>& v){return var(&v[0],&v[0]+v.size());}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
TPC(vitr) double L1(vitr beg, vitr end)
{
	double tot=0;
	for(; beg!=end; ++beg){
		if((*beg)<0) tot-=(*beg); else tot+=(*beg);
	}
	return tot;
}
TPC(real) inline	double L1(vector  <real>& v){return L1(v.begin(),v.end());}
TPC(real) inline	double L1(valarray<real>& v){return L1(&v[0],&v[0]+v.size());}

TPC(vitr) inline	double L22(vitr beg, vitr end)
{
	double tot=0;
	for(; beg!=end; ++beg){tot+=(*beg)*(*beg);}
	return tot;
}
TPC(real) inline	double L22(vector  <real>& v){return L22(v.begin(),v.end());}
TPC(real) inline	double L22(valarray<real>& v){return L22(&v[0],&v[0]+v.size());}


TPC2(R,vitr) inline bool
getminmax (R& m, R& M, vitr beg, vitr end)
{
	m=M=0; if(end<=beg) return false;
	m=M=(*beg); R tmp;
	for(;beg!=end;++beg){
		tmp=(*beg);
		if(m>tmp)m=tmp;
		if(M<tmp)M=tmp;
	}
	return true;
}
TPC(R) inline	bool getminmax(R& m, R& M, vector  <R>& v){return getminmax(m,M,v.begin(),v.end());}
TPC(R) inline	bool getminmax(R& m, R& M, valarray<R>& v){return getminmax(m,M,&v[0],&v[0]+v.size());}

/*
TPC(R) inline int
getminmax (vector<R>&v, R& vmin, R& vmax)
{
	size_t n,N=v.size();
	vmin=vmax=0; if(N<=0) return 0;
	vmax=v[0]; vmin=v[0];
	R tmp; int t, c;
	for(n=0;n<N;++n){
		tmp=v[n];
		if(vmax<tmp) vmax=tmp;
		if(vmin>tmp) vmin=tmp;
	}
	return 1;
}
*/
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
template<class real1, class real2, class real3> inline
int setseq(vector<real1>&v, real2 beg, real3 end)
{
	uint n,N=(end-beg+1);
	v.resize(N);
	for(n=0; n<N; n++){
		v[n]=beg;
		beg++;
	}
	return N;
}


template<class real1, class real2, class real3> inline
int setseq(valarray<real1>&v, real2 beg, real3 end)
{
	uint n,N=(end-beg+1);
	v.resize(N);
	for(n=0; n<N; n++){
		v[n]=beg;
		beg++;
	}
	return N;
}

template<class real> inline
int setseq(vector<real>&v, real beg, real end, real delta)
{
	uint n,N=(end-beg+delta)/delta;
	v.resize(N);
	for(n=0; n<N; n++){
		v[n]=beg;
		beg+=delta;
	}
	return N;
}

template<class real> inline
int setseq(valarray<real>&v, real beg, real end, real delta)
{
	uint n,N=(end-beg+delta)/delta;
	v.resize(N);
	for(n=0; n<N; n++){
		v[n]=beg;
		beg+=delta;
	}
	return N;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
template<class real>
struct pair_ri{  real r; int i;
	   pair_ri(){     r=0;   i=0;}
};

template<class real>
struct lispair_ri{ //left is smaller
	int operator()(const pair_ri<real>& l, const pair_ri<real>& r)
	{if(l.r<r.r)return 1; return 0;}//(l.d>r.d)?1:0;}
};

template<class vitr> inline
int to2rank(vector<int> & r, vitr beg, vitr end)
{
	typedef double real;
	vector<pair_ri<real> > w;
	vitr it;	pair_ri<real>  ri;
	for(it=beg;it!=end; ++it){
		ri.r=(*it); ri.i=it-beg;
		w.push_back(ri);
	}
	sort(w.begin(), w.end(), lispair_ri<real>() );
	size_t n,N=w.size();
	r.resize(N);
	for(n=0; n<N; n++){
		r[w[n].i]=n;
	}
	return 1;
}

TPC(real) inline	int to2rank(vector<int>& r, vector  <real>& v){return to2rank(r,v.begin(),v.end());}
TPC(real) inline	int to2rank(vector<int>& r, valarray<real>& v){return to2rank(r,&v[0],&v[0]+v.size());}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


template<class vitr> inline
int to2lmaxpos(vector<int> & r, vitr beg, vitr end)
{
  int n,N=end-beg; vitr v=beg;
  r.clear(); r.resize(N,0);
  int up=1;
  for(n=1; n<N; n++){
	if(up>0){
	  if(v[n-1]<=v[n]){++up;}
	  else{r[n-1]=1; up=-1;}
	}else{
	  if(v[n-1]> v[n]){--up;}
	  else{up=1;}
	}
  }
  if(up>0)r[N-1]=1;
  return 1;
}
TPC(real) inline	int to2lmaxpos(vector<int>& r, vector  <real>& v){return to2lmaxpos(r,v.begin(),v.end());}
TPC(real) inline	int to2lmaxpos(vector<int>& r, valarray<real>& v){return to2lmaxpos(r,&v[0],&v[0]+v.size());}

////////////////////////////////////////////////////////
template<class vitr> inline
int to2locmpos(vector<int> & r, vitr beg, vitr end)
{
  int n,N=end-beg; vitr v=beg;
  r.clear(); r.resize(N,0);
  int up=0; int ntie=0;
  for(n=1; n<N; n++){
	if(up>0){
	  if(v[n-1]<=v[n]){++up;}
	  else{r[n-1]=1; up=-1;}
	}else if(up<0){
	  if(v[n-1]>=v[n]){--up;}
	  else{r[n-1]=-1;up=1;}
	}else{
	  if	 (v[n-1]>v[n]){r[n-1]= 1;up=-1;ntie=0;}
	  else if(v[n-1]<v[n]){r[n-1]=-1;up= 1;ntie=0;}
	  else ntie++;
	}
  }
  if(up>0)r[N-1]=1;else if(up<0)r[N-1]=-1;
  return 1;
}
TPC(real) inline	int to2locmpos(vector<int>& r, vector  <real>& v){return to2locmpos(r,v.begin(),v.end());}
TPC(real) inline	int to2locmpos(vector<int>& r, valarray<real>& v){return to2locmpos(r,&v[0],&v[0]+v.size());}

////////////////////////////////////////////////////////
TPCI(vitr) int count_pos(vitr beg, vitr end)
{
	int n=0; if(end<=beg) return n;
	for(;beg!=end;++beg) if((*beg)>0) n++;
	return n;
}
TPCI(vitr) int count_neg(vitr beg, vitr end)
{
	int n=0; if(end<=beg) return n;
	for(;beg!=end;++beg) if((*beg)<0) n++;
	return n;
}
TPCI(R) int count_pos(vector  <R>&v){return count_pos(v.begin(),v.end());}
TPCI(R) int count_neg(vector  <R>&v){return count_neg(v.begin(),v.end());}
TPCI(R) int count_pos(valarray<R>&v){return count_pos(&v[0],&v[0]+v.size());}
TPCI(R) int count_neg(valarray<R>&v){return count_neg(&v[0],&v[0]+v.size());}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
TPCI2(R1, R2) bool operator<<(vector  <R1>& lhs, vector  <R2> &rhs)
{
	lhs.resize(rhs.size()); size_t n,N=rhs.size();
	for(n=0;n<N;++n) lhs[n]+=rhs[n];
	return true;
}
TPCI2(R1, R2) bool operator<<(valarray<R1>& lhs, valarray<R2> &rhs)
{
	lhs.resize(rhs.size()); size_t n,N=rhs.size();
	for(n=0;n<N;++n) lhs[n]+=rhs[n];
	return true;
}
TPCI2(R1, R2) bool operator<<(vector  <R1>& lhs, valarray<R2> &rhs)
{
	lhs.resize(rhs.size()); size_t n,N=rhs.size();
	for(n=0;n<N;++n) lhs[n]+=rhs[n];
	return true;
}
TPCI2(R1, R2) bool operator<<(valarray<R1>& lhs, vector  <R2> &rhs)
{
	lhs.resize(rhs.size()); size_t n,N=rhs.size();
	for(n=0;n<N;++n) lhs[n]+=rhs[n];
	return true;
}

////////////////////////////////////////////////////////
TPCI2(R1, R2) bool operator>>(vector  <R1>& lhs, vector  <R2> &rhs)
{
	rhs.resize(lhs.size()); size_t n,N=lhs.size();
	for(n=0;n<N;++n) rhs[n]=lhs[n];
	return true;
}
TPCI2(R1, R2) bool operator>>(valarray<R1>& lhs, valarray<R2> &rhs)
{
	rhs.resize(lhs.size()); size_t n,N=lhs.size();
	for(n=0;n<N;++n) rhs[n]=lhs[n];
	return true;
}
TPCI2(R1, R2) bool operator>>(vector  <R1>& lhs, valarray<R2> &rhs)
{
	rhs.resize(lhs.size()); size_t n,N=lhs.size();
	for(n=0;n<N;++n) rhs[n]=lhs[n];
	return true;
}
TPCI2(R1, R2) bool operator>>(valarray<R1>& lhs, vector  <R2> &rhs)
{
	rhs.resize(lhs.size()); size_t n,N=lhs.size();
	for(n=0;n<N;++n) rhs[n]=lhs[n];
	return true;
}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
TPC(R) inline bool sinugen_::
add (vector<R>&v, double amp, double frq, double phs)
{//*add sinusoid(cosine w/ phase)
	return add	(v.begin(), v.end(), amp, frq, phs);
}
TPC(R) inline bool sinugen_::
addc(vector<R>&v, double amp, double frq)
{//*add cosine
	return addc	(v.begin(), v.end(), amp, frq);
}
TPC(R) inline bool sinugen_::
adds(vector<R>&v, double amp, double frq)
{//*add sine
	return adds	(v.begin(), v.end(), amp, frq);
}
TPC(R) inline bool sinugen_::
addn(vector<R>&v, double amp)
{//*add gaussian white noise
	return addn	(v.begin(), v.end(), amp);
}
TPC(R) inline bool sinugen_::
addh(vector<R>&v, double amp, double frq, int nhar)
{//*add harmonic
	return addh	(v.begin(), v.end(), amp, frq, nhar);
}
////////////////////////////////////////////////////////
TPC(R) inline bool sinugen_::
add (valarray<R>&v, double amp, double frq, double phs)
{//*add sinusoid(cosine w/ phase)
	return add	(&v[0],&v[0]+v.size(), amp, frq, phs);
}
TPC(R) inline bool sinugen_::
addc(valarray<R>&v, double amp, double frq)
{//*add cosine
	return addc	(&v[0],&v[0]+v.size(), amp, frq);
}
TPC(R) inline bool sinugen_::
adds(valarray<R>&v, double amp, double frq)
{//*add sine
	return adds	(&v[0],&v[0]+v.size(), amp, frq);
}
TPC(R) inline bool sinugen_::
addn(valarray<R>&v, double amp)
{//*add gaussian white noise
	return addn	(&v[0],&v[0]+v.size(), amp);
}
TPC(R) inline bool sinugen_::
addh(valarray<R>&v, double amp, double frq, int nhar)
{//*add harmonic
	return addh	(&v[0],&v[0]+v.size(), amp, frq, nhar);
}
////////////////////////////////////////////////////////
TPC(vitr) inline bool sinugen_::
add (vitr beg, vitr end, double amp, double frq, double phs)
{
	double fd=frq*(1.0/sprate);//frq*delta
	int k,K=end-beg;
	for(k=0; k<K; ++k)
		beg[k]+=amp*cos(twopi*(fd*k+phs));
	return true;
}
TPC(vitr) inline bool sinugen_::
addc(vitr beg, vitr end, double amp, double frq)//*add cosine
{
	double fd=frq*(1.0/sprate);//frq*delta
	int k,K=end-beg;
	for(k=0; k<K; ++k)
		beg[k]+=amp*cos(twopi*fd*k);
	return true;
}
TPC(vitr) inline bool sinugen_::
adds(vitr beg, vitr end, double amp, double frq)//*add cosine
{
	double fd=frq*(1.0/sprate);//frq*delta
	int k,K=end-beg;
	for(k=0; k<K; ++k)
		beg[k]+=amp*sin(twopi*fd*k);
	return true;
}
TPC(vitr) inline bool sinugen_::
addh(vitr beg, vitr end, double amp, double frq, int nhar)//*add harmonic
{
	if(nhar<=0) nhar=1; int n;
	for(n=1; n<nhar; ++n)
		addc(beg, end, amp/(n*n), frq*n);
	return true;
}
TPC(vitr) inline bool sinugen_::
addn(vitr beg, vitr end, double amp)//*add noise
{
	int k,K=end-beg;
	for(k=0; k<K; ++k)
		beg[k]+=rn.BM()*amp;
	return true;
}
TPC(vitr) inline bool sinugen_::
smth(vitr beg, vitr end, double msec)//*smooth wave at both ends
{
	int n,N=ms2np(int(msec));
	int k,K=end-beg;
	if(K<2*N) N=K/2;
	if(N<=0) return false;
	double delta=(1.0/N); double tmp;
	for(n=0; n<N; ++n){
		tmp			 =(n*delta);
		beg[n]		*=tmp;
		beg[K-n-1]	*=tmp;
	}
	return true;
}
////////////////////////////////////////////////////////
TPC(R) inline bool sinusig_::
add(valarray<R>&v)
{
	switch(kind){
	case 'c': return sinugen_::addc(&v[0],&v[0]+v.size(), amp, frq);
	case 's': return sinugen_::adds(&v[0],&v[0]+v.size(), amp, frq);
	case ' ': return sinugen_::add (&v[0],&v[0]+v.size(), amp, frq, phs);
	case '~': return sinugen_::smth(&v[0],&v[0]+v.size(), amp);//*amp is msec here
	case 'h': return sinugen_::addh(&v[0],&v[0]+v.size(), amp, frq, nhar);
	case 'n': return sinugen_::addn(&v[0],&v[0]+v.size(), amp);
	}
	return false;
}
TPC(R) inline bool sinusig_::
add(vector<R>&v)
{
	switch(kind){
	case 'c': return sinugen_::addc(v.begin(),v.end(), amp, frq);
	case 's': return sinugen_::adds(v.begin(),v.end(), amp, frq);
	case ' ': return sinugen_::add (v.begin(),v.end(), amp, frq, phs);
	case '~': return sinugen_::smth(v.begin(),v.end(), amp);//*amp is msec here
	case 'h': return sinugen_::addh(v.begin(),v.end(), amp, frq, nhar);
	case 'n': return sinugen_::addn(v.begin(),v.end(), amp);
	}
	return false;
}


////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


TPC(T) inline void vecvec<T>::
resize(int ntimes1, int ncmpts1)
{
	vector<vector<T> >::resize(ntimes1);
	for(size_t n=0; n<size(); n++)
		(*this)[n].resize(ncmpts1);
}

////////////////////////////////////////////////////////
TPC(T) inline int
getminmax (T& vmin, T& vmax, vecvec<T>&m)
{
	size_t TT=m.nfrm(), CC=m.ncmp();
	vmin=vmax=0;
	if(TT<=0||CC<=0) return 0;
	vmax=m(0,0); vmin=m(0,0);
	T tmp; int t, c;
	for(t=0;t<TT;t++)for(c=0;c<CC;c++){
		tmp=m(t,c);
		if(vmax<tmp) vmax=tmp;
		if(vmin>tmp) vmin=tmp;
	}
	return 1;
}

TPC(T) inline int
getminmax (T& vmin, T& vmax, vecvec<T>&m, int nthfrm)
{
	size_t TT=m.nfrm(), CC=m.ncmp();
	vmin=vmax=0;
	if(TT<=0||CC<=0) return 0; if(nthfrm<0||nthfrm>=TT) return 0;
	vmax=m(nthfrm,0); vmin=m(nthfrm,0);
	T tmp; int t, c;
	for(c=0;c<CC;c++){
		tmp=m(nthfrm,c);
		if(vmax<tmp) vmax=tmp;
		if(vmin>tmp) vmin=tmp;
	}
	return 1;
}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

template<class real> inline
int log(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=log(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int exp(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=exp(m(tt,cc));
  return CC*TT;
}


template<class real> inline
int sin(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=sin(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int cos(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=cos(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int tan(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=tan(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int asin(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=asin(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int acos(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=acos(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int atan(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=atan(m(tt,cc));
  return CC*TT;
}

template<class real, class real2> inline
int pow(vecvec<real>& m, real2 expon)
{
	uint tt, TT=m.nfrm();
	uint cc, CC=m.nfrm();
	double mn,ex;
	for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++){
		mn=m(tt,cc);ex=expon; m(tt,cc)=std::pow(mn,ex);
	}
	return CC*TT;
}


template<class real> inline
int sqr(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=(m(tt,cc))*(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int sqrt(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=sqrt(m(tt,cc));
  return CC*TT;
}

template<class real> inline
int abs(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	if(m(tt,cc)<0)m(tt,cc)=-m(tt,cc);
  return CC*TT;
}

template<class real1,class real2> inline vecvec<real1>&
set2(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=c;
  return m;
}

template<class real1,class real2> inline vecvec<real1>&
operator+=(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)+=c;
  return m;
}

template<class real1,class real2> inline vecvec<real1>&
operator-=(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)-=c;
  return m;
}

template<class real1,class real2> inline vecvec<real1>&
operator/=(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)/=c;
  return m;
}

template<class real1,class real2> inline vecvec<real1>&
operator*=(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)*=c;
  return m;
}



//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
template<class real> inline 
int log(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=log(v[n]);
	return N;
}

template<class real> inline
int exp(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=exp(v[n]);
	return N;
}

template<class real> inline
int sin(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=sin(v[n]);
	return N;
}

template<class real> inline 
int cos(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=cos(v[n]);
	return N;
}

template<class real> inline 
int tan(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=tan(v[n]);
	return N;
}

template<class real> inline 
int asin(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=asin(v[n]);
	return N;
}

template<class real> inline 
int acos(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=acos(v[n]);
	return N;
}

template<class real> inline
int atan(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=atan(v[n]);
	return N;
}

template<class real, class real2> inline 
int pow(vector<real>& v, real2 expon)
{
	size_t n,N=v.size();
	double mn, ex=expon;
	for(n=0; n<N; n++)
		{mn=v[n]; v[n]=pow(mn,ex);}
	return N;
}


template<class real> inline 
int sqr(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=v[n]*v[n];
	return N;
}

template<class real> inline 
int sqrt(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=sqrt(v[n]);
	return N;
}

template<class real> inline 
int abs(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		if(v[n]<0) v[n]=-v[n];
	return N;
}

template<class real> inline 
int inv(vector<real>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=1.0/v[n];
	return N;
}

//////////////////////////////////////////////////////
template<class real1,class real2> inline 
vector<real1>& set2(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n] =c;
	return v;
}
template<class real1,class real2> inline
vector<real1>& operator+=(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]+=c;
	return v;
}

template<class real1,class real2> inline
vector<real1>& operator-=(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]-=c;
	return v;
}

template<class real1,class real2> inline
vector<real1>& operator/=(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]/=c;
	return v;
}

template<class real1,class real2> inline
vector<real1>& operator*=(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]*=c;
	return v;
}

//////////////////////////////////////////////////////
template<class real1,class real2> inline
vector<real1>& eeae(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]+=c[n];
	return v;
}

template<class real1,class real2> inline
vector<real1>& eese(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]-=c[n];
	return v;
}
template<class real1,class real2> inline
vector<real1>& eede(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]/=c[n];
	return v;
}

template<class real1,class real2> inline
vector<real1>& eeme(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]*=c[n];
	return v;
}

template<class real1,class real2> inline
double dot(vector<real1>& v, vector<real2>& c)
{
	double tmp=0;
	uint n,N=v.size();
	for(n=0;n<N;n++)
		tmp+=v[n]*c[n];
	return tmp;
}



#endif //#ifndef DI5VP_HH


