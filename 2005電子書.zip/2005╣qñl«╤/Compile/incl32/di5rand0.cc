//
//	di5rand.cc0
//	vector processing
//	.h  	contains only prototype and comment only
//	.cc0 	contains tedious  implementation, to be included in the middle of .h
//	.cc 	contains template implementation, included at end of .h
//	.cpp 	contains other    implementation, add-to project
//

#ifndef DI5RAND0_CC
#define DI5RAND0_CC
// to be included for di5rand.h
// to include the following class
// class tabsit_template<spcf_>;
// class	spcf_binomial;     //class	spcf_poisson;
// class	spcf_geometric;    //class	spcf_negbinomial;

#ifndef TPC
// first a macro for a shorter name,
// remember spaces after TPC(X)
#define TPC(X)			template<class X>
#define TPC1(X)			template<class X>
#define TPC2(X,Y)		template<class X, class Y>
#define TPC3(X,Y,Z)		template<class X, class Y, class Z>
#define TPCI(X)			template<class X> inline
#define TPCI1(X)		template<class X> inline
#define TPCI2(X,Y)		template<class X, class Y> inline
#define TPCI3(X,Y,Z)	template<class X, class Y, class Z> inline
//vitr means iterator of vector/valarray/array, or random acess iterator
#endif //#ifndef TPC
//#ifndef TPC


////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
template<class  spcf_> inline //* pcn: do not change into &,so that pcn can be re-used
int		inverse_transform(spcf_& spcf, spcn_ pcn, double y, int frombegin)
{
	if(frombegin)
		spcf.init(pcn);
	while(1){
		if(y<=pcn.cdf) return pcn.ndx;
		spcf.next(pcn);
	}
}

inline	int		bs_cdfndx(vector<double>& v, double y)
{
	unsigned int lo,hi,mid;
	lo=0, hi=v.size(); if(hi<=1) return 0;
	--hi;
	if(y< v[lo]) return 0;
	if(y>=v[hi]) return hi;//sdbe checked beforehand, but return hi anyway
	mid=(lo+hi)/2;
	while(mid!=lo){
		if(y<v[mid])hi=mid;
		else 		lo=mid;
		mid=(lo+hi)/2;
	}
	return hi;
}


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
template<class spcf_>
class	tabsit_ { public:
		tabsit_(spcf_& spcf1, int TABSZ, int CDFSZ):spcf(spcf1){init(TABSZ,CDFSZ);}
public:
	int		operator()(unif_& unif=uuni);
public:
	int		init(int TABSZ, int CDFSZ);
protected:
	spcf_ 		   &spcf;
	vector<int> 	tab;
	vector<double>	rmdr;
	double			tabprob;
	double			trprob;//
	spcn_			pcn;
	//* pcn: serve 2 purposes:
	//* 1. arg to iterate 4 init
	//* 2. start pcn 4 it()(thus:make a copy in it(), or as a value-copy arg).
protected:
	void	clear(){tab.clear();rmdr.clear();pcn.set2(0,0,0);tabprob=trprob=0;}
	int		init0();
};

///////////////////////////////////////////////////////////////////////////////
template<class  spcf_>inline
int		tabsit_<spcf_>::	operator()(unif_& unif)
{
	double u=unif();
	//try fast table lookup
	int ndx=tab[(unsigned int)(u*tab.size())];
	if(ndx>=0) return ndx;
	//try log(N) bs
	if(u<=trprob)
		return bs_cdfndx(rmdr,u-tabprob);
	//try slowest and cdbe-infinite-range it
	int frombegin=0;
	return inverse_transform(spcf, pcn, u, frombegin);
}

template<class  spcf_>inline
int		tabsit_<spcf_>::	init(int TABSZ, int CDFSZ)
{
	clear();
	if(TABSZ<1||CDFSZ<1) return 0;
	tab .resize (TABSZ,-1); rmdr.reserve(CDFSZ);
	spcf.init(pcn);
	rmdr.push_back(pcn.pdf);
	int n=0; double cp, cpprev=0;
	for(n=1; n<CDFSZ; n++){
		cp=spcf.next(pcn);
		if(cp!=1.0||cp!=cpprev){
			rmdr.push_back(pcn.pdf);
			cpprev=pcn.cdf;
		}
		else
			break;
	}
	trprob=cpprev;//pcn.cdf;
	return init0();
}

template<class  spcf_>inline
int		tabsit_<spcf_>::	init0()
{
	int tabndx=0;int TABSZ=int(tab.size());
	unsigned int n,N=rmdr.size();
	//fill up table, and adjust prob.'s in rmdr
	for(n=0; n<N; n++){
		int 	imul=rmdr[n]*TABSZ;
		for(int nn=0;nn<imul; ++nn){
			tab[tabndx++]=n;
		}
		double prob=double(imul)/TABSZ;
		rmdr[n] -=prob;
	}
	tabprob=double(tabndx)/TABSZ;
	//find the cdf in rmdr to enable binsearch
	for(n=1; n<N; ++n)
		rmdr[n]+=rmdr[n-1];
	return tabndx;
}

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
class 	spcf_binomial{public:
		spcf_binomial(int n1=12,double p1=0.5){n=n1;p=p1;}
	double	init(spcn_& pcn){double t=pow(1-p,n);pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					if(ndx<n)
						{pdf=pdf*(n-ndx)*p/((ndx+1)*(1-p)); cdf+=pdf;  ndx++;}
					else
						{pdf=0;cdf=1;ndx=n+1;}
					return cdf;
				}
public:
	int		n;
	double	p;
};


class 	spcf_poisson{public:
		spcf_poisson(double lamda1=1){lamda=lamda1;}
	double	init(spcn_& pcn){double t=exp(-lamda);pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					{pdf=pdf*lamda/(ndx+1); cdf+=pdf;  ndx++;}
					return cdf;
				}
public:
	double	lamda;
};

class 	spcf_geometric{public:
		spcf_geometric(double p1=0.5){p=p1;}
	double	init(spcn_& pcn){double t=p;pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					{pdf=pdf*(1-p); cdf+=pdf;  ndx++;}
					return cdf;
				}
public:
	double	p;
};

class 	spcf_negbinomial{public:
		spcf_negbinomial(int r1=1,double p1=0.5){r=r1;p=p1;}
	double	init(spcn_& pcn){double t=pow(p,r);pcn.set2(t,t,0);return t;}
	double	next(spcn_& pcn)
				{   double& pdf=pcn.pdf, &cdf=pcn.cdf; int &ndx=pcn.ndx;;
					{pdf=pdf*(1-p)*(r+ndx)/(ndx+1); cdf+=pdf;  ndx++;}
					return cdf;
				}
public:
	int		r;
	double	p;
};

//typedef tabsit_<spcf_binomial	> tabbinomial;
//typedef tabsit_<spcf_poisson 	> tabpoisson;
//typedef tabsit_<spcf_negbinomial> tabnegbinomial;
//typedef tabsit_<spcf_geometric	> tabgeometric;

/*
#undef TPC(X)
#undef TPC1(X)
#undef TPC2(X)
#undef TPC3(X)
#undef TPCI(X)
#undef TPCI1(X)
#undef TPCI2(X)
#undef TPCI3(X)
*/

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
#endif //#ifndef DI5RAND0_CC
