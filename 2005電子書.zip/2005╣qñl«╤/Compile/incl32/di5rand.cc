//
//	di5rand.cc
//	vector processing
//	.h  	contains only prototype and comment only
//	.cc 	contains template implementation, included at end of .h
//	.cpp 	contains other    implementation, add-to project
//

#ifndef DI5RAND_CC
#define DI5RAND_CC
// to be included for di5rand.h

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
inline double it3bino::operator()(unif_&unif)	{return rn(unif);}
inline it3bino::it3bino (int n, double p, int TABSZ, int CDFSZ)
				:spcf(n,p),rn(spcf, TABSZ,CDFSZ)
				{}
////////////////////////////////////////////////////////////////////////////
inline double it3pois::operator()(unif_&unif){return rn(unif);}
inline it3pois::it3pois (double lamda, int TABSZ, int CDFSZ)
				:spcf(lamda),rn(spcf, TABSZ,CDFSZ)
				{}
////////////////////////////////////////////////////////////////////////////
inline double it3geom::operator()(unif_&unif){return rn(unif);}
inline it3geom::it3geom (double p, int TABSZ, int CDFSZ)
				:spcf(p),rn(spcf, TABSZ,CDFSZ)
				{}
////////////////////////////////////////////////////////////////////////////
inline double it3nbin::operator()(unif_&unif){return rn(unif);}
inline it3nbin::it3nbin (int r, double p, int TABSZ, int CDFSZ)
				:spcf(r,p),rn(spcf, TABSZ,CDFSZ)
				{}
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

#endif //#ifndef DI5RAND_CCC
