//
// file ivdraw.h
//

#ifndef IVDRAW_H
#define IVDRAW_H

#include <windows.h>
#include <di5base.h>
//#include <chars.h>
#include <vwin.h>
#include <wgdi.h>


static const nSLEN=1024;

struct fontset_ { int ithfontsize; font_ eu, es, el, hu, hs, hl;
			 fontset_	( ) { set2(5); }
			 void set2	 ( int fontsizeset ) {
											static char e[]="Times New Roman";
											static char h[]="�s�ө���"; set2(fontsizeset, e,h); }
			 void set2 	( int fontsizeset, char* efn1,char* hfn1);
};

class ivdrawetc_ { public:
			ivdrawetc_():	heighttimes(1.8), qiqen('d'), justify(0), lnjust(0),
      							ithfontsize(-1), ithefn(0), ithhfn(0)
									{setDEFshow();setfont0(7);}
	//HFONT 	uf, sf, lf; //upperfont, smallfont and largefong
	//font_		uf, sf, lf;
	font_		euf, esf, elf, huf, hsf, hlf;//upper/small/large fonts, English/Hanri
	int			sfheight, lfheight;
  int 		lw; //linewidth
  double 	heighttimes; // def2 1.8
  int 		justify, lnjust;
  char 		qiqen; // daiqi, kehqi, miaulik or huaqi 'd'/'k'/'m'/'h'
private:
  int  		showYIM, showVUN, showDH, show1D, showKQD, showSN;
public:
  void 	setDEFshow(){showYIM=showVUN=showDH=show1D=showKQD=showSN=1;}
	void	set1D(int ubiau);
  void 	set_yim(int yes) 			{ showYIM=yes; 	}
  void 	set_vun(int yes) 			{ showVUN=yes; 	}
  void 	set_diauhing(int n) 	{ showDH =n; 		}
  void	set_sn(int yes)				{ showSN =yes; 	}
  void  set_1diau(int yes)		{ show1D =yes; set1D(yes);	}
  void	set_kauqidiau(int yes){ showKQD=yes; 	}
  void  tog_yim()							{ set_yim				(!showYIM); }
  void	tog_vun() 						{ set_vun				(!showVUN); }
  void	tog_diauhing()				{ set_diauhing	(!showDH);  }
  void	tog_sn()							{ set_sn 				(!showSN);  }
  void	tog_kauqidiau()				{ set_kauqidiau	(!showKQD); }
  void	tog_1diau()						{ set_1diau			(!show1D);	}
  int		getyim()							{ return (showYIM)?1:0; }
  int		getvun()							{ return (showVUN)?1:0; }
  int		getyimonly()					{ return ( showYIM)&&(!showVUN); 		 }
  int		getvunonly()					{ return (!showYIM)&&( showVUN); 		 }
  int 	getyimORvunonly()			{ return ((showYIM)&&( showVUN))?0:1;}
  int 	get_diauhing ()				{ return showDH; 		}
  int 	getdanridiau()				{ return !showKQD; 	}
  int 	getkauqidiau()				{ return showKQD; 	}
  int 	get_sn()							{ return showSN; 		}
  int		get_1diau()						{ return show1D;		}
public:
				int	gapim, gapsu;
  void setgap(int fontsize)
			{gapim=fontsize/5; gapsu=fontsize;	lw=(fontsize+10)/20;}
public:
				int ithfontsize; int ithefn, ithhfn;
	int		efontnamesize();
	int		hfontnamesize();
	char*	efontname(int ithefn1);
	char* hfontname(int ithhfn1);
  char* fontsetsizeinfo(int i);
	char* fontsetinfo();
  int		fontsetsize();
  int   fontset() { return ithfontsize; }
private:
	void	setfont00(int ithsize1, char* efn1, char* hfn1);
public:
	void	setfont(int ithsize1, int ithefn1, int ithhfn1);
	void	setfont(int ithsize1=-2){setfont(ithsize1,ithefn, ithhfn);}
	void	setfont0(int ithsize1=-2);
public:
	void	nextfont() { setfont(ithfontsize+1); }
	void	prevfont() { setfont(ithfontsize-1); }
	int		rowheight		(){ return int((lfheight+sfheight*getyim())*heighttimes);}
	//void	selectfont	(HDC dc){ uf.select(dc); sf.select(dc); lf.select(dc);}
	void	selectfont	(HDC dc){ euf.select(dc); esf.select(dc); elf.select(dc);
														  huf.select(dc); hsf.select(dc); hlf.select(dc);}
	//void	restorefont	(){ uf.restore(   ); sf.restore(   ); lf.restore(   ); }
	void	restorefont	(){ euf.restore(   ); esf.restore(   ); elf.restore(   );
												huf.restore(   ); hsf.restore(   ); hlf.restore(   );}
};




class ivdraw_ { public:
			ivdraw_() { setetc2def(); etc=&(etcs[0]); }
	ivdrawetc_* etc;
	ivdrawetc_ etcs[7]; int MAXETC;
  HDC hdc;
  chars si, sv, si1; charspp sppi, sppv;
  chars iwork, vwork;
  void setetc2ith(int ith=0){	if(ith<0)ith=0;if(ith>=MAXETC)ith=MAXETC-1;
  														etc=&(etcs[ith]);}
  void setetc2def(){MAXETC=7;etcs[0].setfont(5,0,0);etcs[1].setfont(7,0,1);etcs[2].setfont(6,0,1);}
  void sethdc(HDC hdc1);
public:
			  int nFIT; SIZE szi, szv;
			  int ncumwidth0[nSLEN+2]; int *ncumwidth;
	int		getwidth_su (char* vun, char* im);
	int		getwidth_su0(char* vun, char* im);
	//int	getwidth_gu (char* vun, char* im);
	SIZE	gettext_su		(char* vun, char* im);
	SIZE	gettext_su0		(char* vun, char* im);
	SIZE	gettext_su		(char* vunim);
  SIZE	gettextwidt4(HDC hdc1, char* t, font_* efont, font_* hfont);
public:
	int 	idqtransform(char* im); // transform im to iwork;
	int 	vdqtransform(char* im); // transform im to vwork;
  char* SStext		(char* t);
  char* NONSStext	(char* t);
public:
	void	setdiaupoints(point_* pt, int * npt,int diau, int xb,int yb,int xe,int ye,int lw);
	int		textoutsu(         int selected, RECT rect, char* vun, char* im);
	int		textout  (HDC hdc1,int selected, RECT rect, char* vun, char* im);
  void	drawdiau(HDC hdc,int x,int dx,int base,char c,char diau,
  							int selected,char qiqen);
public:
				int		vipos[nSLEN+2];
	int		isin(char c, char* in){while(*in)if(c==*in++)return 1;return 0;}
  int		is_aeiou(char c){static char s[]="aeiou";return isin(c,s);}
  int		is_mn   (char c){static char s[]="mn";   return isin(c,s);}
  void	setvorim(char* im);
public:
	char* fontsetinfo(){return etc->fontsetinfo();}
	int		fontsetsize(){return etc->fontsetsize();}
};


/*
void ivdrawBCB_::setetc()
{
	etc.qiqen=transcript.qiqen;
  TDrawGrid* dg=Form1->DrawGrid1_;
  TLabel*    lb =Form1->lb4smallfont1_;
  TLabel*    lbu=Form1->lb4upperfont1_;
  etc.lf= dg ->Font->Handle;
  etc.sf= lb ->Font->Handle;
  etc.uf= lbu->Font->Handle;
  hdc=dg->Canvas->Handle;
  TEXTMETRIC tm;
  SelectObject(hdc,etc.lf);  GetTextMetrics(hdc, &tm);etc.lfheight=tm.tmHeight;
  SelectObject(hdc,etc.sf);  GetTextMetrics(hdc, &tm);etc.sfheight=tm.tmHeight;

  etc.set_yim( (Form1->mi4hensi_yim1_	->Checked)?1:0 );
  etc.set_vun( (Form1->mi4hensi_vun1_	->Checked)?1:0 );

  if		 (Form1->mi4left1_		->Checked) etc.justify=-1;
  else if(Form1->mi4center1_	->Checked) etc.justify= 0;
  else if(Form1->mi4right1_		->Checked) etc.justify= 1;

  if		 (Form1->mi4diauhing1_	->Checked) etc.set_diauhing(1);
  else if(Form1->mi4diaului1_		->Checked) etc.set_diauhing(2);
  else if(Form1->mi4diau5gai1_	->Checked) etc.set_diauhing(3);

  if		 (Form1->mi4kauqidiau1_	->Checked) etc.set_kauqidiau(1);
  else if(Form1->mi4danridiau1_	->Checked) etc.set_kauqidiau(0);

  if		 (Form1->mi4no1diau1_	->Checked) etc.set_1diau(0);
  else if(Form1->mi4no2diau1_	->Checked) etc.set_1diau(1);

  etc.setgap(dg->Font->Size);
}

*/



/*
class ivdrawBCB_ : public ivdraw_ { public:
	int  textout(int selected, RECT rect, int nth_line);
	void setetc();
  int  getwidth_gu(int nth_line){return ivdraw_::getwidth_gu(transcript.vun(nth_line),transcript.im(nth_line));}
  int  rowheight() { return etc.rowheight(); }
  int  colwidth ();
}ivdraw;

int ivdrawBCB_::colwidth()
{
	int nth, width, WIDTH=0;
  for(nth=0; nth<transcript.size(); nth++){
  	width=getwidth_gu(nth);
    if(width>WIDTH) WIDTH=width;
  }
  return WIDTH;
}

int ivdrawBCB_::textout(int selected, RECT rect, int nth_line)
{
	setetc();
  if(transcript.tag(nth_line)[0]=='#') return 0;
	return	ivdraw_::textout
  (hdc,selected,rect,transcript.vun(nth_line),transcript.im(nth_line));
}

void ivdrawBCB_::setetc()
{
	etc.qiqen=transcript.qiqen;
  TDrawGrid* dg=Form1->DrawGrid1_;
  TLabel*    lb =Form1->lb4smallfont1_;
  TLabel*    lbu=Form1->lb4upperfont1_;
  etc.lf= dg ->Font->Handle;
  etc.sf= lb ->Font->Handle;
  etc.uf= lbu->Font->Handle;
  hdc=dg->Canvas->Handle;
  TEXTMETRIC tm;
  SelectObject(hdc,etc.lf);  GetTextMetrics(hdc, &tm);etc.lfheight=tm.tmHeight;
  SelectObject(hdc,etc.sf);  GetTextMetrics(hdc, &tm);etc.sfheight=tm.tmHeight;

  etc.set_yim( (Form1->mi4hensi_yim1_	->Checked)?1:0 );
  etc.set_vun( (Form1->mi4hensi_vun1_	->Checked)?1:0 );

  if		 (Form1->mi4left1_		->Checked) etc.justify=-1;
  else if(Form1->mi4center1_	->Checked) etc.justify= 0;
  else if(Form1->mi4right1_		->Checked) etc.justify= 1;

  if		 (Form1->mi4diauhing1_	->Checked) etc.set_diauhing(1);
  else if(Form1->mi4diaului1_		->Checked) etc.set_diauhing(2);
  else if(Form1->mi4diau5gai1_	->Checked) etc.set_diauhing(3);

  if		 (Form1->mi4kauqidiau1_	->Checked) etc.set_kauqidiau(1);
  else if(Form1->mi4danridiau1_	->Checked) etc.set_kauqidiau(0);

  if		 (Form1->mi4no1diau1_	->Checked) etc.set_1diau(0);
  else if(Form1->mi4no2diau1_	->Checked) etc.set_1diau(1);

  etc.setgap(dg->Font->Size);
}

*/



#endif //#ifndef IVDRAW_H

