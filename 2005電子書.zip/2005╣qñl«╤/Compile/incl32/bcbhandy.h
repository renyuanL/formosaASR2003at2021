
#include <vcl.h>

bool isFormOpened(TForm* form); //* is a MDIChild form opened?


