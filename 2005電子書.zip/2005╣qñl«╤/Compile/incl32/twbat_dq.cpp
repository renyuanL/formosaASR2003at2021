//
// file twbat_da.cpp
//

#ifdef TWBAT_DQ_CPP
#define TWBAT_DQ_CPP

char* imzet12twbat(char* imzet1);


struct daiqi_node{
		 char *id, *ty2, *twb, *di5, *ty;
 };
 /*
struct daiqi_node{
		 char id[10],daiim[10],cgu[10],tys[20],ty[20];
 };
*/
 //{"0",	"daiim",	"cgu",	"tys",	"ty"},

static daiqi_node daiqi[]={//[848]={
<?xml version="1.0" encoding="Big5" standalone="yes"?>
<imzet qiqen="daiqi" sigan="2001-1-6"  >
<izd zg=""	di2="a"  	twb1="a"  	di="a"  	twb="a"  	/>  
<izd zg=""	di2="ah"  	twb1="aH"  	di="ah"  	twb="ah"	/>  
<izd zg=""	di2="ai"  	twb1="ai"  	di="ai"  	twb="a-i"	/>  
<izd zg=""	di2="ak"  	twb1="aK"  	di="ak"  	twb="ak"	/>  
<izd zg=""	di2="am"  	twb1="aM"  	di="am"  	twb="a-m"	/>  
<izd zg=""	di2="an"  	twb1="aN"  	di="an"  	twb="a-n"	/>  
<izd zg=""	di2="ang"  	twb1="aG"  	di="ang"  	twb="a-ng"	/>  
<izd zg=""	di2="ann"  	twb1="A"  	di="ann"  	twb="ann"	/>  
<izd zg=""	di2="ap"  	twb1="aP"  	di="ap"  	twb="ap"	/>  
<izd zg=""	di2="at"  	twb1="aT"  	di="at"  	twb="at"	/>  
<izd zg=""	di2="au"  	twb1="au"  	di="au"  	twb="a-u"	/>  
<izd zg=""	di2="ba"  	twb1="ba"  	di="ba"  	twb="b-a"	/>  
<izd zg=""	di2="bah"  	twb1="baH"  	di="bah"  	twb="b-ah"	/>  
<izd zg=""	di2="bai"  	twb1="bai"  	di="bai"  	twb="b-a-i"	/>  
<izd zg=""	di2="bainn"  	twb1="bAI"  	di="bainn"  	twb="b-ann-inn"	/>  
<izd zg=""	di2="bak"  	twb1="baK"  	di="bak"  	twb="b-ak"	/>  
<izd zg=""	di2="ban"  	twb1="baN"  	di="ban"  	twb="b-a-n"	/>  
<izd zg=""	di2="bang"  	twb1="baG"  	di="bang"  	twb="b-a-ng"	/>  
<izd zg=""	di2="bat"  	twb1="baT"  	di="bat"  	twb="b-at"	/>  
<izd zg=""	di2="bau"  	twb1="bau"  	di="bau"  	twb="b-a-u"	/>  
<izd zg=""	di2="be"  	twb1="be"  	di="be"  	twb="b-e"	/>  
<izd zg=""	di2="beh"  	twb1="beH"  	di="beh"  	twb="b-eh"	/>  
<izd zg=""	di2="ben"  	twb1="beN"  	di="ben"  	twb="b-e-n"	/>  
<izd zg=""	di2="benn"  	twb1="bE"  	di="benn"  	twb="b-enn"	/>  
<izd zg=""	di2="bet"  	twb1="beT"  	di="bet"  	twb="b-et"	/>  
<izd zg=""	di2="bi"  	twb1="bi"  	di="bi"  	twb="b-i"	/>  
<izd zg=""	di2="biah"  	twb1="biaH"  	di="biah"  	twb="b-i-ah"	/>  
<izd zg=""	di2="biak"  	twb1="biaK"  	di="biak"  	twb="b-i-ak"	/>  
<izd zg=""	di2="biann"  	twb1="bIA"  	di="biann"  	twb="b-inn-ann"	/>  
<izd zg=""	di2="biau"  	twb1="biau"  	di="biau"  	twb="b-i-a-u"	/>  
<izd zg=""	di2="bih"  	twb1="biH"  	di="bih"  	twb="b-ih"	/>  
<izd zg=""	di2="bik"  	twb1="biK"  	di="bik"  	twb="b-ik"	/>  
<izd zg=""	di2="bin"  	twb1="biN"  	di="bin"  	twb="b-i-n"	/>  
<izd zg=""	di2="bing"  	twb1="biG"  	di="bing"  	twb="b-i-ng"	/>  
<izd zg=""	di2="binn"  	twb1="bI"  	di="binn"  	twb="b-inn"	/>  
<izd zg=""	di2="bior"  	twb1="bir"  	di="bior"  	twb="b-i-or"	/>  
<izd zg=""	di2="bit"  	twb1="biT"  	di="bit"  	twb="b-it"	/>  
<izd zg=""	di2="biu"  	twb1="biu"  	di="biu"  	twb="b-i-u"	/>  
<izd zg=""	di2="bng"  	twb1="bG"  	di="bng"  	twb="b-ng"	/>  
<izd zg=""	di2="bo"  	twb1="bo"  	di="bo"  	twb="b-o"	/>  
<izd zg=""	di2="bok"  	twb1="boK"  	di="bok"  	twb="b-ok"	/>  
<izd zg=""	di2="bong"  	twb1="boG"  	di="bong"  	twb="b-o-ng"	/>  
<izd zg=""	di2="bor"  	twb1="br"  	di="bor"  	twb="b-or"	/>  
<izd zg=""	di2="borh"  	twb1="brH"  	di="borh"  	twb="b-orh"	/>  
<izd zg=""	di2="bu"  	twb1="bu"  	di="bu"  	twb="b-u"	/>  
<izd zg=""	di2="bua"  	twb1="bua"  	di="bua"  	twb="b-u-a"	/>  
<izd zg=""	di2="buah"  	twb1="buaH"  	di="buah"  	twb="b-u-ah"	/>  
<izd zg=""	di2="buan"  	twb1="buaN"  	di="buan"  	twb="b-u-a-n"	/>  
<izd zg=""	di2="buann"  	twb1="bUA"  	di="buann"  	twb="b-unn-ann"	/>  
<izd zg=""	di2="buat"  	twb1="buaT"  	di="buat"  	twb="b-u-at"	/>  
<izd zg=""	di2="bue"  	twb1="bue"  	di="bue"  	twb="b-u-e"	/>  
<izd zg=""	di2="bueh"  	twb1="bueH"  	di="bueh"  	twb="b-u-eh"	/>  
<izd zg=""	di2="buh"  	twb1="buH"  	di="buh"  	twb="b-uh"	/>  
<izd zg=""	di2="bui"  	twb1="bui"  	di="bui"  	twb="b-u-i"	/>  
<izd zg=""	di2="bun"  	twb1="buN"  	di="bun"  	twb="b-u-n"	/>  
<izd zg=""	di2="but"  	twb1="buT"  	di="but"  	twb="b-ut"	/>  
<izd zg=""	di2="cha"  	twb1="ca"  	di="ca"  	twb="c-a"	/>  
<izd zg=""	di2="chah"  	twb1="caH"  	di="cah"  	twb="c-ah"	/>  
<izd zg=""	di2="chai"  	twb1="cai"  	di="cai"  	twb="c-a-i"	/>  
<izd zg=""	di2="chak"  	twb1="caK"  	di="cak"  	twb="c-ak"	/>  
<izd zg=""	di2="cham"  	twb1="caM"  	di="cam"  	twb="c-a-m"	/>  
<izd zg=""	di2="chan"  	twb1="caN"  	di="can"  	twb="c-a-n"	/>  
<izd zg=""	di2="chang"  	twb1="caG"  	di="cang"  	twb="c-a-ng"	/>  
<izd zg=""	di2="chap"  	twb1="caP"  	di="cap"  	twb="c-ap"	/>  
<izd zg=""	di2="chat"  	twb1="caT"  	di="cat"  	twb="c-at"	/>  
<izd zg=""	di2="chau"  	twb1="cau"  	di="cau"  	twb="c-a-u"	/>  
<izd zg=""	di2="che"  	twb1="ce"  	di="ce"  	twb="c-e"	/>  
<izd zg=""	di2="cheh"  	twb1="ceH"  	di="ceh"  	twb="c-eh"	/>  
<izd zg=""	di2="chen"  	twb1="ceN"  	di="cen"  	twb="c-e-n"	/>  
<izd zg=""	di2="chenn"  	twb1="cE"  	di="cenn"  	twb="c-enn"	/>  
<izd zg=""	di2="chet"  	twb1="ceT"  	di="cet"  	twb="c-et"	/>  
<izd zg=""	di2="chi"  	twb1="ci"  	di="ci"  	twb="c-i"	/>  
<izd zg=""	di2="chia"  	twb1="cia"  	di="cia"  	twb="c-i-a"	/>  
<izd zg=""	di2="chiah"  	twb1="ciaH"  	di="ciah"  	twb="c-i-ah"	/>  
<izd zg=""	di2="chiak"  	twb1="ciaK"  	di="ciak"  	twb="c-i-ak"	/>  
<izd zg=""	di2="chiam"  	twb1="ciaM"  	di="ciam"  	twb="c-i-a-m"	/>  
<izd zg=""	di2="chiang"  	twb1="ciaG"  	di="ciang"  	twb="c-i-a-ng"	/>  
<izd zg=""	di2="chiann"  	twb1="cIA"  	di="ciann"  	twb="c-inn-ann"	/>  
<izd zg=""	di2="chiap"  	twb1="ciaP"  	di="ciap"  	twb="c-i-ap"	/>  
<izd zg=""	di2="chiau"  	twb1="ciau"  	di="ciau"  	twb="c-i-a-u"	/>  
<izd zg=""	di2="chih"  	twb1="ciH"  	di="cih"  	twb="c-ih"	/>  
<izd zg=""	di2="chik"  	twb1="ciK"  	di="cik"  	twb="c-ik"	/>  
<izd zg=""	di2="chim"  	twb1="ciM"  	di="cim"  	twb="c-i-m"	/>  
<izd zg=""	di2="chin"  	twb1="ciN"  	di="cin"  	twb="c-i-n"	/>  
<izd zg=""	di2="ching"  	twb1="ciG"  	di="cing"  	twb="c-i-ng"	/>  
<izd zg=""	di2="chinn"  	twb1="cI"  	di="cinn"  	twb="c-inn"	/>  
<izd zg=""	di2="chiok"  	twb1="cioK"  	di="ciok"  	twb="c-i-ok"	/>  
<izd zg=""	di2="chiong"  	twb1="cioG"  	di="ciong"  	twb="c-i-o-ng"	/>  
<izd zg=""	di2="chionn"  	twb1="cIO"  	di="cionn"  	twb="c-inn-onn"	/>  
<izd zg=""	di2="chior"  	twb1="cir"  	di="cior"  	twb="c-i-or"	/>  
<izd zg=""	di2="chiorh"  	twb1="cirH"  	di="ciorh"  	twb="c-i-orh"	/>  
<izd zg=""	di2="chit"  	twb1="ciT"  	di="cit"  	twb="c-it"	/>  
<izd zg=""	di2="chiu"  	twb1="ciu"  	di="ciu"  	twb="c-i-u"	/>  
<izd zg=""	di2="chiunn"  	twb1="cIU"  	di="ciunn"  	twb="c-inn-unn"	/>  
<izd zg=""	di2="chng"  	twb1="cG"  	di="cng"  	twb="c-ng"	/>  
<izd zg=""	di2="cho"  	twb1="co"  	di="co"  	twb="c-o"	/>  
<izd zg=""	di2="chok"  	twb1="coK"  	di="cok"  	twb="c-ok"	/>  
<izd zg=""	di2="chong"  	twb1="coG"  	di="cong"  	twb="c-o-ng"	/>  
<izd zg=""	di2="chop"  	twb1="coP"  	di="cop"  	twb="c-op"	/>  
<izd zg=""	di2="chor"  	twb1="cr"  	di="cor"  	twb="c-or"	/>  
<izd zg=""	di2="chu"  	twb1="cu"  	di="cu"  	twb="c-u"	/>  
<izd zg=""	di2="chua"  	twb1="cua"  	di="cua"  	twb="c-u-a"	/>  
<izd zg=""	di2="chuah"  	twb1="cuaH"  	di="cuah"  	twb="c-u-ah"	/>  
<izd zg=""	di2="chuai"  	twb1="cuai"  	di="cuai"  	twb="c-u-a-i"	/>  
<izd zg=""	di2="chuan"  	twb1="cuaN"  	di="cuan"  	twb="c-u-a-n"	/>  
<izd zg=""	di2="chuann"  	twb1="cUA"  	di="cuann"  	twb="c-unn-ann"	/>  
<izd zg=""	di2="chue"  	twb1="cue"  	di="cue"  	twb="c-u-e"	/>  
<izd zg=""	di2="chueh"  	twb1="cueH"  	di="cueh"  	twb="c-u-eh"	/>  
<izd zg=""	di2="chui"  	twb1="cui"  	di="cui"  	twb="c-u-i"	/>  
<izd zg=""	di2="chun"  	twb1="cuN"  	di="cun"  	twb="c-u-n"	/>  
<izd zg=""	di2="chut"  	twb1="cuT"  	di="cut"  	twb="c-ut"	/>  
<izd zg=""	di2="da"  	twb1="da"  	di="da"  	twb="d-a"	/>  
<izd zg=""	di2="dah"  	twb1="daH"  	di="dah"  	twb="d-ah"	/>  
<izd zg=""	di2="dai"  	twb1="dai"  	di="dai"  	twb="d-a-i"	/>  
<izd zg=""	di2="dak"  	twb1="daK"  	di="dak"  	twb="d-ak"	/>  
<izd zg=""	di2="dam"  	twb1="daM"  	di="dam"  	twb="d-a-m"	/>  
<izd zg=""	di2="dan"  	twb1="daN"  	di="dan"  	twb="d-a-n"	/>  
<izd zg=""	di2="dang"  	twb1="daG"  	di="dang"  	twb="d-a-ng"	/>  
<izd zg=""	di2="dann"  	twb1="dA"  	di="dann"  	twb="d-ann"	/>  
<izd zg=""	di2="dap"  	twb1="daP"  	di="dap"  	twb="d-ap"	/>  
<izd zg=""	di2="dat"  	twb1="daT"  	di="dat"  	twb="d-at"	/>  
<izd zg=""	di2="dau"  	twb1="dau"  	di="dau"  	twb="d-a-u"	/>  
<izd zg=""	di2="de"  	twb1="de"  	di="de"  	twb="d-e"	/>  
<izd zg=""	di2="deh"  	twb1="deH"  	di="deh"  	twb="d-eh"	/>  
<izd zg=""	di2="den"  	twb1="deN"  	di="den"  	twb="d-e-n"	/>  
<izd zg=""	di2="denn"  	twb1="dE"  	di="denn"  	twb="d-enn"	/>  
<izd zg=""	di2="det"  	twb1="deT"  	di="det"  	twb="d-et"	/>  
<izd zg=""	di2="di"  	twb1="di"  	di="di"  	twb="d-i"	/>  
<izd zg=""	di2="dia"  	twb1="dia"  	di="dia"  	twb="d-i-a"	/>  
<izd zg=""	di2="diah"  	twb1="diaH"  	di="diah"  	twb="d-i-ah"	/>  
<izd zg=""	di2="diam"  	twb1="diaM"  	di="diam"  	twb="d-i-a-m"	/>  
<izd zg=""	di2="diang"  	twb1="diaG"  	di="diang"  	twb="d-i-a-ng"	/>  
<izd zg=""	di2="diann"  	twb1="dIA"  	di="diann"  	twb="d-inn-ann"	/>  
<izd zg=""	di2="diap"  	twb1="diaP"  	di="diap"  	twb="d-i-ap"	/>  
<izd zg=""	di2="diau"  	twb1="diau"  	di="diau"  	twb="d-i-a-u"	/>  
<izd zg=""	di2="dih"  	twb1="diH"  	di="dih"  	twb="d-ih"	/>  
<izd zg=""	di2="dik"  	twb1="diK"  	di="dik"  	twb="d-ik"	/>  
<izd zg=""	di2="dim"  	twb1="diM"  	di="dim"  	twb="d-i-m"	/>  
<izd zg=""	di2="din"  	twb1="diN"  	di="din"  	twb="d-i-n"	/>  
<izd zg=""	di2="ding"  	twb1="diG"  	di="ding"  	twb="d-i-ng"	/>  
<izd zg=""	di2="dinn"  	twb1="dI"  	di="dinn"  	twb="d-inn"	/>  
<izd zg=""	di2="dioh"  	twb1="dioH"  	di="dioh"  	twb="d-i-oh"	/>  
<izd zg=""	di2="diok"  	twb1="dioK"  	di="diok"  	twb="d-i-ok"	/>  
<izd zg=""	di2="diong"  	twb1="dioG"  	di="diong"  	twb="d-i-o-ng"	/>  
<izd zg=""	di2="dionn"  	twb1="dIO"  	di="dionn"  	twb="d-inn-onn"	/>  
<izd zg=""	di2="dior"  	twb1="dir"  	di="dior"  	twb="d-i-or"	/>  
<izd zg=""	di2="diorh"  	twb1="dirH"  	di="diorh"  	twb="d-i-orh"	/>  
<izd zg=""	di2="dit"  	twb1="diT"  	di="dit"  	twb="d-it"	/>  
<izd zg=""	di2="diu"  	twb1="diu"  	di="diu"  	twb="d-i-u"	/>  
<izd zg=""	di2="diunn"  	twb1="dIU"  	di="diunn"  	twb="d-inn-unn"	/>  
<izd zg=""	di2="dng"  	twb1="dG"  	di="dng"  	twb="d-ng"	/>  
<izd zg=""	di2="do"  	twb1="do"  	di="do"  	twb="d-o"	/>  
<izd zg=""	di2="dok"  	twb1="doK"  	di="dok"  	twb="d-ok"	/>  
<izd zg=""	di2="dom"  	twb1="doM"  	di="dom"  	twb="d-o-m"	/>  
<izd zg=""	di2="dong"  	twb1="doG"  	di="dong"  	twb="d-o-ng"	/>  
<izd zg=""	di2="dor"  	twb1="dr"  	di="dor"  	twb="d-or"	/>  
<izd zg=""	di2="dorh"  	twb1="drH"  	di="dorh"  	twb="d-orh"	/>  
<izd zg=""	di2="du"  	twb1="du"  	di="du"  	twb="d-u"	/>  
<izd zg=""	di2="dua"  	twb1="dua"  	di="dua"  	twb="d-u-a"	/>  
<izd zg=""	di2="duan"  	twb1="duaN"  	di="duan"  	twb="d-u-a-n"	/>  
<izd zg=""	di2="duann"  	twb1="dUA"  	di="duann"  	twb="d-unn-ann"	/>  
<izd zg=""	di2="duat"  	twb1="duaT"  	di="duat"  	twb="d-u-at"	/>  
<izd zg=""	di2="due"  	twb1="due"  	di="due"  	twb="d-u-e"	/>  
<izd zg=""	di2="duh"  	twb1="duH"  	di="duh"  	twb="d-uh"	/>  
<izd zg=""	di2="dui"  	twb1="dui"  	di="dui"  	twb="d-u-i"	/>  
<izd zg=""	di2="dun"  	twb1="duN"  	di="dun"  	twb="d-u-n"	/>  
<izd zg=""	di2="dut"  	twb1="duT"  	di="dut"  	twb="d-ut"	/>  
<izd zg=""	di2="e"  	twb1="e"  	di="e"  	twb="e"  	/>     
<izd zg=""	di2="eh"  	twb1="eH"  	di="eh"  	twb="eh"	/>  
<izd zg=""	di2="en"  	twb1="eN"  	di="en"  	twb="e-n"	/>  
<izd zg=""	di2="enn"  	twb1="E"  	di="enn"  	twb="enn"	/>  
<izd zg=""	di2="et"  	twb1="eT"  	di="et"  	twb="et"	/>  
<izd zg=""	di2="ga"  	twb1="ga"  	di="ga"  	twb="g-a"	/>  
<izd zg=""	di2="gah"  	twb1="gaH"  	di="gah"  	twb="g-ah"	/>  
<izd zg=""	di2="gai"  	twb1="gai"  	di="gai"  	twb="g-a-i"	/>  
<izd zg=""	di2="gak"  	twb1="gaK"  	di="gak"  	twb="g-ak"	/>  
<izd zg=""	di2="gam"  	twb1="gaM"  	di="gam"  	twb="g-a-m"	/>  
<izd zg=""	di2="gan"  	twb1="gaN"  	di="gan"  	twb="g-a-n"	/>  
<izd zg=""	di2="gang"  	twb1="gaG"  	di="gang"  	twb="g-a-ng"	/>  
<izd zg=""	di2="gann"  	twb1="gA"  	di="gann"  	twb="g-ann"	/>  
<izd zg=""	di2="gap"  	twb1="gaP"  	di="gap"  	twb="g-ap"	/>  
<izd zg=""	di2="gat"  	twb1="gaT"  	di="gat"  	twb="g-at"	/>  
<izd zg=""	di2="gau"  	twb1="gau"  	di="gau"  	twb="g-a-u"	/>  
<izd zg=""	di2="gauh"  	twb1="gauH"  	di="gauh"  	twb="g-a-uh"	/>  
<izd zg=""	di2="ge"  	twb1="ge"  	di="ge"  	twb="g-e"	/>  
<izd zg=""	di2="geh"  	twb1="geH"  	di="geh"  	twb="g-eh"	/>  
<izd zg=""	di2="gen"  	twb1="geN"  	di="gen"  	twb="g-e-n"	/>  
<izd zg=""	di2="genn"  	twb1="gE"  	di="genn"  	twb="g-enn"	/>  
<izd zg=""	di2="get"  	twb1="geT"  	di="get"  	twb="g-et"	/>  
<izd zg=""	di2="gi"  	twb1="gi"  	di="gi"  	twb="g-i"	/>  
<izd zg=""	di2="gia"  	twb1="gia"  	di="gia"  	twb="g-i-a"	/>  
<izd zg=""	di2="giah"  	twb1="giaH"  	di="giah"  	twb="g-i-ah"	/>  
<izd zg=""	di2="giak"  	twb1="giaK"  	di="giak"  	twb="g-i-ak"	/>  
<izd zg=""	di2="giam"  	twb1="giaM"  	di="giam"  	twb="g-i-a-m"	/>  
<izd zg=""	di2="giang"  	twb1="giaG"  	di="giang"  	twb="g-i-a-ng"	/>  
<izd zg=""	di2="giann"  	twb1="gIA"  	di="giann"  	twb="g-inn-ann"	/>  
<izd zg=""	di2="giap"  	twb1="giaP"  	di="giap"  	twb="g-i-ap"	/>  
<izd zg=""	di2="giau"  	twb1="giau"  	di="giau"  	twb="g-i-a-u"	/>  
<izd zg=""	di2="gih"  	twb1="giH"  	di="gih"  	twb="g-ih"	/>  
<izd zg=""	di2="gik"  	twb1="giK"  	di="gik"  	twb="g-ik"	/>  
<izd zg=""	di2="gim"  	twb1="giM"  	di="gim"  	twb="g-i-m"	/>  
<izd zg=""	di2="gin"  	twb1="giN"  	di="gin"  	twb="g-i-n"	/>  
<izd zg=""	di2="ging"  	twb1="giG"  	di="ging"  	twb="g-i-ng"	/>  
<izd zg=""	di2="ginn"  	twb1="gI"  	di="ginn"  	twb="g-inn"	/>  
<izd zg=""	di2="giok"  	twb1="gioK"  	di="giok"  	twb="g-i-ok"	/>  
<izd zg=""	di2="giong"  	twb1="gioG"  	di="giong"  	twb="g-i-o-ng"	/>  
<izd zg=""	di2="gionn"  	twb1="gIO"  	di="gionn"  	twb="g-inn-onn"	/>  
<izd zg=""	di2="gior"  	twb1="gir"  	di="gior"  	twb="g-i-or"	/>  
<izd zg=""	di2="gip"  	twb1="giP"  	di="gip"  	twb="g-ip"	/>  
<izd zg=""	di2="giu"  	twb1="giu"  	di="giu"  	twb="g-i-u"	/>  
<izd zg=""	di2="giunn"  	twb1="gIU"  	di="giunn"  	twb="g-inn-unn"	/>  
<izd zg=""	di2="gng"  	twb1="gG"  	di="gng"  	twb="g-ng"	/>  
<izd zg=""	di2="go"  	twb1="go"  	di="go"  	twb="g-o"	/>  
<izd zg=""	di2="gok"  	twb1="goK"  	di="gok"  	twb="g-ok"	/>  
<izd zg=""	di2="gong"  	twb1="goG"  	di="gong"  	twb="g-o-ng"	/>  
<izd zg=""	di2="gor"  	twb1="gr"  	di="gor"  	twb="g-or"	/>  
<izd zg=""	di2="gorh"  	twb1="grH"  	di="gorh"  	twb="g-orh"	/>  
<izd zg=""	di2="gu"  	twb1="gu"  	di="gu"  	twb="g-u"	/>  
<izd zg=""	di2="gua"  	twb1="gua"  	di="gua"  	twb="g-u-a"	/>  
<izd zg=""	di2="guah"  	twb1="guaH"  	di="guah"  	twb="g-u-ah"	/>  
<izd zg=""	di2="guai"  	twb1="guai"  	di="guai"  	twb="g-u-a-i"	/>  
<izd zg=""	di2="guainn"  	twb1="gUAI"  	di="guainn"  	twb="g-unn-ann-inn"	/>  
<izd zg=""	di2="guan"  	twb1="guaN"  	di="guan"  	twb="g-u-a-n"	/>  
<izd zg=""	di2="guann"  	twb1="gUA"  	di="guann"  	twb="g-unn-ann"	/>  
<izd zg=""	di2="guat"  	twb1="guaT"  	di="guat"  	twb="g-u-at"	/>  
<izd zg=""	di2="gue"  	twb1="gue"  	di="gue"  	twb="g-u-e"	/>  
<izd zg=""	di2="gueh"  	twb1="gueH"  	di="gueh"  	twb="g-u-eh"	/>  
<izd zg=""	di2="gui"  	twb1="gui"  	di="gui"  	twb="g-u-i"	/>  
<izd zg=""	di2="gun"  	twb1="guN"  	di="gun"  	twb="g-u-n"	/>  
<izd zg=""	di2="gut"  	twb1="guT"  	di="gut"  	twb="g-ut"	/>  
<izd zg=""	di2="ha"  	twb1="ha"  	di="ha"  	twb="h-a"	/>  
<izd zg=""	di2="hah"  	twb1="haH"  	di="hah"  	twb="h-ah"	/>  
<izd zg=""	di2="hai"  	twb1="hai"  	di="hai"  	twb="h-a-i"	/>  
<izd zg=""	di2="hainn"  	twb1="hAI"  	di="hainn"  	twb="h-ann-inn"	/>  
<izd zg=""	di2="hak"  	twb1="haK"  	di="hak"  	twb="h-ak"	/>  
<izd zg=""	di2="ham"  	twb1="haM"  	di="ham"  	twb="h-a-m"	/>  
<izd zg=""	di2="han"  	twb1="haN"  	di="han"  	twb="h-a-n"	/>  
<izd zg=""	di2="hang"  	twb1="haG"  	di="hang"  	twb="h-a-ng"	/>  
<izd zg=""	di2="hann"  	twb1="hA"  	di="hann"  	twb="h-ann"	/>  
<izd zg=""	di2="hannh"  	twb1="hAH"  	di="hannh"  	twb="h-annh"	/>  
<izd zg=""	di2="hap"  	twb1="haP"  	di="hap"  	twb="h-ap"	/>  
<izd zg=""	di2="hat"  	twb1="haT"  	di="hat"  	twb="h-at"	/>  
<izd zg=""	di2="hau"  	twb1="hau"  	di="hau"  	twb="h-a-u"	/>  
<izd zg=""	di2="he"  	twb1="he"  	di="he"  	twb="h-e"	/>  
<izd zg=""	di2="heh"  	twb1="heH"  	di="heh"  	twb="h-eh"	/>  
<izd zg=""	di2="hen"  	twb1="heN"  	di="hen"  	twb="h-e-n"	/>  
<izd zg=""	di2="henn"  	twb1="hE"  	di="henn"  	twb="h-enn"	/>  
<izd zg=""	di2="hennh"  	twb1="hEH"  	di="hennh"  	twb="h-ennh"	/>  
<izd zg=""	di2="het"  	twb1="heT"  	di="het"  	twb="h-et"	/>  
<izd zg=""	di2="hi"  	twb1="hi"  	di="hi"  	twb="h-i"	/>  
<izd zg=""	di2="hia"  	twb1="hia"  	di="hia"  	twb="h-i-a"	/>  
<izd zg=""	di2="hiah"  	twb1="hiaH"  	di="hiah"  	twb="h-i-ah"	/>  
<izd zg=""	di2="hiam"  	twb1="hiaM"  	di="hiam"  	twb="h-i-a-m"	/>  
<izd zg=""	di2="hiang"  	twb1="hiaG"  	di="hiang"  	twb="h-i-a-ng"	/>  
<izd zg=""	di2="hiann"  	twb1="hIA"  	di="hiann"  	twb="h-inn-ann"	/>  
<izd zg=""	di2="hiap"  	twb1="hiaP"  	di="hiap"  	twb="h-i-ap"	/>  
<izd zg=""	di2="hiau"  	twb1="hiau"  	di="hiau"  	twb="h-i-a-u"	/>  
<izd zg=""	di2="hik"  	twb1="hiK"  	di="hik"  	twb="h-ik"	/>  
<izd zg=""	di2="him"  	twb1="hiM"  	di="him"  	twb="h-i-m"	/>  
<izd zg=""	di2="hin"  	twb1="hiN"  	di="hin"  	twb="h-i-n"	/>  
<izd zg=""	di2="hing"  	twb1="hiG"  	di="hing"  	twb="h-i-ng"	/>  
<izd zg=""	di2="hinn"  	twb1="hI"  	di="hinn"  	twb="h-inn"	/>  
<izd zg=""	di2="hiok"  	twb1="hioK"  	di="hiok"  	twb="h-i-ok"	/>  
<izd zg=""	di2="hiong"  	twb1="hioG"  	di="hiong"  	twb="h-i-o-ng"	/>  
<izd zg=""	di2="hionn"  	twb1="hIO"  	di="hionn"  	twb="h-inn-onn"	/>  
<izd zg=""	di2="hior"  	twb1="hir"  	di="hior"  	twb="h-i-or"	/>  
<izd zg=""	di2="hiorh"  	twb1="hirH"  	di="hiorh"  	twb="h-i-orh"	/>  
<izd zg=""	di2="hip"  	twb1="hiP"  	di="hip"  	twb="h-ip"	/>  
<izd zg=""	di2="hit"  	twb1="hiT"  	di="hit"  	twb="h-it"	/>  
<izd zg=""	di2="hiu"  	twb1="hiu"  	di="hiu"  	twb="h-i-u"	/>  
<izd zg=""	di2="hiunn"  	twb1="hIU"  	di="hiunn"  	twb="h-inn-unn"	/>  
<izd zg=""	di2="hm"  	twb1="hM"  	di="hm"  	twb="h-m"	/>  
<izd zg=""	di2="hng"  	twb1="hG"  	di="hng"  	twb="h-ng"	/>  
<izd zg=""	di2="ho"  	twb1="ho"  	di="ho"  	twb="h-o"	/>  
<izd zg=""	di2="hok"  	twb1="hoK"  	di="hok"  	twb="h-ok"	/>  
<izd zg=""	di2="hong"  	twb1="hoG"  	di="hong"  	twb="h-o-ng"	/>  
<izd zg=""	di2="honn"  	twb1="hO"  	di="honn"  	twb="h-onn"	/>  
<izd zg=""	di2="hop"  	twb1="hoP"  	di="hop"  	twb="h-op"	/>  
<izd zg=""	di2="hor"  	twb1="hr"  	di="hor"  	twb="h-or"	/>  
<izd zg=""	di2="horh"  	twb1="hrH"  	di="horh"  	twb="h-orh"	/>  
<izd zg=""	di2="hu"  	twb1="hu"  	di="hu"  	twb="h-u"	/>  
<izd zg=""	di2="hua"  	twb1="hua"  	di="hua"  	twb="h-u-a"	/>  
<izd zg=""	di2="huah"  	twb1="huaH"  	di="huah"  	twb="h-u-ah"	/>  
<izd zg=""	di2="huai"  	twb1="huai"  	di="huai"  	twb="h-u-a-i"	/>  
<izd zg=""	di2="huainn"  	twb1="hUAI"  	di="huainn"  	twb="h-unn-ann-inn"	/>  
<izd zg=""	di2="huan"  	twb1="huaN"  	di="huan"  	twb="h-u-a-n"	/>  
<izd zg=""	di2="huann"  	twb1="hUA"  	di="huann"  	twb="h-unn-ann"	/>  
<izd zg=""	di2="huat"  	twb1="huaT"  	di="huat"  	twb="h-u-at"	/>  
<izd zg=""	di2="hue"  	twb1="hue"  	di="hue"  	twb="h-u-e"	/>  
<izd zg=""	di2="hueh"  	twb1="hueH"  	di="hueh"  	twb="h-u-eh"	/>  
<izd zg=""	di2="hui"  	twb1="hui"  	di="hui"  	twb="h-u-i"	/>  
<izd zg=""	di2="huih"  	twb1="huiH"  	di="huih"  	twb="h-u-ih"	/>  
<izd zg=""	di2="huinn"  	twb1="hUI"  	di="huinn"  	twb="h-unn-inn"	/>  
<izd zg=""	di2="hun"  	twb1="huN"  	di="hun"  	twb="h-u-n"	/>  
<izd zg=""	di2="hut"  	twb1="huT"  	di="hut"  	twb="h-ut"	/>  
<izd zg=""	di2="i"  	twb1="i"  	di="i"  	twb="i"  	/>  
<izd zg=""	di2="ia"  	twb1="ia"  	di="ia"  	twb="i-a"	/>  
<izd zg=""	di2="iah"  	twb1="iaH"  	di="iah"  	twb="i-ah"	/>  
<izd zg=""	di2="iak"  	twb1="iaK"  	di="iak"  	twb="i-ak"	/>  
<izd zg=""	di2="iam"  	twb1="iaM"  	di="iam"  	twb="i-a-m"	/>  
<izd zg=""	di2="iang"  	twb1="iaG"  	di="iang"  	twb="i-a-ng"	/>  
<izd zg=""	di2="iann"  	twb1="IA"  	di="iann"  	twb="inn-ann"	/>  
<izd zg=""	di2="iap"  	twb1="iaP"  	di="iap"  	twb="i-ap"	/>  
<izd zg=""	di2="iau"  	twb1="iau"  	di="iau"  	twb="i-a-u"	/>  
<izd zg=""	di2="ik"  	twb1="iK"  	di="ik"  	twb="ik"	/>  
<izd zg=""	di2="im"  	twb1="iM"  	di="im"  	twb="i-m"	/>  
<izd zg=""	di2="in"  	twb1="iN"  	di="in"  	twb="i-n"	/>  
<izd zg=""	di2="ing"  	twb1="iG"  	di="ing"  	twb="i-ng"	/>  
<izd zg=""	di2="inn"  	twb1="I"  	di="inn"  	twb="inn"	/>  
<izd zg=""	di2="iok"  	twb1="ioK"  	di="iok"  	twb="i-ok"	/>  
<izd zg=""	di2="iong"  	twb1="ioG"  	di="iong"  	twb="i-o-ng"	/>  
<izd zg=""	di2="ionn"  	twb1="IO"  	di="ionn"  	twb="inn-onn"	/>  
<izd zg=""	di2="ior"  	twb1="ir"  	di="ior"  	twb="i-or"	/>  
<izd zg=""	di2="iorh"  	twb1="irH"  	di="iorh"  	twb="i-orh"	/>  
<izd zg=""	di2="ip"  	twb1="iP"  	di="ip"  	twb="ip"	/>  
<izd zg=""	di2="it"  	twb1="iT"  	di="it"  	twb="it"	/>  
<izd zg=""	di2="iu"  	twb1="iu"  	di="iu"  	twb="i-u"	/>  
<izd zg=""	di2="iunn"  	twb1="IU"  	di="iunn"  	twb="inn-unn"	/>  
<izd zg=""	di2="ja"  	twb1="ja"  	di="za"  	twb="z-a"	/>  
<izd zg=""	di2="jah"  	twb1="jaH"  	di="zah"  	twb="z-ah"	/>  
<izd zg=""	di2="jai"  	twb1="jai"  	di="zai"  	twb="z-a-i"	/>  
<izd zg=""	di2="jainn"  	twb1="zAI"  	di="zainn"  	twb="z-ann-inn"	/>  
<izd zg=""	di2="jak"  	twb1="jaK"  	di="zak"  	twb="z-ak"	/>  
<izd zg=""	di2="jam"  	twb1="jaM"  	di="zam"  	twb="z-a-m"	/>  
<izd zg=""	di2="jan"  	twb1="jaN"  	di="zan"  	twb="z-a-n"	/>  
<izd zg=""	di2="jang"  	twb1="jaG"  	di="zang"  	twb="z-a-ng"	/>  
<izd zg=""	di2="jann"  	twb1="zA"  	di="zann"  	twb="z-ann"	/>  
<izd zg=""	di2="jap"  	twb1="jaP"  	di="zap"  	twb="z-ap"	/>  
<izd zg=""	di2="jat"  	twb1="jaT"  	di="zat"  	twb="z-at"	/>  
<izd zg=""	di2="jau"  	twb1="jau"  	di="zau"  	twb="z-a-u"	/>  
<izd zg=""	di2="je"  	twb1="je"  	di="ze"  	twb="z-e"	/>  
<izd zg=""	di2="jeh"  	twb1="jeH"  	di="zeh"  	twb="z-eh"	/>  
<izd zg=""	di2="jen"  	twb1="jeN"  	di="zen"  	twb="z-e-n"	/>  
<izd zg=""	di2="jenn"  	twb1="jE"  	di="zenn"  	twb="z-enn"	/>  
<izd zg=""	di2="jet"  	twb1="jeT"  	di="zet"  	twb="z-et"	/>  
<izd zg=""	di2="ji"  	twb1="ji"  	di="zi"  	twb="z-i"	/>  
<izd zg=""	di2="jia"  	twb1="jia"  	di="zia"  	twb="z-i-a"	/>  
<izd zg=""	di2="jiah"  	twb1="jiaH"  	di="ziah"  	twb="z-i-ah"	/>  
<izd zg=""	di2="jiak"  	twb1="ziaK"  	di="ziak"  	twb="z-i-ak"	/>  
<izd zg=""	di2="jiam"  	twb1="jiaM"  	di="ziam"  	twb="z-i-a-m"	/>  
<izd zg=""	di2="jiang"  	twb1="jiaG"  	di="ziang"  	twb="z-i-a-ng"	/>  
<izd zg=""	di2="jiann"  	twb1="jIA"  	di="ziann"  	twb="z-inn-ann"	/>  
<izd zg=""	di2="jiap"  	twb1="jiaP"  	di="ziap"  	twb="z-i-ap"	/>  
<izd zg=""	di2="jiau"  	twb1="jiau"  	di="ziau"  	twb="z-i-a-u"	/>  
<izd zg=""	di2="jih"  	twb1="jiH"  	di="zih"  	twb="z-ih"	/>  
<izd zg=""	di2="jik"  	twb1="jiK"  	di="zik"  	twb="z-ik"	/>  
<izd zg=""	di2="jim"  	twb1="jiM"  	di="zim"  	twb="z-i-m"	/>  
<izd zg=""	di2="jin"  	twb1="jiN"  	di="zin"  	twb="z-i-n"	/>  
<izd zg=""	di2="jing"  	twb1="jiG"  	di="zing"  	twb="z-i-ng"	/>  
<izd zg=""	di2="jinn"  	twb1="jI"  	di="zinn"  	twb="z-inn"	/>  
<izd zg=""	di2="jio"  	twb1="jio"  	di="zio"  	twb="z-i-o"	/>  
<izd zg=""	di2="jiok"  	twb1="jioK"  	di="ziok"  	twb="z-i-ok"	/>  
<izd zg=""	di2="jiong"  	twb1="jioG"  	di="ziong"  	twb="z-i-o-ng"	/>  
<izd zg=""	di2="jionn"  	twb1="zIO"  	di="zionn"  	twb="z-inn-onn"	/>  
<izd zg=""	di2="jior"  	twb1="jir"  	di="zior"  	twb="z-i-or"	/>  
<izd zg=""	di2="jiorh"  	twb1="jirH"  	di="ziorh"  	twb="z-i-orh"	/>  
<izd zg=""	di2="jip"  	twb1="jiP"  	di="zip"  	twb="z-ip"	/>  
<izd zg=""	di2="jit"  	twb1="jiT"  	di="zit"  	twb="z-it"	/>  
<izd zg=""	di2="jiu"  	twb1="jiu"  	di="ziu"  	twb="z-i-u"	/>  
<izd zg=""	di2="jiunn"  	twb1="jIU"  	di="ziunn"  	twb="z-inn-unn"	/>  
<izd zg=""	di2="jng"  	twb1="jG"  	di="zng"  	twb="z-ng"	/>  
<izd zg=""	di2="jo"  	twb1="jo"  	di="zo"  	twb="z-o"	/>  
<izd zg=""	di2="jok"  	twb1="joK"  	di="zok"  	twb="z-ok"	/>  
<izd zg=""	di2="jom"  	twb1="zoM"  	di="zom"  	twb="z-o-m"	/>  
<izd zg=""	di2="jong"  	twb1="joG"  	di="zong"  	twb="z-o-ng"	/>  
<izd zg=""	di2="jor"  	twb1="jr"  	di="zor"  	twb="z-or"	/>  
<izd zg=""	di2="jorh"  	twb1="jrH"  	di="zorh"  	twb="z-orh"	/>  
<izd zg=""	di2="ju"  	twb1="ju"  	di="zu"  	twb="z-u"	/>  
<izd zg=""	di2="jua"  	twb1="jua"  	di="zua"  	twb="z-u-a"	/>  
<izd zg=""	di2="juah"  	twb1="juaH"  	di="zuah"  	twb="z-u-ah"	/>  
<izd zg=""	di2="juan"  	twb1="juaN"  	di="zuan"  	twb="z-u-a-n"	/>  
<izd zg=""	di2="juann"  	twb1="jUA"  	di="zuann"  	twb="z-unn-ann"	/>  
<izd zg=""	di2="juat"  	twb1="juaT"  	di="zuat"  	twb="z-u-at"	/>  
<izd zg=""	di2="jue"  	twb1="jue"  	di="zue"  	twb="z-u-e"	/>  
<izd zg=""	di2="jueh"  	twb1="zueH"  	di="zueh"  	twb="z-u-eh"	/>  
<izd zg=""	di2="jui"  	twb1="jui"  	di="zui"  	twb="z-u-i"	/>  
<izd zg=""	di2="jun"  	twb1="juN"  	di="zun"  	twb="z-u-n"	/>  
<izd zg=""	di2="jut"  	twb1="juT"  	di="zut"  	twb="z-ut"	/>  
<izd zg=""	di2="ka"  	twb1="ka"  	di="ka"  	twb="k-a"	/>  
<izd zg=""	di2="kah"  	twb1="kaH"  	di="kah"  	twb="k-ah"	/>  
<izd zg=""	di2="kai"  	twb1="kai"  	di="kai"  	twb="k-a-i"	/>  
<izd zg=""	di2="kak"  	twb1="kaK"  	di="kak"  	twb="k-ak"	/>  
<izd zg=""	di2="kam"  	twb1="kaM"  	di="kam"  	twb="k-a-m"	/>  
<izd zg=""	di2="kan"  	twb1="kaN"  	di="kan"  	twb="k-a-n"	/>  
<izd zg=""	di2="kang"  	twb1="kaG"  	di="kang"  	twb="k-a-ng"	/>  
<izd zg=""	di2="kann"  	twb1="kA"  	di="kann"  	twb="k-ann"	/>  
<izd zg=""	di2="kap"  	twb1="kaP"  	di="kap"  	twb="k-ap"	/>  
<izd zg=""	di2="kat"  	twb1="kaT"  	di="kat"  	twb="k-at"	/>  
<izd zg=""	di2="kau"  	twb1="kau"  	di="kau"  	twb="k-a-u"	/>  
<izd zg=""	di2="ke"  	twb1="ke"  	di="ke"  	twb="k-e"	/>  
<izd zg=""	di2="keh"  	twb1="keH"  	di="keh"  	twb="k-eh"	/>  
<izd zg=""	di2="ken"  	twb1="keN"  	di="ken"  	twb="k-e-n"	/>  
<izd zg=""	di2="kenn"  	twb1="kE"  	di="kenn"  	twb="k-enn"	/>  
<izd zg=""	di2="ket"  	twb1="keT"  	di="ket"  	twb="k-et"	/>  
<izd zg=""	di2="ki"  	twb1="ki"  	di="ki"  	twb="k-i"	/>  
<izd zg=""	di2="kia"  	twb1="kia"  	di="kia"  	twb="k-i-a"	/>  
<izd zg=""	di2="kiah"  	twb1="kiaH"  	di="kiah"  	twb="k-i-ah"	/>  
<izd zg=""	di2="kiak"  	twb1="kiaK"  	di="kiak"  	twb="k-i-ak"	/>  
<izd zg=""	di2="kiam"  	twb1="kiaM"  	di="kiam"  	twb="k-i-a-m"	/>  
<izd zg=""	di2="kiang"  	twb1="kiaG"  	di="kiang"  	twb="k-i-a-ng"	/>  
<izd zg=""	di2="kiap"  	twb1="kiaP"  	di="kiap"  	twb="k-i-ap"	/>  
<izd zg=""	di2="kiau"  	twb1="kiau"  	di="kiau"  	twb="k-i-a-u"	/>  
<izd zg=""	di2="kih"  	twb1="kiH"  	di="kih"  	twb="k-ih"	/>  
<izd zg=""	di2="kik"  	twb1="kiK"  	di="kik"  	twb="k-ik"	/>  
<izd zg=""	di2="kim"  	twb1="kiM"  	di="kim"  	twb="k-i-m"	/>  
<izd zg=""	di2="kin"  	twb1="kiN"  	di="kin"  	twb="k-i-n"	/>  
<izd zg=""	di2="king"  	twb1="kiG"  	di="king"  	twb="k-i-ng"	/>  
<izd zg=""	di2="kinn"  	twb1="kI"  	di="kinn"  	twb="k-inn"	/>  
<izd zg=""	di2="kioh"  	twb1="kioH"  	di="kioh"  	twb="k-i-oh"	/>  
<izd zg=""	di2="kiok"  	twb1="kioK"  	di="kiok"  	twb="k-i-ok"	/>  
<izd zg=""	di2="kiong"  	twb1="kioG"  	di="kiong"  	twb="k-i-o-ng"	/>  
<izd zg=""	di2="kior"  	twb1="kir"  	di="kior"  	twb="k-i-or"	/>  
<izd zg=""	di2="kiorh"  	twb1="kirH"  	di="kiorh"  	twb="k-i-orh"	/>  
<izd zg=""	di2="kip"  	twb1="kiP"  	di="kip"  	twb="k-ip"	/>  
<izd zg=""	di2="kit"  	twb1="kiT"  	di="kit"  	twb="k-it"	/>  
<izd zg=""	di2="kiu"  	twb1="kiu"  	di="kiu"  	twb="k-i-u"	/>  
<izd zg=""	di2="kiunn"  	twb1="kIU"  	di="kiunn"  	twb="k-inn-unn"	/>  
<izd zg=""	di2="kng"  	twb1="kG"  	di="kng"  	twb="k-ng"	/>  
<izd zg=""	di2="ko"  	twb1="ko"  	di="ko"  	twb="k-o"	/>  
<izd zg=""	di2="kok"  	twb1="koK"  	di="kok"  	twb="k-ok"	/>  
<izd zg=""	di2="kong"  	twb1="koG"  	di="kong"  	twb="k-o-ng"	/>  
<izd zg=""	di2="konn"  	twb1="kO"  	di="konn"  	twb="k-onn"	/>  
<izd zg=""	di2="kor"  	twb1="kr"  	di="kor"  	twb="k-or"	/>  
<izd zg=""	di2="ku"  	twb1="ku"  	di="ku"  	twb="k-u"	/>  
<izd zg=""	di2="kua"  	twb1="kua"  	di="kua"  	twb="k-u-a"	/>  
<izd zg=""	di2="kuah"  	twb1="kuaH"  	di="kuah"  	twb="k-u-ah"	/>  
<izd zg=""	di2="kuai"  	twb1="kuai"  	di="kuai"  	twb="k-u-a-i"	/>  
<izd zg=""	di2="kuan"  	twb1="kuaN"  	di="kuan"  	twb="k-u-a-n"	/>  
<izd zg=""	di2="kuann"  	twb1="kUA"  	di="kuann"  	twb="k-unn-ann"	/>  
<izd zg=""	di2="kuat"  	twb1="kuaT"  	di="kuat"  	twb="k-u-at"	/>  
<izd zg=""	di2="kue"  	twb1="kue"  	di="kue"  	twb="k-u-e"	/>  
<izd zg=""	di2="kueh"  	twb1="kueH"  	di="kueh"  	twb="k-u-eh"	/>  
<izd zg=""	di2="kui"  	twb1="kui"  	di="kui"  	twb="k-u-i"	/>  
<izd zg=""	di2="kuinn"  	twb1="kUI"  	di="kuinn"  	twb="k-unn-inn"	/>  
<izd zg=""	di2="kun"  	twb1="kuN"  	di="kun"  	twb="k-u-n"	/>  
<izd zg=""	di2="kut"  	twb1="kuT"  	di="kut"  	twb="k-ut"	/>  
<izd zg=""	di2="la"  	twb1="la"  	di="la"  	twb="l-a"	/>  
<izd zg=""	di2="lah"  	twb1="laH"  	di="lah"  	twb="l-ah"	/>  
<izd zg=""	di2="lai"  	twb1="lai"  	di="lai"  	twb="l-a-i"	/>  
<izd zg=""	di2="lak"  	twb1="laK"  	di="lak"  	twb="l-ak"	/>  
<izd zg=""	di2="lam"  	twb1="laM"  	di="lam"  	twb="l-a-m"	/>  
<izd zg=""	di2="lan"  	twb1="laN"  	di="lan"  	twb="l-a-n"	/>  
<izd zg=""	di2="lang"  	twb1="laG"  	di="lang"  	twb="l-a-ng"	/>  
<izd zg=""	di2="lap"  	twb1="laP"  	di="lap"  	twb="l-ap"	/>  
<izd zg=""	di2="lat"  	twb1="laT"  	di="lat"  	twb="l-at"	/>  
<izd zg=""	di2="lau"  	twb1="lau"  	di="lau"  	twb="l-a-u"	/>  
<izd zg=""	di2="le"  	twb1="le"  	di="le"  	twb="l-e"	/>  
<izd zg=""	di2="leh"  	twb1="leH"  	di="leh"  	twb="l-eh"	/>  
<izd zg=""	di2="len"  	twb1="leN"  	di="len"  	twb="l-e-n"	/>  
<izd zg=""	di2="let"  	twb1="leT"  	di="let"  	twb="l-et"	/>  
<izd zg=""	di2="li"  	twb1="li"  	di="li"  	twb="l-i"	/>  
<izd zg=""	di2="lia"  	twb1="lia"  	di="lia"  	twb="l-i-a"	/>  
<izd zg=""	di2="liah"  	twb1="liaH"  	di="liah"  	twb="l-i-ah"	/>  
<izd zg=""	di2="liak"  	twb1="liaK"  	di="liak"  	twb="l-i-ak"	/>  
<izd zg=""	di2="liam"  	twb1="liaM"  	di="liam"  	twb="l-i-a-m"	/>  
<izd zg=""	di2="liang"  	twb1="liaG"  	di="liang"  	twb="l-i-a-ng"	/>  
<izd zg=""	di2="liap"  	twb1="liaP"  	di="liap"  	twb="l-i-ap"	/>  
<izd zg=""	di2="liau"  	twb1="liau"  	di="liau"  	twb="l-i-a-u"	/>  
<izd zg=""	di2="lih"  	twb1="liH"  	di="lih"  	twb="l-ih"	/>  
<izd zg=""	di2="lik"  	twb1="liK"  	di="lik"  	twb="l-ik"	/>  
<izd zg=""	di2="lim"  	twb1="liM"  	di="lim"  	twb="l-i-m"	/>  
<izd zg=""	di2="lin"  	twb1="liN"  	di="lin"  	twb="l-i-n"	/>  
<izd zg=""	di2="ling"  	twb1="liG"  	di="ling"  	twb="l-i-ng"	/>  
<izd zg=""	di2="liok"  	twb1="lioK"  	di="liok"  	twb="l-i-ok"	/>  
<izd zg=""	di2="liong"  	twb1="lioG"  	di="liong"  	twb="l-i-o-ng"	/>  
<izd zg=""	di2="lior"  	twb1="lir"  	di="lior"  	twb="l-i-or"	/>  
<izd zg=""	di2="liorh"  	twb1="lirH"  	di="liorh"  	twb="l-i-orh"	/>  
<izd zg=""	di2="lip"  	twb1="liP"  	di="lip"  	twb="l-ip"	/>  
<izd zg=""	di2="lit"  	twb1="liT"  	di="lit"  	twb="l-it"	/>  
<izd zg=""	di2="liu"  	twb1="liu"  	di="liu"  	twb="l-i-u"	/>  
<izd zg=""	di2="lng"  	twb1="lG"  	di="lng"  	twb="l-ng"	/>  
<izd zg=""	di2="lo"  	twb1="lo"  	di="lo"  	twb="l-o"	/>  
<izd zg=""	di2="loh"  	twb1="loH"  	di="loh"  	twb="l-oh"	/>  
<izd zg=""	di2="lok"  	twb1="loK"  	di="lok"  	twb="l-ok"	/>  
<izd zg=""	di2="long"  	twb1="loG"  	di="long"  	twb="l-o-ng"	/>  
<izd zg=""	di2="lor"  	twb1="lr"  	di="lor"  	twb="l-or"	/>  
<izd zg=""	di2="lorh"  	twb1="lrH"  	di="lorh"  	twb="l-orh"	/>  
<izd zg=""	di2="lu"  	twb1="lu"  	di="lu"  	twb="l-u"	/>  
<izd zg=""	di2="lua"  	twb1="lua"  	di="lua"  	twb="l-u-a"	/>  
<izd zg=""	di2="luah"  	twb1="luaH"  	di="luah"  	twb="l-u-ah"	/>  
<izd zg=""	di2="luan"  	twb1="luaN"  	di="luan"  	twb="l-u-a-n"	/>  
<izd zg=""	di2="lue"  	twb1="lue"  	di="lue"  	twb="l-u-e"	/>  
<izd zg=""	di2="lueh"  	twb1="lueH"  	di="lueh"  	twb="l-u-eh"	/>  
<izd zg=""	di2="lui"  	twb1="lui"  	di="lui"  	twb="l-u-i"	/>  
<izd zg=""	di2="lun"  	twb1="luN"  	di="lun"  	twb="l-u-n"	/>  
<izd zg=""	di2="lut"  	twb1="luT"  	di="lut"  	twb="l-ut"	/>  
<izd zg=""	di2="m"  	twb1="M"  	di="m"  	twb="m"  	/>  
<izd zg=""	di2="ma"  	twb1="mA"  	di="ma"  	twb="m-a"	/>  
<izd zg=""	di2="mah"  	twb1="mAH"  	di="mah"  	twb="m-ah"	/>  
<izd zg=""	di2="mai"  	twb1="mAI"  	di="mai"  	twb="m-a-i"	/>  
<izd zg=""	di2="mau"  	twb1="mAU"  	di="mau"  	twb="m-a-u"	/>  
<izd zg=""	di2="me"  	twb1="mE"  	di="me"  	twb="m-e"	/>  
<izd zg=""	di2="meh"  	twb1="mEH"  	di="meh"  	twb="m-eh"	/>  
<izd zg=""	di2="mi"  	twb1="mI"  	di="mi"  	twb="m-i"	/>  
<izd zg=""	di2="mia"  	twb1="mIA"  	di="mia"  	twb="m-i-a"	/>  
<izd zg=""	di2="miann"  	twb1="mIA"  	di="miann"  	twb="m-inn-ann"	/>  
<izd zg=""	di2="miau"  	twb1="mIAU"  	di="miau"  	twb="m-i-a-u"	/>  
<izd zg=""	di2="mih"  	twb1="mIH"  	di="mih"  	twb="m-ih"	/>  
<izd zg=""	di2="min"  	twb1="miN"  	di="min"  	twb="m-i-n"	/>  
<izd zg=""	di2="ming"  	twb1="miG"  	di="ming"  	twb="m-i-ng"	/>  
<izd zg=""	di2="mio"  	twb1="mio"  	di="mio"  	twb="m-i-o"	/>  
<izd zg=""	di2="mng"  	twb1="mG"  	di="mng"  	twb="m-ng"	/>  
<izd zg=""	di2="mo"  	twb1="mO"  	di="mo"  	twb="m-o"	/>  
<izd zg=""	di2="moh"  	twb1="mOH"  	di="moh"  	twb="m-oh"	/>  
<izd zg=""	di2="mong"  	twb1="moG"  	di="mong"  	twb="m-o-ng"	/>  
<izd zg=""	di2="mua"  	twb1="mUA"  	di="mua"  	twb="m-u-a"	/>  
<izd zg=""	di2="muai"  	twb1="mUAI"  	di="muai"  	twb="m-u-a-i"	/>  
<izd zg=""	di2="muan"  	twb1="mUAN"  	di="muan"  	twb="m-u-a-n"	/>  
<izd zg=""	di2="mue"  	twb1="mue"  	di="mue"  	twb="m-u-e"	/>  
<izd zg=""	di2="mui"  	twb1="mUI"  	di="mui"  	twb="m-u-i"	/>  
<izd zg=""	di2="na"  	twb1="nA"  	di="na"  	twb="n-a"	/>  
<izd zg=""	di2="nah"  	twb1="naH"  	di="nah"  	twb="n-ah"	/>  
<izd zg=""	di2="nai"  	twb1="nAI"  	di="nai"  	twb="n-a-i"	/>  
<izd zg=""	di2="nap"  	twb1="nAP"  	di="nap"  	twb="n-ap"	/>  
<izd zg=""	di2="nau"  	twb1="nAU"  	di="nau"  	twb="n-a-u"	/>  
<izd zg=""	di2="ne"  	twb1="nE"  	di="ne"  	twb="n-e"	/>  
<izd zg=""	di2="neh"  	twb1="nEH"  	di="neh"  	twb="n-eh"	/>  
<izd zg=""	di2="ng"  	twb1="G"  	di="ng"  	twb="ng"	/>  
<izd zg=""	di2="ni"  	twb1="nI"  	di="ni"  	twb="n-i"	/>  
<izd zg=""	di2="nia"  	twb1="nIA"  	di="nia"  	twb="n-i-a"	/>  
<izd zg=""	di2="niau"  	twb1="nIAU"  	di="niau"  	twb="n-i-a-u"	/>  
<izd zg=""	di2="nih"  	twb1="nIH"  	di="nih"  	twb="n-ih"	/>  
<izd zg=""	di2="nio"  	twb1="nio"  	di="nio"  	twb="n-i-o"	/>  
<izd zg=""	di2="niu"  	twb1="nIU"  	di="niu"  	twb="n-i-u"	/>  
<izd zg=""	di2="niunn"  	twb1="nIU"  	di="niunn"  	twb="n-inn-unn"	/>  
<izd zg=""	di2="nng"  	twb1="nG"  	di="nng"  	twb="n-ng"	/>  
<izd zg=""	di2="no"  	twb1="nO"  	di="no"  	twb="n-o"	/>  
<izd zg=""	di2="nqa"  	twb1="QA"  	di="nqa"  	twb="ng-a"	/>  
<izd zg=""	di2="nqai"  	twb1="QAI"  	di="nqai"  	twb="ng-a-i"	/>  
<izd zg=""	di2="nqau"  	twb1="QAU"  	di="nqau"  	twb="ng-a-u"	/>  
<izd zg=""	di2="nqe"  	twb1="QE"  	di="nqe"  	twb="ng-e"	/>  
<izd zg=""	di2="nqennh"  	twb1="QEH"  	di="nqennh"  	twb="ng-ennh"	/>  
<izd zg=""	di2="nqi"  	twb1="QI"  	di="nqi"  	twb="ng-i"	/>  
<izd zg=""	di2="nqia"  	twb1="QIA"  	di="nqia"  	twb="ng-i-a"	/>  
<izd zg=""	di2="nqiau"  	twb1="QIAU"  	di="nqiau"  	twb="ng-i-a-u"	/>  
<izd zg=""	di2="nqo"  	twb1="QO"  	di="nqo"  	twb="ng-o"	/>  
<izd zg=""	di2="nqua"  	twb1="QUA"  	di="nqua"  	twb="ng-u-a"	/>  
<izd zg=""	di2="nua"  	twb1="nUA"  	di="nua"  	twb="n-u-a"	/>  
<izd zg=""	di2="o"  	twb1="o"  	di="o"  	twb="o"  	/>  
<izd zg=""	di2="oh"  	twb1="oH"  	di="oh"  	twb="oh"	/>  
<izd zg=""	di2="ok"  	twb1="oK"  	di="ok"  	twb="ok"	/>  
<izd zg=""	di2="om"  	twb1="oM"  	di="om"  	twb="o-m"	/>  
<izd zg=""	di2="ong"  	twb1="oG"  	di="ong"  	twb="o-ng"	/>  
<izd zg=""	di2="onn"  	twb1="O"  	di="onn"  	twb="onn"	/>  
<izd zg=""	di2="or"  	twb1="r"  	di="or"  	twb="or"	/>  
<izd zg=""	di2="orh"  	twb1="rH"  	di="orh"  	twb="orh"	/>  
<izd zg=""	di2="pa"  	twb1="pa"  	di="pa"  	twb="p-a"	/>  
<izd zg=""	di2="pah"  	twb1="paH"  	di="pah"  	twb="p-ah"	/>  
<izd zg=""	di2="pai"  	twb1="pai"  	di="pai"  	twb="p-a-i"	/>  
<izd zg=""	di2="painn"  	twb1="pAI"  	di="painn"  	twb="p-ann-inn"	/>  
<izd zg=""	di2="pak"  	twb1="paK"  	di="pak"  	twb="p-ak"	/>  
<izd zg=""	di2="pan"  	twb1="paN"  	di="pan"  	twb="p-a-n"	/>  
<izd zg=""	di2="pang"  	twb1="paG"  	di="pang"  	twb="p-a-ng"	/>  
<izd zg=""	di2="pann"  	twb1="pA"  	di="pann"  	twb="p-ann"	/>  
<izd zg=""	di2="pau"  	twb1="pau"  	di="pau"  	twb="p-a-u"	/>  
<izd zg=""	di2="pe"  	twb1="pe"  	di="pe"  	twb="p-e"	/>  
<izd zg=""	di2="peh"  	twb1="peH"  	di="peh"  	twb="p-eh"	/>  
<izd zg=""	di2="pen"  	twb1="peN"  	di="pen"  	twb="p-e-n"	/>  
<izd zg=""	di2="penn"  	twb1="pE"  	di="penn"  	twb="p-enn"	/>  
<izd zg=""	di2="pet"  	twb1="peT"  	di="pet"  	twb="p-et"	/>  
<izd zg=""	di2="pi"  	twb1="pi"  	di="pi"  	twb="p-i"	/>  
<izd zg=""	di2="piah"  	twb1="piaH"  	di="piah"  	twb="p-i-ah"	/>  
<izd zg=""	di2="piann"  	twb1="pIA"  	di="piann"  	twb="p-inn-ann"	/>  
<izd zg=""	di2="piau"  	twb1="piau"  	di="piau"  	twb="p-i-a-u"	/>  
<izd zg=""	di2="pik"  	twb1="piK"  	di="pik"  	twb="p-ik"	/>  
<izd zg=""	di2="pin"  	twb1="piN"  	di="pin"  	twb="p-i-n"	/>  
<izd zg=""	di2="ping"  	twb1="piG"  	di="ping"  	twb="p-i-ng"	/>  
<izd zg=""	di2="pinn"  	twb1="pI"  	di="pinn"  	twb="p-inn"	/>  
<izd zg=""	di2="pior"  	twb1="pir"  	di="pior"  	twb="p-i-or"	/>  
<izd zg=""	di2="pit"  	twb1="piT"  	di="pit"  	twb="p-it"	/>  
<izd zg=""	di2="po"  	twb1="po"  	di="po"  	twb="p-o"	/>  
<izd zg=""	di2="pok"  	twb1="poK"  	di="pok"  	twb="p-ok"	/>  
<izd zg=""	di2="pong"  	twb1="poG"  	di="pong"  	twb="p-o-ng"	/>  
<izd zg=""	di2="por"  	twb1="pr"  	di="por"  	twb="p-or"	/>  
<izd zg=""	di2="porh"  	twb1="prH"  	di="porh"  	twb="p-orh"	/>  
<izd zg=""	di2="pu"  	twb1="pu"  	di="pu"  	twb="p-u"	/>  
<izd zg=""	di2="pua"  	twb1="pua"  	di="pua"  	twb="p-u-a"	/>  
<izd zg=""	di2="puah"  	twb1="puaH"  	di="puah"  	twb="p-u-ah"	/>  
<izd zg=""	di2="puan"  	twb1="puaN"  	di="puan"  	twb="p-u-a-n"	/>  
<izd zg=""	di2="puann"  	twb1="pUA"  	di="puann"  	twb="p-unn-ann"	/>  
<izd zg=""	di2="puat"  	twb1="puaT"  	di="puat"  	twb="p-u-at"	/>  
<izd zg=""	di2="pue"  	twb1="pue"  	di="pue"  	twb="p-u-e"	/>  
<izd zg=""	di2="puh"  	twb1="puH"  	di="puh"  	twb="p-uh"	/>  
<izd zg=""	di2="pui"  	twb1="pui"  	di="pui"  	twb="p-u-i"	/>  
<izd zg=""	di2="pun"  	twb1="puN"  	di="pun"  	twb="p-u-n"	/>  
<izd zg=""	di2="put"  	twb1="puT"  	di="put"  	twb="p-ut"	/>  
<izd zg=""	di2="qa"  	twb1="qa"  	di="qa"  	twb="q-a"	/>  
<izd zg=""	di2="qah"  	twb1="qaH"  	di="qah"  	twb="q-ah"	/>  
<izd zg=""	di2="qai"  	twb1="qai"  	di="qai"  	twb="q-a-i"	/>  
<izd zg=""	di2="qak"  	twb1="qaK"  	di="qak"  	twb="q-ak"	/>  
<izd zg=""	di2="qam"  	twb1="qaM"  	di="qam"  	twb="q-a-m"	/>  
<izd zg=""	di2="qan"  	twb1="qaN"  	di="qan"  	twb="q-a-n"	/>  
<izd zg=""	di2="qang"  	twb1="qaG"  	di="qang"  	twb="q-a-ng"	/>  
<izd zg=""	di2="qat"  	twb1="qaT"  	di="qat"  	twb="q-at"	/>  
<izd zg=""	di2="qau"  	twb1="qau"  	di="qau"  	twb="q-a-u"	/>  
<izd zg=""	di2="qe"  	twb1="qe"  	di="qe"  	twb="q-e"	/>  
<izd zg=""	di2="qeh"  	twb1="qeH"  	di="qeh"  	twb="q-eh"	/>  
<izd zg=""	di2="qen"  	twb1="qeN"  	di="qen"  	twb="q-e-n"	/>  
<izd zg=""	di2="qet"  	twb1="qeT"  	di="qet"  	twb="q-et"	/>  
<izd zg=""	di2="qi"  	twb1="qi"  	di="qi"  	twb="q-i"	/>  
<izd zg=""	di2="qia"  	twb1="qia"  	di="qia"  	twb="q-i-a"	/>  
<izd zg=""	di2="qiah"  	twb1="qiaH"  	di="qiah"  	twb="q-i-ah"	/>  
<izd zg=""	di2="qiak"  	twb1="qiaK"  	di="qiak"  	twb="q-i-ak"	/>  
<izd zg=""	di2="qiam"  	twb1="qiaM"  	di="qiam"  	twb="q-i-a-m"	/>  
<izd zg=""	di2="qiang"  	twb1="qiaG"  	di="qiang"  	twb="q-i-a-ng"	/>  
<izd zg=""	di2="qiap"  	twb1="qiaP"  	di="qiap"  	twb="q-i-ap"	/>  
<izd zg=""	di2="qiau"  	twb1="qiau"  	di="qiau"  	twb="q-i-a-u"	/>  
<izd zg=""	di2="qih"  	twb1="qiH"  	di="qih"  	twb="q-ih"	/>  
<izd zg=""	di2="qik"  	twb1="qiK"  	di="qik"  	twb="q-ik"	/>  
<izd zg=""	di2="qim"  	twb1="qiM"  	di="qim"  	twb="q-i-m"	/>  
<izd zg=""	di2="qin"  	twb1="qiN"  	di="qin"  	twb="q-i-n"	/>  
<izd zg=""	di2="qing"  	twb1="qiG"  	di="qing"  	twb="q-i-ng"	/>  
<izd zg=""	di2="qiok"  	twb1="qioK"  	di="qiok"  	twb="q-i-ok"	/>  
<izd zg=""	di2="qiong"  	twb1="qioG"  	di="qiong"  	twb="q-i-o-ng"	/>  
<izd zg=""	di2="qior"  	twb1="qir"  	di="qior"  	twb="q-i-or"	/>  
<izd zg=""	di2="qip"  	twb1="qiP"  	di="qip"  	twb="q-ip"	/>  
<izd zg=""	di2="qit"  	twb1="qiT"  	di="qit"  	twb="q-it"	/>  
<izd zg=""	di2="qiu"  	twb1="qiu"  	di="qiu"  	twb="q-i-u"	/>  
<izd zg=""	di2="qo"  	twb1="qo"  	di="qo"  	twb="q-o"	/>  
<izd zg=""	di2="qok"  	twb1="qoK"  	di="qok"  	twb="q-ok"	/>  
<izd zg=""	di2="qong"  	twb1="qoG"  	di="qong"  	twb="q-o-ng"	/>  
<izd zg=""	di2="qor"  	twb1="qr"  	di="qor"  	twb="q-or"	/>  
<izd zg=""	di2="qu"  	twb1="qu"  	di="qu"  	twb="q-u"	/>  
<izd zg=""	di2="qua"  	twb1="qua"  	di="qua"  	twb="q-u-a"	/>  
<izd zg=""	di2="quai"  	twb1="quai"  	di="quai"  	twb="q-u-a-i"	/>  
<izd zg=""	di2="quan"  	twb1="quaN"  	di="quan"  	twb="q-u-a-n"	/>  
<izd zg=""	di2="quat"  	twb1="quaT"  	di="quat"  	twb="q-u-at"	/>  
<izd zg=""	di2="que"  	twb1="que"  	di="que"  	twb="q-u-e"	/>  
<izd zg=""	di2="queh"  	twb1="queH"  	di="queh"  	twb="q-u-eh"	/>  
<izd zg=""	di2="qui"  	twb1="qui"  	di="qui"  	twb="q-u-i"	/>  
<izd zg=""	di2="qun"  	twb1="quN"  	di="qun"  	twb="q-u-n"	/>  
<izd zg=""	di2="sa"  	twb1="sa"  	di="sa"  	twb="s-a"	/>  
<izd zg=""	di2="sai"  	twb1="sai"  	di="sai"  	twb="s-a-i"	/>  
<izd zg=""	di2="sak"  	twb1="saK"  	di="sak"  	twb="s-ak"	/>  
<izd zg=""	di2="sam"  	twb1="saM"  	di="sam"  	twb="s-a-m"	/>  
<izd zg=""	di2="san"  	twb1="saN"  	di="san"  	twb="s-a-n"	/>  
<izd zg=""	di2="sang"  	twb1="saG"  	di="sang"  	twb="s-a-ng"	/>  
<izd zg=""	di2="sann"  	twb1="sA"  	di="sann"  	twb="s-ann"	/>  
<izd zg=""	di2="sap"  	twb1="saP"  	di="sap"  	twb="s-ap"	/>  
<izd zg=""	di2="sat"  	twb1="saT"  	di="sat"  	twb="s-at"	/>  
<izd zg=""	di2="sau"  	twb1="sau"  	di="sau"  	twb="s-a-u"	/>  
<izd zg=""	di2="se"  	twb1="se"  	di="se"  	twb="s-e"	/>  
<izd zg=""	di2="seh"  	twb1="seH"  	di="seh"  	twb="s-eh"	/>  
<izd zg=""	di2="sen"  	twb1="seN"  	di="sen"  	twb="s-e-n"	/>  
<izd zg=""	di2="senn"  	twb1="sE"  	di="senn"  	twb="s-enn"	/>  
<izd zg=""	di2="set"  	twb1="seT"  	di="set"  	twb="s-et"	/>  
<izd zg=""	di2="si"  	twb1="si"  	di="si"  	twb="s-i"	/>  
<izd zg=""	di2="sia"  	twb1="sia"  	di="sia"  	twb="s-i-a"	/>  
<izd zg=""	di2="siah"  	twb1="siaH"  	di="siah"  	twb="s-i-ah"	/>  
<izd zg=""	di2="siak"  	twb1="siaK"  	di="siak"  	twb="s-i-ak"	/>  
<izd zg=""	di2="siam"  	twb1="siaM"  	di="siam"  	twb="s-i-a-m"	/>  
<izd zg=""	di2="siang"  	twb1="siaG"  	di="siang"  	twb="s-i-a-ng"	/>  
<izd zg=""	di2="siann"  	twb1="sIA"  	di="siann"  	twb="s-inn-ann"	/>  
<izd zg=""	di2="siap"  	twb1="siaP"  	di="siap"  	twb="s-i-ap"	/>  
<izd zg=""	di2="siau"  	twb1="siau"  	di="siau"  	twb="s-i-a-u"	/>  
<izd zg=""	di2="sih"  	twb1="siH"  	di="sih"  	twb="s-ih"	/>  
<izd zg=""	di2="sik"  	twb1="siK"  	di="sik"  	twb="s-ik"	/>  
<izd zg=""	di2="sim"  	twb1="siM"  	di="sim"  	twb="s-i-m"	/>  
<izd zg=""	di2="sin"  	twb1="siN"  	di="sin"  	twb="s-i-n"	/>  
<izd zg=""	di2="sing"  	twb1="siG"  	di="sing"  	twb="s-i-ng"	/>  
<izd zg=""	di2="sinn"  	twb1="sI"  	di="sinn"  	twb="s-inn"	/>  
<izd zg=""	di2="siok"  	twb1="sioK"  	di="siok"  	twb="s-i-ok"	/>  
<izd zg=""	di2="siong"  	twb1="sioG"  	di="siong"  	twb="s-i-o-ng"	/>  
<izd zg=""	di2="sionn"  	twb1="sIO"  	di="sionn"  	twb="s-inn-onn"	/>  
<izd zg=""	di2="sior"  	twb1="sir"  	di="sior"  	twb="s-i-or"	/>  
<izd zg=""	di2="siorh"  	twb1="sirH"  	di="siorh"  	twb="s-i-orh"	/>  
<izd zg=""	di2="sip"  	twb1="siP"  	di="sip"  	twb="s-ip"	/>  
<izd zg=""	di2="sit"  	twb1="siT"  	di="sit"  	twb="s-it"	/>  
<izd zg=""	di2="siu"  	twb1="siu"  	di="siu"  	twb="s-i-u"	/>  
<izd zg=""	di2="siunn"  	twb1="sIU"  	di="siunn"  	twb="s-inn-unn"	/>  
<izd zg=""	di2="sng"  	twb1="sG"  	di="sng"  	twb="s-ng"	/>  
<izd zg=""	di2="so"  	twb1="so"  	di="so"  	twb="s-o"	/>  
<izd zg=""	di2="sok"  	twb1="soK"  	di="sok"  	twb="s-ok"	/>  
<izd zg=""	di2="som"  	twb1="soM"  	di="som"  	twb="s-o-m"	/>  
<izd zg=""	di2="song"  	twb1="soG"  	di="song"  	twb="s-o-ng"	/>  
<izd zg=""	di2="sor"  	twb1="sr"  	di="sor"  	twb="s-or"	/>  
<izd zg=""	di2="sorh"  	twb1="srH"  	di="sorh"  	twb="s-orh"	/>  
<izd zg=""	di2="su"  	twb1="su"  	di="su"  	twb="s-u"	/>  
<izd zg=""	di2="sua"  	twb1="sua"  	di="sua"  	twb="s-u-a"	/>  
<izd zg=""	di2="suah"  	twb1="suaH"  	di="suah"  	twb="s-u-ah"	/>  
<izd zg=""	di2="suai"  	twb1="suai"  	di="suai"  	twb="s-u-a-i"	/>  
<izd zg=""	di2="suainn"  	twb1="sUAI"  	di="suainn"  	twb="s-unn-ann-inn"	/>  
<izd zg=""	di2="suan"  	twb1="suaN"  	di="suan"  	twb="s-u-a-n"	/>  
<izd zg=""	di2="suann"  	twb1="sUA"  	di="suann"  	twb="s-unn-ann"	/>  
<izd zg=""	di2="suat"  	twb1="suaT"  	di="suat"  	twb="s-u-at"	/>  
<izd zg=""	di2="sue"  	twb1="sue"  	di="sue"  	twb="s-u-e"	/>  
<izd zg=""	di2="sueh"  	twb1="sueH"  	di="sueh"  	twb="s-u-eh"	/>  
<izd zg=""	di2="suh"  	twb1="suH"  	di="suh"  	twb="s-uh"	/>  
<izd zg=""	di2="sui"  	twb1="sui"  	di="sui"  	twb="s-u-i"	/>  
<izd zg=""	di2="suinn"  	twb1="sUI"  	di="suinn"  	twb="s-unn-inn"	/>  
<izd zg=""	di2="sun"  	twb1="suN"  	di="sun"  	twb="s-u-n"	/>  
<izd zg=""	di2="sut"  	twb1="suT"  	di="sut"  	twb="s-ut"	/>  
<izd zg=""	di2="ta"  	twb1="ta"  	di="ta"  	twb="t-a"	/>  
<izd zg=""	di2="tah"  	twb1="taH"  	di="tah"  	twb="t-ah"	/>  
<izd zg=""	di2="tai"  	twb1="tai"  	di="tai"  	twb="t-a-i"	/>  
<izd zg=""	di2="tak"  	twb1="taK"  	di="tak"  	twb="t-ak"	/>  
<izd zg=""	di2="tam"  	twb1="taM"  	di="tam"  	twb="t-a-m"	/>  
<izd zg=""	di2="tan"  	twb1="taN"  	di="tan"  	twb="t-a-n"	/>  
<izd zg=""	di2="tang"  	twb1="taG"  	di="tang"  	twb="t-a-ng"	/>  
<izd zg=""	di2="tann"  	twb1="tA"  	di="tann"  	twb="t-ann"	/>  
<izd zg=""	di2="tat"  	twb1="taT"  	di="tat"  	twb="t-at"	/>  
<izd zg=""	di2="tau"  	twb1="tau"  	di="tau"  	twb="t-a-u"	/>  
<izd zg=""	di2="te"  	twb1="te"  	di="te"  	twb="t-e"	/>  
<izd zg=""	di2="teh"  	twb1="teH"  	di="teh"  	twb="t-eh"	/>  
<izd zg=""	di2="ten"  	twb1="teN"  	di="ten"  	twb="t-e-n"	/>  
<izd zg=""	di2="tenn"  	twb1="tE"  	di="tenn"  	twb="t-enn"	/>  
<izd zg=""	di2="tet"  	twb1="teT"  	di="tet"  	twb="t-et"	/>  
<izd zg=""	di2="ti"  	twb1="ti"  	di="ti"  	twb="t-i"	/>  
<izd zg=""	di2="tiah"  	twb1="tiaH"  	di="tiah"  	twb="t-i-ah"	/>  
<izd zg=""	di2="tiam"  	twb1="tiaM"  	di="tiam"  	twb="t-i-a-m"	/>  
<izd zg=""	di2="tiang"  	twb1="tiaG"  	di="tiang"  	twb="t-i-a-ng"	/>  
<izd zg=""	di2="tiann"  	twb1="tIA"  	di="tiann"  	twb="t-inn-ann"	/>  
<izd zg=""	di2="tiap"  	twb1="tiaP"  	di="tiap"  	twb="t-i-ap"	/>  
<izd zg=""	di2="tiau"  	twb1="tiau"  	di="tiau"  	twb="t-i-a-u"	/>  
<izd zg=""	di2="tih"  	twb1="tiH"  	di="tih"  	twb="t-ih"	/>  
<izd zg=""	di2="tik"  	twb1="tiK"  	di="tik"  	twb="t-ik"	/>  
<izd zg=""	di2="tin"  	twb1="tiN"  	di="tin"  	twb="t-i-n"	/>  
<izd zg=""	di2="ting"  	twb1="tiG"  	di="ting"  	twb="t-i-ng"	/>  
<izd zg=""	di2="tinn"  	twb1="tI"  	di="tinn"  	twb="t-inn"	/>  
<izd zg=""	di2="tiok"  	twb1="tioK"  	di="tiok"  	twb="t-i-ok"	/>  
<izd zg=""	di2="tiong"  	twb1="tioG"  	di="tiong"  	twb="t-i-o-ng"	/>  
<izd zg=""	di2="tior"  	twb1="tir"  	di="tior"  	twb="t-i-or"	/>  
<izd zg=""	di2="tiu"  	twb1="tiu"  	di="tiu"  	twb="t-i-u"	/>  
<izd zg=""	di2="tng"  	twb1="tG"  	di="tng"  	twb="t-ng"	/>  
<izd zg=""	di2="to"  	twb1="to"  	di="to"  	twb="t-o"	/>  
<izd zg=""	di2="tok"  	twb1="toK"  	di="tok"  	twb="t-ok"	/>  
<izd zg=""	di2="tong"  	twb1="toG"  	di="tong"  	twb="t-o-ng"	/>  
<izd zg=""	di2="tor"  	twb1="tr"  	di="tor"  	twb="t-or"	/>  
<izd zg=""	di2="tua"  	twb1="tua"  	di="tua"  	twb="t-u-a"	/>  
<izd zg=""	di2="tuah"  	twb1="tuaH"  	di="tuah"  	twb="t-u-ah"	/>  
<izd zg=""	di2="tuan"  	twb1="tuaN"  	di="tuan"  	twb="t-u-a-n"	/>  
<izd zg=""	di2="tuann"  	twb1="tUA"  	di="tuann"  	twb="t-unn-ann"	/>  
<izd zg=""	di2="tuat"  	twb1="tuaT"  	di="tuat"  	twb="t-u-at"	/>  
<izd zg=""	di2="tue"  	twb1="tue"  	di="tue"  	twb="t-u-e"	/>  
<izd zg=""	di2="tui"  	twb1="tui"  	di="tui"  	twb="t-u-i"	/>  
<izd zg=""	di2="tun"  	twb1="tuN"  	di="tun"  	twb="t-u-n"	/>  
<izd zg=""	di2="tut"  	twb1="tuT"  	di="tut"  	twb="t-ut"	/>  
<izd zg=""	di2="u"  	twb1="u"  	di="u"  	twb="u"  	/>  
<izd zg=""	di2="ua"  	twb1="ua"  	di="ua"  	twb="u-a"	/>  
<izd zg=""	di2="uah"  	twb1="uaH"  	di="uah"  	twb="u-ah"	/>  
<izd zg=""	di2="uai"  	twb1="uai"  	di="uai"  	twb="u-a-i"	/>  
<izd zg=""	di2="uan"  	twb1="uaN"  	di="uan"  	twb="u-a-n"	/>  
<izd zg=""	di2="uann"  	twb1="UA"  	di="uann"  	twb="unn-ann"	/>  
<izd zg=""	di2="uat"  	twb1="uaT"  	di="uat"  	twb="u-at"	/>  
<izd zg=""	di2="ue"  	twb1="ue"  	di="ue"  	twb="u-e"	/>  
<izd zg=""	di2="ui"  	twb1="ui"  	di="ui"  	twb="u-i"	/>  
<izd zg=""	di2="uinn"  	twb1="UI"  	di="uinn"  	twb="unn-inn"	/>  
<izd zg=""	di2="un"  	twb1="uN"  	di="un"  	twb="u-n"	/>  
<izd zg=""	di2="ut"  	twb1="uT"  	di="ut"  	twb="ut"	/>  
<izd zg=""	di2="va"  	twb1="va"  	di="va"  	twb="v-a"	/>  
<izd zg=""	di2="vah"  	twb1="vaH"  	di="vah"  	twb="v-ah"	/>  
<izd zg=""	di2="vai"  	twb1="vai"  	di="vai"  	twb="v-a-i"	/>  
<izd zg=""	di2="vak"  	twb1="vaK"  	di="vak"  	twb="v-ak"	/>  
<izd zg=""	di2="van"  	twb1="vaN"  	di="van"  	twb="v-a-n"	/>  
<izd zg=""	di2="vang"  	twb1="vaG"  	di="vang"  	twb="v-a-ng"	/>  
<izd zg=""	di2="vat"  	twb1="vaT"  	di="vat"  	twb="v-at"	/>  
<izd zg=""	di2="vau"  	twb1="vau"  	di="vau"  	twb="v-a-u"	/>  
<izd zg=""	di2="ve"  	twb1="ve"  	di="ve"  	twb="v-e"	/>  
<izd zg=""	di2="veh"  	twb1="veH"  	di="veh"  	twb="v-eh"	/>  
<izd zg=""	di2="ven"  	twb1="veN"  	di="ven"  	twb="v-e-n"	/>  
<izd zg=""	di2="vet"  	twb1="veT"  	di="vet"  	twb="v-et"	/>  
<izd zg=""	di2="vi"  	twb1="vi"  	di="vi"  	twb="v-i"	/>  
<izd zg=""	di2="viau"  	twb1="viau"  	di="viau"  	twb="v-i-a-u"	/>  
<izd zg=""	di2="vih"  	twb1="viH"  	di="vih"  	twb="v-ih"	/>  
<izd zg=""	di2="vik"  	twb1="viK"  	di="vik"  	twb="v-ik"	/>  
<izd zg=""	di2="vin"  	twb1="viN"  	di="vin"  	twb="v-i-n"	/>  
<izd zg=""	di2="ving"  	twb1="viG"  	di="ving"  	twb="v-i-ng"	/>  
<izd zg=""	di2="vior"  	twb1="vir"  	di="vior"  	twb="v-i-or"	/>  
<izd zg=""	di2="vit"  	twb1="viT"  	di="vit"  	twb="v-it"	/>  
<izd zg=""	di2="viu"  	twb1="viu"  	di="viu"  	twb="v-i-u"	/>  
<izd zg=""	di2="vng"  	twb1="vG"  	di="vng"  	twb="v-ng"	/>  
<izd zg=""	di2="vo"  	twb1="vo"  	di="vo"  	twb="v-o"	/>  
<izd zg=""	di2="vok"  	twb1="voK"  	di="vok"  	twb="v-ok"	/>  
<izd zg=""	di2="vong"  	twb1="voG"  	di="vong"  	twb="v-o-ng"	/>  
<izd zg=""	di2="vor"  	twb1="vr"  	di="vor"  	twb="v-or"	/>  
<izd zg=""	di2="vu"  	twb1="vu"  	di="vu"  	twb="v-u"	/>  
<izd zg=""	di2="vua"  	twb1="vua"  	di="vua"  	twb="v-u-a"	/>  
<izd zg=""	di2="vuah"  	twb1="vuaH"  	di="vuah"  	twb="v-u-ah"	/>  
<izd zg=""	di2="vuan"  	twb1="vuaN"  	di="vuan"  	twb="v-u-a-n"	/>  
<izd zg=""	di2="vuat"  	twb1="vuaT"  	di="vuat"  	twb="v-u-at"	/>  
<izd zg=""	di2="vue"  	twb1="vue"  	di="vue"  	twb="v-u-e"	/>  
<izd zg=""	di2="vueh"  	twb1="vueH"  	di="vueh"  	twb="v-u-eh"	/>  
<izd zg=""	di2="vun"  	twb1="vuN"  	di="vun"  	twb="v-u-n"	/>  
<izd zg=""	di2="vut"  	twb1="vuT"  	di="vut"  	twb="v-ut"	/>  
<izd zg=""	di2="zang"  	twb1="zaG"  	di="rang"  	twb="r-a-ng"	/>  
<izd zg=""	di2="ze"  	twb1="ze"  	di="re"  	twb="r-e"	/>  
<izd zg=""	di2="zen"  	twb1="zeN"  	di="ren"  	twb="r-e-n"	/>  
<izd zg=""	di2="zet"  	twb1="zeT"  	di="ret"  	twb="r-et"	/>  
<izd zg=""	di2="zi"  	twb1="zi"  	di="ri"  	twb="r-i"	/>  
<izd zg=""	di2="zia"  	twb1="zia"  	di="ria"  	twb="r-i-a"	/>  
<izd zg=""	di2="ziak"  	twb1="ziaK"  	di="riak"  	twb="r-i-ak"	/>  
<izd zg=""	di2="ziam"  	twb1="ziaM"  	di="riam"  	twb="r-i-a-m"	/>  
<izd zg=""	di2="ziang"  	twb1="ziaG"  	di="riang"  	twb="r-i-a-ng"	/>  
<izd zg=""	di2="ziau"  	twb1="ziau"  	di="riau"  	twb="r-i-a-u"	/>  
<izd zg=""	di2="zih"  	twb1="ziH"  	di="rih"  	twb="r-ih"	/>  
<izd zg=""	di2="zim"  	twb1="ziM"  	di="rim"  	twb="r-i-m"	/>  
<izd zg=""	di2="zin"  	twb1="ziN"  	di="rin"  	twb="r-i-n"	/>  
<izd zg=""	di2="zing"  	twb1="ziG"  	di="ring"  	twb="r-i-ng"	/>  
<izd zg=""	di2="ziok"  	twb1="zioK"  	di="riok"  	twb="r-i-ok"	/>  
<izd zg=""	di2="ziong"  	twb1="zioG"  	di="riong"  	twb="r-i-o-ng"	/>  
<izd zg=""	di2="zior"  	twb1="zir"  	di="rior"  	twb="r-i-or"	/>  
<izd zg=""	di2="zip"  	twb1="ziP"  	di="rip"  	twb="r-ip"	/>  
<izd zg=""	di2="zit"  	twb1="ziT"  	di="rit"  	twb="r-it"	/>  
<izd zg=""	di2="ziu"  	twb1="ziu"  	di="riu"  	twb="r-i-u"	/>  
<izd zg=""	di2="zok"  	twb1="zoK"  	di="rok"  	twb="r-ok"	/>  
<izd zg=""	di2="zu"  	twb1="zu"  	di="ru"  	twb="r-u"	/>  
<izd zg=""	di2="zua"  	twb1="zua"  	di="rua"  	twb="r-u-a"	/>  
<izd zg=""	di2="zuah"  	twb1="zuaH"  	di="ruah"  	twb="r-u-ah"	/>  
<izd zg=""	di2="zuan"  	twb1="zuaN"  	di="ruan"  	twb="r-u-a-n"	/>  
<izd zg=""	di2="zue"  	twb1="zue"  	di="rue"  	twb="r-u-e"	/>  
<izd zg=""	di2="zun"  	twb1="zuN"  	di="run"  	twb="r-u-n"	/>  
<izd zg=""	di2="biang"  	twb1="biaG"  	di="biang"  	twb="b-i-a-ng"	/>  
<izd zg=""	di2="buinn"  	twb1="bUI"  	di="buinn"  	twb="b-unn-inn"	/>  
<izd zg=""	di2="diuh"  	twb1="diuH"  	di="diuh"  	twb="d-i-uh"	/>  
<izd zg=""	di2="guinn"  	twb1="gUI"  	di="guinn"  	twb="g-unn-inn"	/>  
<izd zg=""	di2="hei"  	twb1="hei"  	di="hei"  	twb="h-e-i"	/>  
<izd zg=""	di2="kuh"  	twb1="kuH"  	di="kuh"  	twb="k-uh"	/>  
<izd zg=""	di2="luh"  	twb1="luH"  	di="luh"  	twb="l-uh"	/>  
<izd zg=""	di2="ngiauh"  	twb1="QiauH"  	di="ngiauh"  	twb="ng-i-a-uh"	/>  
<izd zg=""	di2="onnh"  	twb1="OH"  	di="onnh"  	twb="onnh"	/>  
<izd zg=""	di2="pih"  	twb1="piH"  	di="pih"  	twb="p-ih"	/>  
<izd zg=""	di2="sannh"  	twb1="sAH"  	di="sannh"  	twb="s-annh"	/>  
<izd zg=""	di2="sio"  	twb1="sio"  	di="sio"  	twb="s-i-o"	/>  
<izd zg=""	di2="tuh"  	twb1="tuH"  	di="tuh"  	twb="t-uh"	/>  
<izd zg=""	di2="ueh"  	twb1="ueH"  	di="ueh"  	twb="u-eh"	/>  
<izd zg=""	di2="chip"  	twb1="ciP"  	di="cip"  	twb="c-ip"	/>  
<izd zg=""	di2="chuang"  	twb1="cuaG"  	di="cuang"  	twb="c-u-a-ng"	/>  
<izd zg=""	di2="chuat"  	twb1="cuaT"  	di="cuat"  	twb="c-u-at"	/>  
<izd zg=""	di2="dauh"  	twb1="dauH"  	di="dauh"  	twb="d-a-uh"	/>  
<izd zg=""	di2="duah"  	twb1="duaH"  	di="duah"  	twb="d-u-ah"	/>  
<izd zg=""	di2="giorh"  	twb1="girH"  	di="giorh"  	twb="g-i-orh"	/>  
<izd zg=""	di2="hiannh"  	twb1="hIAH"  	di="hiannh"  	twb="h-inn-annh"	/>  
<izd zg=""	di2="huainnh"  	twb1="hUAIH"  	di="huainnh"  	twb="h-unn-ann-innh"	/>  
<izd zg=""	di2="kennh"  	twb1="kEH"  	di="kennh"  	twb="k-ennh"	/>  
<izd zg=""	di2="kionn"  	twb1="kIO"  	di="kionn"  	twb="k-inn-onn"	/>  
<izd zg=""	di2="korh"  	twb1="krH"  	di="korh"  	twb="k-orh"	/>  
<izd zg=""	di2="nqeh"  	twb1="QEH"  	di="ngeh"  	twb="ng-eh"	/>  
<izd zg=""	di2="nqueh"  	twb1="QUEH"  	di="ngueh"  	twb="ng-u-eh"	/>  
<izd zg=""	di2="nor"  	twb1="nr"  	di="nor"  	twb="n-or"	/>  
<izd zg=""	di2="qiuh"  	twb1="qiuH"  	di="qiuh"  	twb="q-i-uh"	/>  
<izd zg=""	di2="ziah"  	twb1="ziaH"  	di="riah"  	twb="r-i-ah"	/>  
<izd zg=""	di2="ziap"  	twb1="ziaP"  	di="riap"  	twb="r-i-ap"	/>  
<izd zg=""	di2="tap"  	twb1="taP"  	di="tap"  	twb="t-ap"	/>  
<izd zg=""	di2="tit"  	twb1="tiT"  	di="tit"  	twb="t-it"	/>  
<izd zg=""	di2="uih"  	twb1="uiH"  	di="uih"  	twb="u-ih"	/>  
<izd zg=""	di2="vui"  	twb1="vui"  	di="vui"  	twb="v-u-i"	/>  
<izd zg=""	di2="juinn"  	twb1="jUI"  	di="zuinn"  	twb="z-unn-inn"	/>  
<izd zg=""	di2="sil"  	twb1="sil"  	di="sil"  	twb="sil"	/>  
<izd zg=""	di2="zzzzzz"  	twb1="zzzzzz"  	di="zzzzzz"  	twb="zzzzzz"	/>
</imzet>
};                                                          
                                                             
#include <stdio.h>                            
#include <ctype.h>                                      
#include <string.h>                                     
#include <stdlib.h>                                     
                                                        
                                                        
int wis_daiqinode1(const void* l, const void* r)        
{	return strcmp(((daiqi_node*)l)->di5, ((daiqi_node*)r)->di5); }
                                                        
class iz12twbat_   { daiqi_node* dq; int SZ; char buf[30],im0[30],imt[20];
public:                                                 
	iz12twbat_() { init20(); }                      
public:                                                 
	void sort() {                                   
		qsort(dq, SZ, sizeof(daiqi_node), wis_daiqinode1);
	}                                               
	void  init20() { SZ=sizeof(daiqi)/sizeof(daiqi_node);
				dq = new daiqi_node[SZ];
				for(int sz=0; sz<SZ;sz++) dq[sz]=(daiqi[sz]);
				SZ-=2; sort();
	}
public:
	int	huntone(char* src, char* iz0, char* izt) {
		iz0[0]=0; izt[0]=0;
		int len=strlen(src); if(len>25) return 0;
		int ntone=0; while(isdigit(*src)) ntone++;
		if(ntone>2) return 0;
		char *s, *t;
		s=src; t=iz0;		while(*s){if(!isdigit(*s))*t++=*s; s++;}*t=0;
		s=src; t=izt;		while(*s){if( isdigit(*s))*t++=*s; s++;}*t=0;
		return 1;
	}
	int lower(char* iz1) {	//static char buf[30]; buf[0]=0;
		if(huntone(iz1, im0, imt)==0) return -1;
		int lo=0, up=SZ, md, res=0;
		res=strcmp(im0, dq[0]   .di5); if(res< 0) {return -1;}
		res=strcmp(im0, dq[SZ-1].di5); if(res> 0) {return -1;}
		while(lo<up-1) {
			md=(lo+up)/2;
			if(strcmp(im0,dq[md].di5)<0) up=md;else lo=md;
		}
		if(strcmp(im0,dq[lo].di5)!=0) return -1;
		return lo;
	}
	char* iz12twbat(char* iz1) {	buf[0]=0;
		int lo=lower(iz1);
		if(lo>=0) strcpy(buf, dq[lo].ty);
		if(imt[0]) strcat(buf, imt);
		return buf;
	}
	char* iz12imso(char* iz1, char sep, int keeptone) {	buf[0]=0;
		int lo=lower(iz1);
		if(lo>=0) strcpy(buf, dq[lo].ty);
		char*t=buf; if(sep!='-') while(*t) {if(*t=='-')*t=sep; t++;}
		if(keeptone) if(imt[0]) { *t++=sep; strcat(buf, imt); }
		return buf;
	}
	char* iz12imso1(char* iz1) {	static char buf[30]; buf[0]=0;
		int lo=0, up=SZ, md, res=0;
		res=strcmp(iz1, dq[0]   .di5); if(res< 0) {return buf;}
		res=strcmp(iz1, dq[SZ-1].di5); if(res> 0) {return buf;}
		while(lo<up-1) {
			md=(lo+up)/2;
			if(strcmp(iz1,dq[md].di5)<0) up=md;else lo=md;
		}
		if(strcmp(iz1,dq[lo].di5)==0) strcpy(buf, dq[lo].ty);
		return buf;
	}
}iz12twbat;

char* imzet12twbat(char* imzet1)
{
	return iz12twbat.iz12twbat(imzet1);
}

char* imzet12imso(char* imzet1, char sep, int keeptone)
{
	return iz12twbat.iz12imso(imzet1, sep, keeptone);
}


#endif //#ifndef TWBAT_DQ_CPP

