//
// file dynPQ.cpp
//
//	IZGang 2002/12

#ifndef DYNPQ_CPP
#define DYNPQ_CPP

#include <dynPQ.h>
#include <di5base.h>

class test_dynPQ{
public:
	void	peek_heap_int(dynPQ_<int>& dPQ) {
		vector<int>& v=*(dPQ.pv); uint n, N=dPQ.nhp.size();chars cs;
//		cs=" val: ";for(n=0; n<N; n++){cs+=v[dPQ.origin(n)];cs+=" "; if((n+1)%3==0) cs+="  ";}
		cs=" val: ";for(n=0; n<N; n++){cs+=v[dPQ.nhp[n]];cs+=" "; if((n+1)%3==0) cs+="  ";}
		cs.show();
	}
	void	pop_peek_all_int(dynPQ_<int>& dPQ)
	{
		vector<int>& v=*(dPQ.pv); uint n, N=dPQ.nhp.size();chars cs; int t;
		for(n=0; n<N; n++){t=dPQ.top();dPQ.pop();cs+=t;cs+=" "; if((n+1)%3==0) cs+="  ";}
		cs.show();
		cs=int(dPQ.size());
		cs.show();
	}
  void test()
  {
	static int iarray[]={6,5,38, 8,40,26, 58,24,75, 99,32,49, 15,74};
	//static int iarray[]={5,6,15, 8,32,26,58,  24,75, 99,40, 49,38, 74};
	vector<int> iv(iarray, iarray+14);
	dynPQ_<int> dPQ; dPQ.init(iv);
	{peek_heap_int(dPQ);}
	{int i=0;	dPQ.change(9,i);	peek_heap_int(dPQ);}
	{int i=74;	dPQ.push(i);		peek_heap_int(dPQ);}
	{int i=20;	dPQ.push(i);		peek_heap_int(dPQ);}
	pop_peek_all_int(dPQ);
  }
};

void test_dynPQ_int()
{
	test_dynPQ test_int;
	test_int.test();
}


#endif //#ifndef DYNPQ_CPP
