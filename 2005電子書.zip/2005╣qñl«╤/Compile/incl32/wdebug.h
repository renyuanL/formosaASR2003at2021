//
// file wdebug.h
//

#ifndef WDEBUG_H
#define WDEBUG_H

class wdebug_ { public:// wdebug0 need to be created before this will work
	void show(int style);
	void move  (int x0, int y0, int dx, int dy, int repaint);
	int clear();
	int nlines();
	int app  (char* m1, char* m2=NULL, char* m3=NULL, char* m4=NULL);
	int appln(char* m1, char* m2=NULL, char* m3=NULL, char* m4=NULL)
	{ app(m1,m2,m3,m4); app("\r\n"); return 1;}
};
extern wdebug_ wdebug;

// implemented in vwin.cpp via wdebug0_

#endif //#ifndef WDEBUG_H

