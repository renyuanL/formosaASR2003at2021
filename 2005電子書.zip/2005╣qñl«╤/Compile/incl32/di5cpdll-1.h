
#include <di5cpconst.h>

class 	di5cpdll_ {
public:	di5cpdll_(char* pfn=0){init(pfn);}
				~di5cpdll_(){di5proc=NULL;}
public:
	int operator()(int m, int &w, int &l){ return getset(m,w,l);}
public:
	int	strset			(char*s, int& l	){ww=(int)s;return getset(DIDM_strsetw,ww,l);}
	int	strget			(char*s, int& l	){ww=(int)s;return getset(DIDM_strgetw,ww,l);}
	int	str10set		(char*s, int& l	){ww=(int)s;return getset(DIDM_str10setw,ww,l);}
	int	str10get		(char*s, int& l	){ww=(int)s;return getset(DIDM_str10getw,ww,l);}
public:
	int	hndleditset	 	(int  h					){ww=h;return getset(DIDM_hndleditsetw,ww,ll);}
	int	hndleditget 	(int &h					){return getset(DIDM_hndleditgetw,(int&)h,ll);}
	int	hndleditclear (								){return getset(DIDM_hndleditclear,ww,ll);}
public:
	int	hndlprntset	 	(int  h					){ww=h;return getset(DIDM_hndlprntsetw,ww,ll);}
	int	hndlprntget 	(int &h					){return getset(DIDM_hndlprntgetw,(int&)h,ll);}
	int	hndlprntclear (								){return getset(DIDM_hndlprntclear,ww,ll);}
public:
	int	wlset				(int w, int l		){ww=w;ll=l;return getset(DIDM_wlset,ww,ll);}
	int	wlget				(int&w, int&l		){return getset(DIDM_wlget,w,l);}
	int	wlchanged		(								){return getset(DIDM_wlchanged,ww,ll);}
private:
	void init(char* pfn){
		di5proc=0; hinst=0;
		char *pfndef="C:\\c2k\\di\\di5cpdll\\Debug\\di5cpdll.dll";
		if(!(pfn&&pfn[0])) pfn=pfndef;
		hinst=LoadLibrary(pfn);
		if(hinst)di5proc = (DI5PROC) GetProcAddress(hinst, (const char*)1);
	}
	int getset(int m, int &w, int &l){
		if(!di5proc)return 0;
		int res=di5proc(m,w,l);
		return res;
	}
	typedef int (*DI5PROC)(int m, int&w, int&l);
	HINSTANCE	hinst;
	DI5PROC 	di5proc; int ww,ll;
};
