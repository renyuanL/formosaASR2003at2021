//
//	speechio.cc
//	.h  	contains only prototype and comment only
//	.cc 	contains template implementation, included at end of .h
//	.cpp 	contains other    implementation, add-to project
//



/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

inline void rcfft_::rfft0(float *x, int N, int isign)//*0based Nreals
{
	rfft1(x-1,N,isign);
}
inline void rcfft_::cfft0(float *x, int N, int isign)//0based Ncmplxs
{
	cfft1(x-1,N,isign);
}
inline void rcfft_::cfft1(float *x, int N, int isign) //x: N complexes, 1-based
{
	if(N>512) cfftg(x,N,isign); //2^9=512
	else cfftf(x,N,isign);
}
inline void rcfft_::sh2ft(float* x, short* sh, int N)
{
	float *f=x; short*s=sh;
	for(int n=0;n<N;n++)
		*f++ = float(*s++);
}

/////////////////////////////////////////////////////////////////////////
inline	float* 	ehfs_::dhf    (short* sh,  int nsh, int dnsmp, float* res1)
{
	return hf   (downsample(sh,nsh,dnsmp),nsh/dnsmp, res1);
}
inline	float* 	ehfs_::dehf   (short* sh,  int nsh, int dnsmp, float* res1, int preem)
{
	return ehf  (downsample(sh,nsh,dnsmp),nsh/dnsmp, res1, preem);
}
inline	float* 	ehfs_::dehfps (short* sh,  int nsh, int dnsmp, float* res1, int preem)
{
	return ehfps(downsample(sh,nsh,dnsmp),nsh/dnsmp, res1, preem);
}
inline	float* 	ehfs_::dehfs  (short* sh,  int nsh, int dnsmp, float* res1, int preem)
{
	return ehfs (downsample(sh,nsh,dnsmp),nsh/dnsmp, res1, preem);
}
inline	float* 	ehfs_::dehfs1 (short* sh,  int nsh, int dnsmp, float* res1, int preem)
{
	return ehfs1(downsample(sh,nsh,dnsmp),nsh/dnsmp, res1, preem);
}
inline	float* 	ehfs_::dfs1   (short* sh,  int nsh, int dnsmp, float* res1)
{
	return fs1  (downsample(sh,nsh,dnsmp),nsh/dnsmp, res1);
}
inline	float* 	ehfs_::dfs1off(short* sh,  int nsh, int dnsmp, float* res1)
{
	return fs1off(downsample(sh,nsh,dnsmp),nsh/dnsmp, res1);
}

/////////////////////////////////////////////////////////////////////////

TPCI(real) void dopreem(real* obs, int nobs, float preem)
{
	for(int i=nobs-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] *=float(1.0-preem);
}

TPCI(real) void dopreem(real* obs, int nobs, float preem, float prevvalue)
{
	for(int i=nobs-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] -=prevvalue*preem;
}

/////////////////////////////////////////////////////////////////////////

TPCI(T) int
gethanning(T* win, int pmark1, int pmark2, int pmark3)//*center at pmark2-pmark1+1, total len=pmark3-pmark1+1, first/last is 0
{
  int nl=pmark2-pmark1, nr=pmark3-pmark2;
  if(nl<=0||nr<=0) return 0;
  int cntr; int n;    double knst;
  cntr=nl;
  if(nl==nr){//*this is actually 2*nl+1 points
	knst=2*3.1415926535/(2.0*nl);
	T tmp;
	for(n=0; n<=nl; n++){
	  tmp=0.5*(1.0-cos(knst*(nl-n)));
	  win[cntr-n]=tmp;
	  win[cntr+n]=tmp;
	}
  }else{
	knst=2*3.1415926535/(2.0*nl);
	cntr=nl;
	for(n=0; n<=nl; n++){
	  win[cntr-n]=0.5*(1.0-cos(knst*(nl-n)));
	}
	knst=2*3.1415926535/(2.0*nr);
	for(n=1; n<=nr; n++){
	  win[cntr+n]=0.5*(1.0-cos(knst*(nr-n)));
	}
  }
  return 1;
}

TPCI(T) int
gethanning(vector<T>&win, int pmark1, int pmark2, int pmark3)//*center at pmark2-pmark1+1, total len=pmark3-pmark1+1, first/last is 0
{
  win.resize(pmark3-pmark1+1);
  T* beg=&(win[0]);
  //memset( beg, 0, sizeof(T)*(pmark3-pmark1+1));
  return gethanning(beg, pmark1, pmark2, pmark3);
}

TPCI(T) int
gethanning(T* win, int nwin)//* win[] has len >= nwin
{
  if(nwin<=0) return 0; if(!win) return 0;
  double knst=2*3.1415926535/(nwin-1);
  for(int n=0; n<nwin; n++){
	win[n]=0.5*(1.0-cos(knst*n));
  }
  return 1;
}

TPCI(T) int
gethanning(vector<T>&win, int nwin)//*center at pmark2-pmark1+1, total len=pmark3-pmark1+1, first/last is 0
{
  if(nwin<=0) return 0;
  win.resize(nwin); if((int)win.size()<nwin) return 0;
  T* beg=&(win[0]);
  return gethanning(beg, nwin);
}


/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

inline	int	htkfmt_::
operator=(htkfmt_& r)
{
	totSamp		=r.totSamp;
	sampPeriod	=r.sampPeriod;
	sizePerSamp	=r.sizePerSamp;
	fileDataKind=r.fileDataKind;
	return 1;
}


/////////////////////////////////////////////////////////////////////////
inline	void	qiimbuf_::thplay	  (int bskip, int eskip)
{
	if(sh) owdef.thplay		(sh+bskip,nshused-bskip-eskip, &pcm);
}
inline	void	qiimbuf_::play 	  (int bskip, int eskip)
{
	if(sh) owdef.playclose	(sh+bskip,nshused-bskip-eskip, &pcm);
}
inline	void	qiimbuf_::thplaybe (int beg, int end)
{
	setbe0(beg,end);
	if(sh) owdef.thplay		(sh+beg,end-beg, &pcm);
}
inline	void	qiimbuf_::playbe   (int beg, int end)
{
	setbe0(beg,end);
	if(sh) owdef.playclose	(sh+beg,end-beg, &pcm);
}
inline	void	qiimbuf_::setbe0   (int&beg, int&end)
{
	::csbe(beg,0,ssize());
	::csbe(end,0,ssize());
	if(end<beg)end=beg;
}

/////////////////////////////////////////////////////////////////////////
template<class real> inline
int	 qiimbuf_::copyfrm	(vector<real>& trg, int nth, int frmsz, int sftsz)
{
	trg.clear();
	int NM=nfrm(frmsz, sftsz);
	if(nth<0||nth>=NM) return 0;
	trg.resize(frmsz);
	int beg=sftsz*nth;
	int n,N=frmsz;
	for(n=0; n<N; ++n){
		trg[n]=sh[n+beg];
	}
	return N;
}
TPCI(VEC) uint qiimbuf_::copyseg		(VEC& trg, uint beg,   uint end)
{
	csbe(beg,end);
	trg.resize(end-beg);
	uint n,N=end-beg;
	for(n=0; n<N; ++n){
		trg[n]=sh[n+beg];
	}
	return N;
}
TPCI(VEC) uint qiimbuf_::copyseg_ms	(VEC& trg, uint begms, uint endms)
{
	return copyseg(trg, ms2nsh(begms),ms2nsh(endms));
}


template<class real> inline
int	 qiimbuf_::get2be (vector<real>&trg,int beg, int end)
{
	trg.clear();
	if(beg<0) beg=0; if(end<0) end=ssize();
	csbe(beg,end);
	if(end<=beg) return 0;
	trg.resize(end-beg);
	int n,N=end-beg;
	for(int n=0; n<N; n++)
		trg[n]=sh[n+beg];
	return N;
}

template<class real> inline
int	 qiimbuf_::get2be_ms (vector<real>&trg,int beg, int end)
{
	if(beg<0) beg=0; beg=ms2nsh(beg);
	if(end<0) end=ssize(); else { end=ms2nsh(end);}
	return qetbe(trg,beg,end);
}

/////////////////////////////////////////////////////////////////////////
template<class real> inline
int feabuf_::copy(vector<real>&v,int tt)
{
	v.clear();v.resize(CC,0);
	float*ftmp=nthsample(tt);
	for(int cc=0;cc<CC;cc++)
		v[cc]=ftmp[cc];
	return CC;
}


/////////////////////////////////////////////////////////////////////////
inline	BOOL wplaysound::thplay(       ){if(nused<=0)return 0;stop(); return PlaySound(t ,NULL,SND_MEMORY  |SND_ASYNC);}
inline	BOOL wplaysound::play  (       ){if(nused<=0)return 0;stop(); return PlaySound(t ,NULL,SND_MEMORY  |SND_SYNC );}
inline	BOOL wplaysound::thplay(char*fn){stop(); return PlaySound(fn,NULL,SND_FILENAME|SND_ASYNC);}
inline	BOOL wplaysound::play  (char*fn){stop(); return PlaySound(fn,NULL,SND_FILENAME|SND_SYNC );}
inline	BOOL wplaysound::stop  (       ){return PlaySound(NULL,NULL,SND_SYNC );}

/////////////////////////////////////////////////////////////////////////
//for general playing
inline	BOOL wtts_::thplay (charspp& spp, char*ext, char* pname){return(cat(spp,ext,pname,0))?wps.thplay():false;}
inline	BOOL wtts_::thplay (char*    fns, char*ext, char* pname){spp.set2Nhun(fns);return(cat(spp,ext,pname,0))?wps.thplay():false;}
//for playint qiim
inline	BOOL wtts_::tqplay (charspp& spp, char*ext, char* pname){return(cat(spp,ext,pname,'1'))?wps.thplay():false;}
inline	BOOL wtts_::tqplay (char*    fns, char*ext, char* pname){spp.set2Nhunhanlor(fns);return(cat(spp,ext,pname,'1'))?wps.thplay():false;}
//for playint daiqi with bendiau
inline	BOOL wtts_::tqplayd(char*    fns, char*ext, char* pname){dobendiau(spp,fns);return tqplay(spp,ext,pname);}
inline	BOOL wtts_::thplayd(char*    fns, char*ext, char* pname){return tqplayd(fns,ext,pname);}
//for general playing
inline	BOOL wtts_::thplay (charspp& spp){return(cat(spp,ename_.s,pname_.s,0))?wps.thplay():false;}
inline	BOOL wtts_::thplay (char*    fns){spp.set2Nhun(fns);return(cat(spp,ename_.s,pname_.s,0))?wps.thplay():false;}
//for playint qiim
inline	BOOL wtts_::tqplay (charspp& spp){return(cat(spp,ename_.s,pname_.s,'1'))?wps.thplay():false;}
inline	BOOL wtts_::tqplay (char*    fns){spp.set2Nhunhanlor(fns);return(cat(spp,ename_.s,pname_.s,'1'))?wps.thplay():false;}
//for playint daiqi with bendiau
inline	BOOL wtts_::tqplayd(char*    fns){dobendiau(spp,fns);return tqplay(spp,ename_.s,pname_.s);}
inline	BOOL wtts_::thplayd(char*    fns){return tqplayd(fns,ename_.s,pname_.s);}



/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

template<class T> inline
chars& operator<<(chars& cs, vecvec<T>& vv)
{
	size_t n,N=vv.nfrm();
	for(n=0; n<N; ++n) cs<<vv[n]<<"\r\n";
	return cs;
}

///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
TPCI2(VEC,P) size_t		calsp_::
acf	(VEC& v, P src, size_t slen, int LAGKIND)
{
	size_t lag, LAG;
	switch(LAGKIND){
	case 0: LAG=slen;		break;
	case 1: LAG=slen/2;		break;
	case 2: LAG=slen*2/3;	break;
	case 3: LAG=slen*3/4;	break;
	case 4: LAG=slen*4/5;	break;
	}
	v.resize(LAG);
	for(lag=0; lag<LAG; ++lag){
		v[lag]=calm.dot(src, src+lag, slen-lag)/float(slen);
	}
	return LAG;
}

//////////////////////////////////////////////////////
TPCI2(VEC,P) size_t		calsp_::
acff(VEC& v, P src, size_t slen, int LAGKIND)
{
	size_t lag, LAG;
	switch(LAGKIND){
	case 0: LAG=slen;		break;
	case 1: LAG=slen/2;		break;
	case 2: LAG=slen*2/3;	break;
	case 3: LAG=slen*3/4;	break;
	case 4: LAG=slen*4/5;	break;
	}
	v.resize(LAG);
	for(lag=0; lag<LAG; ++lag){
		v[lag]=calm.dot(src, src+lag, slen-lag)/float(slen-lag);
	}
	return LAG;
}

inline int vv4spec::spec(qiimbuf_& qb, int frmms, int sftms)//*call calsp.spec
{
	qbsz=qb.size();	smprate=qb.pcm.sr();
	frmsz=qb.ms2nsh(frmms); sftsz=qb.ms2nsh(sftms);
//	return calsp.spec_np(*((vecvec<float>*)this), qb, frmsz, sftsz);
	ehfs_ ehfs;
	return calsp.spec_np(*this, qb, frmsz, sftsz, ehfs, float(0.975));
}


///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////


//* spectrum : from speech buf into a matrix of spectrum

TPCI(R) int calsp_::spec_ms (vecvec<R>& mm, qiimbuf_ &qb,
		int frmms, int sftms, ehfs_& ehfs, float preem)
{
  return spec_np(mm,qb,qb.ms2nsh(frmms),qb.ms2nsh(sftms),ehfs,preem);
}
TPCI(R) int	calsp_::spec_np (vecvec<R>& mm, qiimbuf_ &qb,
		int frmsz, int sftsz, ehfs_& ehfs, float preem)
{
	int rr, RR,CC; int nn,NN=twopowerbound(frmsz/2); float* res;
//	RR=(qb.size()-frmsz)/sftsz;	CC=NN;
	RR=qb.nfrm(frmsz,sftsz);	CC=NN;
	mm.resize(RR,CC);
	for(rr=0; rr<RR; rr++){
		res=ehfs.ehfs (qb.sh+sftsz*rr, frmsz,0,preem);
		for(nn=0;nn<NN; nn++){
			mm(rr,nn)=res[nn];
		}
	}
	return 1;
}

TPCI(R) int	calsp_::spec_np(vecvec<R>& mm, qiimbuf_ &qb,	int frmsz, int sftsz)
{ ehfs_ ehfs; return this->spec_np(mm,qb,frmsz,sftsz, ehfs, 0.975); }

TPCI(R) int calsp_::spec_ms(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms)
{ ehfs_ ehfs;return this->spec_np(mm,qb,qb.ms2nsh(frmms),qb.ms2nsh(sftms), ehfs, 0.975);}


/////////////////////////////////////////////////////////////////////////

//* power spectrum : from speech buf into a matrix of power spectrum
TPCI(R) int calsp_::pspec_ms (vecvec<R>& mm, qiimbuf_ &qb,
		int frmms, int sftms, ehfs_& ehfs, float preem)
{
  return pspec_np(mm,qb,qb.ms2nsh(frmms),qb.ms2nsh(sftms),ehfs,preem);
}

TPCI(R) int calsp_::pspec_np(vecvec<R>& mm, qiimbuf_ &qb,
		int frmsz, int sftsz, ehfs_& ehfs, float preem)
{
	int rr,cc, RR,CC; int nn,NN=twopowerbound(frmsz/2); float* res;
//	RR=(qb.size()-frmsz)/sftsz;	CC=NN;
	RR=qb.nfrm(frmsz,sftsz);	CC=NN;
	mm.resize(RR,CC);
	for(rr=0; rr<RR; rr++){
		res=ehfs.ehfps(qb.sh+sftsz*rr, frmsz,0,preem);
		for(nn=0;nn<NN; nn++){
			mm(rr,nn)=res[nn];
		}
	}
	return 1;
}


TPCI(R) int calsp_::pspec_np(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz)
{ ehfs_ ehfs;  return pspec_np(mm,qb,frmsz,sftsz, ehfs, 0.975); }

TPCI(R) int calsp_::pspec_ms(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms)
{ ehfs_ ehfs;return pspec_np(mm,qb,qb.ms2nsh(frmms),qb.ms2nsh(sftms),ehfs,0.975);}



/////////////////////////////////////////////////////////////////////////

//* fs only, no preem, and no hamming
//* power spectrum : from speech buf into a matrix of power spectrum

TPCI(R) int calsp_::pspec0_ms (vecvec<R>& mm, qiimbuf_ &qb,
		int frmms, int sftms, ehfs_& ehfs)
{
  return pspec0_np(mm,qb,qb.ms2nsh(frmms),qb.ms2nsh(sftms),ehfs);
}

TPCI(R) int calsp_::pspec0_np(vecvec<R>& mm, qiimbuf_ &qb,
		int frmsz, int sftsz, ehfs_& ehfs)
{
	int rr,cc, RR,CC; int nn,NN=twopowerbound(frmsz/2); float* res;
//	RR=(qb.size()-frmsz)/sftsz;	CC=NN;
	RR=qb.nfrm(frmsz,sftsz);	CC=NN;
	mm.resize(RR,CC);
	for(rr=0; rr<RR; rr++){
		res=ehfs.fps(qb.sh+sftsz*rr, frmsz,0);
		for(nn=0;nn<NN; nn++){
			mm(rr,nn)=res[nn];
		}
	}
	return 1;
}


TPCI(R) int calsp_::pspec0_np(vecvec<R>& mm, qiimbuf_ &qb, int frmsz, int sftsz)
{ ehfs_ ehfs;  return pspec0_np (mm,qb,frmsz,sftsz, ehfs); }

TPCI(R) int calsp_::pspec0_ms(vecvec<R>& mm, qiimbuf_ &qb, int frmms, int sftms)
{ ehfs_ ehfs;  return pspec0_np(mm,qb,qb.ms2nsh(frmms),qb.ms2nsh(sftms), ehfs); }

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////


///* obslete, should be delete
template<class T>
class 	rmmat{ // row major matrix of type T
public:
public:	rmmat():a(0),allc(0),R(0),C(0){}
public:	rmmat(int R1, int C1):a(0),allc(0),R(0),C(0){init2(R1,C1);}
public:~rmmat()	{ del(); }
public:
	T&	operator()(int r, int c	){return a[r*C+c]; 	} // so this is row major
	T*	operator()(int r				){return a+r*C;			} // r-th row
	T*	row				(int r				){return a+r*C;			}
	int init2			(int R1, int C1	);
	int	getminmax (T& vmin, T& vmax);
	template<class T1>
	int	copyasrow	(int r, T1*  t1s, int dim)					// dim must be C
								{
									if(C!=dim) return 0;	T* d=row(r);
									for(int c=0;c<C;c++)	*d++ = *t1s++;	return C;
								}
public:
	void		del		(								){if(a)delete[]a;a=0;allc=R=C=0;}
public:
	T* a; int allc; int R, C;
public://for use of spectra, etc, saves the confusion of index, at least used by calspec__
	int	nfrm				(){return R;}//num of frames
	int ncmp				(){return C;}//num of components
	T&	frm_cmp			(int frm, int cmp){ return operator()(frm,cmp);}
	T&	v      			(int frm, int cmp){ return operator()(frm,cmp);}
	T&	val    			(int frm, int cmp){ return operator()(frm,cmp);}
	T&	val_frm_cmp	(int frm, int cmp){ return operator()(frm,cmp);}
};

//class qiimbuf_;
//int calspec__(rmmat <double>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem=0.975);
//int calspec__(vecvec<double>& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem=0.975);
//int calspec__(vecvec<float >& mm, qiimbuf_ &qb, int frmsz, int sftsz, ehfs_& ehfs, float preem=0.975);


template<class T>
int rmmat<T>::init2(int R1, int C1)
{
	if(a){
		if(R1*C1<=allc){
			R=R1; C=C1;
			memset(a, 0, allc*sizeof(T));
			return 1;
		}
		del();
	}
	R=R1; C=C1;allc=R*C;
	a=new T[allc];
	if(!a) { del(); return 0; }
	memset(a, 0, allc*sizeof(T));
	return 1;
}

template<class T>
int	rmmat<T>::getminmax (T& vmin, T& vmax)
{
	if(R<=0||C<=0) return 0;
	vmax=operator()(0,0); vmin=operator()(0,0);
	T tmp; int r, c;
	for(r=0;r<R;r++)for(c=0;c<C;c++){
		tmp=operator()(r,c);
		if(vmax<tmp) vmax=tmp; if(vmin>tmp) vmin=tmp;
	}
	return 1;
}


typedef rmmat<double> rmdmat;
// rmmat : obslete, should be deleted  */

/*
template<class R>
struct 	segment_{R* a; size_t aLEN; size_t beg; size_t len; bool copy;
		segment_(R* a, size_t aLEN, size_t beg, size_t len, bool copy=true){set2(a,aLEN,beg,len,copy);}
public:
	TPC(VEC) void add (VEC& v);
public:
	void set2	(R* a1,size_t aLEN1,size_t beg1,size_t len1,bool copy1){a=a1;aLEN=aLEN1;beg=beg1;len=len1;copy=copy1;}
};

TPC(R) TPCI(VEC) void segment_<R>::add (VEC& v)
{
	if(aLEN<=beg) return; R* aa=a+beg; size_t aaLEN=aLEN-beg;
	size_t addlen, n;
	if(v.size()<=0 || copy){
		addlen=len;		if(addlen<=0||aaLEN<addlen) return;
		v.resize(addlen);
		for(n=0; n<addlen; ++n) v[n] =aa[n];
	}else{
		addlen=v.size(); if(addlen>aaLEN) addlen=aaLEN;
		for(n=0; n<addlen; ++n) v[n]+=aa[n];
	}
}

template<class R>
inline segment_<R> segment(R* a, size_t aLEN, size_t beg, size_t len, bool copy=true)
{ segment_<R> ss(a,aLEN, beg, len, copy); return ss; }

template<class R>
inline segment_<R> segment(R* a, size_t aLEN, size_t beg)
{ segment_<R> ss(a,aLEN, beg, 0, true); return ss; }

TPC2(R,R1) vector<R>  & operator<<(vector  <R>&v,segment_<R1> ss){ss.add(v);return v;}

//bool isinboundms(qiimbuf_& qb, size_t ms){return((int)qb.ms2nsh(ms)<=qb.size())?true:false;}

inline segment_<short>
copyseg(qiimbuf_& qb, size_t msbeg, size_t mslen)
{ 	size_t beg=qb.ms2nsh(msbeg), len=qb.ms2nsh(mslen);
	if(int(beg+len)>qb.size())len=qb.size()-beg;
	segment_<short> ss(qb.sh, qb.size(), beg, len);
	return ss;
}
*/



//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
// vecvec: moveto di5vp.h
/*
template<class T>
class 	vecvec : public vector< vector<T> > { public: int TT, CC;
public: vecvec  ():TT(0),CC(0){}
public: vecvec  (int ntimes1, int ncmpts1)
				:vector< vector<T> >(ntimes1, vector<T>(ncmpts1))
				,TT(ntimes1),CC(ncmpts1)
				{}
public:
  uint nfrm      (              ){return TT;}
  uint ncmp      (              ){return CC;}
  T&   v         (int tt, int cc){return (*this)[tt][cc];}
  T&   operator()(int tt, int cc){return (*this)[tt][cc];}
//or use [tt][cc] to access an entry
	int	getminmax (T& vmin, T& vmax);
	int	getminmax (T& vmin, T& vmax, int nthfrm);
public:
  void resize(int ntimes1, int ncmpts1){
						 vector<vector<T> >::resize(ntimes1);//,vector<T>(ncmpts1));
						 for(unsigned int n=0; n<size(); n++)
						   (*this)[n].resize(ncmpts1);
						 TT=ntimes1; CC=ncmpts1;
  }
};

template<class T>
int	vecvec<T>::getminmax (T& vmin, T& vmax)
{
	if(TT<=0||CC<=0) return 0;
	vmax=operator()(0,0); vmin=operator()(0,0);
	T tmp; int t, c;
	for(t=0;t<TT;t++)for(c=0;c<CC;c++){
		tmp=operator()(t,c);
		if(vmax<tmp) vmax=tmp; if(vmin>tmp) vmin=tmp;
	}
	return 1;
}

template<class T>
int	vecvec<T>::getminmax (T& vmin, T& vmax, int nthfrm)
{
  vmin=vmax=0;
	if(TT<=0||CC<=0) return 0; if(nthfrm<0||nthfrm>=TT) return 0;
	vmax=operator()(nthfrm,0); vmin=operator()(nthfrm,0);
	T tmp; int t, c;
	for(c=0;c<CC;c++){
		tmp=operator()(nthfrm,c);
		if(vmax<tmp) vmax=tmp; if(vmin>tmp) vmin=tmp;
	}
	return 1;
}
*/

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/*

template<int FRMSZ, int NRFFT>
class   emhamfft_ {
public: emhamfft_ (double preem1=0.975) : nrfft(NRFFT), frmsz(FRMSZ)
				{	preem=(float)preem1;	initham(); }
public:
	rcfft_ fft;  int nrfft, frmsz;
	float* hf (short* sh, float* res1=0);
	float* zor(short* sh, float* res1=0, int preem=1);
public:
	float  preem;
	void   dopreem(float* obs);
	void   dopreem(float* obs, float prevvalue);
public:
	float  xdef[NRFFT]; // default working array
	float  ham [FRMSZ];
	void   initham();
	void   doham  (float* obs);
};

template<int FRMSZ, int NRFFT>
float* emhamfft_<FRMSZ, NRFFT>::
hf(short* shobs, float* res1)
{
	int i; float* x;
	if(res1!=0) x=res1; else x=xdef;
	for(i=0; i<FRMSZ; i++) x[i]=shobs[i];
	//float te=totaleng();
	doham(x);
	if((nrfft-frmsz)>0) // zero padding
		memset(x+FRMSZ, 0, (nrfft-frmsz)*sizeof(float));//zero-padding
	fft.rfft1(x-1, NRFFT/2); // real fft, -1:since 1-based
	//x[1]=0; // for htk's ???
	return x;
}

template<int FRMSZ, int NRFFT>
float* emhamfft_<FRMSZ, NRFFT>::
zor(short* shobs, float* res1, int melkind)
{
	int i; float* x;
	if(res1!=0) x=res1; else x=xdef;
	for(i=0; i<FRMSZ; i++) x[i]=shobs[i];
	//float te=totaleng();
	dopreem(x);
	doham(x);
	if((nrfft-frmsz)>0) // zero padding
		memset(x+FRMSZ, 0, (nrfft-frmsz)*sizeof(float));//zero-padding
	fft.rfft1(x-1, NRFFT/2); // real fft, -1:since 1-based
	//x[1]=0; // for htk's ???
	return x;
}


template<int FRMSZ, int NRFFT>
void emhamfft_<FRMSZ, NRFFT>::
dopreem(float* obs)
{
	for(int i=FRMSZ-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] *=float(1.0-preem);
}

template<int FRMSZ, int NRFFT>
void emhamfft_<FRMSZ, NRFFT>::
dopreem(float* obs, float prevvalue)
{
	for(int i=FRMSZ-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] -=prevvalue*preem;
}

template<int FRMSZ, int NRFFT>
void emhamfft_<FRMSZ, NRFFT>::
initham()
{
	const double pi=3.141592653589793;
	double twopi=2*pi;
	float dt=float(twopi/(FRMSZ-1));
	for(int i=0; i<FRMSZ; i++)
		ham[i]=float(0.54-0.46*cos(dt*i));
}

template<int FRMSZ, int NRFFT>
void emhamfft_<FRMSZ, NRFFT>::
doham(float*obs)
{
	float*o=obs, *h=ham;
	for(register int i=0; i<FRMSZ; i++)
		*o++ *= *h++;
}
*/

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////




#ifdef DQSOLDOLDOLD

class dqsoptions_ { public:
	short		nbytes;			// size per sample, must set to 2
	short		nchannels; 	// num of channels, must set to 1
	int	 		bDBoff;			// off DB real time,def2 true(1)
public:
	int 		nfss; 			// frame shift size
	int  		nfsz;				// frame size= 2 times the fss
	int			nframerate;	// num of frames per second
	int			nframefreq;	// time in msec  per frame
public:
  int 		nsamprate; 	// sampling rate, num of samples per second
  int	 		nsampfreq;	// time in 10^-7 seconds per sample
protected:
  void clear() 	{ memset(this, 0, sizeof(*this)); }
	void set00()	{ nbytes=2; nchannels=1; bDBoff=1; }
  void setsamp	(int nsamprate1	)       // def2 16K
							{	nsamprate=nsamprate1;
					nsampfreq=int(10000000.1/nsamprate);} //def2 625
  void setframe	(int nframerate1)        // def2 50 frames persecond
							{	nframerate=nframerate1;
					nframefreq=int(1000.1/nframerate);//def2 20msec
				  nfsz=int(nframefreq/1000.0*nsamprate); //def2 320samp
				  nfss=nfsz/2;							}				//def2 160samp
public:
	void setsamp_frame(int nsamprate1, 			int nframerate1)
				{ setsamp(nsamprate1); setframe(nframerate1);}
  dqsoptions_(int nsamprate1=16000,		int nframerate1=50)
				{ clear(); set00(); setsamp_frame(nsamprate1,nframerate1);}
};
// dqsoptions_ dqs16k;



class WTS2_  { // weighted sum of the trancated spectrogram
//protected:
	int   nobs, nhrfft, CUTCNT; int initOK_;
	float *flt, *spc, *cut, *ct2; // working arrays to be alloc-ed
	qiimbuf_ *qbuf; // qiimbuf to receive the bkg noise
	void	setbelws(); // depends on nhrfft
	void  del();
	int   init2     (int nshort);
	void  conv2spec (float* ft, short* sh); // using nobs, nhrfft
	int   convNtrunc(short* sh);// 2 flt
public:
	WTS2_(int nshort, float sigmatimes1,float btimes1,float etimes1, qiimbuf_* qbuf1=NULL)
		:nobs(0),nhrfft(0),qbuf(0),flt(0),spc(0),cut(0),ct2(0),initOK_(0)
		{sigmatimes=sigmatimes1; init2(nshort); setscale(1.0,btimes1,etimes1);qbuf=qbuf1;}
  void setscale(float scale1,float btimes1, float etimes1);
  int  initOK () { return  initOK_; }
  int  initERR() { return !initOK_; }
public:
	int   be4truncate(int nshort=-1);
	int   __4truncate(short* sh);
	int   en4truncate();
	void	setsigrec  (qiimbuf_* qbuf1=0) {qbuf=qbuf1;}
public:
	float wts     (short* sh, float* lws, int nlws);
	int   beexceed(short* sh){return(wts(sh,blws,nblw)>bthresh)?1:0;}
	int   enexceed(short* sh){return(wts(sh,elws,nelw)>ethresh)?1:0;}
	int`  openend (			){return(ethresh<0.001)?1:0;}
//private:
	float bthresh, ethresh;
	float sigmatimes; //sigma-times off the mean of cut
  float	btimes;	 // beg threshhold times
  float	etimes;	 // end threshhold times
  float	scale;	 // computed as the sum of the std vector from sil
  float blws[10];// array of limit-weights for beg
  float elws[10];// array of limit-weights for end
  int		nblw;		 // nElem in the array of limit-weights for beg
  int		nelw; 	 // nElem in the array of limit-weights for end
};

typedef WTS2_ WTS_;

class WTS1_  { // weighted sum of the trancated spectrogram
	int   nobs, nhrfft, CUTCNT; int initOK_;
	float *flt, *spc, *cut, *ct2; // working arrays to be alloc-ed
	void	setbelws(); // depends on nhrfft
	void  del();
	int   init2    (int nshort);
	void  conv2spec (float* ft, short* sh); // using nobs, nhrfft
	int   convNtrunc(short* sh);// 2 flt
public:
	WTS1_(int nshort, float sigmatimes1, float btimes1, float etimes1)
		:nobs(0),nhrfft(0),flt(0),spc(0),cut(0),ct2(0),initOK_(0)
    {sigmatimes=sigmatimes1; btimes=btimes1; etimes=etimes1;init2(nshort); }
  int initOK () { return  initOK_; }
  int initERR() { return !initOK_; }
public:
	int   be4truncate(int nshort=-1);
	int   __4truncate(short* sh);
	int   en4truncate();
public:
	float wts     (short* sh, float* lws, int nlws);
	int   beexceed(short* sh){return(wts(sh,blws,nblw)>bthresh)?1:0;}
	int   enexceed(short* sh){return(wts(sh,elws,nelw)>ethresh)?1:0;}
	int		openend (					){return(ethresh<0.001)?1:0;}
//private:
	float bthresh, ethresh;
	float sigmatimes; //sigma-times off the mean of cut
  float	btimes;	 // beg threshhold times
  float	etimes;	 // end threshhold times
  float	scale;	 // computed as the sum of the std vector from sil
  float blws[10];// array of limit-weights for beg
  float elws[10];// array of limit-weights for end
  int		nblw;		 // nElem in the array of limit-weights for beg
	int		nelw; 	 // nElem in the array of limit-weights for end
};



class wavinhdrbuf_ :public WAVEHDR { public:
	//static FFT_<1024> fft;
	static rcfft_ fft;
	int id;	short sh[nDQS_FSS];
	static short dbbias;
  short Lnorm; 					// =1(L1-norm) or 2(L2-norm) def2 L2-norm
	int  init(short Lnorm=1);
public:
	wavinhdrbuf_() { init(); }
 ~wavinhdrbuf_() { }
public: int res;
	int		add   (HWAVEIN hwi) {return res=waveInAddBuffer       ( hwi, (LPWAVEHDR)this, sizeof(WAVEHDR) ); }
	int		prep  (HWAVEIN hwi) {return res=waveInPrepareHeader   ( hwi, (LPWAVEHDR)this, sizeof(WAVEHDR) ); }
	int		unprep(HWAVEIN hwi) {return res=waveInUnprepareHeader ( hwi, (LPWAVEHDR)this, sizeof(WAVEHDR) ); }
	void	copy2 (short* tgt ) {if(sh)memmove(tgt, sh, nDQS_FSS*sizeof(short)); }
public:
	int		bsize() { return dwBufferLength; } // byte size of wavedata
	float avgenergy();
	float bias();
	void  adjust_bias();
  float fftoff(int from, double off);
  float fftoff(int from, float* off);
	float fftoff(float* off, float* offlmtwght, int Nlmtwght);
};

class  bejudger_ {
public:
	virtual int  forbeg   (wavinhdrbuf_* p2whb){return 1;}
	virtual int  forend		(wavinhdrbuf_* p2whb){return 0;}
  virtual int	 openend	(										){return 0;}
	virtual void init4def	(int					bDBoff){				 }
};

class beL12_ : public bejudger_ { public:
	int forbeg(wavinhdrbuf_* p2whb){return(p2whb->avgenergy()>dbthresh)?1:0;}
	int forend(wavinhdrbuf_* p2whb){return(p2whb->avgenergy()<dethresh)?1:0;}
  int	openend(									){return (dethresh<0.001)?1:0;}
	void	init4def			(int bDBoff=1);
public:
	double	dback; 						// background noise
	double	dbtimes,  detimes; // times to determine threshhold
  double	dbthresh, dethresh;//=dtimes* dback
public:
	void	settimes			(double dbtimes1, double fetimes1);
  void	setbackground (double dback1);
  void	setthreshes		(double fbeg, double fend);
};

class beWTS_ : public bejudger_ { WTS_* wts;
public:
	beWTS_(WTS_* wts1):wts(wts1){}
	int forbeg(wavinhdrbuf_* p2whb){return   wts->beexceed(p2whb->sh) ;}
	int forend(wavinhdrbuf_* p2whb){return !(wts->beexceed(p2whb->sh));}
	int	openend(									){return   wts->openend();}
	//void init4def			(int bDBoff=1){endpoint_::init4def(bDBoff);}
};


class  endpoint_ { public:
public:endpoint_(bejudger_ *bejudger1)
	{
		clear(); init4def(1);	setDUR(); setsil(5,5);	init4kaisi();
		bejudger=bejudger1;
	}
	void clear  () { memset(this,0, sizeof(*this)); }
public: 												// b:beg, e:end
	int		nkbDUR, nkeDUR;  				// limit of duration
	int		nkbsil, nkesil;					// silence at beg/end
	int		bblurb, eblurb;         // duration to judge blurb
	void	setDUR(int nkbDUR1=-1, int nkeDUR1=-1);
	void	setsil(int nkbsil1, int nkesil1);
	int		nkfront(){return nkbsil+nkbDUR;}// # of frames at front =nkbsil+nkbDUR
	int		_lesskatend() { int r=(nkeDUR-nkesil);return(r>0)?r:0; }
public:
	short		buf0[1+(2*nDQS_MAXIDLEBUF)*nDQS_FSS];
	short*	buf;
	short*	allbuf;
	void		clearbuf() { memset(buf0,0,1+(nkfront())*nDQS_FSS*2);}
	void		initallbuf (short* allbuf1) { allbuf=allbuf1; }
public:
	int			nxt;
	int			nkbdur, beged;
	int			nkedur, ended;
	int			fillfrontdone;
	void		init4kaisi(){nxt=nkbdur=beged=nkedur=ended=fillfrontdone=0;}
public:
	int			fillfront ();
	char*		status();
	char*		state ();
	int			wavein (wavinhdrbuf_* p2whb, int* p2k)
								 {return (beged)?forend0(p2whb,p2k) : forbeg0(p2whb); }
	int   	forbeg0	(wavinhdrbuf_* p2whb          );
	int   	forend0	(wavinhdrbuf_* p2whb, int* p2k);
	bejudger_ *bejudger;
	int  forbeg   (wavinhdrbuf_* p2whb){
  	return bejudger->forbeg (p2whb);
  }
	int  forend		(wavinhdrbuf_* p2whb){
  	return bejudger->forend (p2whb);
  }
  int	 openend	(										){return bejudger->openend(     );}
	void init4def	(int bDBoff);
};


class idlebuf_ { public:
	wavinhdrbuf_ buf[nDQS_MAXIDLEBUF];
	char idles[nDQS_MAXIDLEBUF]; int n0, n1;
public:
	idlebuf_			 (					 )		{ initidle(); }
	void init			 (HWAVEIN hwi);   // those need hwi
	void initidle  (					 );
	void idles2		 (char to    ){for(int i=0;i<nDQS_MAXIDLEBUF;i++) idles[i]=to;}
	void all2idle  (			     ){for(int i=0;i<nDQS_MAXIDLEBUF;i++) set2idle(i);}
	void set2idle  (int id     ){idles[id]=1; }
	void all2driver(HWAVEIN hwi);
};

class  iwavethread_ {
public:iwavethread_ () { init_thread(); init_iwave(); }
			~iwavethread_ () { dele_thread(); dele_iwave(); }
public:
	virtual void VTVVwave() { }
	virtual int  VTIVSwavein(wavinhdrbuf_* p2whb){return 0;}
	void kaisitw() { begthread(); }
	void kaisiw () { VTVVwave(); }
public: // the thread part
	void init_thread() { hnd=NULL; id=0;}
	void dele_thread() { if(hnd) CloseHandle(hnd); hnd=0;}
	HANDLE hnd; uint id;
	void wait4end(int wtime=INFINITE) { WaitForSingleObject(hnd,wtime); }
	void begthread() {dele_thread();		hnd=(HANDLE)
										_beginthreadex(NULL,0,staticthread,this,0,&id);
										//dele_thread();
										}
	static uint WINAPI staticthread(void*pv) {	iwavethread_*t=(iwavethread_*)pv;
											t->VTVVwave();
											t->dele_thread();
											return 0;	}
public: // the iwave part
	void init_iwave(){bOpened=0;setpcm();res=ispcmsupported();idle_init0();}
	void dele_iwave();
	HWAVEIN         hwi; // handle to the oepned input device
	WAVEFORMATEX    wfx; // struct for (querying?) supportted data format
	MMRESULT        res;
	int bOpened;
	HWAVEIN operator()() { return hwi; }
	static int nblock;
	static void CALLBACK waveInProc	(	HWAVEIN  hwi, UINT uMsg, 		DWORD dwInst,
																		DWORD dwPrm1, DWORD dwPrm2);
public:
	int open();
	int start()     { allidle2driver(); return waveInStart(hwi); }
	int openstart() { if(openfail()) return 0; return start(); }
	int openfail()  { if(!bOpened) open(); return !bOpened; }
	int reset()     { int r=waveInReset(hwi); idles2(1); return r;}
	int stop ()     { return waveInStop (hwi); }
	int close()     { return waveInClose(hwi); }
	int rsc  ()     { reset();stop();return close();}
	int stopclose();// { if(bOpened){stop();reset();}bOpened=0;all2idle();reset();return close(); }
public:
	static idlebuf_   bufs;
	void idle_init0			(){ bufs.initidle		(   );	}
	void idle_init 			(){ bufs.init				(hwi);	}
	void idles2	 (char to){ bufs.idles2			(to );	}
  void all2idle 			(){ bufs.all2idle		(   );	}
  void set2idle (int id){ bufs.set2idle		(id );	}
  void allidle2driver (){ bufs.all2driver	(hwi);	}
	void dowhenidle			(){ bufs.all2driver	(hwi);	}
public:
  int setpcm (){ return setpcm(16000, (nDQS_BYTES==1)?8:16); }
  int setpcm  (int nsamples, int nbits);
  int ispcmsupported();
};

class iwstopper_ { public: char _1cu, loop, _4exit;
	void init4def(){_1cu      =loop         =_4exit=0;}
	void set2(char _1cu1, char loop1,   char _4exit1)
					{ _1cu=_1cu1, loop=loop1, _4exit=_4exit1;}
};

typedef void(*VFNqiim)(qiimbuf_*);

class qiimfns_ { public: VFNqiim beg1cu1, end1cu1, rcg;
			qiimfns_(): 	beg1cu1(NULL),end1cu1(NULL), rcg(NULL) { }
			qiimfns_(VFNqiim beg1cu11, VFNqiim end1cu11, VFNqiim rcg1)
					{ set2 ( beg1cu11, 				 end1cu11,         rcg1);}
	void set2   (VFNqiim beg1cu11, VFNqiim end1cu11, VFNqiim rcg1)
							{beg1cu1=beg1cu11, end1cu1=end1cu11;		 rcg=rcg1; }
  void operator=(qiimfns_ rhs){set2(rhs.beg1cu1,rhs.end1cu1,rhs.rcg);}
  void beg1cu(qiimbuf_* qbuf)	{ if(beg1cu1) (*beg1cu1)(NULL); }
  void end1cu(qiimbuf_* qbuf) { if(end1cu1) (*end1cu1)(qbuf); }
};


class  adaptation2_:public iwavethread_ {
public:adaptation2_(VFNV getsok1, WTS_* wts1=NULL, int K1=10)
			:iwavethread_(), getsok(getsok1), wts(wts1),K(K1){init();}
			 WTS_ *wts; double nrg1, nrg2; int k, K; VFNV getsok;
	void init()	{ nrg1=nrg2=0.0; k=0; }
	void VTVVwave();
	int  VTIVSwavein(wavinhdrbuf_* p2whb);
	void kaisitw() { init(); wts->be4truncate(); iwavethread_::kaisitw(); }
	void kaisiw () { init(); wts->be4truncate(); iwavethread_::kaisiw (); }
};


class  siuqiim2_ : public iwavethread_ { public:
	siuqiim2_(int seconds, endpoint_* endpt1, qiimfns_ fns1, dqsoptions_ opt1=dqsoptions_() )
		:iwavethread_()
		{
			endpt=endpt1; fns=fns1; opt=opt1;
			bufset2(seconds); init4def();
		}
		void init4def();
		void init4kaisi() { setnextbuf(); endpt->init4kaisi();k=endpt->nkfront();}
		void setendpoint(endpoint_ *endpt1){endpt=endpt1;endpt->init4def(opt.bDBoff);}
public:
	virtual void VTVVwave();
	virtual int  VTIVSwavein(wavinhdrbuf_* p2whb);
public:
	int k, K;	short* buf;
public:
	dqsoptions_ opt;
	iwstopper_  stopper;
	int  done1cu 		(){ return stopper._1cu||endpt->ended; 	}
	int  complete1cu(){ if(!endpt->openend())return endpt->ended;
											else { return 1;} }
	int  doneloop 	(){ return stopper.loop;								}
	int  done4exit	(){ return stopper._4exit;							}
	int  showstatus	();
	int  fillfront 	(){ return endpt->fillfront(); 					}
public:
	static void thread(void*);
	void beg1cu(qiimbuf_* )	{ fns.beg1cu(NULL			); }
	void end1cu(qiimbuf_* ) { if(complete1cu())fns.end1cu(prevbuf());}
	char*		endptstatus() { return endpt->status(); }
	void		stopall (char stop4exit1=0)
				{stopper.set2(1,1,stop4exit1);owdef.stopclose();spmsg.istatus("");}
public: // buffers
	qiimbuf_	qiimbuf[3]; qiimfns_ fns;	endpoint_* endpt;	int nth, NTH;
	void			setnextbuf();
	qiimbuf_* prevbuf() { int n=((nth-1)>=0)?(nth-1):(NTH-1);return &qiimbuf[n];}
	void bufset2(int seconds)
							{
								int K1=seconds*opt.nsamprate;
								NTH=3; for(int i=0; i<NTH; i++) qiimbuf[i].init2(K1);
								nth=0;  K=seconds*opt.nframerate; setnextbuf();
							}
};




class  	siuqiim3_ : public iwavethread_ {
public: siuqiim3_	(int seconds, endpoint_* endpt1, VFNqiim end1cu=0,
									 VFNqiim beg1cu=0, dqsoptions_ opt1=dqsoptions_() )
		:iwavethread_()
		{
			setendpoint(endpt1); e1cu=end1cu; b1cu=beg1cu; opt=opt1;
			bufset2(seconds); init4def(); init4kaisi();
		}
		void init4def();
		void init4kaisi() { endpt->init4kaisi();k=endpt->nkfront();}
		void setendpoint(endpoint_ *endpt1){endpt=endpt1;endpt->init4def(opt.bDBoff);}
public:
	//static  void thread(void*);
	virtual void VTVVwave();
	virtual int  VTIVSwavein(wavinhdrbuf_* p2whb);
public:
	qiimbuf_			qiimbuf;
	endpoint_			*endpt;
	VFNqiim 			b1cu, e1cu;
	dqsoptions_ 	opt;
	int k, K;	short* buf;
	int stopped;
public:
	int	 done()	{ return (stopped||endpt->ended);	}
	int  showstatus	();
	int  fillfront 	(){ return endpt->fillfront(); }//??
public:
	void beg()	{ if(b1cu) b1cu(&qiimbuf); }
	void end()	{ if(!stopped&&e1cu) e1cu(&qiimbuf); }
	char*		endptstatus() { return endpt->status(); }
	void		stopall (char stop4exit1=0)
				{stopped=1;owdef.stopclose();spmsg.istatus("");}
	void bufset2(int seconds)
							{
								int K1=seconds*opt.nsamprate;
								qiimbuf.init2(K1);
								K=seconds*opt.nframerate;
							}
};


class 	qiimpack2_ {
public:	qiimpack2_(VFNqiim fn_end1cu, VFNV fn_adaptgetsok=0)
				:
					wts(nDQS_FSS, 7, 2, 3),
					beWTS(&wts),
					endpt(&beWTS),
					adapttn(fn_adaptgetsok,&wts, 100),
					siuqiim(100,&endpt,fn_end1cu)
					{
						init_thread();
					}
			 ~qiimpack2_(){dele_thread();}
public:
	HANDLE hnd; uint id;
	void init_thread() { hnd=NULL; id=0;}
	void dele_thread() { if(hnd) CloseHandle(hnd); hnd=0;}
static uint WINAPI
	sithread(void*pv) {	qiimpack2_*t=(qiimpack2_*)pv;	t->siuqiim.begthread();
											//while(t->siuqiim.hnd)Sleep(100);
											t->dele_thread();
											return 0; }
	void begsiuim	() { 	dele_thread();	 hnd=(HANDLE)
											_beginthreadex(NULL,0,sithread,this,0,&id);
											//dele_thread();
									 }
static uint WINAPI
	dsthread(void*pv) {	qiimpack2_*t=(qiimpack2_*)pv;	t->adapttn.begthread();
											//while(t->adapttn.hnd)Sleep(100);
											t->dele_thread();
											return 0; }
	void begadapt	() { 	dele_thread();	 hnd=(HANDLE)
											_beginthreadex(NULL,0,dsthread,this,0,&id);
											//dele_thread();
									 }
public:
	void		adapt		()	{	stopall(100); begadapt();	}
	void		siuim		()	{	stopall(100); begsiuim();	}
	void		stopall	(int msec=200)	{ siuqiim.stopall(); Sleep(msec); }
public:
	WTS_ 						wts;//(nDQS_FSS, 7, 2, 3);
	//beL12_  				beL12;
	beWTS_ 					beWTS;//(&wts);
	endpoint_ 			endpt;//(&beWTS);
	adaptation2_  	adapttn;// (0, &wts, 100);
	siuqiim3_      	siuqiim;//(100, &endpoint, qiimfns_(NULL,fn_end1cu,NULL) );
};

#endif //#ifdef DQSOLDOLDOLD

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////





