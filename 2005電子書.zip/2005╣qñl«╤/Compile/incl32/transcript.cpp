//
//	file transcript.cpp
//

#ifndef TRANSCRIPT_CPP
#define TRANSCRIPT_CPP

#include <transcript.h>





char*	di5pdf_::make_pfname(char* pname1,char* subdir,char* fname1,char* ext1)
{
	chars* s=	getcharsbuf();
  if(pname1) s->app(pname1); if( s->lastbyte()!='\\')  s->app("\\");
  if(subdir) s->app(subdir); if( s->lastbyte()!='\\')  s->app("\\");
  if(fname1) s->app(fname1); if(ext1&&(ext1[0]!='.'))	 s->app(".");
  if(ext1  ) s->app(ext1);
  return s->s;
}

int		di5pdf_::getsetsys	()
{
	char* buf=_getdcwd(0, NULL, 1024);
  if(buf){exe=buf;}else{exe ="";}free(buf);
  tts=exe.getpname(); // the directory is still looks like a file name
  tts+="\\sys\\tts";
  return 1;
};

int		di5pdf_::settcp		(char* pfn4tcp1)
{
	if( (!pfn4tcp1)||(!pfn4tcp1[0]) )return 0;
  chars s; s=pfn4tcp1;
	//pfn4tcp=pfn4tcp1;
  tcp=s.getpname();
  ecf=s.getfname();
  fmt0head=ecf;if(fmt0head.ew(".tcp")) fmt0head.dellastN(4);
	// set tesi pname here	set4tesi(pgn4tcp.getfname());
  //tesi=exe; tesi.app("\\sys\\tesi\\vangsiong");
  //s=ecf; tesi.clear();
  if(s.ew(".tcp")) { s.dellastN(4); s=s.getfname();
  	tesi=exe;
    tesi=tesi.getpname();
    tesi.app("\\sys\\tesi\\"); tesi.app(s.s);
  }
	// set TTS pname here	set4tesi(pgn4tcp.getfname());
  return 1;
}

char* di5pdf_::TTS4(char* fname1, char*ext1, char qiqen)
{
  static char
  dq[]="\\tts\\dqtts\\dq-",
  kq[]="\\tts\\kqtts\\kq-",
  ml[]="\\tts\\mltts\\ml-",
  hq[]="\\tts\\hqtts\\hq-";
  char* t;
  switch (qiqen) {
  case 'k': t=kq; break;
  case 'm': t=ml; break;
  case 'h': t=hq; break;
  case 'd':
  default : t=dq; break;
  }
  return make_pfname(exe.s, t, fname1, ext1);
}

char* di5pdf_::tesi4(char* fname1, char*ext1)
{ return make_pfname(tesi.s, NULL, fname1, ext1); }


int		di5pdf_::isfromTESI(char* str)
{
	if((!str)||(!str[0])) return 0;
  chars s; s=str; chars sf;
  sf=s.getfname(); if(sf.is("tesi")) 	return 1;
  s =s.getpname(); if(!s.s[0]) 				return 0;
  sf=s.getfname(); if(sf.is("tesi")) 	return 1;
  s =s.getpname(); if(!s.s[0]) 				return 0;
  sf=s.getfname(); if(sf.is("tesi")) 	return 1;
  return 0;
}

char*	di5pdf_::tesi4		(charspp* spp1,char*ext1)
{
	char* t; if((*spp1)[0]) t=(*spp1)[0]; else t=NULL;
  return tesi4(t, ext1);
}

char*	di5pdf_::pfname	(charspp* spp1,char*ext1)
{
	char* t; if((*spp1)[0]) t=(*spp1)[0]; else t=NULL;
  return pfname(t, ext1);
}

char*	di5pdf_::pfname	(char*  fname1,char*ext1) // 4 filename of tcp line
{
  return make_pfname(tcp.s, NULL, fname1, ext1);
}




/*

char* di5pdf_::fullpfname(charspp* spp1, char*ext)
{
	s.clear();
  s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  if((*spp1)[0]) s.app((*spp1)[0]);
  if(ext) s.app(ext);
  return s.s;
}

char* di5pdf_::fullpfname(char* fname, char*ext)
{
	s.clear();
  s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  s.app(fname);
  if(ext) s.app(ext);
  return s.s;
}


char* di5pdf_::fullpfname(char* ext)
{
  //spp.set2Nhun(contents[ith*nlines41sentence]);
  spp.set2Nhun(tag());
  return fullpfname(&spp, ext);
}

char* di5pdf_::fullpfname(int i)
{
	if(!isINBND(i))return 0;// ith=i;
  //spp.set2Nhun(contents[i*nlines41sentence]);
  spp.set2Nhun(tag(i));
  return fullpfname(&spp, ".sp");
}


char* di5pdf_::tesipfname(charspp* spp1, char*ext)
{
	static chars s;
	s.clear();
  s.app(pn4tesi()); if(s.lastbyte()!='\\')  s.app("\\");
  s.app((*spp1)[0]);
  if(ext) s.app(ext);
  return s.s;
}

char* di5pdf_::tesipfname(char* ext)
{
	static charspp spp;
  //spp.set2Nhun(contents[ith*nlines41sentence]);
  spp.set2Nhun(tag());
  return tesipfname(&spp, ".sp");
}

char* di5pdf_::tesipfname(int i)
{
	static charspp spp;
	if(!isINBND(i))return 0;// ith=i;
  //spp.set2Nhun(contents[i*nlines41sentence]);
  spp.set2Nhun(tag(i));
  return tesipfname(&spp, ".sp");
}
*/


/////////////////////////////////////////////////
// tcp1_::


char tcp1_::nullstr[8]="";

/*
int tcp1_::peek2setting(char* pfname)
{
	lreader r; r.open(pfname); if(r.isERR())		return 0;
	chars s;   r.getgline(s); r.close();
	qiqen='d'; nlines41sentence=1; fmt=1;
	if(s.s[0]!='#')	{return 0;}
	charspp spp; spp.set2Nhunplus(s.s+1);
	char* t;
	t=spp.part_startwith(":q"); if(t)qiqen=t[2];
	t=spp.part_startwith(":l"); if(t)nlines41sentence=(t[2]-'0');
	t=spp.part_startwith(":f"); if(t)fmt=(t[2]-'0');
	return 1;
}
*/

int tcp1_::setting()
{
//	lreader r; r.open(pfname); if(r.isERR())		return 0;
//	chars s;   r.getgline(s); r.close();
	chars s;
	for(int i=0; i<contents.size(); i++)
  	if(str_isgline(contents[i])){s=contents[i];break;}
	qiqen='d'; nlines41sentence=1; fmt=1;
	if(s.s[0]!='#')	{return 0;}
	charspp spp; spp.set2Nhunplus(s.s+1);
	char* t;
	t=spp.part_bw(":q"); if(t)qiqen=t[2];
	t=spp.part_bw(":l"); if(t)nlines41sentence=(t[2]-'0');
	t=spp.part_bw(":f"); if(t)fmt=(t[2]-'0');
	//t=spp.part_startwith(":q"); if(t)qiqen=t[2];
	//t=spp.part_startwith(":l"); if(t)nlines41sentence=(t[2]-'0');
	//t=spp.part_startwith(":f"); if(t)fmt=(t[2]-'0');
  nchanges=0;
	return 1;
}

int tcp1_::read2contents(char* pfname)
{
	charspp spp;
	lread2line(pfname, spp);
	return contents.set2(&spp);
}

int	tcp1_::	save(int withbackup)
{ // do back up later
	writer w; w.creat(din.pfn4tcp());
  for(int i=0; i<contents.size(); i++) {
  	w.outln(contents[i]);
  }
  w.close();
  nchanges=0;
  return 1;
}

int tcp1_::read0(char* pfname, int delsillines)
{
//	if(din.isfromtesi(pfname)) return 0;
  read2contents(pfname);
  setting();
  if(contents.size()<=0) return 0;
  //pfn4lines=pfname;
  din.settcp(pfname);
	//pn4tesi.clear(); pn4TTS.clear();
  int resetcurrent=1;
  setnglines( delsillines, resetcurrent);
  return 1;
}

int tcp1_::read04tcpedit(char* pfname)
{
	int delsillines=0;
//	if(din.isfromtesi(pfname)) return 0;
  read2contents(pfname);
  setting();
  if(contents.size()<=0) return 0;
  if( (nlines41sentence!=2) ) {
  	contents.clear();
    return 0;
  }
  //pfn4lines=pfname;
  din.settcp(pfname);
	//pn4tesi.clear(); pn4TTS.clear();
  int resetcurrent=1;
  setnglines( delsillines, resetcurrent);
  setnheads();
  return 1;
}

int tcp1_::setnglines(int delsillines, int resetcurrent)
{
  if(fmt==0) {
  	setnlines4fmt0();
  }else{
	  //if(fmt==2) setnlines4fmt2(); else setnlines4fmt1(delsillines);
	  setnlines4fmt2();
  	setnheads();
	  if(resetcurrent) setcurrent(0);
  }
  return nglines.size();
}

char* tcp1_::getstatus()
{
	//s=pfn4lines.s; s+='+'; s+=tos(ith); return s.s;
	s=din.pfn4tcp(); s+='+'; s+=tos(ith); return s.s;
}

int tcp1_::read(char* str, int delsillines)
{
  spp.set2Nhunplus(str);
	if(spp.size()< 1) return 0;
  chars ss=spp[0];
  //pfn4lines=ss.s;
  //pn4lines=ss.getpname();
  if(!read0(spp[0], delsillines) )
   	return 0;
  if(spp.size()<2) return 1;
  setcurrent(s2i(spp[1]));
  return 1;
}

int tcp1_::read4tcpedit(char* str)
{
  spp.set2Nhunplus(str);
	if(spp.size()< 1) return 0;
  chars ss=spp[0];
  //pfn4lines=ss.s;
  //pn4lines=ss.getpname();
  if(!read04tcpedit(spp[0]) )
   	return 0;
  if(spp.size()<2) return 1;
  setcurrent(s2i(spp[1]));
  return 1;
}

/*
void tcp1_::setpfnames(char* fn, char*pure_pname)
{
	pfn4lines=fn;pn4lines=pure_pname;//ExtractFileDir(fn);
}
*/
void tcp1_::setnlines4fmt0()
{
	int i; char* t;
  nglines.clear();
  i=0; t=contents[0];
  if(strncmp(t, "#", 1)==0) i=1;
  for(;i<contents.size(); i++)
  	nglines.app(i);
}

void tcp1_::setnlines4fmt1(int delsillines)
{
  nglines.clear();
	int i; char* t;
  i=0; t=contents[0];
  if(strncmp(t, "#:", 2)==0) i=1;
  for(;i<contents.size(); ) {
  	t=contents[i];
    if(delsillines&&t[0]=='#') { i++; continue; }
    if(nlines41sentence==2) {
	    str_replace(t, ' ');
  	  str_replace(t, '\t');
    }
    if(!t[0]) { i++; continue; }
   	nglines.app(i);   i+=nlines41sentence;
  }
}


void tcp1_::setnlines4fmt2()
{
  nglines.clear();
	int n, i, j; char* t;
  i=0; t=contents[0];
  if(strncmp(t, "#:", 2)==0) i=1;
  for(;i<contents.size(); i+=nlines41sentence) {
  	t=contents[i];
    while( t&&( (!str_isgline(t))||(strncmp(t,"#",1)==0) ) )
    	{ i++; if(i>=contents.size()) break; t=contents[i]; }
    if(i>=contents.size()) break;
    //while( (!str_isgline(t)) ) { i++; t=contents[i]; }
    n=i;
    for(j=n; j<n+nlines41sentence; j++) {
    	if( (!str_isgline(contents[j]))||(t[0]=='#') )
      	msgbox("transcript format error");
    }
    nglines.app(n);
    if(i>=contents.size())
     	msgbox("transcript format error");
  }
}

int	  tcp1_::cntntline2nline(int i)//from ndx in contents to begin ndx in nglines
{
	if(nglines.size()<1) return 0; // this is error anyway
	if(i<=nglines[0]) return 0;
  int j;
	for(j=1; j<nglines.size(); j++) {
  	if(i<nglines[j]) return j;
  }
  return j;
}

void tcp1_::setnheads()
{
  nheads0.clear(); n1sts.clear();
	int i; char* t;
  for(i=0; i<contents.size(); i++) {
  	t=contents[i]; if(!str_isgline(t)) continue;
    while(*t) if(istabspace(*t)) t++;else break;
    if( (t[0]=='#')&&(t[1]==':')&&( (t[2]=='p')||(t[2]=='P') ) )
    	nheads0.app(i);
  }
  if(nheads0.size()<=0) {
  	nheads0.app(nglines[0]); nheads0.app(nglines[1]);
  	n1sts  .app(0); n1sts  .app(0);
	  return;
  }
  for(i=0; i<nheads0.size(); i++)
  	n1sts.app(cntntline2nline(nheads0[i]));
  nheads0.app(nglines.size());
  n1sts.app	 (nglines.size());
}

int   tcp1_::ngline2npf(int i)
{
	int ii=nglines[i];
	for(int j=1;j<nheads0.size();j++)
  	if(ii<nheads0[j]) return j-1;
  return nheads0.size()-2;
}

/*
int   tcp1_::nline2nprgf(int i)
{
	int ii=nglines[i];
	for(int j=1;j<nheads0.size();j++)
  	if(ii<nheads0[j]) return j-1;
  return nheads0.size()-2;
}

*/

int	tcp1_::	trimvunim()
{
  str_replace(vunim[0], '+', ' ');
  str_replace(vunim[0], '=', ' ');
  str_replace(vunim[1], '=', ' ');
  str_replace(vunim[2], '=', ' ');
  str_replace(vunim[3], '=', ' ');
  if(!str_isgline(vunim[3])) vunim[3][0]=0;
  //str_del4kauqidiau(vunim[2]);
  return 1;
}

int  tcp1_::fmt0app1line()
{
	chars* s=getcharsbuf();
  char* t=contents.last()+din.fmt0head.size();//+din.fmt0head.size();
  int i=s2i(t);
  //int i=s2i(contents.last()+din.fmt0head.size());
//  int i=s2i(tag()+din.fmt0head.size());
  s->set2(din.fmt0head.s);
  if(i<99990) s->app (tos(i+10,"%05d"));
  else s->app(tos(i+10,"%d"));
	contents.app(s->s);
  nglines.app(contents.size()-1);
	return 1;
}

int  tcp1_::setcurrent(int i)
{
	/*
	if(fmt==0) { if(i<0) return 0; int iith;
  	if(i>=size()-1) fmt0app1line();
  	ith=i;
    iith=nglines[ith];
    s.set2(contents[iith]);
    s.app( " = =" );
	  vunim.set2Nhun(s.s);
  	trimvunim();
	  return 1;
  }
  */

	if(!isINBND(i)) {
  	if(fmt!=0) 	return 0;
    if( (i<0)||i>size()) return 0;
    fmt0app1line();
  }
  static int junk=0; if(i==15)
  junk++;
  ith=i;
  int iith=nglines[ith];
  s.clear();
  if(nlines41sentence==2) s.app("= ");
  char* t;
  for(int ii=0; ii<nlines41sentence; ii++) {
  	t=contents[iith+ii];
  	s.apptab(t);
  }
  s.app(" = = ="); // make it work even with "empty" line
  vunim.set2Nhun(s.s);
  trimvunim();
  return 1;
}

int		tcp1_::auto_simple_bendiau_all()
{
	for(int i=0; i<size(); i++) {
	  int iith=nglines[i];
  	if(nlines41sentence==2) iith++;
	  str_auto_simple_bendiau(contents.ss[iith]);
  }
  return 1;
}

int		tcp1_::auto_simple_bendiau() // workon current line
{
  int iith=nglines[ith];
  if(nlines41sentence==2) iith++;
  str_auto_simple_bendiau(contents.ss[iith]);
  return 1;
}

void		tcp1_::checkautosave ( )
{
	nchanges++;
  if(nchanges>nCHANGES) { save(); nchanges=0; }
}

int		tcp1_::update_im (char* im1 )
{
	static charspp spp; spp.clear();
  spp.set2Nhun(im1);
  int iith=nglines[ith];
  if(nlines41sentence==2) iith++;
  contents.update(iith, spp.toline('='));
	setnglines(1,0);
  //checkautosave();
  return 1;
}

int		tcp1_::update_vun(char* vun1)
{
	static charspp spp; spp.clear();
  spp.set2Nhun(vun1);
  int iith=nglines[ith];
  //if(nlines41sentence==2) iith++;
  contents.update(iith, spp.toline('='));
  setcurrent(ith);
	setnglines(1,0);
  //checkautosave();
  return 1;
}

int		tcp1_::update_iv (char* im1, char* vun1 )
{
	static charspp spp; spp.clear(); int iith;
  iith=nglines[ith];

  spp.set2Nhun(vun1);
  contents.update(iith, spp.toline('='));

  spp.set2Nhun(im1);
  if(nlines41sentence==2) iith++;
  contents.update(iith, spp.toline('='));

	setnglines(1,0);
  //checkautosave();
  return 1;
}

int		tcp1_::insafter_iv (char* im1, char* vun1 )
{
	static charspp spp; spp.clear(); int iith;
  iith=nglines[ith+1];

  spp.set2Nhun(vun1);
  contents.insert(iith, spp.toline('='));
  //contents.ins(spp.toline('='),iith);

  spp.set2Nhun(im1);
  if(nlines41sentence==2) iith++;
  contents.insert(iith, spp.toline('='));
  //contents.ins(spp.toline('='),iith);

  //update transcript
	setnglines(1,0);
  //checkautosave();
  return 1;
}
int 	tcp1_:: joinwith() // join  next line to current line
{
	if(ith>=nglines.size()-1) return 0; // no lines to join with
	int iith, iith1;
  iith=nglines[ith]; iith1=nglines[ith+1];
  contents.ss[iith  ]->app("=");
  contents.ss[iith  ]->app(contents.ss[iith1  ]->s);
  contents.ss[iith+1]->app("=");
  contents.ss[iith+1]->app(contents.ss[iith1+1]->s);
  contents.del(iith1);
  contents.del(iith1);
  //update transcript
	setnglines(1,0);
  //checkautosave();
  return 1;
}

int 	tcp1_:: mergeto () // merge current line to prev line, make prev current
{
	if(ith<=0) return 0; // no lines to merge to
	int iith, iith1;
  iith=nglines[ith]; iith1=nglines[ith-1];
  contents.ss[iith1  ]->app("=");contents.ss[iith1  ]->app(contents.ss[iith  ]->s);
  contents.ss[iith1+1]->app("=");contents.ss[iith1+1]->app(contents.ss[iith+1]->s);
  contents.del(iith); contents.del(iith);
  setcurrent(ith-1);
  //update transcript especially ith
	setnglines(1,0);
  //checkautosave();
  return 1;
}



char* tcp1_::prgfhead	(int j)
{
	int i=nheads0[j];
  vunim.clear();
  if( (fmt==1)&&(nlines41sentence==2) )
  	vunim.s0.app(" = ");
  //vunim.set2Nhun(contents[i]);
  vunim.s0.app(contents[i]);
  vunim.hun();
  if(vunim.size()>1) { str_replace(vunim[1], '=', ' '); return vunim[1];}
  static char nil[]="";
  return nil;
}

char* tcp1_::prgf_all    (int j, char* sep)
{
	int i,i1,i2;
  i1=n1sts[j  ];//s2i(prgfs[j]);
  i2=n1sts[j+1];//s2i(prgfs[j+1]);
	static chars ss; ss.clear();
  if(j==0) {
  	ss.appln(vun(i1  ));		// should judge tile here!!!!!!
    ss.app("�@ ");ss.appln(vun(i1+1)); // should judge author here!!!!!!
    i1+=2;
  } else  ss.app("�@�@");// 1 zuanhing space here
  for(i=i1; i<i2; i++) {
  	ss.app(vun(i));
    if(sep) ss.app(sep);
  }
  return ss.s;
}

char* tcp1_::imINimzet	(int nth) // separated with spaces
{
	chars* s=getcharsbuf();
  s->set2(im(nth));
  str_replace(s->s, '=', ' ');
  s->inssep4hanlor();
  return s->s;
}

char* tcp1_::imINsu			(int nth) // separated with spaces
{
	chars* s=getcharsbuf();
  s->set2(im(nth));
  str_replace(s->s, '=', ' ');
  return s->s;
}










/////////////////////////////////////////////////
// tcp2_::



int tcp2_::set_nunits()
{
	int i, J; char *vv, *yy; charspp vpp, ypp;
	for(i=0; i<size(); i++) {
		vv=vun(i); yy=im(i);
		J=vpp.set2Nhun(vv); ypp.set2Nhun(yy);
		if(J>ypp.size())
			J=ypp.size(); // should report error here
//		if(vpp.size()!=ypp.size())
//			continue; // should report error here
		nunits.app(J);
	}
	return nunits.size();
}

int   tcp2_::isgood  (int nthprgrf1, int nthunit1)
{
	if( (nthprgrf1>=0)&&(nthprgrf1<nunits.size())&&
			(nthunit1 >=0)&&(nthunit1 <nunits[nthprgrf1]) )
		return 1;
	return 0;
}


int tcp2_::setcurrentprgrf(int nthprgrf1)
{
	if( !( (nthprgrf1>=0)&&(nthprgrf1<nunits.size()) ) ) return 0;
	if(nthprgrf==nthprgrf1) return 1;
	nthprgrf=nthprgrf1;
	sppvun2.set2Nhun(vun(nthprgrf)); 
	sppyim2.set2Nhun(im (nthprgrf));
	return 1;
}

char* tcp2_::itemsyim(int nthprgrf1, int nthunit1)
{
	if(!isgood(nthprgrf1, nthunit1))	return nullstr;
	if(!setcurrentprgrf(nthprgrf1))		return nullstr;
	if(nthunit1>=sppyim2.size())			return nullstr;
	return sppyim2[nthunit1];
}

char* tcp2_::itemsvun(int nthprgrf1, int nthunit1)
{
	if(!isgood(nthprgrf1, nthunit1))	return nullstr;
	if(!setcurrentprgrf(nthprgrf1))		return nullstr;
	if(nthunit1>=sppvun2.size())			return nullstr;
	return sppvun2[nthunit1];
}



/*
int   tcp2_::isgood  (int nthprgrf, int nthunits)
{;//{if( (nthprgrf>=0)&&(nthunits>=0)&&(nthprgrf<prgrfs.size())&&(nthunits<(*prgrfs[nthprgrf]).size()) ) return 1; return 0; }
	return 0;
}


char* tcp2_::items	 (int nthprgrf, int nthunits)
{
	if(!isgood(nthprgrf, nthunits))	return nullstr;
	return prgrfs[nthprgrf]->operator[](nthunits);
}

char* tcp2_::itemsyim(int nthprgrf, int nthunits)
{
	if(!isgood(nthprgrf, nthunits))	return nullstr;
	static charspp spp; spp.clear(); spp.set2(items(nthprgrf, nthunits));
	str_replace(spp.s0.s, '\x03', ' ');
	spp.hun();
	return spp[1];
}

char* tcp2_::itemsvun(int nthprgrf, int nthunits)
{
	if(!isgood(nthprgrf, nthunits))	return nullstr;
	static charspp spp; spp.clear(); spp.set2(items(nthprgrf, nthunits));
	str_replace(spp.s0.s, '\x03', ' ');
	spp.hun();
	return spp[0];
}
	
int 	tcp2_::lines2prgrfs()
{
	int i, j, J; char *vv, *yy; charspp vpp, ypp;
	for(i=0; i<size(); i++) {
		vv=vun(i); yy=im(i);
		vpp.set2Nhun(vv); ypp.set2Nhun(yy);
		if(vpp.size()!=ypp.size()) 
			continue; // should report error here
		J=vpp.size(); charspp *temp=new charspp;
		for(j=0; j<J; j++) {
			temp->app(vpp[j]); 
			temp->s0.app('\x03'); 
			temp->apptab(ypp[j]);
		}
		prgrfs.app(temp);
	}
	for(i=0; i<prgrfs.size(); i++) {
		prgrfs[i]->hun();
	}
	return prgrfs.size();
}
*/


//tcp2_ tcp2;


#endif //#ifndef TRANSCRIPT_CPP





#ifdef OLDOLDOLDOLDOLD




char* tcp1_::fullpfname(charspp* spp1, char*ext)
{
	s.clear();
  s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  if((*spp1)[0]) s.app((*spp1)[0]);
  if(ext) s.app(ext);
  return s.s;
}

char* tcp1_::fullpfname(char* fname, char*ext)
{
	s.clear();
  s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  s.app(fname);
  if(ext) s.app(ext);
  return s.s;
}

char* tcp1_::fullTTSpfname(char* fname, char*ext)
{
	s.clear();
  static char
  dq[]=".\\ceh\\dqtts\\dq-",
  kq[]=".\\ceh\\dqtts\\kq-",
  hq[]=".\\ceh\\dqtts\\hq-";
  //s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  if     (isdaiqi()) s.app(dq);
  else if(iskehqi()) s.app(kq);
  else if(ishuaqi()) s.app(hq);
  s.app(fname);
  if(ext) s.app(ext);
  return s.s;
}

char* tcp1_::fullpfname(char* ext)
{
  //spp.set2Nhun(contents[ith*nlines41sentence]);
  spp.set2Nhun(tag());
  return fullpfname(&spp, ext);
}

char* tcp1_::fullpfname(int i)
{
	if(!isINBND(i))return 0;// ith=i;
  //spp.set2Nhun(contents[i*nlines41sentence]);
  spp.set2Nhun(tag(i));
  return fullpfname(&spp, ".sp");
}


char* tcp1_::tesipfname(charspp* spp1, char*ext)
{
	static chars s;
	s.clear();
  s.app(pn4tesi()); if(s.lastbyte()!='\\')  s.app("\\");
  s.app((*spp1)[0]);
  if(ext) s.app(ext);
  return s.s;
}

char* tcp1_::tesipfname(char* ext)
{
	static charspp spp;
  //spp.set2Nhun(contents[ith*nlines41sentence]);
  spp.set2Nhun(tag());
  return tesipfname(&spp, ".sp");
}

char* tcp1_::tesipfname(int i)
{
	static charspp spp;
	if(!isINBND(i))return 0;// ith=i;
  //spp.set2Nhun(contents[i*nlines41sentence]);
  spp.set2Nhun(tag(i));
  return tesipfname(&spp, ".sp");
}


/*
char transcript_::nullstr[8]="";

int transcript_::peek2setting(char* pfname)
{
	lreader r; r.open(pfname); if(r.isERR())		return 0;
	chars s;   r.getgline(s); r.close();
	qiqen='d'; nlines41sentence=1; fmt=1;
	if(s.s[0]!='#')	{return 0;}
	charspp spp; spp.set2Nhunplus(s.s+1);
	char* t;
	t=spp.part_startwith(":q"); if(t)qiqen=t[2];
	t=spp.part_startwith(":l"); if(t)nlines41sentence=(t[2]-'0');
	t=spp.part_startwith(":f"); if(t)fmt=(t[2]-'0');
	return 1;
}

int transcript_::read(char* pfname, int delsillines)
{
	peek2setting(pfname);
  lread2line(pfname,contents);
  if(contents.size()<=0) return 0;
  pfn4lines=pfname;
	pn4tesi.clear(); pn4TTS.clear();
  if(fmt==2) setnlines4fmt2(); else setnlines4fmt1();
  setnheads();
  setcurrent(0);
  return 1;
}

void transcript_::setnlines4fmt1()
{
  nglines.clear();
	int i; char* t;
  i=0; t=contents[0];
  if(strncmp(t, "#:", 2)==0) i=1;
  for(;i<contents.size(); ) {
  	t=contents[i];
    if(nlines41sentence==2) {
	    str_replace(t, ' ');
  	  str_replace(t, '\t');
    }
    if(!t[0]) { i++; continue; }
   	nglines.app(i);   i+=nlines41sentence;
  }
}

void transcript_::setnlines4fmt2()
{
  nglines.clear();
	int n, i, j; char* t;
  i=0; t=contents[0];
  if(strncmp(t, "#:", 2)==0) i=1;
  for(;i<contents.size(); i+=nlines41sentence) {
  	t=contents[i];
    while( t&&( (!str_isgline(t))||(strncmp(t,"#:",2)==0) ) )
    	{ i++; t=contents[i]; }
    if(i>=contents.size()) break;
    //while( (!str_isgline(t)) ) { i++; t=contents[i]; }
    n=i;
    for(j=n; j<n+nlines41sentence; j++) {
    	if( (!str_isgline(contents[j]))||(t[0]=='#') )
      	msgbox("transcript format error");
    }
    nglines.app(n);
    if(i>=contents.size())
     	msgbox("transcript format error");
  }
}

int	  transcript_::cntntline2nline(int i)//from ndx in contents to begin ndx in nglines
{
	if(nglines.size()<1) return 0; // this is error anyway
	if(i<=nglines[0]) return 0;
  int j;
	for(j=1; j<nglines.size(); j++) {
  	if(i<nglines[j]) return j;
  }
  return j;
}

void transcript_::setnheads()
{
  nheads0.clear(); n1sts.clear();
	int i; char* t;
  for(i=0; i<contents.size(); i++) {
  	t=contents[i]; if(!str_isgline(t)) continue;
    if( (t[0]=='#')&&(t[1]==':')&&( (t[2]=='p')||(t[2]=='P') ) )
    	nheads0.app(i);
  }
  if(nheads0.size()<=0) {
  	nheads0.app(nglines[0]); nheads0.app(nglines[1]);
  	n1sts  .app(0); n1sts  .app(0);
	  return;
  }
  for(i=0; i<nheads0.size(); i++)
  	n1sts.app(cntntline2nline(nheads0[i]));
  nheads0.app(nglines.size());
  n1sts.app	 (nglines.size());
}

int   transcript_::nline2nprgf(int i)
{
	int ii=nglines[i];
	for(int j=1;j<nheads0.size();j++)
  	if(ii<nheads0[j]) return j-1;
  return nheads0.size()-2;
}



int  transcript_::setcurrent(int i)
{
	if(!isINBND(i))return 0;
  static int junk=0; if(i==15)
  junk++;
  ith=i;
  int iith=nglines[ith];
  s.clear();
  if(nlines41sentence==2) s.app("= ");
  char* t;
  for(int ii=0; ii<nlines41sentence; ii++) {
  	t=contents[iith+ii];
  	s.apptab(t);
  }
  s.app(" = = ="); // make it work even with "empty" line
  vunim.set2Nhun(s.s);
  str_replace(vunim[0], '+', ' ');
  str_replace(vunim[0], '=', ' ');
  str_replace(vunim[1], '=', ' ');
  str_replace(vunim[2], '=', ' ');
  str_replace(vunim[3], '=', ' ');
  //str_del4kauqidiau(vunim[2]);
  return 1;
}


char* transcript_::prgfhead	(int j)
{
	int i=nheads0[j];
  vunim.clear();
  if( (fmt==1)&&(nlines41sentence==2) )
  	vunim.s0.app(" = ");
  //vunim.set2Nhun(contents[i]);
  vunim.s0.app(contents[i]);
  vunim.hun();
  if(vunim.size()>1) { str_replace(vunim[1], '=', ' '); return vunim[1];}
  static char nil[]="";
  return nil;
}

char* transcript_::prgf_all    (int j, char* sep)
{
	int i,i1,i2;
  i1=n1sts[j  ];//s2i(prgfs[j]);
  i2=n1sts[j+1];//s2i(prgfs[j+1]);
	static chars ss; ss.clear();
  if(j==0) {
  	ss.appln(vun(i1  ));		// should judge tile here!!!!!!
    ss.app("�@ ");ss.appln(vun(i1+1)); // should judge author here!!!!!!
    i1+=2;
  } else  ss.app("�@�@");// 1 zuanhing space here
  for(i=i1; i<i2; i++) {
  	ss.app(vun(i));
    if(sep) ss.app(sep);
  }
  return ss.s;
}

char* transcript_::imINimzet	(int nth) // separated with spaces
{
	chars* s=getcharsbuf();
  s->set2(im(nth));
  str_replace(s->s, '=', ' ');
  s->inssep4hanlor();
  return s->s;
}

char* transcript_::imINsu			(int nth) // separated with spaces
{
	chars* s=getcharsbuf();
  s->set2(im(nth));
  str_replace(s->s, '=', ' ');
  return s->s;
}





char* transcript_::getstatus()
{
	s=pfn4lines.s; s+='+'; s+=tos(ith); return s.s;
}

int transcript_::setstatus(char* str, int delsillines)
{
  spp.set2Nhunplus(str);
	if(spp.size()< 1) return 0;
  chars ss=spp[0];
  pn4lines=ss.getpname();
  if(!read(spp[0], delsillines) )
   	return 0;
  pfn4lines=ss.s;
  if(spp.size()<2) return 1;
  setcurrent(s2i(spp[1]));
  return 1;
}


void transcript_::setpfnames(char* fn, char*pure_pname)
{
	pfn4lines=fn;pn4lines=pure_pname;//ExtractFileDir(fn);
}





char* transcript_::fullpfname(charspp* spp1, char*ext)
{
	s.clear();
  s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  s.app((*spp1)[0]);
  if(ext) s.app(ext);
  return s.s;
}

char* transcript_::fullpfname(char* fname, char*ext)
{
	s.clear();
  s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  s.app(fname);
  if(ext) s.app(ext);
  return s.s;
}

char* transcript_::fullTTSpfname(char* fname, char*ext)
{
	s.clear();
  static char
  dq[]=".\\ceh\\dqtts\\dq-",
  kq[]=".\\ceh\\dqtts\\kq-",
  hq[]=".\\ceh\\dqtts\\hq-";
  //s.app(pname());   if(s.lastbyte()!='\\') s.app("\\");
  if     (isdaiqi()) s.app(dq);
  else if(iskehqi()) s.app(kq);
  else if(ishuaqi()) s.app(hq);
  s.app(fname);
  if(ext) s.app(ext);
  return s.s;
}

char* transcript_::fullpfname(char* ext)
{
  spp.set2Nhun(contents[ith*nlines41sentence]);
  return fullpfname(&spp, ext);
}

char* transcript_::fullpfname(int i)
{
	if(!isINBND(i))return 0; ith=i;
  spp.set2Nhun(contents[i*nlines41sentence]);
  return fullpfname(&spp, ".sp");
}


char* transcript_::tesipfname(charspp* spp1, char*ext)
{
	static chars s;
	s.clear();
  s.app(pn4tesi()); if(s.lastbyte()!='\\')  s.app("\\");
  s.app((*spp1)[0]);
  if(ext) s.app(ext);
  return s.s;
}

char* transcript_::tesipfname(char* ext)
{
	static charspp spp;
  spp.set2Nhun(contents[ith*nlines41sentence]);
  return tesipfname(&spp, ".sp");
}

char* transcript_::tesipfname(int i)
{
	static charspp spp;
	if(!isINBND(i))return 0; ith=i;
  spp.set2Nhun(contents[i*nlines41sentence]);
  return tesipfname(&spp, ".sp");
}
*/

#endif //OLDOLDOLDOLDOLD







