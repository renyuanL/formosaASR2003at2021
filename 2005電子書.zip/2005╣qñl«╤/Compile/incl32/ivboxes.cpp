//
// file ivboxes.cpp
//
#ifndef IVBOXES_CPP
#define IVBOXES_CPP

#include <ivboxes.h>
hboxes_<10> hboxes;


#endif //#ifndef IVBOXES_CPP


