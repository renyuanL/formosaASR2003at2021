//
// wgdi.h
// v.2 2k.6.5
//

#ifndef WGDI_H
#define WGDI_H

#include <windows.h>
#include <vwin.h>

const char SSmark=0x01; // SuperScript mark
const char DHmark=0x02; // DiauHing mark
extern char* fontBiauKaiTe;
extern char* fontSinSeVingTe;
extern char* fontSeVingTe;

enum diaugi_ {vorbiau=0,gorbenn,diongbenn,gegang,gorgang,gorgau,gorsing,
							gordiam,gebenn,divor, gordit};

/*
struct point_ :public POINT {	void set2(int x1, int y1) { x=x1; y=y1; }
	point_(							 ){set2( 0,0 ); }
	point_(int x1, int y1){set2(x1,y1); }
	int operator ==(point_ r) { return ((x==r.x)&&(y==r.y))?1:0; }
};
*/

/*
struct rect_ :public RECT {
	rect_(												) { setltrb(0,0,0,0); }
	rect_(int l,int t,int r,int b	) { setltrb(l,t,r,b); }
	int  toregular(){ int t,r=0;if(left>right){t=left;left=right;right=t;r=1;}
										if(top>bottom){t=top;top=bottom;bottom=t;r=1;}return r;}
	void getclient(event& evn){GetClientRect(evn.h,this);};
	void getclient(HWND  hwnd){GetClientRect(hwnd ,this);};
	RECT*operator	()() { return (RECT*)this; }
	long& x0(){ return left;  }
	long& y1(){ return bottom;}
	long& x1(){ return right; }
	long& y0(){ return top;   }
	int  dx(){ return x1()-x0();}
	int  dy(){ return y0()-y1();}
	void setdx	(int dx) { right=left+dx; }
	void setdy	(int dy) { bottom=top+dy; }
	void setdxdy(int dx, int dy) { setdx(dx); setdy(dy); }
	void setdxdy(POINT pt) { setdx(pt.x); setdy(pt.y); }
	void setlt(int left1,	 int top1   ) { left=left1; top=top1; }
	void setrb(int right1, int bottom1) { right=right1;bottom=bottom1; }
	void setlt(POINT pt)	{ setlt(pt.x, pt.y); }
	void setrb(POINT pt)	{ setrb(pt.x, pt.y); }
	void setltrb(int l, int t, int r, int b){ left=l; top=t; right=r;bottom=b;}
	void hshift(int dx) { left+=dx; right+=dx; }
	void rshift(int dy) { top+=dy; bottom+=dy; }
	void operator = (RECT& r ){left=r.left;top=r.top;right=r.right;bottom=r.bottom;}
	void operator +=(POINT pt){left+=pt.x;right+=pt.x;top+=pt.y;bottom+=pt.y;}
	void operator ++(				){right++;bottom++;}
	void operator --(				){right--;bottom--;toregular();}
	void   shrinkby(int  n){left+=n;top+=n;right-=n;bottom-=n;toregular();}
	void  xshrinkby(int  n){left+=n;			 right-=n;				  toregular();}
	void  yshrinkby(int  n){				top+=n;				  bottom-=n;toregular();}
	void dxshrinkby(int  n){right-=n;	toregular();}
	void dyshrinkby(int  n){bottom-=n;toregular();}
	void    shiftby(int  n){left+=n;top+=n;right+=n;bottom+=n;}
	void   xshiftby(int  n){left+=n;			 right+=n;					}
	void   yshiftby(int  n){				top+=n;				  bottom+=n;}
};
*/

class  font_ { HFONT f; int hite;
public:font_ 		(					): f(0) {}
			~font_ 		(					){destroy();}
	HFONT operator()(				){return f; }
	HFONT select	(HDC hdc	){return (HFONT) SelectObject(hdc, f); }
	void  destroy (					){if(f) DeleteObject(f); f=0; }
	void  create	(int height, char* fontname=fontSinSeVingTe);
	// warning: create will destroy prev font 1st, 
	// make sure this font is not selected into hdc
	int height		() { return hite; }
};

class  hdc_ { 	HDC 	hdc;  HFONT of; font_ nf; COLORREF oc; int goc;LOGBRUSH lb;
public:hdc_():hdc(0), of(0),oc(0), goc(0){setlb();}
			~hdc_(){popf();popc();}
public:
	HDC 	operator()(        ){return hdc;}
	void 	setHDC		(HDC hdc1, int totwip=1){ hdc=hdc1;if(totwip)set2twip(hdc); }
	void 	set2twip	(HDC hdc1) { if(!hdc1)return;
							SetBkMode(hdc, TRANSPARENT);
							SetMapMode(hdc, MM_ANISOTROPIC);
							SetWindowExtEx(hdc, 1440,1440,NULL); // always use logical "twip"
							SetViewportExtEx(hdc, GetDeviceCaps(hdc,LOGPIXELSX),
																		GetDeviceCaps(hdc,LOGPIXELSY),NULL);
	}
public:
	void  del			(						){if(hdc)DeleteDC(hdc);hdc=0;						}
	void	setlb		(						){lb.lbStyle=BS_SOLID;									}
	void	push		(font_& f0	){popf(); of=f0.select(hdc); 						}
	void	popf		(				 		){if(hdc&&of)SelectObject(hdc,of);of=0;	}
	void	pushc		(COLORREF nc){popc();oc=GetTextColor(hdc);SetTextColor(hdc,nc);goc=1;}
	void	popc		(				 		){if(hdc&&goc)SetTextColor(hdc,oc);goc=0;	}
public:
	int		ew (char s){SIZE sz;GetTextExtentPoint32(hdc,&s,1,&sz);return sz.cx;}
	int		ew (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,1,&sz);return sz.cx;}
	int		hw (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,2,&sz);return sz.cx;}
	int		eh (char s){SIZE sz;GetTextExtentPoint32(hdc,&s,1,&sz);return sz.cy;}
	int		eh (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,1,&sz);return sz.cy;}
	int		hh (char*s){SIZE sz;GetTextExtentPoint32(hdc, s,2,&sz);return sz.cy;}
	SIZE	esz(char s){SIZE sz;GetTextExtentPoint32(hdc,&s,1,&sz);return sz;		}
	SIZE	esz(char*s){SIZE sz;GetTextExtentPoint32(hdc, s,1,&sz);return sz;		}
	SIZE	hsz(char*s){SIZE sz;GetTextExtentPoint32(hdc, s,2,&sz);return sz;		}
public:
	SIZE	tsz(char* s,font_& ef,font_& hf,int len=-1);
	int		w	 (char* s,font_& ef,font_& hf,int len=-1){return tsz(s,ef,hf,len).cx;}
public:
	void	eo (char*s,int x,int y){TextOut(hdc, x, y, s, 1);}
	void	ho (char*s,int x,int y){TextOut(hdc, x, y, s, 2);}
	int		o	 (char*s,int x,int y, font_& ef,font_& hf, int len=-1);
	void	o	 (char*s,int x,int y, int len=-1);
public:
	int   ew (char s, font_&f) {push(f); return ew(s); }
	int   ew (char*s, font_&f) {push(f); return ew(s); }
	int   hw (char*s, font_&f) {push(f); return hw(s); }
	int   eh (char s, font_&f) {push(f); return eh(s); }
	int   eh (char*s, font_&f) {push(f); return eh(s); }
	int   hh (char*s, font_&f) {push(f); return hh(s); }
	SIZE	esz(char s, font_&f) {push(f); return esz(s);}
	SIZE	esz(char*s, font_&f) {push(f); return esz(s);}
	SIZE	hsz(char*s, font_&f) {push(f); return hsz(s);}
	void	eo (char*s,int x,int y, font_&f){push(f);TextOut(hdc, x, y, s, 1);}
	void	ho (char*s,int x,int y, font_&f){push(f);TextOut(hdc, x, y, s, 2);}
public:
	char* SStext		(char* s);
	char* NONSStext	(char* s);
	SIZE	yvsubsz	(char* s,font_&ef,font_&hf, int bSStext=0);
	SIZE	SSsz		(char* s,font_&ef,font_&hf){return yvsubsz(s,ef,hf,1);}
	SIZE	NONSSsz	(char* s,font_&ef,font_&hf){return yvsubsz(s,ef,hf,0);}
public:
	SIZE	yvsz(						 char* s, font_&ef,font_&hf, font_&efu,font_&hfu,char qiqen,int gapim);
	int		yvw (						 char* s, font_&ef,font_&hf, font_&efu,font_&hfu,char qiqen,int gapim);
	int		yvo (int x,int y,char* s, font_&ef,font_&hf, font_&efu,font_&hfu,char qiqen,int gapim);
public:
	static void 	set1D(int ubiau);
	void	setdiaupoints(point_* pt, int * npt,int diau, int xb,int yb,int xe,int ye,int lw);
	void	drawdiau(int x,int dx,int base,char c,char diau,
								int selected,char qiqen, int height);
public:
	void  move2(int x, int y) { MoveToEx(hdc, x, y, NULL); }
	void	line2(int x, int y) { LineTo  (hdc, x, y      ); }
};

class chars;

class  imzet1_ {
public:imzet1_(){clear();}
	void clear(){s=g=q=p=r=d=hasd=0;im[0]=0;}
	int  len()  {return s+g+q+p+r+d; }
	int  cumu() { hasd=d; int ns=s; g+=s; q+=g; p+=q; r+=p; d+=r; s-=ns;g-=ns;q-=ns;p-=ns;r-=ns;d-=ns;return 1;}
	int  imzet1to6parts(char* im1);
	int  checkset4unvor_m (char* imsub);
	int  checkset4unvor_ng(char* imsub);
	int  isgood () { hasd=d; return (imsz==len()); }
	int  isin(char c, char* in){while(*in)if(c==*in++)return 1;return 0;}
	//int  isin(char c, char* in){return str_isin(c,in);} //while(*in)if(c==*in++)return 1;return 0;}
	int  is_aeiou(char c){static char s[]="aeiou";return isin(c,s);}
	char*to4ivdraw( int nn_ben, int d_move, char qiqen);
	char*to5gaidiau( char d, char qiqen);
	void nrhtransform(char* t ); // transform t when \n\r\h;
	int  idqtransform(char* im, chars& iwork, char qiqen, int kauqidiau, int diaugi, int supn);
	int  vdqtransform(char* im, chars& iwork); // transform im to vwork;
private:
	int  s, g, q, p, r, d, hasd;//siann, gaiim, quanim, pinn,rip,diau, hasdiau
	char im[20]; int imsz; // remember the im1 to im
};



#endif //WGDI_H

