//
// file di_sys.h
//

#ifndef DI_SYS_H
#define DI_SYS_H

unsigned int getSystemDirectory( char* buf, int buflen);
char getSystemDrive();
const char* daiim_pathname(); //by checkint the existence of ime2cntl.exe
int ty7ic_shiftisdown();

struct diini_ { int imex0, imey0;
			 diini_() { init0(); }
	int read();
	int write();
	int init0();
};
extern diini_ diini;

struct yesetc_		{ int soridiau;int hensi;int uannsu; int imex0, imey0;
			 yesetc_()	{ init(); }
	void init()			{ soridiau=0; hensi=2; uannsu=3; }
	int setsoridiau (int v) { soridiau  =( (v)?1:0 ); return soridiau;}
	int sethensi		(int v) { hensi			=( (v)?2:0 ); return hensi;		}
	int setuannsu		(int v) { uannsu		=( (v)?3:0 ); return uannsu;	}
	int getsoridiau () { return soridiau; }
	int gethensi		() { return hensi ;		}
	int getuannsu		() { return uannsu;		}
	int process(char* str); // set various setting if yes, 0 ow.
};

extern yesetc_  yesetc;


#endif //#ifndef DI_SYS_H
