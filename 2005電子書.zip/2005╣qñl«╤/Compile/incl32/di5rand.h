//
// file di5rand.h
//

#ifndef DI5RAND_H
#define DI5RAND_H

#include<stdlib.h>
#include<math.h>
#include<vector>
using namespace std;
//#define pi (3.1415926525)


////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
class unif_{public:virtual float operator()()=0;};

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
class congru_: public unif_{
	float operator()(){ return float(rand())/float(RAND_MAX);}
//	float operator()(){ return float(_lrand())/float(LRAND_MAX);}
};

extern congru_ congru;

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
class  uuni_ : public unif_{
public:uuni_(int i1=12, int j1=34, int k1=56, int l1=78)
	  {init (    i1,        j1,        k1,        l1);}// 1~168, not all 1
	float operator()(); // return a unif(0,1) RN
	void init(int i1, int j1, int k1, int l1);
private:
	float U[97]; float C, CD, CM;
	int I, J;
};
extern uuni_ uuni;
void   uuni_re_init(int i1, int j1, int k1, int l1);

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
//the scale parameter always use the form of /beta (dev by beta) in the pdf
class rn_ {
public:
	double	BM		(unif_& unif=uuni);
	double	expo	(unif_& unif=uuni){return -log(unif());}
	double	laplace	(unif_& unif=uuni);
	double lognormal(unif_& unif=uuni){return exp(normal(unif));}
	double	normal	(unif_& unif=uuni){return BM(unif);	}
	float	uni		(unif_& unif=uuni){return unif();	}
public:
	double	expo	(			 double theta,	unif_& unif=uuni){return -theta*log(unif());}
public:
	double	beta	(double alfa,double beta,	unif_& unif=uuni);
	double	gamma	(double alfa,double beta,	unif_& unif=uuni){return stdgamma(alfa,unif)*beta;}
public:
	double	BM		(double mu,  double sigma, 	unif_& unif=uuni){return BM(unif)*sigma+mu;	}
	double	cauchy	(double alfa,double theta,	unif_& unif=uuni){return alfa-theta/tan(3.1415926535*unif());}
	double	weibull	(double alfa,double beta,	unif_& unif=uuni){return beta*pow(expo(unif),1.0/alfa);}
	double	laplace	(double alfa,double theta,	unif_& unif=uuni){return laplace(unif)*theta+alfa;}
	double lognormal(double mu,  double sigma, 	unif_& unif=uuni){return exp(normal(mu,sigma,unif));}
	double	normal	(double mu,  double sigma, 	unif_& unif=uuni){return BM(mu,sigma,unif);	}
	float	uni		(double a,   double b, 		unif_& unif=uuni){return unif()*(b-a)+a;	}
	double	gammaL1	(double alfa,	unif_& unif=uuni);
	double	gammaG1	(double alfa,	unif_& unif=uuni);
	double	stdgamma(double alfa,	unif_& unif=uuni){if(alfa==1.0)return expo(unif);return(alfa<1.0)?gammaL1(alfa,unif):gammaG1(alfa,unif);}
};
extern rn_ rn;

struct spcn_{//sequential pdf cdf ndx
	double pdf, cdf; int ndx;
	void set2(double p1, double c1, int n1){pdf=p1;cdf=c1;ndx=n1;}
};

template<class  spcf_> //* pcn: do not change into &,so that pcn can be re-used
int		inverse_transform(spcf_& spcf, spcn_ pcn, double y, int frombegin=1);
int		bs_cdfndx(vector<double>& v, double y);//inlined in .cc

#include <di5rand0.cc>
// to include the following class
// class tabsit_template<spcf_>;
// class	spcf_binomial;     //class	spcf_poisson;
// class	spcf_geometric;    //class	spcf_negbinomial;

class 	it3bino {
public:	it3bino (int n, double p, int TABSZ=256, int CDFSZ=32);
	double operator()(unif_&unif=uuni);
public:
	spcf_binomial spcf;
	tabsit_<spcf_binomial> rn;
};

class 	it3pois {
public:	it3pois (double lamda, int TABSZ=256, int CDFSZ=32);
	double operator()(unif_&unif=uuni);
public:
	spcf_poisson spcf;
	tabsit_<spcf_poisson> rn;
};

class 	it3geom {
public:	it3geom (double p, int TABSZ=256, int CDFSZ=32);
	double operator()(unif_&unif=uuni);
public:
	spcf_geometric spcf;
	tabsit_<spcf_geometric> rn;
};

class 	it3nbin {
public:	it3nbin (int r, double p, int TABSZ=256, int CDFSZ=32);
	double operator()(unif_&unif=uuni);
public:
	spcf_negbinomial spcf;
	tabsit_<spcf_negbinomial> rn;
};

#include <di5rand.cc>

#endif //#ifndef DI5RAND_H


