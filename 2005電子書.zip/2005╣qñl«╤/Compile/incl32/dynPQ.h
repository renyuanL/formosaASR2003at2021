//
// file dynPQ.h
//
//	IZGang 2002/12

#ifndef DYNPQ_H
#define DYNPQ_H
#include <vector>
#include <functional>
#include <limits>
using namespace std;
typedef unsigned int uint;

template<class type, class LeftHighP=less<type> > //* left has higher priority
class	dynPQ_ {
public:
	dynPQ_		(			    			){}
	dynPQ_		(vector<type>& v			){init(v);}
	dynPQ_		(vector<type>& v, int copyit){vcopy=v; 				init(vcopy);}
	dynPQ_		(type * beg, 	  type * end){vcopy.assign(beg,end);init(vcopy);}
	dynPQ_		(dynPQ_<type,LeftHighP>	&rr	){set2(rr);}
public:
	int		init	(vector<type>& v);
	int		init	(vector<type>& v, int copyit){vcopy=v; 				return init(vcopy);}
	int		init	(type * beg,  	  type * end){vcopy.assign(beg,end);return init(vcopy);}
	void 	set2	(dynPQ_<type,LeftHighP> & rr){pv =rr.pv;nhp=rr.nhp;aux=rr.aux;vcopy=rr.vcopy;}
	void operator=	(dynPQ_<type,LeftHighP>&rr){set2(rr);}
public:
	type&	top		(){return (*pv)[nhp[0]];}
	int		topndx	(){return nhp[0]; } 	//* top element has an index in v
	void	pop		();
	void	push	(const type& newentry);	//*will push_back to original v too
	int		changed	(uint  ondx); 			//* change the value of v[ondx] youself, and immediately call change(ondx)
	int		change	(uint  ondx, type& newentry);//*thus must have = defined
	uint	size	(){return nhp.size();}
public:
	typedef	uint ndxo;	typedef uint ndxh;  //* ndx in orig, ndx in heap
	bool	isempty	(){return nhp.size()==0;}
	uint	uimax	(){return numeric_limits<unsigned int>::max();}
const type&	val		(ndxh nh){return (*pv)[nhp[nh]];}
public://debugging routines, call these two after pop()/push()
	int		heappOK	();//return -1 if OK, ow ret-val is what is err
	int		ndxOK	(char* s=0);
private:
	vector<type>	*pv;
	vector<ndxo>	nhp;	//* index heap, nhp[0] is topindex, (*pv)[nhp[0]] is top, and so on
	vector<ndxh> 	aux;    //* nth-position of aux always for (*pv)[n],
							//* (*pv)[n]'s index,i.e., n, is at position nhp[aux[n]], thus change is possible
	//* use ndxh indexing into nhp, while it returns ndxo
	//* use ndxo indexing into aux, while it returns ndxh
	vector<type>	vcopy;	//* private copy, use it only when no extern vector
private:
	void	goup(ndxh hndx);
	void	godn(ndxh hndx);
	void	make_heap();
	friend	class test_dynPQ;
	friend	class test_dynPQ1;
	bool	childOK (ndxh nh);
};

template<class type, class LeftHighP>	void	dynPQ_<type,LeftHighP>::
pop		(	)
{
	uint N=nhp.size();
	if(N<=0) return;
	swap(nhp[0],nhp[N-1]);	swap(aux[nhp[0]],aux[nhp[N-1]]);
	aux[nhp[N-1]]=uimax();	//donot aux.pop_back(), ow lost link to vector v
	nhp.pop_back();
	godn(0);
}

template<class type, class LeftHighP>	void	dynPQ_<type,LeftHighP>::
push	(const type& newentry)
{
	vector<type>& v=(*pv);//*alias the name for easier reading
	ndxo nn=v.size();
	v  .push_back(newentry);
	nhp.push_back(nn);
	aux.push_back(nhp.size()-1);
	goup(nhp.size()-1);
}

template<class type, class LeftHighP>	int	dynPQ_<type,LeftHighP>::
change	(uint  ondx, type& newentry)//*thus must have = defined
{
	if(ondx<pv->size()){
		if(aux[ondx]==uimax()) return 0;
		(*pv)[ondx]=newentry;
		return changed(ondx);
	}
	return 0;
}

template<class type, class LeftHighP>	int	dynPQ_<type,LeftHighP>::
changed	(uint  origin_ndx)//* change the value youself, difficult2 abstract change
{
	vector<type>& v=(*pv);//*alias the name for easier reading
	uint SZ; SZ=v.size();
	if(origin_ndx>=SZ)	return 0;	//*out-of-bound
	ndxh hn; hn=aux[origin_ndx];
	SZ=nhp.size();
	if(hn>=SZ )	return 0;	//*out-of-bound
	if(hn==0) { godn(hn);return 1;}	//*it cannot goup
	ndxh hprnt=(hn-1)/2;
	if(LeftHighP()(v[nhp[hn]], v[nhp[hprnt]]))
		goup(hn);
	else
		godn(hn);
	return 1;
}

template<class type, class LeftHighP>	void	dynPQ_<type,LeftHighP>::
goup(ndxh hn)
{
	if(hn<=0) return;
	vector<type>& v=(*pv);	//*alias the name for easier reading
	ndxo tmp =nhp[hn];		//*copy the original index to be moved
	ndxh hprnt=(hn-1)/2;	//*case hn==0 is taken care of
	int moved=0;
	while(hprnt!=hn && LeftHighP()(v[tmp], v[nhp[hprnt]]) ){//check if moveup
		//move up
		nhp[hn]=nhp[hprnt];
		aux[nhp[hn]]=hn;
		moved=1;
		//next trial of moving
		hn=hprnt; if(hn==0) break;
		hprnt=(hn-1)/2;
	}
	//now it is in place, copy the original index into new correct position
	if(moved){
		nhp[hn]=tmp;
		aux[nhp[hn]]=hn;
	}
}

template<class type, class LeftHighP>	void	dynPQ_<type,LeftHighP>::
godn(ndxh hn)
{
	vector<type>& v=(*pv);	//*alias the name for easier reading
	ndxo tmp =nhp[hn];		//*copy the original index to be moved
	ndxh hchld=(hn)*2+1;
	if(hchld<nhp.size()-1 && LeftHighP()(v[nhp[hchld+1]],v[nhp[hchld]]))
		++hchld;
	int moved=0;
	while(hchld<nhp.size() && LeftHighP()(v[nhp[hchld]],v[tmp]) ){//check if movedown
		//move down
		nhp[hn]=nhp[hchld];
		aux[nhp[hn]]=hn;
		moved=1;
		//next trial of moving
		hn=hchld;
		hchld=(hn)*2+1;
		if(hchld<nhp.size()-1 && LeftHighP()(v[nhp[hchld+1]],v[nhp[hchld]] ))
			++hchld;
	}
	//now it is in place, copy the original index into new correct position
	if(moved){
		nhp[hn]=tmp;
		aux[nhp[hn]]=hn;
	}
}

template<class type, class LeftHighP>	int		dynPQ_<type,LeftHighP>::
init(vector<type>& v)
{
	pv=&v;	//save it for later use
	uint n, N=v.size();
	nhp.resize(v.size());	for(n=0; n<N; ++n) nhp[n]=n;
	aux.resize(v.size());	for(n=0; n<N; ++n) aux[n]=n;
	make_heap();
	return N;
}

template<class type, class LeftHighP>	void	dynPQ_<type,LeftHighP>::
make_heap()
{
	if(nhp.size()<=0) return;
	ndxh hn=(nhp.size())/2;
	while(1){
		godn(hn);
		if(hn==0) break;
		hn--;
	}
}

template<class type, class LeftHighP>	bool	dynPQ_<type,LeftHighP>::
childOK (ndxh nh)
{
	vector<type>& v=(*pv);//*alias the name for easier reading
	if(nhp.size()<=0) return true;
	ndxh hchld=(nh)*2+1; bool OK=true;
	if(hchld<nhp.size()-1 && (LeftHighP()(v[nhp[hchld]],v[nhp[nh]]))){
		if(LeftHighP()(v[nhp[nh]],v[nhp[hchld]]))
			;//* means prio are the same, thus do nothing
		else{
			return false;
			//OK=false;
			//{chars cs; cs=nh; cs+=", prnt: ";cs+=v[nhp[nh]];    cs+="  "; cs+=v[nhp[hchld]];    cs.show();}
			//LeftHighP()(v[nhp[hchld]],v[nhp[nh]]);
		}
	}
	++hchld;
	if(hchld<nhp.size()-1 && (LeftHighP()(v[nhp[hchld]],v[nhp[nh]])) ){
		if(LeftHighP()(v[nhp[nh]],v[nhp[hchld]]))
			;//* means prio are the same, thus do nothing
		else{
			return false;
			//OK=false;
			//{chars cs; cs=nh; cs+=", prnt: ";cs+=v[nhp[nh]];    cs+="  "; cs+=v[nhp[hchld]];    cs.show();}
			//LeftHighP()(v[nhp[hchld]], v[nhp[nh]]);
		}
	}
	return OK;
}

template<class type, class LeftHighP>	int	dynPQ_<type,LeftHighP>::
heappOK	()
{
	ndxh hn=(nhp.size())/2;
	for(; hn>0; hn--){
		if(!childOK(hn))
			return hn;
	}
		if(!childOK(0))
			return 0;
	return -1;
}

template<class type, class LeftHighP>	int	dynPQ_<type,LeftHighP>::
ndxOK	(char* s)
{
	uint n,N;
	N=nhp.size();
	for(n=0; n<N; n++){
		if(aux[nhp[n]]!=n){
			//chars cs; if(s&&s[0]) cs=s; cs+=" aux[nhp[n]]!=n :n="; cs+=n; cs.show();
			return n;
		}
	}
	N=aux.size();
	for(n=0; n<N; n++){
		if(aux[n]>=nhp.size()) continue;
		if(nhp[aux[n]]!=n){
			//chars cs; if(s&&s[0]) cs=s; cs+=" nhp[aux[n]]!=n :n="; cs+=n; cs.show();
			return n;
		}
	}
	return -1;
}



#endif //DYNPQ_H
