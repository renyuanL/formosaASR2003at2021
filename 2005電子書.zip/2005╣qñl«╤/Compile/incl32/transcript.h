//
//	file transcript.h
//

#ifndef TRANSCRIPT_H
#define TRANSCRIPT_H

#include <di5base.h>
#include <direct.h>


class di5pdf_ { public:// use din as initials (path/directory/file names)
			di5pdf_() { getsetsys(); }
public:
	chars exe;	// pathname for the exe
	chars tesi;	// pathname for the tesi files
	chars tts;	// pathname for the tts files
	chars tcp;	// pathname for the tcp  file
	chars ecf;	// file name of the tcp  file
	chars fmt0head;
	char*	make_pfname(char* pname, char* subdir, char* fname, char* ext);
public:
	int		getsetsys	();
	int		settcp		(char* pfn4tcp1);
public:
	int		isfromTESI(char* pfname1);
	char*	TTS4 		(char* fname1, char*ext1, char qiqen);
	char*	pfname	(charspp* spp1,char*ext1);
	char*	pfname	(char*  fname1,char*ext1); // 4 filename of tcp line
	char*	tesi4		(charspp* spp1,char*ext1);
	char*	tesi4		(char* fname1, char*ext1);
	char* pn4tcp	(	) { return tcp.s; }
	char* pfn4tcp	( )	{ return make_pfname(tcp.s, NULL, ecf.s, NULL);}
};


class tcp1_ { public:
			tcp1_() :qiqen('d'),nlines41sentence(1),fmt(1),nchanges(0),nCHANGES(200)
							 {vunim.set2Nhun("= = = ="); trimvunim(); }
			int fmt;
public:
//protected:
//			charspp     contents;// tcp contents
			charss				contents;// tcp contents
      voids<int>		nglines; // linenum into contents of good tcp line
      voids<int>		nheads0; // linenum into contents of nominal prgf heads
      voids<int>		n1sts;   // linenum into nglines  of 1st line of prgf
  int		cntntline2nline(int i);// from ndx in contents to begin ndx in nglines
protected:	 static char nullstr[8];
public:
  int		npf2n1st 	(int npf1){ return n1sts[npf1]; 	 }
  int   ngline2npf(int i);
public:
      int ith;           	// current line
      charspp vunim;
      char qiqen;
			int  nlines41sentence;
      int  nchanges, nCHANGES;
      charspp spp; chars s;
public:
	void  clear(){contents.clear(); nglines.clear();nheads0.clear();n1sts.clear();
  							ith=0;vunim.set2Nhun("= = = ="); trimvunim();
  }
	int		save(int withbackup=1);
  void  checkautosave();
	int		read2contents (char* pfname);
	//int		peek2setting	(char* pfname);
	int		setting	();
	int  	read0					(char* pfname, int delsillines);
  int		read04tcpedit	(char* pfname);
  int 	setnglines		(int delsillines, int resetcurrent);
	void 	setnlines4fmt0();
	void 	setnlines4fmt1(int delsillines);
	void 	setnlines4fmt2();
	void 	setnheads			();
	//int  	setstatus			(char* str, int delsillines);
  int  	read					(char* str, int delsillines=0);
	int 	read4tcpedit	(char* str);
  char* getstatus    	();
public:
	int  	isINBND	(int i){ return ( (0<=i)&&(i< nglines.size()) )?1:0;}
	int	 	pfsize	(			){ return nheads0.size(); }
  int  	size	  (		  ){ return nglines.size();}
  int  	isdaiqi	(			){ return qiqen=='d'; 	 }
  int  	iskehqi	(			){ return qiqen=='k'; 	 }
  int  	ismiaulik(		){ return qiqen=='m'; 	 }
  int  	ishuaqi(			){ return qiqen=='h'; 	 }
	int		fmt0app1line();
  int  	setcurrent(int i	);
  int		trimvunim();
  int  	set2prev  (				) { return setcurrent(ith-1);			}
  int  	set2next  (				) { return setcurrent(ith+1);			}
  char*	tcpline		(int nth)	{	return contents[nglines[nth]];}
public:
  char* dam   (int i=-1) { if(i>=0)setcurrent(i);return vunim[0];}
  char* tag   (int i=-1) { if(i>=0)setcurrent(i);return vunim[0];}
  char* vun   (int i=-1) { if(i>=0)setcurrent(i);return vunim[1];}
  char* yim   (int i=-1) { if(i>=0)setcurrent(i);return vunim[2];}
	char* im    (int i=-1) { if(i>=0)setcurrent(i);return vunim[2];}
  char* lab   (int i=-1) { if(i>=0)setcurrent(i);
  												 if(vunim[3][0]) return vunim[3];
                           return vunim[2]; }
	int		auto_simple_bendiau_all();
	int		auto_simple_bendiau(); // workon current line
  int   update_iv (char* im1, char* vun1);
  int		update_im (char* im1 );
  int		update_vun(char* vun1);
	int		insafter_iv (char* im1, char* vun1 ); // after current line
  int   joinwith(); // join  next line to current line
  int   mergeto (); // merge current line to prev line, make prev current
//  int		update_tag(char* tag1);
  char* ext4sp		(			){ static char t[]=".sp"; return t; }
  char* prgfhead	(int j);
  char* prgf_all 	(int j, char* sep=" ");
  char* imINimzet	(int nth); // separated with spaces
  char* imINsu		(int nth); // separated with spaces
public:
      di5pdf_ din;
public:
	int		isfromTESI(char* str)	{ return din.isfromTESI(str); }
  int		settcp(char* fn)		 	{ return din.settcp(fn); }
	char* pname ()   						{ return din.tcp(); }
  char* fname	(int i=-1)			{ return tag(i); }
public:
  char* pfname (charspp* spp1,char*ext1){return din.pfname(spp1,  ext1);		}
  char* pfname (char*  fname1,char*ext1){return din.pfname(fname1,ext1);		}
  char* pfname (							char*ext1){return din.pfname(tag( ),ext1);		}
  char* pfname (int i)									{return din.pfname(tag(i),ext4sp());}
public:
  char* TTS4 	(char* fname1, char*ext1){return din.TTS4 (fname1, ext1, qiqen);}
  char* tesi4	(charspp* spp1,char*ext1){return din.tesi4(spp1, 	 ext1); 			}
  char* tesi4	(char* fname1, char*ext1){return din.tesi4(fname1, ext1); 			}
  char* tesi4 (							 char*ext1){return din.tesi4(tag( ), ext1    );		}
  char* tesi4 (int i)									 {return din.tesi4(tag(i), ext4sp());		}
};



class tcp2_ : public tcp1_ {
	voids<int> nunits;
	int set_nunits();
	charspp sppyim2, sppvun2; int nthprgrf, nthunit;
	int setcurrentprgrf(int nthprgrf1);
public:
	tcp2_():nthprgrf(-1), nthunit(-1) {}
public:
	int   read		(char* pfname) { tcp1_::read0(pfname,-1); return set_nunits(); }
	int   isgood  (int nthprgrf1, int nthunit1);//{if( (nthprgrf>=0)&&(nthunits>=0)&&(nthprgrf<prgrfs.size())&&(nthunits<(*prgrfs[nthprgrf]).size()) ) return 1; return 0; }
	char* items		(int nthprgrf1, int nthunit1);
	char* itemsyim(int nthprgrf1, int nthunit1);
	char* itemsvun(int nthprgrf1, int nthunit1);
};

class tcp4sent {
	chars m,y,v;// mia(speech file name), yim, vun;
	int set2(char* s);
	int set2(char*m1, char*y1, char* v1);
};
class tcp4pgf  {
	vector<tcp4sent*> pgf;
	int app(char* s);
	int app(char*m1, char*y1, char* v1);
};

class tcp4art  { // tcp4 article
	vector<tcp4pgf*> abc;
};

typedef tcp4sent tcpsent;
typedef tcp4pgf  tcppgf;
typedef tcp4art  tcpart;



#ifdef OLDOLDOLDOLDOLD
class transcript_ { public:
			transcript_() : qiqen('d'), nlines41sentence(1),fmt(1) { }
protected:
			charspp     contents;// tcp contents
      voids<int>	nglines;  // linenum into contents of real tcp line
      voids<int>  nheads0; // linenum into contents of prgf heads in string
      voids<int>		n1sts;   // linenum into nglines  of 1st line of prgf
      int fmt;
  int		cntntline2nline(int i);// from ndx in contents to begin ndx in nglines
protected:	 static char nullstr[8];
public:
	int	 	psize() 		{ return nheads0.size(); }
  int		nprgf2nline	(int nprgf1) { return n1sts[nprgf1]; }
  int   nline2nprgf	(int i);
  int   nprgf2n1st	(int j){ return n1sts[j]; }
public:
      int ith;           	// current line
      charspp vunim;
      char qiqen;
      int  nlines41sentence;
      charspp spp; chars s;
public:
	int		peek2setting(char* pfname);
	int  	read		(char* pfname, int delsillines);
	void 	setnlines4fmt1();
	void 	setnlines4fmt2();
	void 	setnheads();
  int  	setstatus    (char* str, int delsillines=1);
public:
	int  	isINBND(int i){ return ( (0<=i)&&(i< nglines.size()) )?1:0;}
  int  	size	  (		  ){ return nglines.size();}
  int  	isdaiqi(			){ return qiqen=='d'; 	}
  int  	iskehqi(			){ return qiqen=='k'; 	}
  int  	ismiaulik(		){ return qiqen=='m'; 	}
  int  	ishuaqi(			){ return qiqen=='h'; 	}
  int  	setcurrent(int i);
  int  	set2prev  (     ) { return setcurrent(ith-1); }
  int  	set2next  (     ) { return setcurrent(ith+1); }
  char*	tcpline		(int nth){return contents[nglines[nth]];}
public:
  char* tag   (int i=-1) { if(i>=0)setcurrent(i);return vunim[0];}
  char* vun   (int i=-1) { if(i>=0)setcurrent(i);return vunim[1];}
  char* im    (int i=-1) { if(i>=0)setcurrent(i);return vunim[2];}
  char* lab   (int i=-1) { if(i>=0)setcurrent(i);static char nil[]="";
  													return(vunim.size()>3)?vunim[3]:nil; }
  char* prgfhead	(int j);
  char* prgf_all 	(int j, char* sep=" ");
  char* imINimzet	(int nth); // separated with spaces
  char* imINsu		(int nth); // separated with spaces
public:
      chars pfn4lines;
      chars pn4lines;
      chars pn4tesi, pn4TTS;
public:
  void	setpfnames(char* fn, char*pure_pname);
  char* pname  ()   		{ return pn4lines.c_str(); 			}
  char* fnames(int i=-1) { if(i>=0)setcurrent(i);return vunim[0];}
  char* fullpfname   (charspp* spp1, char*ext);
  char* fullTTSpfname(char* fname, char*ext);
  char* fullpfname   (char* fname, char*ext);
  char* fullpfname   (char* ext);
  char* fullpfname   (int i);
  char* tesipfname   (charspp* spp1, char*ext);
  char* tesipfname   (char* ext);
  char* tesipfname   (int i);
  char* getstatus    ();
};

#endif //OLDOLDOLDOLDOLD



#endif //#ifndef TRANSCRIPT_H

/*
class transcript_ { public:
			transcript_() : qiqen('d') { }
			charspp tcp_lines;
      charspp prgfs; // store lineno of prgf heads in string
      int ith; charspp vunim; // current line
      chars tcp_pfname; chars tcp_pname;
      chars tesipname;
      charspp spp; chars s;
      char qiqen;
	int  read(char* pfname);
  int  isINBND(int i){ return ( (0<=i)&&(i<tcp_lines.size()) )?1:0; }
  int  size	 (		 ){ return tcp_lines.size(); }
public:
  void setpfnames(char* fn, char*pure_pname);
public:
	void setprgfs();
  void delempty(){tcp_lines.delparts_startwith("#");}
public:
  int  setcurrent(int i);
  int  set2prev  (     ) { return setcurrent(ith-1); }
  int  set2next  (     ) { return setcurrent(ith+1); }
  char* pname  ()   		{ return tcp_pname.c_str(); 			}
  char* fnames(int i=-1) { if(i>=0)setcurrent(i);return vunim[0];}
  char* vun   (int i=-1) { if(i>=0)setcurrent(i);return vunim[1];}
  char* im    (int i=-1) { if(i>=0)setcurrent(i);return vunim[2];}
  char* lab   (int i=-1) { if(i>=0)setcurrent(i);static char nil[]="";
  													return(vunim.size()>3)?vunim[3]:nil; }
  char* prgfhead(int j) { int i=s2i(prgfs[j]); return vun(i); }
  char* prgf    (int j, char* sep=" ");
  int   get_nprgf(int i);
  char* fullpfname   (charspp* spp1, char*ext);
  char* fullTTSpfname(char* fname, char*ext);
  char* fullpfname   (char* fname, char*ext);
  char* fullpfname   (char* ext);
  char* fullpfname   (int i);
  char* tesipfname   (charspp* spp1, char*ext);
  char* tesipfname   (char* ext);
  char* tesipfname   (int i);
  char* getstatus    ();
  int   setstatus    (char* str, int delsillines=1);
  int   isdaiqi()    { return qiqen=='d'; }
  int   iskehqi()		 { return qiqen=='k'; }
  int   ishuaqi()		 { return qiqen=='h'; }
};

*/

