//
//	vecproc.h
//	collection of vectoring routines
//	IZGang 2002
//
#ifndef VECPROC_H
#define VECPROC_H

#include <vector>
#include <valarray>


template<class real>
void partition(vector<real>&v, uint low, uint hai, uint& ndxpivot)
{
  uint i,j;
  uint mid=(low+hai)/2; swap(v[low],v[mid]);
  real val=v[low];
  j=low;
  for(i=low+1; i< hai; i++){// i < hai, since 0-based
	if(v[i]<val){
	  j++;
	  swap(v[i],v[j]);
	}
  }
  ndxpivot=j;
  swap(v[low],v[ndxpivot]);
}

template<class real>
real kthlargest(vector<real>&v, uint low, uint hai, uint K)
{
  if(low==hai)
	return v[low];
  uint ndxpivot;
  partition(v,low,hai,ndxpivot);
  if(K==ndxpivot)
	return v[ndxpivot];
  if(K<ndxpivot)
	return kthlargest(v,low,ndxpivot-1,K);
  else
	return kthlargest(v,ndxpivot+1,hai,K);
}

template<class real>
real kthlargest(vector<real>&v, uint K)
{
  return kthlargest(v,0,v.size(),K);
}

template<class real>
real quantile(vector<real>&v, float p)
{
  if(p>1) p=1; if(p<0) p=0;  uint K=uint(p*v.size());
  return kthlargest(v,0,v.size(),K);
}

template<class real>
int quantile(vector<real>&v, real&vp1, real&vp2, float p1, float p2)
{
  vp1=kthlargest(v,p1);
  vp2=kthlargest(v,p2);
  return 2;
}

template<class real>
real quantile(vecvec<real>&vv, float p1)
{
  vector<real> v; v.resize(vv.nfrm()*vv.ncmp(),0); uint pos=0;
  for(uint tt=0;tt<vv.nfrm();tt++)for(uint cc=0;cc<vv.ncmp();cc++)v[pos++]=vv(tt,cc);
  return quantile(v,p1);
}

template<class real>
int quantile(vecvec<real>&vv, real& vvp1, real& vvp2, float p1, float p2)
{
  vector<real> v; v.resize(vv.nfrm()*vv.ncmp(),0); uint pos=0;
  for(uint tt=0;tt<vv.nfrm();tt++)for(int cc=0;cc<vv.ncmp();cc++)v[pos++]=vv(tt,cc);
  return quantile(v,vvp1,vvp2,p1,p2);
}



template<class real>
double meanvar(double& mean, double& var, vector<real>& v)
{
  uint n,N=v.size(); double tmp;
  double sum=0; for(n=0; n<N;n++) { sum+=v[n];		} mean=sum/N;
  double tot=0; for(n=0; n<N;n++) { tmp =v[n]-mean; tot+=tmp*tmp; }
  var=tot/(N-1);
  return 2;
}

template<class real>
double var(vector<real>& v)
{
	double mn, vr;
	meanvar(mn,vr, v);
	return vr;
}

template<class real>
double meanvar(double& mean, double& var, vector<real>& v, uint beg, uint end)
{
  uint n; double tmp;
  double sum=0; for(n=beg; n<end;n++) { sum+=v[n]; 		} mean=sum/double(end-beg);
  double tot=0; for(n=beg; n<end;n++) { tmp =v[n]-mean; tot+=tmp*tmp; }
  var=tot/double(end-beg);
  return 2;
}

template<class real>
double mean(vector<real>& v, uint beg, uint end)
{
  uint n; double tmp;
  double sum=0; for(n=beg; n<end;n++) { sum+=v[n]; 		}
  double mn=sum/double(end-beg);
  return mn;
}

template<class real>
double var(vector<real>& v, uint beg, uint end)
{
	double mn, vr;
	meanvar(mn,vr,  v,  beg,end);
	return vr;
}

template<class real1, class real2>
int ratio_sbvar(vector<real1>&v, vecvec<real2>&m, int nbands)
{
	uint tt,TT=m.nfrm(),cc,CC=m.ncmp(), dband=CC/nbands;
	vector<double> tmp;tmp.resize(CC); v.resize(TT);
	for(tt=0;tt<TT;tt++){
		for(cc=0;cc<CC;cc++) tmp[cc]=m(tt,cc); //copy all cmps in a frm to tmp
//		v[tt]=mean(tmp,0+4,dband+4)/mean(tmp,dband*(nbands-1),CC);
		v[tt]=var (tmp,0+1,dband+1)/var (tmp,CC-dband,CC);
	}
	return v.size();
}


template<class frwditer>
int zerocross(frwditer beg, frwditer end)
{
	int cnt=0;
	int sgn; sgn=((*beg)<0)?-1:1;
	for(beg++; beg!=end; ++beg){
		if(sgn<0){
			if((*beg)<0) continue;
			else {sgn=1; ++cnt;}
		}else{
			if((*beg)>0) continue;
			else {sgn=-1;++cnt;}
		}
	}
	return cnt;
}

template<class real> inline
int zerocross(vector<real>& v)
{
	return zerocross(v.begin(),v.end());
}
template<class real> inline
int zerocross(valarray<real>& v)
{
	return zerocross(&v[0],&v[v.size()-1]);
}

template<class frwditer>
int L1(frwditer beg, frwditer end)
{
	double tot=0;
	for(; beg!=end; ++beg){
		if((*beg)<0) tot-=(*beg); else tot+=(*beg);
	}
	return tot;
}

template<class real>
double L1(vector<real>& v)
{
	return L1(v.begin(), v.end());
}




double L2norm(vector<double>& v1, vector<double>&v2)
{
  if(v1.size()!=v2.size()) return -1;
  uint n,N=v1.size();double tot,tmp;
  tot=0.0;
  for(n=0; n<N; n++){tmp=v1[n]-v2[n];tot+=tmp*tmp;}
  return sqrt(tot);
}






template<class real>
struct pair_ri{  real r; int i;
	   pair_ri(){     r=0;   i=0;}
};

template<class real>
struct lispair_ri{ //left is smaller
  int operator()(const pair_ri<real>& l, const pair_ri<real>& r)
  {if(l.r<r.r)return 1; return 0;}//(l.d>r.d)?1:0;}
};

template<class real>
int vec2rank(vector<int> & r, vector<real>& v)
{
  vector<pair_ri<real> > w;
  uint n,N=v.size(); pair_ri<real>  ri;
  for(n=0;n<N; n++){
	ri.r=v[n]; ri.i=n;
	w.push_back(ri);
  }
  sort(w.begin(), w.end(), lispair_ri<real>() );
  r.resize(N);
  for(n=0; n<N; n++){
	r[w[n].i]=n;
  }
  return 1;
}


////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


template<class real>
int vec2lmaxpos(vector<int> & r, vector<real>& v)
{
  uint n,N=v.size(); r.clear(); r.resize(N,0);
  int up=1;
  for(n=1; n<N; n++){
	if(up>0){
	  if(v[n-1]<=v[n]){++up;}
	  else{r[n-1]=1; up=-1;}
	}else{
	  if(v[n-1]> v[n]){--up;}
	  else{up=1;}
	}
  }
  if(up>0)r[N-1]=1;
  return 1;
}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////




////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


template<class real1, class real2, class real3>
int setseq(vector<real1>&v, real2 beg, real3 end)
{
	uint n,N=(end-beg+0.0001);
	v.resize(N);
	for(n=0; n<N; n++){
		v[n]=beg;
		beg++;
	}
	return N;
}

template<class real1, class real2, class real3, class real4>
int setseq(vector<real1>&v, real2 beg, real3 end, real4 delta)
{
	uint n,N=(end-beg+delta*0.0001)/delta;
	v.resize(N);
	for(n=0; n<N; n++){
		v[n]=beg;
		beg+=delta;
	}
	return N;
}




////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


template<class real>
int log(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=log(m(tt,cc));
  return CC*TT;
}

template<class real>
int exp(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=exp(m(tt,cc));
  return CC*TT;
}


template<class real>
int sin(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=sin(m(tt,cc));
  return CC*TT;
}

template<class real>
int cos(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=cos(m(tt,cc));
  return CC*TT;
}

template<class real, class real2>
int pow(vecvec<real>& m, real2 expon)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=pow(m(tt,cc),expon);
  return CC*TT;
}


template<class real>
int sqr(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=(m(tt,cc))*(m(tt,cc));
  return CC*TT;
}

template<class real>
int sqrt(vecvec<real>& m)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)=srqt(m(tt,cc));
  return CC*TT;
}

template<class real1,class real2>
int add_by(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)+=m(tt,cc);
  return CC*TT;
}

template<class real1,class real2>
int sub_by(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)-=m(tt,cc);
  return CC*TT;
}

template<class real1,class real2>
int div_by(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)/=m(tt,cc);
  return CC*TT;
}

template<class real1,class real2>
int mul_by(vecvec<real1>& m, real2 c)
{
  uint tt, TT=m.nfrm();
  uint cc, CC=m.nfrm();
  for(tt=0;tt<TT;tt++)for(cc=0;cc<CC;cc++)
	m(tt,cc)*=m(tt,cc);
  return CC*TT;
}



////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////




template<class real>
int log(vector<real>& v)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=log(v[n]);
	return N;
}

template<class real>
int exp(vector<real>& v)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=exp(v[n]);
	return N;
}


template<class real>
int sin(vector<real>& v)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=sin(v[n]);
	return N;
}

template<class real>
int cos(vector<real>& v)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=cos(v[n]);
	return N;
}

template<class real, class real2>
int pow(vector<real>& v, real2 expon)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=pow(v[n],expon);
	return N;
}


template<class real>
int sqr(vector<real>& v)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=v[n]*v[n];
	return N;
}

template<class real>
int sqrt(vector<real>& v)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=sqrt(v[n]);
	return N;
}

template<class real>
int inverse(vector<real>& v)
{
	uint n,N=v.size();
	for(n=0; n<N; n++)
		v[n]=1.0/v[n];
	return N;
}

////////////////////////////////////////////////////////


template<class real1,class real2>
int add_by(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]+=c;
	return N;
}

template<class real1,class real2>
int sub_by(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]-=c;
	return N;
}

template<class real1,class real2>
int div_by(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]/=c;
	return N;
}

template<class real1,class real2>
int mul_by(vector<real1>& v, real2 c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]*=c;
	return N;
}

////////////////////////////////////////////////////////

template<class real1,class real2>
int add_byv(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]+=c[n];
	return N;
}

template<class real1,class real2>
int sub_byv(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]-=c[n];
	return N;
}

template<class real1,class real2>
int div_byv(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]/=c[n];
	return N;
}

template<class real1,class real2>
int mul_byv(vector<real1>& v, vector<real2>& c)
{
	uint n,N=v.size();
	for(n=0;n<N;n++)
		v[n]*=c[n];
	return N;
}



////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////



#endif //#ifndef VECPROC_H
