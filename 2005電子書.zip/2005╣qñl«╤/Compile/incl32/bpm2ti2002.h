extern ze2he bpm2ti2002;
//add above declaration to whereever before you need it 
//class ze2he is defined in <di5base.h>
//see using ze2he (power point) for example usage
