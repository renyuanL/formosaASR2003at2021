//---------------------------------------------------------------------------
#ifndef fplotbcbH
#define fplotbcbH
//---------------------------------------------------------------------------
//
// file fplotbcb.h
//
#include <windows.h>
//---------------------------------------------------------------------------
class  COLORS256 {
public:COLORS256(int nth=4) { setcolors(nth); }
	COLORREF colors[256];
	COLORREF nthcolor(float x);
	COLORREF operator ()(float x){ return nthcolor(x); }
	void setcolors(int nth=4);
};

class  GREYS : public COLORS256 {
public:GREYS():COLORS256(4){}
};


class fplotbase {
public: fplotbase() { setdotwh(2,2); }
	int ires;// int result, for debugging
	int 	px0, py0, pdx, pdy; // (x0,y0) is left-top
	float lx0, ly0, ldx, ldy;
	float scalex, scaley;
public:
	int  pwidth()										{ return pdx; 	}
	int  pheight() 									{ return pdy; 	}
	int  lwidth()                  	{ return ldx; 	}
	int  lheight()									{ return ldy; 	}
	int  width()                   	{ return ldx; 	}
	int  height()										{ return ldy; 	}
	int    l2px(float lx)  { return int((lx-lx0)/scalex); }
	int    l2py(float ly)  { return int((ly-ly0)/scaley); }
	float  p2lx(int   px)  { return  px*scalex+lx0;  }
	float  p2ly(int   py)  { return  py*scaley+ly0;  }
public:
	void  setlx0(float lx01){lx0=lx01;}
	void  setly0(float ly01){ly0=ly01;}
	void  setldx(float ldx1){ldx=ldx1;}
	void  setldy(float ldy1){ldy=ldy1;}
	void  setpx0(float px01){px0=px01;}
	void  setpy0(float py01){py0=py01;}
	void  setpdx(float pdx1){pdx=pdx1;}
	void  setpdy(float pdy1){pdy=pdy1;}
	float getlx0(					 ){return lx0;}
	float getly0(					 ){return ly0;}
	float getldx(					 ){return ldx;}
	float getldy(					 ){return ldy;}
	float getpx0(					 ){return px0;}
	float getpy0(					 ){return py0;}
	float getpdx(					 ){return pdx;}
	float getpdy(					 ){return pdy;}
public: // (x0,y0) is left-top
	void  setpscale (int px01,int py01, int pdx1, int pdy1)
									{px0=px01;py0=py01; pdx=pdx1; pdy=pdy1;}
	void  setlscale (float lx01,float ly01, float ldx1,float ldy1)
									{  lx0=lx01;  ly0=ly01;   ldx=ldx1;  ldy=ldy1;setlscalexy();}
	void  setlscalexy(){	scalex =  1.0*getldx()/getpdx();
												scaley = -1.0*getldy()/getpdy(); }
public:
	virtual void ptextout(int px,int py, char*str){}//{pc()->TextOut(px,py,str);}
	void  textout(float lx, float ly, char* str){ptextout(l2px(lx),l2py(ly),str);}
	void  textoutlt(char* str){ ptextout(10,10,str); } // lt: left top
public:
	virtual void pmove2(int px, int py) 		{ }//pb->Canvas->MoveTo(px, py); }
	virtual void pline2(int px, int py) 		{ }//pb->Canvas->LineTo(px, py); }
	void  move2(float lx, float ly)	{ pmove2(l2px(lx), l2py(ly)); }
	void  line2(float lx, float ly) { pline2(l2px(lx), l2py(ly)); }
public:
	int  dotw, doth;
	void setdotwh (int w, int h) { dotw=w; doth=h;  }
	virtual void pputdot (int px,int py, int clr){}//{pc()->Pixels[px][py]=TColor(clr);}
	void pputbdot(int px,int py, int clr){int i,j;for(i=0;i<dotw;i++)for(j=0;j<doth;j++)
									pputdot(px+i,py+j,clr);													}
	void  putdot (float lx,float ly,int clr){pputdot (l2px(lx), l2py(ly),TColor(clr)); }
	void  putbdot(float lx,float ly,int clr){pputbdot(l2px(lx),l2py(ly),TColor(clr)); }
public:
	void XORvpline(int px,  TColor cln=clRed);
public:
	TPenMode pm_old; TColor cl_old;
	virtual void pushPenColor (COLORREF clr){}//{cl_old=pc()->Pen->Color;pc()->Pen->Color=cln;}
	virtual void pop_PenColor (            ){}//{                    pc()->Pen->Color=cl_old; }
	virtual void pushPenMode  (TPenMode pmn){}//{pm_old=pc()->Pen->Mode; pc()->Pen->Mode=pmn; }
	virtual void pop_PenMode  (            ){}//{                    pc()->Pen->Mode=pm_old;  }
	virtual void blanknow     (            ){}//{pb->Invalidate();  pb->Update(); }
public:
	int dragX, dragY, dragON; COLORREF dragclr;
	virtual void dragplot(int X, int Y){}
	void dragplot0();//{pushPenMode(pmNotXor);dragplot(dragX,dragY);pop_PenMode();}
	void begdrag(int X, int Y, COLORREF clr=-1);
	void movdrag(int X, int Y){if(!dragON) return; dragplot0(); dragX=X; dragY=Y; dragplot0();}
	void enddrag(int X, int Y){dragplot0(); dragX=X; dragY=Y; dragON=0;}
};

inline void fplotbase:: XORvpline(int px, TColor clr)
{
	pushPenColor(clr); 	pushPenMode(pmNotXor);
	pmove2(px, 0);     	pline2(px, getpdx());
	pop_PenMode();  		pop_PenColor();
}

inline void fplotbase::begdrag(int X, int Y, COLORREF clr)
{
	dragclr=clr;
	dragX=X; dragY=Y; dragON=1;dragplot0();
}

inline void fplotbase::dragplot0()
{
	pushPenMode(pmNotXor);
	if(dragclr>=0) pushPenColor(dragclr);
	dragplot(dragX,dragY);
	if(dragclr>=0) pop_PenColor();
	pop_PenMode();
}

inline COLORREF COLORS256::nthcolor(float x)
{int n=x;if(n>255)n=255;if(n<0)n=0;return colors[n];}

inline void COLORS256:: setcolors(int nth)
{ int i; int bk1=0, bk2=0, bk3=0;
	switch(nth) {
	case  1: for(i=0;i<256;i++)colors[255-i]=RGB(i  ,bk2,bk3);break;
	case  2: for(i=0;i<256;i++)colors[255-i]=RGB(bk1,i  ,bk3);break;
	case  3: for(i=0;i<256;i++)colors[255-i]=RGB(bk1,bk2,i  );break;
	default: for(i=0;i<256;i++)colors[255-i]=RGB(i  ,i  ,i  );break;
	}
}


class Tfplot: public fplotbase {
public:
	TPaintBox* 	pb;
	TCanvas*		pc()									{ return pb->Canvas; }
	void  setPaintBox(TPaintBox* pb1)  { pb=pb1;
					setpscale(0,0,pb->Width,pb->Height);setlscale(0,0,1,1); }
	void  setlscale (float lx01,float ly01, float ldx1,float ldy1)
					{ fplotbase::setlscale(lx01,ly01, ldx1, ldy1); }
public: // there are the first 9 simple virtual functions need to be derived
	virtual void ptextout(int px,int py, char*str){pc()->TextOut(px,py,str);   }
	virtual void pmove2	 (int px,int py) {pb->Canvas->MoveTo(px, py); }
	virtual void pline2  (int px,int py) {pb->Canvas->LineTo(px, py); }
	virtual void pputdot (int px,int py, int clr) {pc()->Pixels[px][py]=TColor(clr);}
	virtual void pushPenColor (COLORREF clr){cl_old=pc()->Pen->Color;pc()->Pen->Color=TColor(clr);}
	virtual void pop_PenColor (            ){                    pc()->Pen->Color=cl_old; }
	virtual void pushPenMode  (TPenMode pmn){pm_old=pc()->Pen->Mode; pc()->Pen->Mode=pmn; }
	virtual void pop_PenMode  (            ){                    pc()->Pen->Mode=pm_old;  }
	virtual void blanknow     (            ){pb->Invalidate();  pb->Update(); }
	virtual void dragplot     (int X, int Y){pmove2(dragX, 0);pline2(dragX, pheight());}
};

//derived from Tfplot (say, override dragplot) to retain the power




#endif //#ifndef fplotbcbH



