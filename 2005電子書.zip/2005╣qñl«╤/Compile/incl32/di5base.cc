//
// di5base.cc
// 2003-04 (C)IZGang
//

#ifndef DIBASE_CC
#define DIBASE_CC

/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
template<class T> inline// check and set t in limits [lo,hi]
void cslimit(T &t, const T&lo, const T& hi)
{
	if(lo>hi)return;
	if(t<lo) t=lo;
	if(hi<t) t=hi;
}
template<class T> inline // check t in limits [lo,hi]
int cklimit(T t, const T lo, const T hi)
{
	if((t<lo)||(hi<t)) return 0;
	return 1;
}



template<class T> inline // check and set t in limits [lo,hi]  // same as cslimit
void cslmt(T &t, const T&lo, const T& hi)
{
	if(lo>hi)return;
	if(t<lo) t=lo;
	if(hi<t) t=hi;
}
template<class T> inline // check t in limits [lo,hi] // same as cklimit
int cklmt(T t, const T lo, const T hi)
{
	if((t<lo)||(hi<t)) return 0;
	return 1;
}

template<class T> inline // check and set t in limits [lo,hi]
void csbe(T &t, const T&be, const T& en)
{
	if(be>en)return;
	if(t< be) t=be;
	if(t>=en) t=en;
}
template<class T> inline // check t in limits [lo,hi]
int ckbe(T t, const T be, const T en)
{
	if((t<be)||(en<=t)) return 0;
	return 1;
}


inline void byteswap_::bs4(void *p) // swap 4 bytes
{
   char temp,*q;
   q = (char*) p;
   temp = *q; *q = *(q+3); *(q+3) = temp; // swap byte[0] with byte[3]
	 q++;
   temp = *q; *q = *(q+1); *(q+1) = temp; // swap byte[1] with byte[2]
}

inline void byteswap_::bs2(void *p)// swap 4 bytes
{
   char temp,*q;
   q = (char*) p;
   temp = *q; *q = *(q+1); *(q+1) = temp;
}



/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
template<class T> inline
chars& operator<<(chars& cs, vector<T>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; ++n) cs<<v[n]<<"\t";
	return cs;
}

template<class T> inline
chars& operator<<(chars& cs, valarray<T>& v)
{
	size_t n,N=v.size();
	for(n=0; n<N; ++n) cs<<v[n]<<"\t";
	return cs;
}




/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////

#ifdef Di5USEMEMPOOL

template<size_t BSZ, size_t PSZ>
inline void
mpool<BSZ,PSZ>::
dllc_pnodes()
{
	pnode* pn;
	while(phead){
		pn=phead;
		phead=phead->next;
		free(pn);
	}
	pn_destroyed=1;
	uhead=0;
}


template<size_t BSZ, size_t PSZ>
inline int
mpool<BSZ,PSZ>::
allc_pnodes()
{
	pnode* pn=(pnode*)malloc(bsz*psz);
	if(!pn){ uhead=0; return 0; }
	if(pn_destroyed){ return 0; }
	pn->next=phead;phead=pn;
	unode* un; char* cs=(char*)pn; size_t i;
	for(i=0; i<psz;i++){
		un=(unode*)&(cs[i*bsz]);
		un->next=uhead; uhead=un;
	}
	return psz;
}

template<size_t BSZ, size_t PSZ>
inline void*
mpool<BSZ,PSZ>::
allc(size_t bsz1)
{
	if(bsz!=bsz1) return malloc(bsz1);
	if(!uhead){if(!allc_pnodes())return NULL;}
	unode* un=uhead;
	uhead=uhead->next;
	return (void*)un;
}

template<size_t BSZ, size_t PSZ>
inline void
mpool<BSZ,PSZ>::
dllc(void*un1, size_t bsz1)
{
	if(!un1) return;
	if(bsz!=bsz1) { free(un1); return; }
	if(pn_destroyed) return;
	unode* un=(unode*)un1;
	un->next=uhead;
	uhead=un;
}

#endif //#ifdef Di5USEMEMPOOL


/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////

TPCI(T) int  voids<T>::resize(int size)
{
	if(size<=allocsize)return 1;
	if(a)
		a=(T*)realloc(a,size*sizeof(T));
	else
		a=(T*)malloc (size*sizeof(T));
	if(a){own=1;allocsize=size; return 1;}
	init20();
	return 0;
}
TPCI(T) uint voids<T>::nextsz(			)
{
	if(allocsize<16)return 16;
	if(allocsize<=512)
		return 2*allocsize;
	return int(allocsize*1.1);
}

TPCI(T) int voids<T>::app	( T t			 )
{
	if(asz >= allocsize){
		if(!resize(nextsz()))
			return 0;
	}
	memset(&a[asz],0,sizeof(T));
	a[asz++]=t;
	return 1;
}
TPCI(T) int voids<T>::ins	(T t, int n)
{
	if(!app(t))return 0; int i=size()-1;
	for(;i>n;i--)a[i]=a[i-1]; a[n]=t; return 1;
}
TPCI(T) T   voids<T>::del	(int n		 )
{
	T orphan=a[n];  asz--;
	for(int s=n; s<asz; s++)
		a[s]=a[s+1];
	return orphan;
}
TPCI(T) T   voids<T>::rm  (int n		 )
{
	T orphan=a[n];  asz--;
	for(int s=n; s<asz; s++)
		a[s]=a[s+1];
	return orphan;
}
TPCI(T) void voids<T>::
operator=(voids<T>& r)
{
	clear();
	for(int i=0;i<r.size();i++)
		{app(r[i]);}
}

/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////

inline int	str_isrline		(char* s){ return !str_isblank(s); }
inline int  str_isP_P 		(char* s, char c) {return str_isPBC(s, '(', ')',c);}//(...c)
inline int  str_isB_B 		(char* s, char c) {return str_isPBC(s, '[', ']',c);}//[...c]
inline int  str_isC_C 		(char* s, char c) {return str_isPBC(s, '{', '}',c);}//{...c}
inline int 	str_tr		 	(char*s, char tbr, char r){return str_replace(s,tbr,r);}
inline int	str_slashch2ch1  (char*s,char ch, char ch1 ){return str_control_ch2ch1(s,'/' ,ch,ch1);}
inline int	str_bslashch2ch1 (char*s,char ch, char ch1 ){return str_control_ch2ch1(s,'\'',ch,ch1);}
inline int	str_slash_ch2ch1 (char*s,char ch, char ch1 ){return str_control_ch2ch1(s,'/' ,ch,ch1);}
inline int	str_bslash_ch2ch1(char*s,char ch, char ch1 ){return str_control_ch2ch1(s,'\'',ch,ch1);}

inline void str_rmove    (char* s, int slen, int nbytes){  memmove(s+nbytes, s, slen+1); }
inline void str_overwrite(char* st, char* ss, int sslen){ memmove(st,ss, sslen);	}



/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
inline	void chars::
set20(	)
{
	if(s)
		s[0]=0;
	else
		init20();
}



/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////

#define int2mcr(name, x, y) 														\
struct	name { int x,y;                                                     		\
		 name	 		 (							 ){set20();	}					\
		 name	 		 (int x1, int y1 ){set2(x1,				y1);	}			\
	name&operator =(const name& rhs){set2(rhs.x,		rhs.y);		return *this;}	\
	name&operator+=(const name& rhs){set2(x+rhs.x, 	y+rhs.y);	return *this;}	\
	name&operator-=(const name& rhs){set2(x-rhs.x, 	y-rhs.y);	return *this;}	\
	name&operator*=(double times	 ){set2(x*times,  y*times);	return *this;}	\
	name&operator/=(double times	 ){set2(x/times,  y/times);	return *this;}	\
	name operator+ (const name& rhs){return name(x+rhs.x, y+rhs.y);}	        \
	name operator- (const name& rhs){return name(x-rhs.x, y-rhs.y);}    	    \
	void set2			 (const name& rhs){set2(rhs.x, rhs.y);	}       		\
	void set20		 (							 ){set2(0,0);			}		\
	void clear		 (							 ){set20(	);			}       \
	void set2neg	 (							 ){x=y=-1;				}       \
	int	 isnneg		 (							 ){return (x>=0)&&(y>=0);}      \
	int	 isneg 	   (							 ){return !isnneg();	}       \
	void set2			 (int x1, int y1 ){x=x1;y=y1;					}       \
	void operator= (const SIZE& s  ){set2(s.cx,s.cy);					}       \
};// end of int2mcr

#define int3mcr(name, x, y, z) \
struct 	name { int x,y,z;                                                     	\
		name(		 			 ){set20();	}									\
		name(int x1,int y1,int z1){set2(x1,	y1, z1);  }     					\
	name&operator =(const name& r){set2(r.x,	r.y,  r.z);		return *this;}	\
	name&operator+=(const name& r){set2(x+r.x,y+r.y,z+r.z);	return *this;}	  	\
	name&operator-=(const name& r){set2(x-r.x,y-r.y,z-r.z);	return *this;}	  	\
	name&operator*=(double times ){set2(x*times,y*times, z*times);return *this;}\
	name&operator/=(double times ){set2(x/times,y/times, y/times);return *this;}\
	name operator+ (const name& r){return name(x+r.x, y+r.y, z+r.z);}     	  	\
	name operator- (const name& r){return name(x-r.x, y-r.y, z-r.z);}     	  	\
	void set2	   (const name& r){set2(r.x, r.y, r.z);}						\
	void set20	   (							 ){set2(0,0,0);		}          	\
	void clear	   (							 ){set20(	);		}          	\
	void set2neg   (							 ){x=y=-1;			}          	\
	int	 isnneg	   (							 ){return (x>=0)&&(y>=0)&&(z>=0);} 	\
	int	 isneg 	   (							 ){return !isnneg();}          	\
	void set2	   (int x1, int y1, int z1 ){x=x1;y=y1;z=z1;		}			\
};// end of int4mcr

#define int4mcr(name, x, y, z, w) \
struct 	name { int x,y,z,w;                                           	   	\
		name (							 ){set20();						}	\
		name (int x1,int y1,int z1,int w1){set2 (x1,	y1,  z1,  w1);	}	\
	name&operator =(const name& r){set2(r.x,	r.y,  r.z, r.w);	return *this;}\
	name&operator+=(const name& r){set2(x+r.x,y+r.y,z+r.z,w+r.w);	return *this;}\
	name&operator-=(const name& r){set2(x-r.x,y-r.y,z-r.z,w+r.w);	return *this;}\
	name&operator*=(double t 		 ){set2(x*t,y*t, z*t, w*t);		return *this;}\
	name&operator/=(double t 		 ){set2(x/t,y/t, y/t, w/t);		return *this;}\
	name operator+ (const name& r){return name(x+r.x, y+r.y, z+r.z, w+r.w);	}	\
	name operator- (const name& r){return name(x-r.x, y-r.y, z-r.z, w-r.w);	}   \
	void set2	   (const name& r){set2(r.x, r.y, r.z, r.w);				}	\
	void set20	   (							 ){set2(0,0,0,0);			}   \
	void clear	   (							 ){set20();					}   \
	void set2neg   (							 ){x=y=-1;					}   \
	int	 isnneg	   (							 ){return (x>=0)&&(y>=0)&&(z>=0)&&(w>=0); }   \
	int	 isneg 	   (							 ){return !isnneg();		}   \
	void set2	   (int x1, int y1, int z1, int w1 ){x=x1;y=y1;z=z1;w=w1;	}	\
};// end of int4mcr



/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////



#endif //#ifndef DIBASE_CC



