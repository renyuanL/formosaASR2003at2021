
//
// file alldngsu.cpp
//

#ifndef ALLDNGSU_CPP
#define ALLDNGSU_CPP

#include <alldngsu.h>

int alldngsu_::
set2(char*s)
{
	spp.set2(s); spp.s0.inssep4hanlor("\t",1);//1 for hun gua-o
	str_replacepunct (spp.s0.s, ' ');//del punct here
	return spp.hun();
}


int alldngsu_::
emit (short* a, int size)
{
	static chars s; s.clear();
	for(int n=0; n<size; n++) {
		s.app(substr(a[n],a[n+1]) );
		s.app("\x01");
	}
	s.dellastbyte();
	//msgbox(s.s,"\n");
	if(dngsus.s0.s[0]) dngsus.app(" "); dngsus.app(s.s);
	return 1;
}


char* alldngsu_::
substr(int beg, int end)
{
	static chars s; s.clear();
	for(int i=beg; i<end; i++) s.app(spp[i]);
	return s.s;
}


int alldngsu_::
checkAll1suGood()
{
	for(int i=0; i<spp.size(); i++) if(!find(spp[i])) return 0;
	return 1;
}

int alldngsu_::
alldngsu()
{
	if( spp.size()<=0 ) return 0; 
	if(!checkAll1suGood()) return 0; chars s; 
	short* temp; temp=new short[spp.size()+3];
	short* a=temp+1;
	int index=0; a[index-1]=0;
	// a[index-1] is the end of pro-ed substr
	int w1=MAX;
	while(1) {
		if(w1>spp.size()-a[index-1]) w1=spp.size()-a[index-1];
		s.set2(substr(a[index-1],a[index-1]+w1));
		int found=find(s.s);
		if(!found) {
			w1--;
			if(w1) continue;
			else {
				w1=a[index-1]; if(a[0]==0) break;
				continue;
			}
		}else{
			a[index++]=a[index-1]+w1;w1=MAX;
			if(spp.size()-a[index-1]>0) continue;
			if(!emit(temp, index)) break; // so always start at 0

			int ndx=index;
			while((ndx>0)&&(a[ndx-1]-a[ndx-2]<=1)) ndx--;
			if(ndx<=0) break;
			a[ndx-1]--;
			index=ndx;
			w1=spp.size()-a[index-1]; 
			if(a[0]==0) break;
			continue;
		}
	}
	delete temp;
	dngsus.hun();
	for(int i=0; i<dngsus.size(); i++)
		str_replace(dngsus[i], '\x01', ' ');
	return dngsus.size();
}


#endif //#ifndef ALLDNGSU_CPP


#define ALLDNGSU_CPP_TEST
#ifdef  ALLDNGSU_CPP_TEST

r2ic3d_ riden("di5dqr2i.c3d");
alldngsu_ alldngsu(&riden);

static void output()
{
	for(int n=0; n<alldngsu.size(); n++) {
		msgbox(alldngsu.ithdngsu(n), "\n");
	}
	msgbox("\ndngsu size=",tos(alldngsu.size(),"%d\n"));
}

void main_alldngsu(int argc, char* argv[])
{
	//char s[]="�x�W�O�x�W�H���Ҧb.";
	//char s[]="�C�x,�W�I�O�СH�x�H���W���H�H���C�ҢI�b�C";
	char s[]="�C�x,�W�I�O�СH�x�H���W���H�H���C�ҢI�b�C";
	alldngsu.set2Nalldngsu(s);
	output();
}

#endif //#ifdef  ALLDNGSU_CPP_TEST

