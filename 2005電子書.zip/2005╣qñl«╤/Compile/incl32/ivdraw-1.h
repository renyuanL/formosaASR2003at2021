//
// file ivdraw.h
//

#ifndef IVDRAW_H
#define IVDRAW_H

#include <windows.h>
#include <chars.h>

static const nSLEN=1024;
class ivdrawetc_ { public:
			ivdrawetc_():heighttimes(1.8), qiqen('d'){setDEFshow();}
	HFONT 	uf, sf, lf; //upperfont, smallfont and largefong
	int			sfheight, lfheight;
  int 		lw; //linewidth
  double 	heighttimes; // def2 1.8
  int 		/*diauhing, pinim,*/ justify;
  char 		qiqen; // daiqi, kehqi, miaulik or huaqi 'd'/'k'/'m'/'h'
private:
  int  		showYIM, showVUN, showDH, show1D, showKQD, showSN;
public:
  void 	setDEFshow(){showYIM=showVUN=showDH=show1D=showKQD=showSN=1;}
  void 	set_yim(int yes) 			{ showYIM=yes; 	}
  void 	set_vun(int yes) 			{ showVUN=yes; 	}
  void 	set_diauhing(int n) 	{ showDH =n; 		}
  void	set_sn(int yes)				{ showSN =yes; 	}
  void  set_1diau(int yes)		{ show1D =yes;	}
  void	set_kauqidiau(int yes){ showKQD=yes; 	}
  void  tog_yim()							{ set_yim				(!showYIM); }
  void	tog_vun() 						{ set_vun				(!showVUN); }
  void	tog_diauhing()				{ set_diauhing	(!showDH);  }
  void	tog_sn()							{ set_sn 				(!showSN);  }
  void	tog_kauqidiau()				{ set_kauqidiau	(!showKQD); }
  void	tog_1diau()						{ set_1diau			(!show1D);	}
  int		getyim()							{ return (showYIM)?1:0; }
  int		getvun()							{ return (showVUN)?1:0; }
  int		getyimonly()					{ return ( showYIM)&&(!showVUN); 		 }
  int		getvunonly()					{ return (!showYIM)&&( showVUN); 		 }
  int 	getyimORvunonly()			{ return ((showYIM)&&( showVUN))?0:1;}
  int 	get_diauhing ()				{ return showDH; 		}
  int 	getdanridiau()				{ return !showKQD; 	}
  int 	getkauqidiau()				{ return showKQD; 	}
  int 	get_sn()							{ return showSN; 		}
  int		get_1diau()						{ return show1D;		}
public:
//  int 		yvidiau[11];
//  void setyvidiau(int fontsize);
public:
  int 		gapim, gapsu;
  void setgap(int fontsize)
  						{gapim=fontsize/5; gapsu=fontsize;	lw=(fontsize+4)/8;}
public:
  int  rowheight() { return int((lfheight+sfheight*getyim())*heighttimes); }
};


class ivdraw_ { public:
	ivdrawetc_ etc;
  HDC hdc;
  chars si, sv, si1; charspp sppi, sppv;
  chars iwork, vwork;
public:
  int nFIT; SIZE szi, szv;
  int ncumwidth0[nSLEN+2]; int *ncumwidth;
  int getwidth_su (char* vun, char* im);
  int getwidth_gu (char* vun, char* im);
public:
	int 	idqtransform(char* im); // transform im to iwork;
	int 	vdqtransform(char* im); // transform im to vwork;
  char* SStext		(char* t);
  char* NONSStext	(char* t);
public:
	int  textoutsu(         int selected, RECT rect, char* vun, char* im);
	int  textout  (HDC hdc1,int selected, RECT rect, char* vun, char* im);
  void drawdiau(HDC hdc,int x,int dx,int base,char c,char diau,
  							int selected,char qiqen);
public:
	int  vipos[nSLEN+2];
	int  isin(char c, char* in){while(*in)if(c==*in++)return 1;return 0;}
  int  is_aeiou(char c){static char s[]="aeiou";return isin(c,s);}
  int  is_mn   (char c){static char s[]="mn";   return isin(c,s);}
  void setvorim(char* im);
};

#endif //#ifndef IVDRAW_H

