#include <set>
#include <dir.h>
//#include <di5tcp.h>
#include <speechio.h>

struct fslen{chars f; int l;
	char*getfname()const{return f.getfname();}
};

struct less4fslen{static chars cs, lfn, rfn;
	bool operator()(const fslen& l, const fslen&r){
		lfn=l.getfname(); rfn=r.getfname();
		return (lfn<rfn);
	}
};

uint dir2chars__  (chars &ocs, char* pname, char* fname);
uint dir2flset__  (set<fslen, less4fslen>&flset, char* pname, char* fname,int prpnd_pname);
uint flist2flset__(set<fslen, less4fslen>&flset, char* dt, char* ext);


class 	mfcatter_ {
public: mfcatter_(){}
	//uint 	cat (char*s){return cat2(s);}
	uint	catdirsp	(char* pname);
	uint	catdidzc	(char* fname, char* pname, char* spextname, char iv_iusen);
	uint	testmfb		(char* fname=0);
public:
	uint 	cat2				(char*fname, char*panme=0);
	uint 	dir2flset		(char*pname, char*fname=0){return dir2flset__(flset,pname,fname,1);}
	uint 	flist2flset	(char*flist, char*ext  =0){return flist2flset__(flset,flist,ext);}
	uint	tml2flset		(chars& pn, chars& fn, char* spextname, chars& errmes);
	char*	flset2			(chars& cs);//ret cs.s
	int	 	flset2			(tyio&  io);
	int	 	flset2a			(tyio&  io);
	int		writesubfseq(tyio&	io);
	int	 	flset2dzbbsz();
	int		flset2seqbsz();
	int		catftime3(){return mfh.hasftime3();}
public:
	int  break2(char* pfname, char*srcfname);
public:
	set<fslen, less4fslen> 									 flset;
	typedef set<fslen, less4fslen>::iterator flitr;
	mfheader 	mfh;
	di53rd 		dzb;
	int				mffsize;
public:
	chars csset;
	qiimbuf_ qb;
	char*	dzb2(chars& cs);
};
extern mfcatter_ macat;
// using mfcatter is a 3 steps process:
// 1. collect subfile info using tml2flset, dir2flset or flist2flset
// 2. setting other info such as main-script, ftime3 etc
// 3. writing the mffile using cat2(outfilename);
//**********************************************************************
//**********************************************************************
//**********************************************************************

