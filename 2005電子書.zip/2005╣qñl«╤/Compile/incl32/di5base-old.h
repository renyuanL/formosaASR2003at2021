//
// dibase.h
//
// copyright 1994~2k Gang, IrngZin

#ifndef DIBASE_H
#define DIBASE_H

#ifdef FORCOMMENTONLY
  This collects (almost) all functions that proved useful
  _for writing daiim suriphuat and various utilities.
	The following classes are defined

	tos's
	class voids<simple_type>;
	//class sis_; extern sis_ sis; (string is)
	//class wis_; extern wis_ wis; (who is smaller)
	class chars;
	class charss;
	class charpp;
	class charspp;
	class tyio;
	class writer;
	class lreader;
	class inifname;
	struct szmioh;
	struct szmiohs;





#endif //#ifdef FORCOMMENTONLY


#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <conio.h>
#include <search.h>
//#include <memory>
#include <vector>
#include <algorithm>
using namespace std;

#pragma warning(disable:4786) //name too long for STL
#pragma warning(disable:4244) //double to float
#pragma warning(disable:4018) //signed/unsigned mismatch

const char ch01='\x01';
const char ch02='\x02';
const char ch03='\x03';
const char ch04='\x04';
const char ch05='\x05';
const char ch06='\x06';
const char ch07='\x07';
const char ch08='\x08';
const char ch09='\x09';
const char ch10='\x10';
const char chff='\xff';


typedef unsigned char  UCHAR;
typedef unsigned short USHORT;
typedef unsigned int   UINT;
typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned int   uint;
typedef unsigned int   WPARAM;

typedef const char  cchar;
#define OP					 operator
#define MBOKRET(x,y) {MessageBox(0,x,y,MB_OK);return;}
#define MBOKCNT(x,y) {MessageBox(0,x,y,MB_OK);continue;}
#define MBOKRETR(x,y,r) {MessageBox(0,x,y,MB_OK);return r;}
#define MBOKONLY(x,y) {MessageBox(0,x,y,MB_OK);}
#define CRFLRET(x) {MessageBox(0,x,"cannot create file",MB_OK);return;}
#define OPFLRET(x) {MessageBox(0,x,"cannot open file",MB_OK);return;}
#define CRFLRETR(x,r) {MessageBox(0,x,"cannot create file",MB_OK);return r;}
#define OPFLRETR(x,r) {MessageBox(0,x,"cannot open file",MB_OK);return r;}

//these are for bcb's common vcl's: Edit/CheckedBox/RadioBox
//inline template<class T> char* getText		(T*t				){return t->Text.c_str();}
//inline template<class T> void 	setText		(T*t,cchar*s){t->Text=s;}
//inline template<class T> bool  emptyText	(T*t				){return t->Text.IsEmpty();}
//inline template<class T> bool  Checked		(T*t				){return t->Checked;}
//inline template<class T> void  Checked		(T*t, bool b){t->Checked=b;}





extern char *tosfmtc,*tosfmts,*tosfmtuh,*tosfmtd,*tosfmth,*tosfmtld,*tosfmtf,*tosfmtlf;

inline void tos(char*s, char   v, char* fmt=tosfmtc ){ sprintf(s,fmt,v); }
inline void tos(char*s, char*  v, char* fmt      		){ sprintf(s,fmt,v); }
inline void tos(char*s, USHORT v, char* fmt=tosfmtuh){ sprintf(s,fmt,v); }
inline void tos(char*s, int    v, char* fmt=tosfmtd ){ sprintf(s,fmt,v); }
inline void tos(char*s, short  v, char* fmt=tosfmth ){ sprintf(s,fmt,v); }
inline void tos(char*s, long   v, char* fmt=tosfmtld){ sprintf(s,fmt,v); }
inline void tos(char*s, float  v, char* fmt=tosfmtf ){ sprintf(s,fmt,v); }
inline void tos(char*s, double v, char* fmt=tosfmtlf){ sprintf(s,fmt,v); }

char*ntos(char*  v, int   len      ); // copy at most len char's

char* tos(char   v, char* fmt=tosfmtc ); // r: result string[257]
char* tos(char*  v, char* fmt=tosfmts ); // r: result string[257]
char* tos(USHORT v, char* fmt=tosfmtuh); // r: result string[257]
char* tos(int    v, char* fmt=tosfmtd );
char* tos(short  v, char* fmt=tosfmth );
char* tos(long   v, char* fmt=tosfmtld);
char* tos(float  v, char* fmt=tosfmtf );
char* tos(double v, char* fmt=tosfmtlf);

inline int    s2i (cchar* s) { return atoi(s); }
inline long   s2l (cchar* s) { return atol(s); }
inline USHORT s2us(cchar* s) { return (USHORT)atoi(s); }
inline double s2f (cchar* s) { return atof(s); }
inline double s2d (cchar* s) { return atof(s); }

template<class T> // check and set t in limits [lo,hi]
void cslimit(T &t, const T&lo, const T& hi)
{
	if(lo>hi)return;
	if(t<lo) t=lo;
	if(hi<t) t=hi;
}
template<class T> // check t in limits [lo,hi]
int cklimit(T t, const T lo, const T hi)
{
	if((t<lo)||(hi<t)) return 0;
	return 1;
}

template<class T> // check and set t in limits [lo,hi]  // same as cslimit
void cslmt(T &t, const T&lo, const T& hi)
{
	if(lo>hi)return;
	if(t<lo) t=lo;
	if(hi<t) t=hi;
}
template<class T> // check t in limits [lo,hi] // same as cklimit
int cklmt(T t, const T lo, const T hi)
{
	if((t<lo)||(hi<t)) return 0;
	return 1;
}


template<class T> // check and set t in limits [lo,hi]
void csbe(T &t, const T&be, const T& en)
{
	if(be>en)return;
	if(t< be) t=be;
	if(t>=en) t=en;
}
template<class T> // check t in limits [lo,hi]
int ckbe(T t, const T be, const T en)
{
	if((t<be)||(en<=t)) return 0;
	return 1;
}

inline void icslimit(int& t, int lo, int hi){if(t<lo)t=lo;if(t>hi)t=hi;}
inline int  icklimit(int& t, int lo, int hi){return((t<lo)||(hi<t))?0:1;}

#define int2mcr(name, x, y) \
struct name { int x,y;                                                     \
			 name	 		 (							 ){set20();	}                            	 \
			 name	 		 (int x1, int y1 ){set2(x1,				y1);					}          \
	name&operator =(const name& rhs){set2(rhs.x,		rhs.y);		return *this;} \
	name&operator+=(const name& rhs){set2(x+rhs.x, 	y+rhs.y);	return *this;} \
	name&operator-=(const name& rhs){set2(x-rhs.x, 	y-rhs.y);	return *this;} \
	name&operator*=(double times	 ){set2(x*times,  y*times);	return *this;} \
	name&operator/=(double times	 ){set2(x/times,  y/times);	return *this;} \
	name operator+ (const name& rhs){return name(x+rhs.x, y+rhs.y);}         \
	name operator- (const name& rhs){return name(x-rhs.x, y-rhs.y);}         \
	void set2			 (const name& rhs){set2(rhs.x, rhs.y);					}          \
	void set20		 (							 ){set2(0,0);										}          \
	void clear		 (							 ){set20(	);										}          \
	void set2neg	 (							 ){x=y=-1;											}          \
	int	 isnneg		 (							 ){return (x>=0)&&(y>=0); 			}          \
	int	 isneg 	   (							 ){return !isnneg();			 			}          \
	void set2			 (int x1, int y1 ){x=x1;y=y1;										}          \
	void operator= (const SIZE& s  ){set2(s.cx,s.cy);							}          \
};

#define int3mcr(name, x, y, z) \
struct name { int x,y,z;                                                     	\
			 name	(							 			 ){set20();	}                            			\
			 name (int x1,int y1,int z1){set2(x1,			y1,     z1);					 }      \
	name&operator =(const name& r){set2(r.x,	r.y,  r.z);		return *this;}			\
	name&operator+=(const name& r){set2(x+r.x,y+r.y,z+r.z);	return *this;}			\
	name&operator-=(const name& r){set2(x-r.x,y-r.y,z-r.z);	return *this;}			\
	name&operator*=(double times ){set2(x*times,y*times, z*times);return *this;}\
	name&operator/=(double times ){set2(x/times,y/times, y/times);return *this;}\
	name operator+ (const name& r){return name(x+r.x, y+r.y, z+r.z);}     			\
	name operator- (const name& r){return name(x-r.x, y-r.y, z-r.z);}     			\
	void set2			 (const name& r){set2(r.x, r.y, r.z);							}						\
	void set20		 (							 ){set2(0,0,0);										}          	\
	void clear		 (							 ){set20(	);											}          	\
	void set2neg	 (							 ){x=y=-1;												}          	\
	int	 isnneg		 (							 ){return (x>=0)&&(y>=0)&&(z>=0);	}          	\
	int	 isneg 	   (							 ){return !isnneg();			 				}          	\
	void set2			 (int x1, int y1, int z1 ){x=x1;y=y1;z=z1;				}						\
};

#define int4mcr(name, x, y, z, w) \
struct name { int x,y,z,w;                                           	      	\
			 name	(													  ){set20();	}                    			\
			 name (int x1,int y1,int z1,int w1){set2(x1,	y1,  z1,  w1);					} \
	name&operator =(const name& r){set2(r.x,	r.y,  r.z, r.w);		return *this;}\
	name&operator+=(const name& r){set2(x+r.x,y+r.y,z+r.z,w+r.w);	return *this;}\
	name&operator-=(const name& r){set2(x-r.x,y-r.y,z-r.z,w+r.w);	return *this;}\
	name&operator*=(double t 		 ){set2(x*t,y*t, z*t, w*t);				return *this;}\
	name&operator/=(double t 		 ){set2(x/t,y/t, y/t, w/t);				return *this;}\
	name operator+ (const name& r){return name(x+r.x, y+r.y, z+r.z, w+r.w);	}		\
	name operator- (const name& r){return name(x-r.x, y-r.y, z-r.z, w-r.w);	}   \
	void set2			 (const name& r){set2(r.x, r.y, r.z, r.w);								}		\
	void set20		 (							 ){set2(0,0,0,0);													}   \
	void clear		 (							 ){set20();																}   \
	void set2neg	 (							 ){x=y=-1;																}   \
	int	 isnneg		 (							 ){return (x>=0)&&(y>=0)&&(z>=0)&&(w>=0); }   \
	int	 isneg 	   (							 ){return !isnneg();			 								}   \
	void set2			 (int x1, int y1, int z1, int w1 ){x=x1;y=y1;z=z1;w=w1;		}		\
};

struct charp2 { char *s1, *s2; charp2():s1(0),s2(0){}
charp2(char*p1, char*p2):s1(p1),s2(p2){}
};

//#ifndef MSGBOX_H
//#include <msgbox.h>
//#endif //#ifndef MSGBOX_H
/////////////////////////////////////
enum DI5MSG_MMODE {DI5MSG_MNULL, DI5MSG_MDOS, DI5MSG_MWIN, DI5MSG_MAUTO};
enum DI5NSG_DMODE {DI5MSG_DNULL, DI5MSG_DEBUG};   //up: MAUTO 2 MDOS/MWIN

class  messagebox_ {int mm, dm; // dm is currently not used
public:messagebox_():dm(DI5MSG_DNULL) {mmode_autoset();}
	void mmode_autoset();//set2 MDOS/MWIN 4 defined _CONSOLE or not
	void setmmode(int mmode) { mm=mmode; }
	void setdmode(int dmode) { dm=dmode; }
	char msg     (cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
public:// the fo3 works for DOS mode only, although will show msg
	char pause   (cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
	char ask4quit(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
	char ask4exit(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
};
extern messagebox_ msg;


//char pausebox  (cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);
//char messagebox(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0);

inline
char msgbox(cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.msg(s1,s2,s3,s4);}
inline
char pause (cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.pause(s1,s2,s3,s4);}

inline
char ask4quit (cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.ask4exit(s1,s2,s3,s4);}

inline
char ask4exit (cchar *s1=0, cchar *s2=0, cchar *s3=0, cchar* s4=0)
		{ return msg.ask4exit(s1,s2,s3,s4);}

#define VOIDRTN(x1)			{ x1; return  ; }
#define VALRTN(r,x1)		{ x1; return r; }
////////////////////////////////////////////////////

class stepmsg_ { public: int i, ntv; //ntv: interval
			stepmsg_(int ntv1=1000){i=0;ntv=ntv1;}
	void inc(); // increment and message if reach multiples of ntv
	void showfull(cchar*pre_str=0, cchar* post_str=0);
	void reset(int ntv1=1000){i=0;ntv=ntv1;}
	void operator++(int) { inc(); }
	int  operator()(   ) { return i; }
};
extern stepmsg_ stepmsg;


template<class T>
class voids { public:  int allocsize; short own;
	T*    a;   int   asz;
	void  init20() {a=0;asz=0;allocsize=0;own=0; }
public:
	int  resize(int size) { if(size<=allocsize)return 1;
													a=(T*)realloc(a,size*sizeof(T));
													if(a){own=1;allocsize=size; return 1;}
													init20();return 0; }
	int  nextsz(				) { if(allocsize<16)return 16;
													if(allocsize<=512)return 2*allocsize;
													return int(allocsize*1.1);}
public:
	T*  operator()(     )			{ return a;		}// or (variable name).s
	T&  operator[](int i)const{ return a[i];}// so no app thru this function
	T&  v					(int i)const{ return a[i];}// v: value
	int isgood		(int n)			{ return ( (n>=0)&&(n<size()) )?1:0; }
	int size			(     )			{	return asz; 			}
	T&	last			(     )			{ return a[asz-1];	}
	int push_back	( T t )			{ return app(t);		}
public:
	int app	( T t			 ){
												if(asz >= allocsize){if(!resize(nextsz())) return 0;}
												memset(&a[asz],0,sizeof(T));  a[asz++]=t;  return 1;}
	int ins	(T t, int n){
												if(!app(t))return 0; int i=size()-1;
												for(;i>n;i--)a[i]=a[i-1]; a[n]=t; return 1; }
  T   del	(int n		 ){ T orphan=a[n];  asz--;
												for(int s=n; s<asz; s++)a[s]=a[s+1];return orphan;}
  T   rm  (int n		 ){ T orphan=a[n];  asz--;
												for(int s=n; s<asz; s++)a[s]=a[s+1];return orphan;}
	void operator=(voids<T>& r){clear();for(int i=0;i<r.size();i++){app(r[i]);}}
public:
	//dn: should free each T, but that add complication, so only simple type
  void destroy()			{ if(own){ free(a); init20();} }
  voids(int size):a(0){ init20(); resize(size);}// resize will own mem
  voids(				):a(0){ init20(); 							}// resize will own mem
  void clear()				{ asz=0; }
	void reset()				{ asz=0; }
 ~voids()							{ destroy(); }
};


int		str_rbytes			(cchar* s);//r: 0 null; 2 hanzi; 1 others including ascii
int		str_lbytes			(cchar* s, int at);
inline int		is012		(cchar* s){return str_rbytes(s); }

inline int 	istabspace  (char c) { return (c=='\t'||c==' '); }
int 	isbig5punct (char*s); // is head big5punct
int 	is_tsrn(char c);//tab space \r \n

char* str_skipheadblank0   (char* s); //destructive to the array
inline char* str_skiptabsp    (char* s){return(istabspace(s[0]))?str_skipheadblank0(s):s;}
inline char* str_skiptabspace (char* s){return str_skiptabspace(s);}
int str_delfirstN			(char* s, int N);
int str_delleadspaces (char* s);
int str_deltrailspaces(char* s);
int str_delltspaces   (char* s);

int		str_isin(char c, char* s);
void	str_tolower			 (char* s);
int		str_all1byte (char* s);
int   str_alldigits(char* s);
int   str_hasdigit (char* s);
int   str_hashanri (char* s);
int		str_isorset  (char* s); // strict, true if is (...), and no l/t spaces
int		str_hasorset (char* s); // loose, true if has ( or ) or |
int   str_mayberi  (char* s);

int   str_isSS     (char* s); // slash slash at beg or at end
int   str_isSSEE   (char* s); // slash slash exclamation exclamation
int   str_isblank  (char* s); // is blank
int		str_isgline	 (char* s);
inline int		str_isrline	 (char* s){ return !str_isblank(s); }

int   str_isPBC    (char* s, char c1st, char clast, char c);
inline int   str_isP_P (char* s, char c=0) {return str_isPBC(s, '(', ')',c);}//(...c)
inline int   str_isB_B (char* s, char c=0) {return str_isPBC(s, '[', ']',c);}//[...c]
inline int   str_isC_C (char* s, char c=0) {return str_isPBC(s, '{', '}',c);}//{...c}

int		str_startwith(char* s, char* match, int N=-1);
int		str_endwith  (char* s, char* match, int N=-1);
int 	str_find1		 (char* s, char c); // r:-1 if not find
int 	str_findts	 (char* s);         // r:-1 if not find, ts: tabspace
int 	str_findnonts(char* s);         // r:-1 if not find
int 	str_findtsrn(char* s);//tab space \r \n
int 	str_findnontsrn(char* s); //tab space \r \n
int		str_find 		 (char* s, char* match, int N=-1);
//up1: r: startpos of match in s, 0-based		//simple match only

char* orset_1stoption1(char* src);
char* orset_1stoption (char* src);

char* str_search4				(char* s, char c);
char* str_search4crnl		(char* s);				//return null if not found
char* str_search4crORnl	(char* s, int* nbytes_returned);
int	str_countlet				(char* t);


// down:  return num replaced
int		str_replacepunct (char* s, char replacement=0);
int		str_replacedigits(char* s, char replacement=0);
void	str_replacewchar (char*s, char* rt, char r=0);
int		str_replace			 (char*s, char tobereplaced, char replacement=0);
int		str_trts				 (char* s, char ch2rep); // tr tab/space
inline int  str_tr		 (char*s, char tbr, char r=0){return str_replace(s,tbr,r);}
int 	str_nchar				 (char* s, char c);

inline void str_rmove  (char* s, int slen, int nbytes)
{  memmove(s+nbytes, s, slen+1); }
inline void str_overwrite(char* st, char* ss, int sslen)
{ memmove(st,ss, sslen);	}

int		str_ki2it		 		(char* s);  // destructive
void  str_deldigits		(char* s);  // destructive
void  str_delbutdigits(char* s);  // destructive
void  str_delbutpuncts(char* s);  // destructive
void  str_delbutpunctdigits(char* s);  // destructive
char* orset_1stoption	(char* src);//must bw'(', ew')',&no nested(), or ret src
/////******************************/////
void  str_del4wis  (char* s); //del digits and '-' but not leading digits
/////******************************/////
void  str_del4kauqidiau(char*s);
void  str_del4danridiau(char*s);
char* str_daiqibendiau (char*s);
void  str_kauqidiau_pos(char*s, voids<int> * p, int checksinglediau=0);
int   str_kauqidiau_pos(char*s, vector<int>& p, int checksinglediau=0);
int   str_danridiau_pos(char*s, vector<int>& p);
void  str_tokendelimpos(char*s, voids<int>* p);

int		str_is1stpi(char* pi, char* ri);
int		str_setpi_ri(char** pi, char** ri, char* s1, char* s2);

int upper			(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ
int lower			(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ
int bfind			(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ
int bfindlast	(char*s, char**dt, int N, int NSZ);//so sizeof(dt) is N*NSZ

// following 5 for binary search: key always on the left when wis is called
int __cdecl wislower (
				const void *key,
				const void *base,
        size_t num_elements,
        size_t width,
        int (__cdecl *wis)(const void *, const void *)
				);

int __cdecl wisupper (
        const void *key,
        const void *base,
				size_t num_elements,
        size_t width,
        int (__cdecl *wis)(const void *, const void *)
				);

int __cdecl wislower1 (
        const void *key,
        const void *base,
				size_t num_elements,
        size_t width,
				int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
        );

int __cdecl wisupper1 (
        const void *key,
        const void *base,
        size_t num_elements,
        size_t width,
        int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
        );

int __cdecl bfind ( // same as bsearch, return -1 if not found
				const void *key,
        const void *base,
				size_t numelem,
        size_t width,
        int (__cdecl *compare)(const void *, const void *)
        );


class wis_ { // who is smaller, -1 for left, 0 for eq, +1 for right
public:
static int pi		(const char** ll, const char** rr);
static int rdpi	(const char** ll, const char** rr);
static int pi		(const char*  ll, const char*  rr);//??
static int rdpi	(const char*  ll, const char*  rr);//??
static int hanzi(const char* l, const char * r)
	{return(l[0]==r[0])?(UCHAR(r[1])-UCHAR(l[1])):(UCHAR(r[0])-UCHAR(l[0]));}
public:
static int sNsp(const void*l, const void*r)
	{	return strcmp((char*)l, *((char**)r)); }
static int spNsp(const void*l, const void*r)
	{	return strcmp(*((char**)l), *((char**)r)); }
};
extern wis_ wis;




template<size_t NSZ> // node size, must > 4, where 4=sizeof(charnode*)
struct charnode{ charnode* next; char c[NSZ-4]; };

template<size_t NSZ, size_t PSZ>
class mpool {
public:
	void 	dllc(void*un1, size_t nsz1);
	void*	allc(					 size_t nsz1);
 ~mpool			() { dllc_pnodes(); }
	mpool			(): phead(0), uhead(0), psz(PSZ), nsz(NSZ) {}
private:
	typedef charnode<NSZ    > unode; size_t nsz; unode* uhead;
	typedef charnode<NSZ*PSZ> pnode; size_t psz; pnode* phead;
	void 		dllc_pnodes();
	int  		allc_pnodes();
};

class capool{ // char array pool
public:
	void 	dllc(void*p,size_t nsz){(nsz==64)? mp1.dllc(p,nsz):mp2.dllc(p,nsz);}
	char*	allc(size_t nsz){return(char*)((nsz==64)?mp1.allc(nsz):mp2.allc(nsz));}
public:
	size_t sz1() { return  64;}
	size_t sz2() { return 256;}
private:
	mpool< 64, 256> mp1;
	mpool<256,  64> mp2;
};

class pppool{ // char** array
public:
	void 	dllc(void*p,size_t nsz){mp.dllc(p,sizeof(char*)*nsz);}
	char**allc(			  size_t nsz){return(char**)mp.allc(sizeof(char*)*nsz);}
private:
	mpool<sizeof(char*)*24, 64> mp;
};

class chars;
class csspool{//chars* array
	void	dllc(void*p,size_t nsz){mp.dllc(p,sizeof(chars*)*nsz);}
	chars*allc(				size_t nsz){return(chars*)mp.allc(sizeof(chars*)*nsz);}
private:
	mpool<sizeof(chars*)*256, 8> mp;
};



template<size_t NSZ, size_t PSZ>
void
mpool<NSZ,PSZ>::
dllc_pnodes()
{
	pnode* pn;
	while(phead){
		pn=phead;
		phead=phead->next;
		free(pn);
	}
}

template<size_t NSZ, size_t PSZ>
int
mpool<NSZ,PSZ>::
allc_pnodes()
{
	pnode* pn=(pnode*)malloc(nsz*psz);
	if(!pn)return 0;
	pn->next=phead;phead=pn;
	unode* un; char* cs=(char*)pn; size_t i;
	for(i=0; i<psz;i++){
		un=(unode*)&(cs[i*nsz]);
		un->next=uhead; uhead=un;
	}
	return psz;
}

//inline
template<size_t NSZ, size_t PSZ>
void*
mpool<NSZ,PSZ>::
allc(size_t nsz1)
{
	if(nsz!=nsz1) return malloc(nsz1);
	if(!uhead){if(!allc_pnodes())return NULL;}
	unode* un=uhead;
	uhead=uhead->next;
	return (void*)un;
}

//inline
template<size_t NSZ, size_t PSZ>
void
mpool<NSZ,PSZ>::
dllc(void*un1, size_t nsz1)
{
	if(!un1) return;
	if(nsz!=nsz1) { free(un1); return; }
	unode* un=(unode*)un1;
	un->next=uhead;
	uhead=un;
}








class chars { public:
	char* s;		//chuli only one strings
	int 	asize;	// asize(alloc size) in sizeof(char)
	void 	init20() {s=0;asize=0;}
public:
	int  	resize(int size);
	int  	nextsize(int newsize=-1);
	void 	destroy()       { free(s); init20(); }
public:
	char* c_str()     { return s; }
	char* operator()(){ return s; } // or (variable name).s
	char& operator[](int i) { return s[i]; }
	char*	tosxa	 (char* ki, int begWspace=1);//tos to xml attribute: ki="..."
	int   hassome() { return ((s)&&s[0]);  }
	int		hasnone() { return  !hassome();  }
	int   isempty() { return  !hassome();  }
	int   isG    () { return isempty()?0:!(str_isSS(s)||str_isblank(s)); }
	int		isgline() { return str_isgline(s); }
	int   size   () { return strlen(s);   }
	int   usize  () { return charunits(); }
	int   charunits(); // in unit of echar and cchar, not in byte
public:
	chars()         :s(0){ init20(); resize(28);  clear(); }
	chars(int size) :s(0){ init20(); resize(size);clear(); }
	chars(char*s1)  :s(0){ init20(); set2(s1);}        // always own mem
	chars(const chars&ss){ init20(); set2full((chars*)&ss);}// always own mem
 ~chars()              { free(s); init20(); }
public:
	int		has 	(char c){ return str_find1(s, c)>=0; 	}
	int		hascnt(char c){ return str_nchar(s,c);			}
	int		nchar	(char c){ return str_nchar(s,c);			}
	int		find	(char c){ return str_find1(s, c); 		}
	int		find	(char c, int begfrom){ if(begfrom>=size()) return -1;int pos;
					pos=str_find1(s+begfrom, c); return (pos>=0)?begfrom+pos: -1; }
	int		has (char*sstr) { return str_find(s, sstr)>=0; }
	int		find(char*sstr) { return str_find(s, sstr); }
	int		find(char*sstr, int startfrom){ if(startfrom>=size())return -1;int pos;
					pos=str_find(s+startfrom, sstr); return (pos>=0)?startfrom+pos: -1; }
public:
	void cpy			(char*s1){ set2(s1);  		}
	void cat			(char*s1){ app (s1);  		}
	void catln		(char*s1){ appln(s1); 		}
	void catln		(				){ app("\r\n");		}
	void catexpand(char*s1){ appexpand(s1);	}
public:
	void set20 ()       {if(s)s[0]=0;else init20();}
	void clear ()       {set20();}
	int  set2  (const char*s1){if(!s1)return 0;int n=strlen(s1)+1;
														 if(resize(n)){strcpy(s,s1);return 1;} return 0;}
	int  set2  (const char*s1,int N){if(!s1)return 0;if(set2(s1)){if((int)strlen(s1)>N)s[N]=0;return 1;} return 0;}
	void set2full(const chars* p2s);
	int  set24fep(char* fname, char* ename, char* pname=NULL);
public:
	void app   (const char*s1){if((!s1)||(!s1[0]))return;
												int n=strlen(s1)+3; if(s)n+=strlen(s);
												resize(n); strcat(s,s1);
	}
	void app   (const char c ){ char s1[2];s1[1]=0;s1[0]=c; app(s1); }
	void app   (char*s1,int N){ if(N<=0) return; char c[2]=" ";c[0]=s1[N-1];s1[N-1]=0;app(s1);app(c); s1[N-1]=c[0]; }
	void app	 (cchar*s1,cchar*s2){app(s1);app(s2);}
public:
	void appsep(const char*s1,char c='\t'){char s[2]; s[1]=0; s[0]=c; app(s1); app(s); }
	void apptab(const char*s1){ app(s1); app("\t");		}
	void appln (const char*s1){ app(s1); app("\r\n"); }
	void apptab(char c) { app(c); apptab(); }
	void appln (char c) { app(c); appln (); }
	void apptab(	){ app("\t"); }
	void appln (	){ app("\r\n"); }
public:
	int  d1app(const char* s1);//app BYTE(strlen(s1)),then s1. No app if null
public:
	int goodat(int  at);
	int lbytes(int  at); // nbytes of character at left,  0 or 1 or 2
	int rbytes(int  at); // nbytes of character at right, 0 or 1 or 2
	int lbytes(int* at){return lbytes(*at);}
	int rbytes(int* at){return rbytes(*at);}
	int left  (int* at); // nbytes of character at left,  0 or 1 or 2
	int rite  (int* at); // nbytes of character at right, 0 or 1 or 2
	int ins(int* at, char c ) { static char s1[2]=" ";s1[0]=c; return ins(at,s1,1); }
	int ins(int* at, char*s1) { return ins(at,s1,strlen(s1)); }
	int ins(int* at, char*s1, int nbytes);
	int del(int* at); // del a character at right, 0 or 1 or 2
	int del(int* at, int nbytes);
  int del(int beg, int end) { static int b=beg; return del(&beg, end-beg); }
	int BS (int* at); // BS  a character at left,  0 or 1 or 2
	int BS (int* at, int nbytes);
	int tr(char tobereplaced, char replacement=0){ return str_replace(s,tobereplaced,replacement);}
	int trdigits(char replacement=0) { return str_replacedigits(s,replacement);}
public:
	int inssep4hanlor   (char* sep="\t", int hunguao=0);
	int inssep4tokenizer(char* sep="\t", int hunhanri=0);
	int inssep4012			(char* sep="\t");
public:
	int  dellastbyte ();
	void dellastdigit() { if(isdigit(lastbyte())) s[size()-1]=0; }
	char lastbyte    () { if(s[0]) return s[size()-1]; else return s[0]; }
	char bB 				 (){return s[0];}
	char eB					 (){return lastbyte();}
	void dellastdiauhor();
	//int	 lastNis(char* last);
	int	 delfirstN			(int N){return str_delfirstN(s,N);}
	int  dellastN 			(int N);
	int	 delb						(int N){return delfirstN(N);}
	int	 dele						(int N){return dellastN (N);}
	int	 delleadspaces 	(			){return str_delleadspaces	(s);}
	int	 deltrailspaces	(			){return str_deltrailspaces	(s);}
	int  delltspaces		(			){return str_delltspaces		(s);}
	int  dellts					(			){return str_delltspaces		(s);}
	void del4wis				(			){ str_del4wis(s); }
	void fstoption			(			);
	void tr4wis 				(			){fstoption();del4wis();}
	int	 is(char* str) 	{ return strcmp(s,str)==0; }
	int	 is(chars str) 	{ return is(str.s); }
	int	 isxtag (char* tg=0);
	int	 isxetag(char* tg=0);//empty tag, note can have attr
	int	 isxotag(char* tg=0);//open tag
	int	 isxctag(char* tg=0);//close tag
	int	 isxcomment();
	void appx		(char* tg, char*val=0, char sep='\t')
					 	 		{app(tg);app("=\"");app(val);app("\"");app(sep);}
	int	 isnl(); // is \r\n or \n only
	int  isorset(			)	{ return str_isorset(s); }
	int  startwith(char* match, int N=-1){return str_startwith(s,match,N);}
	int  endwith  (char* match, int N=-1){return str_endwith  (s,match,N);}
	int	 bw	(char* match, int N=-1) { return startwith(match,N); }
	int  ew (char* match, int N=-1) { return endwith  (match,N); }
	int  bw (char  c){char cs[2];cs[0]=c;cs[1]=0; return bw(cs); }
	int  ew (char  c){char cs[2];cs[0]=c;cs[1]=0; return ew(cs); }
public:
	void operator= (const char*   s1) { clear();set2((char*)s1  ); }
	void operator= (const chars&  s1) { clear();set2full((chars*)&s1);}
	void operator= (char           c) { clear();char s[2];s[0]=c;s[1]=0; app(s);}
	void operator= (unsigned short i) { clear();app(tos(i)); }
	void operator= (short          i) { clear();app(tos(i)); }
	void operator= (int            i) { clear();app(tos(i)); }
	void operator= (long           i) { clear();app(tos(i)); }
	void operator= (float          d) { clear();app(tos(d)); }
	void operator= (double         d) { clear();app(tos(d)); }
public:
	void operator+=(const chars   s1) { app((char*)(s1.s)); }
	void operator+=(const char*   s1) { app((char*)s1); }
	void operator+=(char           c) { char t[2];t[0]=c;t[1]=0;app(t);}
	void operator+=(unsigned short i) { app(tos(i)); }
	void operator+=(short          i) { app(tos(i)); }
	void operator+=(int            i) { app(tos(i)); }
	void operator+=(long           i) { app(tos(i)); }
	void operator+=(float          d) { app(tos(d)); }
	void operator+=(double         d) { app(tos(d)); }
public:
	void appexpand(char*s1){if((!s1)||(!s1[0]))return;int n=strlen(s1)+3;
										if(s)n+=strlen(s);resize(nextsize(n));strcat(s,s1);}
										//if(s)n+=strlen(s);own_copy_s(nextsize(n));strcat(s,s1);}
	int  expand()       {resize(nextsize());return asize;} // expand
	char*getfname(); // assume chars contains full path name
	char*getpname(); // assume chars contains full path name
  void appfname(char*fname); // append // if necessary
};
//up: use app    will save mem,
//up: use appexp will save time/fragmentation(realloc more mem at one time)
inline char* tos(chars s) { return tos(s.s); }
chars* getcharsbuf(); // return a chars from a pool

void str_auto_simple_bendiau(chars* im, int lastdanridiau=1);
typedef const chars cchars;
inline operator==(cchars& l, cchars& r){return strcmp(l.s,r.s)==0;}
inline operator!=(cchars& l, cchars& r){return strcmp(l.s,r.s);}
inline operator< (cchars& l, cchars& r){return strcmp(l.s,r.s)< 0;}
inline operator> (cchars& l, cchars& r){return strcmp(l.s,r.s)> 0;}
inline operator<=(cchars& l, cchars& r){return strcmp(l.s,r.s)<=0;}
inline operator>=(cchars& l, cchars& r){return strcmp(l.s,r.s)>=0;}

class charpp { 	public:
								char** pp; //chuli a group of strings
								int asize; short own; // asize in sizeof(char*)
								int sz; // num of valid char*
	void init20		(){pp=0;asize=0;sz=0;own=0; }
public:
	void resize		(int size);
	int  nextsize	(				 );
public:
	char** operator()	(				){ return pp; }
	char*  operator[]	(int i	){ return pp[i]; }
	char*  last				(				){ return pp[size()-1]; }
	int    inbound		(int i	){ return ((i>=0)&&(i<asize)); }
	int    size				(				){ return sz; }
	char*  tos				(char sep='\t');
public:
	charpp				(					):pp(0){ init20(); 												}
	charpp				(int size	):pp(0){ init20(); resize(size);					}
	charpp				(charpp&ss)	     { init20(); set2full((charpp*)&ss);}
 ~charpp				(					)      { destroy(); 											}
public:
	void operator=(charpp& pp		){ set2full((charpp*)&pp); }
	void set20		(							){ sz=0; }
	void clear		(							){ sz=0; }
	void destroy	(							){ if(own) free(pp); init20(); 			}
	void set2			(const char*s1){ set20(); app((char*)s1); }
	void set2full	(charpp* p2pp	);
	void app 			(char*s1			);
	int  expand		(							){ resize(nextsize());return asize; }
	int  startwith(cchar* str, int N=-1,int from=0);
	int  bw				(cchar* str, int N=-1,int from=0){return startwith(str,N,from);}
	char*part_bw	(cchar* str, int N=-1,int from=0); // bw: begin with
	int  delpart	(int i				);
	int  delparts_bw(cchar* str);
};

int chars_hunNlet  (charpp& pp,chars& ss, int N=10000);
int chars_hunNbohun(charpp& pp,chars& ss, int N=10000, char crnl_replacement=' ');
// last argument means the option that crnl will be replaced with
// use 0 if want to remove all /r /n
int chars_cut(charpp&pp, chars& s, char ch, int N=10000);


class charspp {public:
			charspp		() {}
			charspp		(charspp& spp){set2full((charspp*)&spp); }
		 ~charspp		(){destroy();}
								chars  s0;
								charpp pp0;
	void  clear		(){s0.clear();  pp0.sz=0; }
	void  reset		(){clear(); }
	int   size 		(){return pp0.size(); }
	void  destroy	(){s0.destroy();pp0.destroy();}
public:
	void  operator= (const char* s1 ){s0.set2		 ((char*)s1); }
	void  operator= (charspp&    spp){s0.set2full(&(spp.s0 ));pp0.set2full(&(spp.pp0 ));}
	void  set2full  (charspp*    spp){s0.set2full(&(spp->s0));pp0.set2full(&(spp->pp0));}
	void  set2			(const char* s1 ){s0.set2(s1);}
	int		insert 		(int n, cchar* s);// insert at n, (stl sense)
	int		insert 		(int n, char   c){char s[2]=" ";s[0]=c;return insert(n,s);}
	int   app     	(cchar* s				){return insert(size(), s); }
	int   delpart 	(int i					);//{return pp0.delpart(i); }
	int   delparts_bw		(const char* str);
	int   del4kauqidiau	();
	int 	del_kauqidiau	();
public:
	int		atpart (int ip, int toleft=1);
public:
	int   hun    (int N=10000,char crnlrep=' '){return chars_hunNbohun(pp0,s0,N,crnlrep);}
	int		hun1d	 (int N=10000									); // hun 1d str: (BYTE(strlen),str}...
	int		hun012 (int N=10000									){s0.inssep4012();	return hun(N); }
	int		cut		 (char ch, int N=10000				){return chars_cut(pp0, s0, ch, N);}
	int		cet		 (char ch, int N=10000				){return chars_cut(pp0, s0, ch, N);}
public:
	int   hunlet (int N=10000) { return chars_hunNlet(pp0, s0, N); }
	int   hunrlet(int N=10000); // rlet : non-empty line
	int   hunglet(int N=10000); // glet : non-enpty and not-commented by //
public:
	char* s					()      { return s0(); }
	char* operator()()      { return s0(); }
	char* operator[](int i) { return pp0[i];}
	int		inbnd			(int n) { return cklmt(n, 0, size()-1); }
	char* last			()			{ return pp0.last(); }
	char* toline		(char sep='\t'){ return toline(sep, 0, -1); }//-1 for upto last
	char* toline		(char sep, int beg, int end); // end==-1 for upto last
	char* tos				(char*sep, int beg, int end);
	char* tos				(char*sep){return tos(sep,0,size());}
	char* tos   		(char sep, int beg, int end){char s[]=" ";s[0]=sep;return tos(s,beg,end);}
	char* tos				(char sep='\t')							{return tos(sep,0, -1 );}
	char* rtos  		(char sep, int beg, int end); // reverse tos
	int  	startwith	(const char* str, int N=-1, int from=0){return pp0.bw(str,N,from);}
	char* part_bw		(const char* str, int N=-1){return pp0.part_bw(str, N); }
	int		is   			(int n, char*tt){return (strcmp(pp0[n],tt)==0);}
	int		isnot			(int n, char*tt){return (strcmp(pp0[n],tt)!=0);}
	int		bw	 			(int n, char*tt);//is part n bw tt?
	int		ew   			(int n, char*tt);//is part n ew tt?
public:
	int		set2trNhun			(cchar* str, char tobereplaced	 ) {set2(str);s0.tr(tobereplaced,' ');return hun();}
public:
	int   set2Ncut				(cchar* str, char ch, int N=10000) { s0.set2(str); return cut(ch, N); }
	int   set2Ncet				(cchar* str, char ch, int N=10000) { return set2Ncut(str, ch, N); }
public:
	int   set2Nhun				(cchar* str, int N=10000, char crnlrep=' ') { s0.set2(str); return hun(N,crnlrep); }
	int		set2Nhun1d			(cchar* str							){s0.set2(str);return hun1d(); }
	int		set2Nhun012			(cchar* str							){s0.set2(str);return hun012();}
	int   set2Nhungu			(cchar* str, int keeppunct=0, int N=10000 );
	int   set2Nhunlet			(cchar* str, int N=10000, char crnlrep=' ') { s0.set2(str); return chars_hunNlet(pp0,s0,N);}
	int   set2Nhunsls			(cchar* str							);//sls 4 soliong su, f.e. 53van
	int   set2Nhunplus		(cchar* str, int N=10000, char crnlrep=' ');
	int   set2Nhunpinim		(cchar* str, int N=10000, char crnlrep=' ',int keepdash=0);
	int   set2Nhunhanlor	(cchar* str, int N=10000, char crnlrep=' ',int keepdash=0);
	int   set2Nhunsentence(cchar* str, int N=10000 ){ return set2Nhungu(str,N); }
	int   set2Nhunorset		(cchar* str, int N=10000, char crnlrep=' ') { s0.set2(str); return hunorset(N,crnlrep); }
	int				 hunorset		(						 int N=10000, char crnlrep=' ');
};





class charss { public: voids<chars*> ss; //int sz;
public:
	charss(int size=10) 	{ ssresize(size); }
 ~charss()							{ destroy(); }
public:
	void ssdestroy		();
	void ssclear  		();
	void ssreset  		(){ ssclear(); }
	void clearcontent	();
	void destroy			(){	ssdestroy	(); }
	void clear				(){ ssclear		(); }
	void reset				(){ clear(); }
	int	 ssresize			(int newsize);
public:
	chars*	nth				(int n				)	{ return ss.a[n];										}
	char*		operator[](int n				) { return nth(n)->s; 								}
	int			size			(							)	{	return ss.size(); 								}
	char*		last			(							)	{ return (ss.a[size()-1])->s; 			}
	int			is   			(int n,char*tt) { return (strcmp(nth(n)->s,tt)==0);	}
	int			isnot			(int n,char*tt) { return (strcmp(nth(n)->s,tt)!=0);	}
	int 		push_back	(char* s			) { return app(s); 										}
	int 		app				(char* s			) { return insert(size(), s);					}
	int 		insert		(int n,char* s);// insert s at part n (stl sense)
	int			insert		(int n,char  c){char s[2]=" ";s[0]=c;return insert(n,s);}
	int 		del 			(int n);
public:
	int		set2	(charspp* spp, int beg=-1, int end=-1);
	int		set2	(int n, const chars* s) { return update(n,s->s,1);}
	int		set2	(int n, const chars& s) { return update(n,s.s, 1);}
	int		set2	(int n, const char * s) { return update(n,s,   1);}
	int		update(int n, const char * s, int expandss=0);
				//set2 the nth chars, expand if [n] not exist and expandss==1
public:
	char* tos		(char sep='\t'					 ){char s[]=" ";s[0]=sep;return tos(s,0,size());}
	char* tos		(char sep,int beg,int end){char s[]=" ";s[0]=sep;return tos(s,beg,end );}
	char* tos		(char*sep								 ){return tos(sep,0,size());}
	char* tos		(char*sep,int beg,int end);
public:
	int  	startwith(const char* str, int N=-1, int from=0);
	int  	bw			 (const char* str, int N=-1, int from=0){return startwith(str,N,from);}
public:
	int   set2Nhun				(cchar* str, int N=10000, char crnlrep=' ') { spp.set2Nhun			(str, N, crnlrep);  return set2(&spp); }
	int   set2Ncut				(cchar* str, char sep, int N=10000				) { spp.set2Ncut			(str, sep, N    );  return set2(&spp); }
	int   set2Nhungu			(cchar* str, int keeppunct=0, int N=10000 ) { spp.set2Nhungu		(str,keeppunct,N);  return set2(&spp); }
	int   set2Nhunlet			(cchar* str, int N=10000, char crnlrep=' ') { spp.set2Nhunlet		(str, N, crnlrep);  return set2(&spp); }
	int   set2Nhunplus		(cchar* str, int N=10000, char crnlrep=' ') { spp.set2Nhunplus		(str, N, crnlrep);  return set2(&spp); }
	int   set2Nhunpinim		(cchar* str, int N=10000, char crnlrep=' ', int keepdash=0) { spp.set2Nhunpinim	(str, N, crnlrep, keepdash);  return set2(&spp); }
	int   set2Nhunhanlor	(cchar* str, int N=10000, char crnlrep=' ', int keepdash=0) { spp.set2Nhunhanlor	(str, N, crnlrep, keepdash);  return set2(&spp); }
	int   set2Nhunorset		(cchar* str, int N=10000, char crnlrep=' ') { spp.set2Nhunorset	(str, N, crnlrep);	return set2(&spp); }
	int   set2Nhunsls			(cchar* str)							{ spp.set2Nhunsls(str);  return set2(&spp); }//sls 4 soliong su, f.e. 53van
	int   set2Nhunsentence(cchar* str, int N=10000 ){ spp.set2Nhunsentence(str, N);  return set2(&spp); }
private: charspp spp; chars cs;
};

class pairss: public charspp { int sorted;
public:
	pairss() { sorted=0; }
	static chars nulls;
	int	getndx   (char* lhs);//seq/bin get depends on sorted
	int    set   (char* lhs, char* rhs);//forced set
	int  reset   (char* lhs, char* rhs);
	int  resetset(char* lhs, char* rhs){if(!reset(lhs,rhs))set(lhs,rhs);return 1;}
	char*  get   (char* lhs);// { return (sorted)?bget():sget();}
	int  isend   (char* s) { return (s==nulls.s); }
	int  get2i   (char*lhs,int def=-1){char*t=get(lhs);return(t&&t[0])?s2i(t):def;}
	void qsort   ();
};


class 	echars { public: int ip; chars cs; int dirt, set2isd;// editable chars
public:	echars(int set2isdirty1=0):set2isd(set2isdirty1){ clear(); }
	void 	clear		(		)					{ cs.clear(); ip=0;	dirt=0;}
	void	cksetip	(		)					{ cslimit(ip,0,size());}
	void	setip		(int ip1)			{ ip=ip1;cslmt(ip,0,size());}
	int		set2(char*s,int ip1=0){cs=s;ip=ip1;dirt=(set2isd)?1:0;cslmt(ip,0,size());return cs.s?1:0;}
	int	 	ins	(char*s,int nB	 ){int ret=cs.ins(&ip,s,nB);	dirt=1; return ret;}
	int	 	ins			(char c	)			{int ret=cs.ins(&ip, c);		dirt=1; return ret;}
	int	 	ins			(char*s	)			{int ret=cs.ins(&ip, s);		dirt=1; return ret;}
	int	 	del			(				)			{int ret=cs.del(&ip); 			dirt=1; return ret;}
	int	 	del			(int nB	)			{int ret=cs.del(&ip, nB);		dirt=1; return ret;}
	int		BS 			(				)			{int ret=cs.BS(&ip);				dirt=1; return ret;}
	int		BS 			(int nB	)			{int ret=cs.BS(&ip,nB);			dirt=1; return ret;}
	int		left		(				)			{return cs.left(&ip);}
	int		rite		(				)			{return cs.rite(&ip);}
	int		home		(				)			{int r=(ip<=0)?0:1; ip=0; return r;}
	int		end 		(				)			{int r,sz=size();r=(ip>=sz)?0:1; ip=sz; return r;}
	char* OP()		(				)			{return cs.s;}
	int		size		(				)			{return cs.size();}
	int		isdirty	(				)			{return dirt;}
	int		at  		(				)			{return ip;}
	int		atb			(				)			{return ip<=0;}
	int		ate			(				)			{return ip>=size();}
	char	prevb		(				)			{return (ip>0)?*(cs.s+ip-1):0; 	}
	char	nextb		(				)			{return *(cs.s+ip); 						}
	char	prevb		(char c	)			{return prevb()==c;			 	}
	char	nextb		(char c	)			{return nextb()==c; 			}
	char* tos1 		(				)		{chars&s=*getcharsbuf();s.app(cs.s,ip);return s.s;}
	char* tos2 		(				)		{chars&s=*getcharsbuf();s.app(cs.s+ip);return s.s;}
	char* tosln(char sep=0)		{chars&s=*getcharsbuf();s.app(cs.s,ip);
															if(sep)s.app(sep);s.app(cs.s+ip);return s.s;}
	int		onchar	 (char   c);
	int		onkeydown(WPARAM w);
	int		dell_keep1tspace(); // del lead space, keep only 1 trail space if any
};



class istr4line {public:
  char* s; char*now;
	istr4line(char*  s1 ):s(0),now(0) {s=s1;now=s;} // will not own char*
  int hasmore() { return ((s)&&now[0]); }
public: // same as that in tyio8
  int  getline    (chars&buf); //get into outside resizable line recursively
  int  getsentence(chars&buf); // return num of bytes of the last punctuation
	//u2r:2 if juanhing,1 if buannhing,0 if not end with huhor(so check buf[0])
public:
	int  getrline(chars&buf); //rline: nonblank(real) line
	int  getgline(chars&buf); //gline: rline and not startting with //
};

class		curpath {
public:	curpath	():sz(0){init();}
void		init		();
char*	get 		(  int withbackslash=1);
char*	operator()(int withbackslash=1){return get(withbackslash);}
chars path; int sz;
};
char*	getexepath(int withbackslah=1);//actually startup path






void* new_pa(long size);
void 	delete_pa(void* pa);
int 	askOK4_file_overwrite(char*fname);

int tyjl_hunNbohun(char** ppt, char* ps, int N);

class tyio{ public:
	int hfile;
  int closable;
  void init_tyio0() { hfile=0; closable=0; }
  int  close();
public:
  tyio() { init_tyio0(); } // so that it will not be closed automatically
  tyio(tyio& io) { init_tyio0(); hfile=io.hfile;}
  tyio(char*fname,char*pname=0) { init_tyio0();open(fname,pname); }
 ~tyio() { if(closable) close(); }
  int operator ()() { return hfile;   }
	int isOK()        { return hfile;   }
  int isERR()       { return !isOK(); }
  int isOK(char* fname);
public:
	int open       (char* fname, int ioflag);
  int open       (char* fname, char *pname=NULL);
	int openMES    (char* fname, char* pname=NULL){return openERRMES(fname,pname);}
  int openERRMES (char* fname, char* pname=NULL);
	int openOWmes  (char* fname, char* pname=NULL, char* mes=NULL);
  int openNerr   (char* fname, char* pname=NULL, char* mes=NULL){return !openOWmes(fname,pname);}
	int open4append(char* fname, char *pname=NULL);
  int creat      (char* fname, int ioflag); // ioflag 0 for normal read/write
  int creat      (char* fname, char *pname=NULL);
  int creatMES   (char* fname, char *pname=NULL){return creatERRMES(fname,pname);}
  int creatERRMES(char* fname, char *pname=NULL);
public:
  int  exist   (char* fname, char* pname=NULL);
  long filesize();
  unsigned int read (void * p, unsigned int len);
  unsigned int write(void * p, unsigned int len);
  long rmoveto(long nbytes);//{return _llseek(hfile, nbytes, FILE_CURRENT);}
public: // dn: so sz must be long
	USHORT readsz (long* pl) { return (USHORT)read ( pl, sizeof(long)); }
  USHORT writesz(long  ll) { return (USHORT)write(&ll, sizeof(long)); }
  //char* readszblock (long* bsz_read_ED=0, int extra=0);//need to be castted
public: // binary write
  uint put( void  *p, uint len) { return write(p, len); }
  uint put( short *p) { return put(p, sizeof( short)); }
  uint put(ushort *p) { return put(p, sizeof(ushort)); }
  uint put( int   *p) { return put(p, sizeof( int)  ); }
  uint put(uint   *p) { return put(p, sizeof(uint)  ); }
	uint put(float  *p) { return put(p, sizeof(float) ); }
  uint put(double *p) { return put(p, sizeof(double)); }
  uint put(char   *p) { return put(p, strlen(p)     ); }
public: // binary read
  uint get( void  *p, uint len) { return read(p, len); }
	uint get( short *p) { return get(p, sizeof( short)); }
	uint get(ushort *p) { return get(p, sizeof(ushort)); }
	uint get( int   *p) { return get(p, sizeof( int)  ); }
  uint get(uint   *p) { return get(p, sizeof(uint)  ); }
  uint get(float  *p) { return get(p, sizeof(float) ); }
  uint get(double *p) { return get(p, sizeof(double)); }
  uint get(char   *p) { return get(p, strlen(p)     ); }
};


int  lread2gline(char*fn, charspp&buf, int appendit=0);
int  lread2rline(char*fn, charspp&buf, int appendit=0);
int  lread2line (char*fn, charspp&buf, int appendit=0);

class lreader: public tyio { public:
  int tbuflen; int deletable; int EOF_reached;
  char* tbuf;     //tbuf: new-ed to tbuflen size, seems speedup io
  void init_tbuf0(){ tbuflen=0;deletable=0;EOF_reached=0; tbuf=0; }
	int  init_tbuf(int buflength);
  int  del_tbuf();
  int  fill_tbuf();
  void move_tbuf(char* from);
public:
  lreader()                  { init_tbuf0();init_tbuf(136); }
  lreader(int buflength)     { init_tbuf0();init_tbuf(buflength); }
  lreader(char* fname,char* pname=NULL, int buflength=136) 
				 : tyio(fname,pname) { init_tbuf0();init_tbuf(buflength);}
  lreader(tyio &io)          { init_tbuf0();init_tbuf(136); init_tyio0(); hfile=io.hfile; }
	lreader(lreader &lr)       { init_tbuf0();tbuf=lr.tbuf;tbuflen=lr.tbuflen; hfile=lr.hfile;}
 ~lreader() { del_tbuf(); close(); }
public:
	//intopen (char* fname, char *pname=NULL){EOF_reached=0;return tyio:: open(fname,pname);}
	int  open (char* fname, char *pname=NULL);
  int  isEOF() { return EOF_reached&&(tbuf[0]==0); }
public:
	int  getline_rec    (chars&buf); //get into outside resizable line recursively
  int  getsentence_rec(chars&buf); //includes last huhor recursively
  //u2r:2 if juanhing,1 if buannhing,0 if not end with huhor(so check buf[0])
public:
  int  getline    (chars&buf) { buf.set20(); return getline_rec(buf);			}
  int  getsentence(chars&buf) { buf.set20(); return getsentence_rec(buf); }
  int  getrline		(chars&buf); //rline: nonblank(real) line
  int  getgline		(chars&buf); //gline: rline and not startting with //
public:
  //int  getline    (charspp&buf, int appendit=0);
  //int  getsentence(charspp&buf, int appendit=0);
  int  getrline		(charspp&buf, int appendit=0);
  int  getgline		(charspp&buf, int appendit=0);
	int  getall			(charspp&buf, int appendit=0);
};

typedef lreader linereader;

class writer : public tyio {
  char* f;  int   nlen;// just local
  char  t[137];
public:
	writer() {  }
 //~writer() {  } // close() should not be called automatically
public:
  unsigned int writestr(char* p) { return tyio::write(p, strlen(p));}
  unsigned int write   (char* p) { return writestr(p);	}
  unsigned int write   (void* p, int len) { return tyio::write(p, len);	}
  unsigned int writetab()        { return writestr("\t");			}
  unsigned int writetab(char* p) { nlen=writestr(p);return(nlen+writetab());}
  unsigned int writeln ()        { return writestr("\r\n"); }
  unsigned int writeln (char* p) { nlen=writestr(p);return(nlen+writeln());}
	unsigned int writeNbohun  (char** pps, int N, char* separator="\t");
  unsigned int writelnNbohun(char** pps, int N, char* separator="\t");
  unsigned int writecharpp  (charpp pp, char* separator="\t")
      { return writeNbohun  (pp.pp, pp.sz, separator);      }
	unsigned int writelncharpp(charpp pp, char* separator="\t")
      { return writelnNbohun(pp.pp, pp.sz, separator);      }
public:
  unsigned int out(char c)   { return tyio::write(&c,1); }
	unsigned int out(char* s)  { return writestr(s); }
  unsigned int out(int v, char* fmt=NULL)
			{ f=(fmt)?fmt:"%d";  sprintf(t,f,v); return out(t); }
  unsigned int out(long v, char* fmt=NULL)
			{ f=(fmt)?fmt:"%ld"; sprintf(t,f,v); return out(t); }
  unsigned int out(float v, char* fmt=NULL)
			{ f=(fmt)?fmt:"%f";  sprintf(t,f,v); return out(t); }
  unsigned int out(double v, char* fmt=NULL)
			{ f=(fmt)?fmt:"%lf"; sprintf(t,f,v); return out(t); }
public:
	unsigned int outtab()      { return tyio::write("\t",1); }
  unsigned int outtab(char c)  { nlen =out(c); return (nlen+ outtab()); }
  unsigned int outtab(char* s) { nlen =out(s); return (nlen+ outtab()); }
  unsigned int outtab(int v,   char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
	//unsigned int outtab(long v,  char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
  unsigned int outtab(float v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
  unsigned int outtab(double v,char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outtab());}
public:
  unsigned int outln()        { return out("\r\n"); }
  unsigned int outln(char c)  { nlen =out(c); return (nlen+ outln()); }
  unsigned int outln(char* s) { nlen =out(s); return (nlen+ outln()); }
  unsigned int outln(int v,   char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
  //unsigned int outln(long v,  char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
  unsigned int outln(float v, char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
	unsigned int outln(double v,char* fmt=NULL){ nlen=out(v,fmt); return (nlen+outln());}
};

int spp_hunattr(charspp& spp, char* data=0);
// makes a str of the form att="something" att2="2" into
// spp[0] contains att, and spp[1] contains something and so on

extern char* xmlline1alone;
class  	tcpreader;

class  	xmltag { public:int mpt; chars tg; charspp as; // tag and attributes
				xmltag		(char*data=0){mpt=0;if(data)set2(data);}
			 ~xmltag 		(						){destroy();}
	void	destroy		(						){mpt=0;tg.destroy();as.destroy();}
	int  	read			(tcpreader& r				); //read2 tg
	int		set2Nhun	(const char* data		);
	int		hun 			(const char* data=0	);
	char* tag 			(						)	{return tg.s;}
	int		tis				(cchar* tag	);// tag is
	char* operator()(						){return tg.s;}
	char* operator[](cchar*att	); //return value for the given att
	char* operator[](int  i  		){return as[2*i+1];}//return value for i-th att
	char*	nth0			(int  n			){return as[n];		 }
	int		hasattr		(cchar*att	);
	int		size			(							){return as.size()/2; 	}
	int		set2			(char*data		){return tg.set2(data);}
	int		settag		(char* tagname){tg=tagname;return 1;}
	void	setmpttag	(int mpt1=1		){mpt=mpt1;}
	char* tos 			(char sep='\t');
	char* tos 			(charspp& spp, char sep='\t');
};

class		xmltagrw {public:int mpt; chars tg; charss as;//tag and attributes, r/w version
				xmltagrw	(char*data=0){mpt=0;if(data)set2(data);}
			 ~xmltagrw 	()		{destroy();}
	void	destroy		()		{mpt=0;tg.destroy();as.destroy();}
	void	clear			()    {mpt=0;tg.clear();as.clear(); }
	int  	read			(tcpreader& r			); //read2 tg
	int		set2Nhun	(const char* data	){tg.set2(data);return hun();}
	int		hun 			(char* data=0			);
	char* tag 			(									){return tg.s;}
	int		tis				(cchar* tag				); // tag is
	char* operator()(									){return tg.s;}
	char* operator[](char*att					);//return value for the given att
	char* operator[](int  i  					){return as[2*i+1];}//ret ith att value
	char*	nth0			(int  n						){return as[n];		 }
	int		att2ith		(char*att					);
	int		hasattr		(cchar*att				);
	int		size			(									){return as.size()/2; 	}
	int		settag		(char* tagname		){tg=tagname;return 1;}
	void	setmpttag	(int mpt1=1				){mpt=mpt1;}
	int		set2			(char*data				){return tg.set2(data);}
	int		set2			(char*ki, char*val);
	int		app 			(char*ki, char*val);
	char* tos 			(char sep='\t'		);
	char* tos 			(charspp& spp, char sep='\t');
};

class  	tcpreader :public lreader {	int kplnbr; int lnnow;
																		chars fn,pn,en;chars nxttmp, nxtln;
public:	tcpreader(int keeplnbr=1):kplnbr(keeplnbr){}
				tcpreader(char*fname,char*pname=0,int keeplnbr=1)
														:kplnbr(keeplnbr){if(fname)open(fname,pname);}
	void  setkeeplnbr	(int keep) { kplnbr=keep; }
	int		open				(char*fname=0,char*pname=0){fn=fname;pn=pname; lnnow=0;
																					return lreader::open(fname,pname);}
	int		skip2root		(char* rootname);//return 0 if rootname not match
public:
	int  	isEOF				(){ return ( lreader::isEOF()&&(nxtln[0]==0) ); }
	char* next				();
	int		skip				()						{return skipnext(			 );}
	int		skipnext		()						{return getnext	(nxttmp);}
	int		nisotag			(char* tag=0);
	int		nisctag			(char* tag=0);
	int		nistag			(char* tag=0);
	int		nisln	 			();
	int		nisdata			();
	int		niscommand	();
	int		linenow			(){ return lnnow; }
public:
	int		nextistag		(					){return nistag();		}
	int		nextistag		(char* tag){return nistag(tag);	}
	int		getnext			(chars& cs,int keepSB=1);
	int		matchedtag	(char *btag, char *etag);
	int		matchedtag	(chars&btag, chars&etag){return matchedtag(btag.s,etag.s);}
	int		getnexttag	(chars& cs,int keepSB=1){return getnexttag0(cs,keepSB);}
private:
	int		sametoken		(char* tocheck, char* token);
	int		getnextdta0	(chars& cs);
	int		getnexttag0	(chars& cs, int keppSB=1);
	int		getlnbuf		(chars& cs);
	void  testread		();
	void  testread0		(){}
	void  testdel			();
};

class  ze2he { public:char**dt; int N, NSZ; chars s0;
	ze2he(char**data1, int N1, int NSZ1):dt(data1),N(N1),NSZ(NSZ1){s0=" ";s0="";}
	int  bfind    (char* s){return ::bfind(s,dt,N,NSZ);}
	int  bfindlast(char* s){return ::bfindlast(s,dt,N,NSZ);}
	int  lower    (char* s){return ::lower(s,dt,N,NSZ);}
	int  upper    (char* s){return ::upper(s,dt,N,NSZ);}
	char*d0       (int   n       ){return dt[n*N  ];}
	char*d1       (int   n       ){return dt[n*N+1];}
	char*dk       (int   n, int k){return dt[n*N+k];}
	char*d1       (char* s){int n=bfind(s);return (n<0)?s0.s:dt[n*N+1];}
	char*dk       (char* s, int k){int n=bfind(s);return (n<0)?s0.s:dt[n*N+k];}
};


class config_ { public: xmltagrw tg; chars curdir; int loadOK;
			config_			(			){tg.setmpttag(1);loadOK=0;}
	int 	load			(char* fname				);
	int 	save			(char* fname				);
	int		set2			(char* key, char*val){return tg.set2(key,val);	}
	int		app				(char* key, char*val){return tg.app (key,val);	}
	char* operator[](char* att					){return tg[att];						}
	int		set2Nhun	(char* proto				){return tg.set2Nhun(proto);}
	void	getcurpath(										){curdir=getexepath();			}
};





class madis { //main_arg, dir, ini, script
public:
	madis() :argcini(0), argvini(NULL){ VTIinit(); }
  madis(int argcini1, char* argvini1[]) { initini(argcini1, argvini1); }
	int err(int i){return 0;}
	//typedef map<string, string, less<string> > maps2;
	//typedef maps2::iterator itr;
  //maps2 s2s;
	pairss s2s; //could have used:map<string, string, less<string> >
	chars ss;
public:
	virtual int VTIinit() { return 0; }
	void qsort  () { s2s.qsort(); }
	int reset	  (char* lhs, char* rhs)	{return s2s.reset   (lhs,rhs);}
	int 	set	  (char* lhs, char* rhs)	{return s2s.  set   (lhs,rhs);}
	int resetset(char* lhs, char* rhs)	{return s2s.resetset(lhs,rhs);}
	char* get	  (char* lhs)							{return s2s.  get   (lhs    );}
  int		get2i (char*lhs,int idef=-999999) { char*t=get(lhs);
  													return(t&&t[0])?s2i(t):idef; }
public:
	int readscp (char* scpfname);
	int getdirs (); // get various dir
	int setmarg (int argc, char* argv[]);
public:
	int argcini; char** argvini;
  int   initini(int argcini1, char* argvini1[]);
  virtual int VTIwriteini(writer& w) { return 0; }
  int		writepairln(writer&w, char* lhs){if(writepair(w,lhs))w.writeln("");return 1;}
  int		writepair  (writer&w, char* lhs);
	int 	writeiniVTI(char* inifname=NULL);// use inifname in readini
	int 	writeini   (char* inifname=NULL);// use those in argvini
	int 	readini		 (char* inifname);
	char* getinifname(					){return get("inifname");}
  void	setcomment (char*  rhs){if(rhs)set("startcomment",rhs);}
  char* getcomment (					){return get("startcomment"); }
};



class mainarg_ { char fg[64]; chars av[64];  int ac,forhelp,err;
int	ndx(char c){if(isdigit(c))return c-'0';if(isupper(c))return c-'A'+10;
								if(islower(c))return c-'a'+36; 
								return (c=='?')?62:63; }
public:
	void	clear() {err=forhelp=ac=0; for(int n=0;n<64;n++){fg[n]=0;av[n].clear();}}
	virtual int preset  () { return 1; }// called before set(argc, argv);
	int		set       (int argc, char* argv[]);
	int		set2      (int argc, char* argv[]){return set(argc,argv);}
	int		set1			(char c, char* v);
	void	reset1		(char c) { fg[ndx(c)]=0; av[ndx(c)]=""; }
	int		is4help		(			 ) { return forhelp;			}
	char* argv			(char c) { return av[ndx(c)].s; }
	char* v					(char c) { return av[ndx(c)].s; }
	int		flag			(char c) { return fg[ndx(c)];	}
	int		argc			(			 ) { return ac;						}
	char* operator()(char c) { return argv(c);			}
};

class lastfname_ : public lreader { public:
      lastfname_ (char* iniprofname1, char* comment1=NULL){clear();iniprofname.set2(iniprofname1);comment.set2(comment1); startup();}
		 ~lastfname_ () { cleanup(); }
  chars iniprofname, comment, ifnlast;
  void  clear()   { iniprofname.clear(); comment.clear(); ifnlast.clear(); }
  void  openpro(char* fnn) { open(fnn); pro(); }
  void  startup() { openpro(iniprofname.s); }
  void  cleanup() { write(iniprofname.s, comment.s); }
	void  set2lastname (char* ifnlast1) { ifnlast.set2( ifnlast1 ); }
  char* lastname  () { return ifnlast.s; }
  int   iniGD     () { return ifnlast.hassome(); }
public:
  int   pro(){  if(!isOK()) return 0;  chars s;
          while(getgline(s)){
						if( s()[1]=='=' && s()[0]=='i' ) { ifnlast.set2(s()+2); continue; }
          }return 1;
        }
  void  write(char* ofname, char* comment=0) { if(!ofname) return;
             writer w; w.creat(ofname); if(w.isERR()) return;
             if(comment){
               if( (comment[0]!='/')||(comment[1]!='/') )w.out("//");
               w.outln(comment);
						 }
             if(ifnlast.hassome()) { w.out("i="); w.outln(ifnlast.s); }
        }
};


int	 	csfname4play1daiqi(chars& cs); 													// check/set
int	 	csfname4play1daiqi(chars& cs, char* ext); 							// check/set
int	 	csfname4play1daiqi(chars& cs, float& emph); 						// check/set
int	 	csfname4play1daiqi(chars& cs, char* ext, float& emph); 	// check/set



template<int fixsz, int bufsz>
class fixmac { //fixsize malloc fixsz must be >=sizeof(pointer)
	struct bufnode{ bufnode(){next=0;} bufnode* next; char c[bufsz*fixsz];};
	struct fixnode{ fixnode(){next=0;} fixnode* next; };
	bufnode* bhead; fixnode* fhead;
	void freebuf () { bufnode* bn; while(bhead){bn=bhead;bhead=bhead->next;free(bn);}}
	int  allocbuf() { bufnode* bn=(bufnode*)malloc(sizeof(bufnode)); if(!bn)return 0;
				bn->next=bhead;bhead=bn; for(int i=0; i<bufsz;i++)put(&(bn->c[fixsz*i]));
				return bufsz;
	}
public:
 ~fixmac() { freebuf(); }
	fixmac(): bhead(0), fhead(0) {}
	void put(void*fnode){fixnode* fn=(fixnode*)fnode;fn->next=fhead;fhead=fn;}
	void*get(){if(!fhead)	{	if(!allocbuf())				return NULL;			}
									fixnode* fn=fhead;fhead=fhead->next;return (void*)fn;
	}
};







#define diTS_UNDERLINE        1
#define diTS_UNDERLINERED     2
#define diTS_UNDERLINEDOT     3
#define diTS_UNDERLINEDASH    4
#define diTS_SUPERSCRIPT      11
#define diTS_SUBSCRIPT				12
#define diTS_GRAYTEXT					13
#define LM_USED 1

struct szmio { long sz; char* pm; // sz is byte-size(bsz) // a nice handy structure
			 szmio(): sz(0),pm(0) {}
		//~szmio() { }//del(); }
	int   write(tyio& io, long size) {io.writesz(size);
										return 4+io.write(pm,size);}
	char* read(tyio& io, int szdef=-1){long res=io.readsz(&sz);
							if(res!=(long)sizeof(long)){ sz=0; return 0; }
							if(szdef>=0) if(sz!=szdef) {sz=0; return 0; }
							pm=new2(sz,0);	res=io.read(pm, sz); sz=res; return pm;}
//	char* read(tyio& io, int extra=0){long res=io.readsz(&sz);
//							if(res!=(long)sizeof(long)){ sz=0; return 0; }
//							pm=new2(sz,extra);	res=io.read(pm, sz); sz=res; return pm;}
	void  destroy()    { del(); }
	long  peeksz(tyio& io)
	{long res=io.readsz(&sz);io.rmoveto(-(long)sizeof(long)); return sz; }
	long  size()       { return sz; }
	long	bszasinhdr(); //treat pm as hdr_, return the bsz
	char* operator()() { return pm; }
	void  del(); // reverse of new2
	char* new2(long bsize, int extra=0);
	int		isOK() { return pm!=0; }
};

struct  szmiohs { static int hdrbsz;
			 ~szmiohs(){del();}
	szmio h, s;
	int read (tyio& io) { int bsz;
												bsz=hdrbsz;
												if(!h.read(io, bsz)) return 0;
												bsz=h.bszasinhdr();
												if(!s.read(io, bsz)) return 0;
												return (h.sz+s.sz+8);
											}
	int write(tyio& io) {
												h.write(io,h.sz);
												s.write(io,s.sz);
												return(h.sz+s.sz+8);
											}
	void del() { h.del(); s.del(); }
};


enum rdkind {DIRD_NRK, DIRD_NIT, DIRD_DZB, DIRD_DZB3, DIRD_LAIVE, DIRD_C1SU};
enum dikey	{DIRDKEY_IM, DIRDKEY_RI };


struct rdhdr53 { // riden header, note: sizeof(di51rdhdr) is 28, different from previous version 32
	long 		asz;		// size of data in unit of usize (array size)
	long 		bsz;		// size of data in unit of byte  (array size in bytes)
	long 		usz;		// size of each unit, 0 if not const
	char 		idf[7];
	char 		frq; // has frq or not
	char 		qqn,key,col,knd;//qiqen(d/k/h),key(dikey),col(1/2/3),kind(rdkind)
	USHORT 	vM;
	USHORT 	vm;
public:
	rdhdr53					(							 ){setidfv(); setabu(0,0,0); idf[0]=0; 	}
	void 	setidfier (char*s,int n=7){if(n>7)n=7;strncpy(idf,s,n); 				}
	void 	getidfier (char*s        ){strncpy(s,idf,7);s[7]=0; 						}
	void 	peekidfier(tyio& r,char*s){peek(r); getidfier(s);								}
	void 	peek			(tyio& r 			 ){int i; r.read(&i,4); read(r);
																r.rmoveto(-(long)(sizeof(int)+sizeof(*this)));}
	char*	idfier		( ){return idf;}
	void 	setidfv	 	( ){setidfier("dif");vM=5;vm=3;}
	void 	setv	 		(ushort M=5, ushort m=3 ){vM=M;vm=m;}
	void 	setabu		(long asiz,long bsiz,long usiz)
										{asz=asiz; bsz=bsiz; usz=usiz; }
	void 	setfqkck	(char freq,char qiqen, char key1, char c2c3, char kind)
										{frq=freq; qqn=qiqen; key=key1; col=c2c3; knd=kind; }
	long  read		 	(tyio& r){return r.read (this, sizeof(*this));}
	long  write		 	(tyio& w){return w.write(this, sizeof(*this));}
};
typedef rdhdr53 rdhdr;

struct rikive { char r[2]; ushort k; // cutri and ripkive
			 rikive ( char* r1,  int k1 ) { r[0]=r1[0]; r[1]=r1[1]; k=(ushort)k1;}
			 rikive ( )		{ r[0]=r[1]=0; k=0; }
	int  ishanri( )	{ return (r[0])&&(r[0]!='*'); }
	int  isgood ( ) { return (r[0]&&k); }
};

struct dilaive { ushort n;
			 dilaive ( ushort n1=0 ) : n(n1) { }
			 dilaive ( int    n1   ) : n((ushort)n1) { }
			 void operator=(dilaive& r) { n=r.n; }
};


int __cdecl wisdirikive(const void* l, const void* r);
int __cdecl wisc1su(const void* l, const void* r);


class dilaives {
	rikive* rkvs; int nRKVS;
	char* kis; int nKIS; int kilen;
	tyio    io;   szmiohs mmrkv, mmki;
public:
 ~dilaives() {del();}
	void del() { mmrkv.del(); mmki.del(); }
	int read(tyio& r ){del();mmrkv.read(r);mmki.read(r);afterread(); return 1; }
	int read(char* fn){if(!io.open(fn))return 0;int r=read(io);io.close();return r;}
	int afterread();
	int isOK(){return (kis&&rkvs); }
public:
	char* ki		( int n) { dilaive nn=n;return ki  (nn); }
	char* ki0		( int n) { dilaive nn=n;return ki0 (nn); }
	char* ri		( int n) { dilaive nn=n;return ri  (nn); }
	char* line	( int n) { dilaive nn=n;return line(nn); }
public:
	char* ki		( dilaive& n);
	char* ki0		( dilaive& n);
	char* ri		( dilaive& n);
	char* line	( dilaive& n);
public:
	char* ri		(dilaive*a, int K, char sep=0		);
	char* ki		(dilaive*a, int K, char sep='-'	);
	char* ki0		(dilaive*a, int K, char sep=0		);
	char* line	(dilaive*a, int K, char sep='\t');
	char* it		(dilaive*a, int K) { return imtau(a,K); }
	char* imtau	(dilaive*a, int K);
public: // for building other suden
	rikive  torikive(cchar* ri, cchar* ki); // works for 1 ri/ki
	int   	ndx 	(cchar* ri, cchar* ki); 	// works for 1 ri/ki
	int			kindx (cchar* ki);							// works for 1 ri/ki
};

struct dilaivesNxtr { dilaives* lv; int usz; int K; };

class di53rd_;
struct di5wis_ { static chars ll, rr;
	static	int byki0		(const void*l, const void*r)
	{
		ll.set2(  (char* )l ); str_del4wis(ll.s);
		rr.set2(*((char**)r)); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static	int byki		(const void*l, const void*r)
	{
		rr.set2(*((char**)r));
		return strcmp((char*)l,rr());
	}
	static	int byki0f	 (const void*l, const void*r)
	{
		ll.set2(    (char* )l );     str_del4wis(ll.s);
		rr.set2( (*((char**)r))+5 ); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static	int bykif		(const void*l, const void*r)
	{
		rr.set2(*((char**)r)+5);
		return strcmp((char*)l,rr());
	}
public:
	static int nrK(const void*l, const void*r, dilaivesNxtr* lvx);
	static int nit(const void*l, const void*r, di53rd_* 			rd);
};
extern di5wis_ di5wis;

int pfit1vun  (const char* kiin, const char* rr);
int pfit1py(const char* kiin, const char* rr, int mustfit_diau);
	//pfit1:partial fit, assuem ll is kiin, and shorter
	// r: #bytes in ll that is partially used by rr



struct LMU { int l, m, u;
	int 	nff(){return m-l;}// full fit
	int 	npf(){return u-m;}// partial fit
	void	clear() { l=m=u=0; }
};

struct LU	 { int l, u;
	int 	nf (){return u-l;}//fit
	void	clear() { l=u=0; }
};

struct IDLMU { int id, l, m, u; };
struct IDLU	 { int id, l, u; 		};

class di53rd_ { public:
	dilaivesNxtr 	lvx;
	di53rd_* 			base4nit;   int K;
	void setlv(dilaives* lv1){lvx.lv=lv1; lvx.K=K; lvx.usz=hd_->usz;}
	void setrd(di53rd_* rd){base4nit=rd;}
protected:
	tyio    io;   szmiohs mm;
	rdhdr* 	hd_;  void*   dt_;
	short 	id;  	char 		s4null[4];
	chars 	cs1;
protected: // for dzb, dst_ is alloc-ed
	char**  dst_;
	int 		jumpbyte;
	int 		hsd2, hsd3, hsd4, hsd5;
	void 	setinnr();
	int		cols_is() { return (hd_->col)-'0'; }
protected:
	int (__cdecl *wis ) (const void *, const void *);
	int (__cdecl *wisx) (const void *, const void *, const void*);
protected:
	char* smd(char* s) { static chars ss; if(hd_->key!='i') return s;
												ss=s; str_del4wis(ss.s);return ss.s;}
public:
	int lower(char*s);
	int upper(char*s);
	int	lu	 (char*s, int*l, int*u);
	int lmu  (char*s, int*l, int*m, int*u); //r: nonsense
	LU  lu	 (char*s){LU  r;lu (s,&(r.l),&(r.u));return r;}
	LMU lmu	 (char*s){LMU r;lmu(s,&(r.l),&(r.m),&(r.u));return r;}
public:
	di53rd_()				 : hd_(0),wis(di5wis.byki0) {s4null[0]=0; }
	di53rd_(char* fn): hd_(0),wis(di5wis.byki0) {s4null[0]=0; read(fn); }
 ~di53rd_(){del();}
public:
	void 	del() { mm.del(); }
	int 	read(tyio& r ){int rs;del();rs=mm.read(r);if(rs)afterread();return rs;}
	int 	read(char* fn){if(!io.open(fn))return 0;int rs=read(io);io.close();return rs;}
	int 	afterread();
public:
	int	hasd2()		{ return hsd2; }
	int	hasd3()		{ return hsd3; }
	int	hasd4()		{ return hsd4; }
	int	hasd5()		{ return hsd5; }
	int hasfreq() { return hd_->frq; }
	int isnit();
public:
	int	 	isOK	() { return (int)hd_; }
	int 	size  () { return (uint)(hd_->asz);			}
	int		maxri	() { return 5; }
	char 	key   () { return hd_->key; }
	char 	qiqien() { return hd_->qqn; }
	char 	luibet() { return hd_->knd; }
	char 	lb		() { return hd_->knd; }
	int  	lb		(rdkind knd) { return knd==hd_->knd; }
	int  	luibet(rdkind knd) { return knd==hd_->knd; }
	char*	idfier() { return hd_->idfier();	}
	int  	keyi  () { return 'i'==key(); }
	int	 	npart	() { return K; }
public:
	char*    ki (USHORT n); // depends on luibet
	char*    ri (USHORT n); // depends on luibet
	char*    ki0(ushort n){cs1=ki(n); str_del4wis(cs1.s); return cs1.s;}
	char*		 im (ushort n);
	char*    im0(ushort n){cs1=im(n); str_del4wis(cs1.s); return cs1.s;}
	char*		 it (ushort n); // only nrK will return imtau, nit should use ki
public:
	char*    ki (USHORT n, int nthpart); // depends on luibet
	char*    ri (USHORT n, int nthpart); // depends on luibet
	char*    ki0(ushort n, int nthpart){cs1=ki(n,nthpart); str_del4wis(cs1.s); return cs1.s;}
	char*		 im (ushort n, int nthpart);
	char*    im0(ushort n, int nthpart){cs1=im(n,nthpart); str_del4wis(cs1.s); return cs1.s;}
public:    // last unit
	char*    eki (USHORT n); // depends on luibet
	char*    eri (USHORT n); // depends on luibet
	char*    eki0(ushort n){cs1=eki(n); str_del4wis(cs1.s); return cs1.s;}
	char*		 eim (ushort n);
	char*    eim0(ushort n){cs1=eim(n); str_del4wis(cs1.s); return cs1.s;}
protected: // for nrk
protected: // for nit
protected: // for laive
protected: // for c1su
//	int   ndx(const char*s) { return bfind(s,dt_,size(),hd_->usz, ???wisc1su_); }
public: //for dzb
	//float freq(USHORT n) { return *( (float*)(*(dst_+n)) ); }
	int		freq(int n) { return *( (int*)( (*(dst_+n)) -sizeof(int)-1 ) ); }
	char* d0	(int n) { return dst_[n]+jumpbyte;	} // d0 is key
	char* d1	(int n) { if(!hsd2)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1; }
	char* d2	(int n) { if(!hsd3)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1; }
	char* d3	(int n) { if(!hsd4)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1; }
	char* d4	(int n) { if(!hsd5)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1;}
};
typedef di53rd_ di53rd;
extern  di53rd_ rdnull;

struct ustmio { // usage status, changed to byte-array rather than bit-array
public:
	void		suaned  (USHORT n, USHORT n0, USHORT n9); //[n0,n9):range
	void		unsuaned(          USHORT n0, USHORT n9); //[n0,n9):range
	int			status(USHORT n);
	void		inc(USHORT n);
	//void	dec(USHORT n);
public:
	ustmio() : ph(0), pv(0) { }
 ~ustmio() { del(); }
public:
	typedef	rdhdr53 hust;
	tyio  	io;
	szmio 	h, v;
	hust  	*ph;
	UCHAR		*pv;
	void  	init(){ph=0;pv=0;}
	int			read (tyio& io);//{h.read(io);v.read(io);return (h.sz+v.sz);}
	int			write(tyio& io){h.write(io,h.sz); v.write(io,v.sz);//8: for 2 long's
													return(h.sz+v.sz);  }
	int			read(char*fn){io.open(fn);int res=(io.isOK())?read(io):0;io.close();
													return res;}
	void		destroy() { h.destroy(); v.destroy(); }
	void		del()     { h.destroy(); v.destroy(); }
	int			new2(long asize);
	int			isOK()        {return (pv)?1:0;}
	uint 		size  () 			{return (uint)(ph->asz);			}
	int			isOK(USHORT n){if(!pv)return 0;return((ph->asz>0)&&(n<=ph->asz))?1:0;}
};




#ifdef OLDOLDOLDOLDOLD

struct riki {	char r[2]; ushort k; // cutri and ripki
			 riki ( char* r1,  int k1 ) { r[0]=r1[0]; r[1]=r1[1]; k=(ushort)k1;}
			 riki ( )		{ r[0]=r[1]=0; k=0; }
	int  ishanri( )	{
	 return (r[0])&&(r[0]!='*'); }
	int  isgood ( ) { return (r[0]&&k); }
};

struct rikin { ushort n;
			 rikin ( ushort n1=0 ) : n(n1) { }
			 rikin ( int    n1   ) : n((ushort)n1) { }
			 void operator=(rikin r) { n=r.n; }
};


class laivetos {
	riki* ns; int nslen;
	char* kis;int kislen; int WKI;
public:
	char* tos_ki	( int n) { return tos_ki  (rikin(n)); }
	char* tos_ki0	( int n) { return tos_ki0 (rikin(n)); }
	char* tos_ri	( int n) { return tos_ri  (rikin(n)); }
	char* tos_line( int n) { return tos_line(rikin(n)); }
public:
	char* tos_ki	( rikin n);
	char* tos_ki0	( rikin n);
	char* tos_ri	( rikin n);
	char* tos_line( rikin n);
public:
	char* tos_ri		(rikin*a, int K, char sep=0		);
	char* tos_ki		(rikin*a, int K, char sep='-'	);
	char* tos_ki0		(rikin*a, int K, char sep=0		);
	char* tos_line	(rikin*a, int K, char sep='\t');
	char* tos_it		(rikin*a, int K) { return tos_imtau(a,K); }
	char* tos_imtau	(rikin*a, int K);
public: // for building other suden
	riki  toriki(const char* ri, const char* ki);
	int   tondx (const char* ri, const char* ki);
	rikin ton   (const char* ri, const char* ki){return rikin(tondx(ri,ki));}
};

struct laivetosK { laivetos* lv; int K; };

struct di5wis_ {
	static	int i2r		(const void*l, const void*r)
	{
		static chars ll; ll.set2(  (char* )l ); str_del4wis(ll.s);
		static chars rr; rr.set2(*((char**)r)); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static	int r2i		(const void*l, const void*r)
	{
		static chars rr; rr.set2(*((char**)r));
		return strcmp((char*)l,rr());
	}
	static	int i2rf	 (const void*l, const void*r)
	{
		static chars ll; ll.set2(    (char* )l );     str_del4wis(ll.s);
		static chars rr; rr.set2( (*((char**)r))+5 ); str_del4wis(rr.s);
		return strcmp(ll.s,rr.s);
	}
	static	int r2if		(const void*l, const void*r)
	{
		static chars rr; rr.set2(*((char**)r)+5);
		return strcmp((char*)l,rr());
	}
public:
	static int c1su(const void*l, const void*r)
	{
		return strcmp((char*)l, (char*)r);
	}
	static int riki1(const void*l, const void*r)
	{
		uchar *ll, *rr; ll=(uchar *)l; rr=(uchar *)r;	int res;
		res=ll[0]-rr[0]; if(res) return res;
		res=ll[1]-rr[1]; if(res) return res;
		return ((riki*)l)->k - ((riki*)r)->k;
	}
public:
	static int i2rnkrK(const void*l, const void*r, laivetosK* lv);
	static int i2rnitK(const void*l, const void*r, laivetosK* lv);
};
extern di5wis_ di5wis;



class di53rd_ { // 2 or 3 column
	laivetosK* lvK;
	di53rd_* base4nit;
protected:
	tyio    io;   szmiohs mm;
	rdhdr* hd_;  void*   dt_;
	short id;  char s4null[4];
protected: // for dzb, dst_ is alloc-ed
	char**  dst_;
	int 		jumpbyte;
	int 		hsd2, hsd3, hsd4, hsd5;
	void 	setinnr();
	int		cols_is() { return (hd_->col)-'0'; }
protected:
	int (__cdecl *wis ) (const void *, const void *);
	int (__cdecl *wisx) (const void *, const void *, const void*);
protected:
	char* smd(char* s) { static chars ss; if(hd_->key!='i') return s;
												ss=s; str_del4wis(ss.s);return ss.s;}
public:
	int lower(char*s) { return (wisx)?
			wislower1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
			wislower (smd(s),dst_,size(),sizeof(char**),wis);
	}
	int upper(char*s) {  return (wisx)?
			wisupper1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
			wisupper (smd(s),dst_,size(),sizeof(char**),wis);
	}
	int lmu  (char*s, int*l, int*m, int*u); //r: nonsense
public:
	di53rd_()				 : hd_(0),wis(di5wis.i2r) {s4null[0]=0; }
	di53rd_(char* fn): hd_(0),wis(di5wis.i2r) {s4null[0]=0; read(fn); }
 ~di53rd_(){del();}
public:
	void 	del() { mm.del(); }
	int 	read(tyio& r ){ del(); mm.read(r ); afterread(); return 1; }
	int 	read(char* fn){ if(!io.open(fn))return 0;read(io);io.close();return 1; }
	int 	afterread();
public:
	int	hasd2()		{ return hsd2; }
	int	hasd3()		{ return hsd3; }
	int	hasd4()		{ return hsd4; }
	int	hasd5()		{ return hsd5; }
	int hasfreq() { return hd_->frq; }
public:
	int	 isOK	 () { return (int)hd_; }
	uint size  () { return (uint)(hd_->asz);			}
	char key   () { return hd_->key; }
	char qiqien() { return hd_->qqn; }
	char luibet() { return hd_->knd; }
	int  luibet(rdkind knd) { return knd==hd_->knd; }
	int  keyi  () { return 'i'==key(); }
public:
	char*    ki (USHORT n); // depends on luibet
	char*    ri (USHORT n); // depends on luibet
	char*    ki0(ushort n){static chars s; s=ki(n); str_del4wis(s.s); return s.s;}
protected: // for nrk
protected: // for nit
protected: // for laive
protected: // for c1su
//	int   ndx(const char*s) { return bfind(s,dt_,size(),hd_->usz, ???wisc1su_); }
public: //for dzb
	float freq(USHORT n) { return *( (float*)(*(dst_+n)) ); }
	char* d1	(USHORT n) { return dst_[n]+jumpbyte;	}
	char* d2	(USHORT n) { if(!hsd2)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1; }
	char* d3	(USHORT n) { if(!hsd3)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1+ strlen(d2(n))+1; }
	char* d4	(USHORT n) { if(!hsd4)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1; }
	char* d5	(USHORT n) { if(!hsd5)return s4null; return dst_[n]+jumpbyte + strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1+ strlen(d4(n))+1;}
};
typedef di53rd_ di53rd;



class dzb53_ { // 2 or 3 column
protected:
	tyio    io;   szmiohs mm;
	rdhdr* hd_;  char*   dt_;  char**  dst_;
	short id; int jumpbyte; char s4null[4]; int hsd2, hsd3, hsd4, hsd5;
	void  setinnr();
	int	cols_is() { return (hd_->col)-'0'; }
	int (__cdecl *wis ) (const void *, const void *);//the wis function
	char* smd(char* s) { static chars ss; if(hd_->key!='i') return s;
												ss=s; str_del4wis(ss.s);return ss.s;}
public:
	int lower(char*s) { return wislower(smd(s),dst_,size(),sizeof(char**),wis);}
	int upper(char*s) { return wisupper(smd(s),dst_,size(),sizeof(char**),wis);}
	int find (char*s) { return bfind   (smd(s),dst_,size(),sizeof(char**),wis);}
	int lmu  (char*s, int*l, int*m, int*u); //r: nonsense
public:
	dzb53_()				:	wis(di5wis.i2r) {s4null[0]=0; }
	dzb53_(char* fn): wis(di5wis.i2r) {s4null[0]=0; read(fn); }
 ~dzb53_(){del();}
public:
	void del() { mm.del(); }
	int read(tyio& r ){ del(); mm.read(r ); setinnr(); return 1; }
	int read(char* fn){ tyio io; if(!io.open(fn))return 0; mm.del();
											mm.read(io);
											setinnr();
											io.close(); return 1; }
public:
	int	hasd2()		{ return hsd2; }
	int	hasd3()		{ return hsd3; }
	int	hasd4()		{ return hsd4; }
	int	hasd5()		{ return hsd5; }
	int hasfreq() { return hd_->frq; }
public:
	int	 isOK	 () { return (int)hd_; }
	uint size  () { return (uint)(hd_->asz);			}
	char key   () { return hd_->key; }
	char qiqien() { return hd_->qqn; }
	char luibet() { return hd_->knd; }
public:
	float freq(USHORT n) { return *( (float*)(*(dst_+n)) ); }
	char* d0	(USHORT n) { return dst_[n]+jumpbyte;	} // d0 is key
	char* d1	(USHORT n) { if(!hsd2)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1; }
	char* d2	(USHORT n) { if(!hsd3)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1; }
	char* d3	(USHORT n) { if(!hsd4)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1; }
	char* d4	(USHORT n) { if(!hsd5)return s4null; return dst_[n]+jumpbyte + strlen(d0(n))+1+ strlen(d1(n))+1+ strlen(d2(n))+1+ strlen(d3(n))+1;}
};


typedef dzb53_ dzb_;







inline int wisc1su_(const void* l, const void*r) 
{ return strcmp((char*)l,(char*)r); }

class c1su_ {protected: short id; int usz; // size of each unit in byte
	szmiohs mm;  rdhdr* hd_;  char*   dt_;
	void  setinnr(){ hd_=(rdhdr*)(mm.h)(); dt_=(char*)(mm.s)(); usz=hd_->usz; }
public:
  int write(tyio& r ){ int res=mm.write(r);return res; }
	int read (tyio& r ){ int res=mm.read (r); setinnr(); return res; }
public:
  unsigned int  size() { return (unsigned int)(hd_->asz); }
  unsigned int usize() { return (unsigned int)(usz); }
public:
	char* c1(USHORT n) { return dt_+n*usz; }
	int   ndx(const char*s) { return bfind(s,dt_,size(),usz, wisc1su_); }
};

struct int2 { int i1, i2;
int2(int i11=0, int i21=0) { i1=i11; i2=i21; }
};


struct idndx {
  short  i;
	USHORT n;
  idndx() : i(0), n(0) {}
  idndx(short id, USHORT ndx) : i(id), n(ndx) {}
  void set2 (short i1, USHORT n1){ i=i1; n=n1; }
  void set20(                   ){ i=0 ; n=0 ; }
  void clear(                   ){ i=0 ; n=0 ; }
	int  isnull() { return i<=0; }
  int notnull() { return i> 0; }
  void operator = (idndx r) {i=r.i; n=r.n;}
	void operator ++()    { n++; }
  void operator ++(int) { n++; }
  void operator --()    { n--; }
  void operator --(int) { n--; }
  void operator +=(int t) { n+=(short)t; }
  void operator -=(int t) { n-=(short)t; }

	void trimend  (USHORT ubound)   { if(n>ubound) n=ubound; }
  void trimbegin(USHORT lbound=0) { if(n<lbound) n=lbound; }
};

inline int operator < (idndx& l, idndx& r) { return l.n< r.n; }
inline int operator <=(idndx& l, idndx& r) { return l.n<=r.n; }
inline int operator ==(idndx& l, idndx& r) { return (l.i==r.i)&&(l.n==r.n); }


struct idndx2 { idndx l, u;
idndx2() { }
idndx2(idndx  l1, idndx  u1) { l=l1;  u=u1;		}
  void operator = (idndx2 r) { l=r.l; u=r.u;	}
  int count()    { return u.n-l.n;			}
  int    none () { return u.n-l.n <=0;	}
	int hasnone () { return none();				}
	int hassome () { return count();			}
  idndx& begin() { return l;						}
  idndx& end  () { return u;						}
};

struct idndx3 { idndx l, m, u;
idndx3() { }
idndx3(idndx  l1, idndx  m1, idndx  u1) { l=l1;  m=m1;  u=u1; }
	void operator = (idndx3 r)						{ l=r.l; m=r.m; u=r.u;}
	int count   ()	{ return u.n-l.n;			}
	int    none ()	{ return u.n-l.n <=0;	}
	int hasnone ()	{ return none();			}
	int hassome ()	{ return count();			}
	int has1sthalf(){ return m.n-l.n;			}
	int has2ndhalf(){ return u.n-m.n;			}
	idndx& begin()	{ return l;						}
	idndx& end  ()	{ return u;						}
};

#endif //#ifdef OLDOLDOLDOLDOLD


template <class K, int SZ1=701>
class strhash {
	struct node { chars s; K k; node* nxt; };
	node* tbl[SZ1]; int SZ;
public:
	strhash(): SZ(SZ1) { memset(tbl, 0, sizeof(*tbl)*SZ1); }
	int size() { return SZ; }
public:
	uint hval(char* s){uint v=0;for(;*s;s++)v=*s+31*v;return v%SZ;}
	K&   get (char* name, int insert=0);
};

template<class K, int SZ1> K& strhash<K, SZ1>::
get(char* name, int insert)
{
	static K kk;
	node *p; int h=hval(name);
	p = tbl[h];
	if (p==NULL)		// entry empty
		if (insert) { p=tbl[h]=new node; p->s=name; return p->k; }
	while(p!=NULL){ // look for name */
		if(p->s.is(name)) return p->k;
		p=p->nxt;
	};
	// name not found
	if(insert) { p=tbl[h]=new node; p->s=name; return p->k; }
	return kk;
}
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
class pinimexpander { public: charspp output;
	int set2Nexpand(char*s);
	char*operator[](int n)  { return output[n];			}
	int size()							{ return output.size(); }
};

class tcpmlexpander { public: charspp output;
	int set2Nexpand(char*s);
	char*operator[](int n)  { return output[n];			}
	int size()							{ return output.size(); }
};
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////

class segtr_ { charspp tspp, ispp; charspp ospp;
	di53rd_** wrds; int nwrds; di53rd_* rds[2]; int nrds;
	int maxsu;
public:
	segtr_(){nwrds=nrds=0;}
public:
	void	setrds (di53rd_* rd1						){rds[0]=rd1; nrds=1; setwrds();}
	void	setrds (di53rd_* rd1,di53rd_*rd2){rds[0]=rd1;rds[1]=rd2;nrds=2; setwrds();}
	void	setrds (di53rd_**rds1,int nrds1	){setwrds(rds1,nrds1);}
	void	setwrds(di53rd_**rds1,int nrds1	){wrds=rds1;nwrds=nrds1;setmaxsu(wrds,nwrds);}
	void	setwrds(						 					 	){wrds=&(rds[0]) ;nwrds=nrds; setmaxsu(wrds,nwrds);}
	int		isOK	 (){return nrds>0;}
public:
	int		smmseg(chars& ot, charspp& in, char sep=ch01);
	int		 mmseg(chars& ot, charspp& in, char sep=ch01);
	char*		 seg(char* s, int domm, char sep);
	char*	 mmseg(char* s, char sep='='){return seg(s,1,sep);}
	char*	smmseg(char* s, char sep='='){return seg(s,0,sep);}
public:
	int		smmtr (chars& ocs0,chars& ocs1, charspp& in, char sep=ch01);
	int		 mmtr (chars& ocs0,chars& ocs1, charspp& in, char sep=ch01);
	char*		 tr (char* s, int domm, char sep);
	char*	 mmtr (char* s, char sep='='){return tr(s,1,sep);}
	char*	smmtr (char* s, char sep='='){return tr(s,0,sep);}
protected:
	int		check4skip(char*s);//check huhor, all digit, pinimri with diaugi
	void	setmaxsu(di53rd_* rds[], int nrds){int n,b;maxsu=0;
										for(n=0;n<nrds;n++)
										{b=rds[n]->maxri();if(b>maxsu)maxsu=b;}
										if(maxsu<=0)maxsu=1;}
	int		 mmseg(chars& ot, charspp& in, int B, int E, int nmsu, char tmpsep);
	int		 mmtr (chars& ocs0,chars& ocs1, charspp& in, int B, int E, int nmsu, char tmpsep);
};

////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////


#endif //#ifndef DIBASE_H


