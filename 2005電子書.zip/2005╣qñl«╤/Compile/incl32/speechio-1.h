//
// file speechio.h
// copyright 1998 Gang, IrngZin
//


#ifndef SPEECHIO_H
#define SPEECHIO_H
// for VC++6.0
// speechio needs 
//  1. set _MT switch in C/C++ compiler
//  2. add winmm.lib in link/library
// MT is for multithread

#include <windows.h>
#include <mmsystem.h>
#include <process.h>
#include <di5base.h>
#include <math.h>

//#include <spmsg.h>
//#include <rcfft.h>
//#include <realfft.h>
//#include "crealfft.h"

typedef unsigned long ulong;

#define nDQS_MAXIDLEBUF	60
#ifdef  DQS_PCM8
	#define nDQS_BYTES		1
	#define nDQS_FSS			256
#else
	#define nDQS_BYTES		2
	#define nDQS_FSS			256
#endif

// Here we design two ways a thread can be created:
// 1. derive from threader2_, and
//		implement VTVVSthread w/arg= void* that can be casted into "this"
// 2. defineNset client w/func of tye VFNVS, use the VS to get "this", as in 1.
//    use threader1_
// Note that BCB requires? its VCL acess thru its own TThread, so use it if BCB

typedef void (*VFNV )(void );
typedef void (*VFNVS)(void*);
typedef void (*VFNS) (char*);

class threader1_ { public:HANDLE hnd; uint id;
									VFNVS client, onterminate; void* arg;
			threader1_():hnd(NULL),id(0),client(NULL),onterminate(NULL){  }
		 ~threader1_(){if(hnd) CloseHandle(hnd);}
public://caution to use wait2end: the one that calls will sleep
	void wait4end(int wtime=INFINITE)
								{ WaitForSingleObject(hnd,wtime); }
	void start   (VFNVS client1=NULL, void*arg1=NULL, VFNVS onterminate1=NULL){
									if(hnd)CloseHandle(hnd);
									client=client1; arg=arg1;	onterminate=onterminate1;
									//hnd=CreateThread(NULL,0,staticthread,this,0,&id);
									hnd=(HANDLE)(_beginthreadex(NULL,0,staticthread,this,0,&id));
	}
protected:
static uint WINAPI staticthread(void*pv) {
			threader1_*t=(threader1_*)pv;
			if(t->client			)(*(t->client))(t->arg);
      if(t->onterminate	)(*(t->onterminate))(t->arg);
      if(t->hnd) { CloseHandle(t->hnd); t->hnd=0; }
			return 0;
	}
};

class threader2_{ public:HANDLE hnd; uint id;
			threader2_():hnd(NULL),id(0){}
		 ~threader2_(){dele();}
public://caution to use wait2end: the one that calls will sleep
	virtual void VTVVthread  () { }
	void dele    (){if(hnd) CloseHandle(hnd);hnd=0;}
	void wait4end(int wtime=INFINITE) { WaitForSingleObject(hnd,wtime); }
	void start(){dele();hnd=(HANDLE)_beginthreadex(NULL,0,thethread,this,0,&id);}
	void kaisi   (){start();}
	static uint WINAPI thethread(void*pv)
		{	threader2_*t=(threader2_*)pv;	t->VTVVthread(); t->dele();	return 0; }
};

class  spmsgcase {// must use thread to implement this
public:spmsgcase(int asdef=1){ setasdef(asdef); }
	void  setasdef(int asdef);// { spmsg.set2(this, asdef);   }
	chars s;
	void set2s(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{s.clear();
						 if(s1)s+=s1;if(s2)s+=s2;if(s3)s+=s3;if(s4)s+=s4; }
	virtual void rcg0    (cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	virtual void debug0  (cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	virtual void ostatus0(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	virtual void istatus0(cchar *s1, cchar*s2, cchar*s3, cchar*s4)	{}
	//void rcg    (char *s1,char*s2=0,char*s3=0,char*s4=0){rcg0    (s1,s2,s3,s4);}
	//void debug  (char *s1,char*s2=0,char*s3=0,char*s4=0){debuf0  (s1,s2,s3,s4);}
	//void ostatus(char *s1,char*s2=0,char*s3=0,char*s4=0){ostatus0(s1,s2,s3,s4);}
	//void istatus(char *s1,char*s2=0,char*s3=0,char*s4=0){istatus0(s1,s2,s3,s4);}
};

class  spmsg_ {	spmsgcase * c;
public:spmsg_() {c=NULL; }
	void set2(spmsgcase* c1, int asdef=1)
		{
			if(asdef) c=c1;
			else if(!c)
				c=c1;
		}
	void rcg(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->rcg0(s1,s2,s3,s4);}
	void debug(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->debug0(s1,s2,s3,s4);}
	void ostatus(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->ostatus0(s1,s2,s3,s4);}
	void istatus(cchar *s1, cchar*s2=0, cchar*s3=0, cchar*s4=0)
		{if(c)c->istatus0(s1,s2,s3,s4);}
};
extern spmsg_ spmsg;
extern spmsgcase spmsgNULL;


#ifndef RCFFT_H
#define RCFFT_H


class   rcfft_ {
public: rcfft_():lastN(0),lastisign(0) {}
	void rfft1(float *x, int N, int isign=1);//x: 2N reals,     1-based
	void cfft1(float *x, int N, int isign=1) //x:  N complexes, 1-based
						{if(N>512) cfftg(x,N,isign); else cfftf(x,N,isign);}
public:
	void sh2ft(float* x, short* sh, int N){float *f=x; short*s=sh;
						 for(int n=0;n<N;n++)
							*f++ = float(*s++);
	}
private:int lastN, lastisign;
	short bitrev[513]; double sinhalftheta[9], sintheta[9]; //2^9=512
	void cfftf(float *x, int N, int isign=1);// faster version
	void cfftg(float *x, int N, int isign=1);// general version
};
extern rcfft_ rcfft;

class   ehfs_ {
public: ehfs_ (double preem1=0.975)
				{	init20(); preem=(float)preem1;	initham(); }
public:
	rcfft_ fft;
	float* ehf (short* sh, int nsh, float* res1=0, int preem=1);
	float* ehfs(short* sh, int nsh, float* res1=0, int preem=1);
public:
	float  preem;
	void   dopreem(float* obs);
	void   dopreem(float* obs, float prevvalue);
private: int lastFRMSZ, lastNRFFT, aFRMSZ, aNRFFT;
	float  *xdef; // default working array
	float  *ham;
	int    alloc4work(int aFRMSZ1);
  int 	 ge2pow(int t){float tt=t-0.05;int rr=1;while(rr<tt)rr*=2;return rr;}
  void	 init20(){lastFRMSZ=lastNRFFT=aFRMSZ=aNRFFT;xdef=ham=0;}
public:
	void   initham();
	void   doham  (float* obs);
};



template<int FRMSZ, int NRFFT>
class   emhamfft_ {
public: emhamfft_ (double preem1=0.975)
				{	preem=(float)preem1;	initham(); }
public:
	rcfft_ fft;
	float* zor(short* sh, float* res1=0, int preem=1);
public:
	float  preem;
	void   dopreem(float* obs);
	void   dopreem(float* obs, float prevvalue);
public:
	float  xdef[NRFFT]; // default working array
	float  ham [FRMSZ];
	void   initham();
	void   doham  (float* obs);
};

template<int FRMSZ, int NRFFT> 
float* emhamfft_<FRMSZ, NRFFT>::
zor(short* shobs, float* res1, int melkind)
{
	int i; float* x;
	if(res1!=0) x=res1; else x=xdef;
	for(i=0; i<FRMSZ; i++) x[i]=shobs[i];
	//float te=totaleng();
	dopreem(x);
	doham(x);
	if((NRFFT-FRMSZ)>0)
		memset(x+FRMSZ, 0, (NRFFT-FRMSZ)*sizeof(float));//zero-padding
	fft.rfft1(x-1, NRFFT/2); // real fft, -1:since 1-based
	//x[1]=0; // for htk's ???
	return x;
}

template<int FRMSZ, int NRFFT> 
void emhamfft_<FRMSZ, NRFFT>::
dopreem(float* obs)
{
	for(int i=FRMSZ-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] *=float(1.0-preem);
}

template<int FRMSZ, int NRFFT> 
void emhamfft_<FRMSZ, NRFFT>::
dopreem(float* obs, float prevvalue)
{
	for(int i=FRMSZ-1; i>0; i--)	obs[i]-=obs[i-1]*preem;
	obs[0] -=prevvalue*preem;
}

template<int FRMSZ, int NRFFT>
void emhamfft_<FRMSZ, NRFFT>::
initham()
{
	const double pi=3.141592653589793;
	double twopi=2*pi;
	float dt=float(twopi/(FRMSZ-1));
	for(int i=0; i<FRMSZ; i++)
  	ham[i]=float(0.54-0.46*cos(dt*i));
}

template<int FRMSZ, int NRFFT>
void emhamfft_<FRMSZ, NRFFT>::
doham(float*obs)
{
	float*o=obs, *h=ham;
	for(register int i=0; i<FRMSZ; i++)
		*o++ *= *h++;
}




#endif //#ifndef RCFFT_H



class wavhdr_ :public WAVEHDR { public: // this header is for speech io
			wavhdr_() { init0(); }
	void clear(){ memset(this,0,sizeof(*this)); }
	void init0() { clear(); }
	void init4def() { }
	//int  read (tyio& i);//with checking
	//int  write(tyio& o){return o.write(this,sizeof(*this));}
public:
  int  	size() {return dwBufferLength; }
  void operator=(const wavhdr_&rhs){memmove(this,&rhs,sizeof(*this));}
};

class pcmfmt_ : public WAVEFORMATEX { public: void* extra; // .wav header
			pcmfmt_() { memset(this, 0, sizeof(*this)); }	
		 ~pcmfmt_() { if(extra) delete[] extra; }	
public:
	int    isCPM() { return CPM()==fmt();		}
	WORD   CPM  () { return WAVE_FORMAT_PCM;}
	WORD & fmt  () { return wFormatTag;			}
	WORD & ch   () { return nChannels;			}
	DWORD& sr   () { return nSamplesPerSec;	}
	DWORD& Bpsec() { return nAvgBytesPerSec;}
  WORD & Bpsmp() { return nBlockAlign;		}// bytes per sample in nChannels
  WORD & bpsmp() { return wBitsPerSample;	}// bits per sample in 1 Chanel
  WORD & xtr  () { return cbSize;					}
public:
	int isconsistent(){return ( (nBlockAlign==WORD(nChannels*wBitsPerSample/8))&&
										(nAvgBytesPerSec==(nSamplesPerSec*nBlockAlign)) )?1:0;}
	void set44k22()	{set2(44100,2);}
  void set44k12()	{set2(44100,1);}
  void set22k22()	{set2(22050,2);}
  void set22k12()	{set2(22050,1);}
  void set11k22()	{set2(11025,2);}
  void set11k12()	{set2(11025,1);}
  void set8k22 ()	{set2( 8000,2);}
  void set8k12 ()	{set2( 8000,1);}
	void set16k22()	{set2(16000,2);}
	void set16k12()	{set2(16000,1);}
	void set16k  ()	{set2(16000,1);}
	void set2(DWORD samppsec, WORD channels=1, WORD bitspsamp=16)
  {
  	wFormatTag=WAVE_FORMAT_PCM; nChannels=channels;nSamplesPerSec=samppsec;
    wBitsPerSample=bitspsamp; cbSize=0;
    nBlockAlign=WORD(channels*bitspsamp/8);nAvgBytesPerSec=samppsec*nBlockAlign;
  }
public:
	void set2def ()	{set16k();			}
	int  read (tyio& i);//checking if WAVE_FORMAT_PCM
	int  write(tyio& o){int res=o.write(this,sizeof(*this));
											if(extra&&xtr())res+=o.write(extra,xtr());return res;}
};

class htkfmt_ { public:
			htkfmt_() { init0(); }
	void init0() { memset(this,0,sizeof(*this)); }
	int  read (tyio& i);// with checking
	int  write(tyio& o){return o.write(this,sizeof(*this));}
public:
	void  init2def(){sampPeriod=625;sizePerSamp=2;fileDataKind=0;}
  int   totSamp;		 // speech data in samples,not in bytes,excluding header
  int   sampPeriod;  // =625 per 10^-7 second for 16K (10^7/16k)
  short sizePerSamp; // =2;   2 byte per sample
  short fileDataKind;// =0;   wavedata, according HTK convention
public:
  int  	size() {return totSamp; }
  void operator=(const htkfmt_&rhs){memmove(this,&rhs,sizeof(*this));}
};

class dqsoptions_ { public:
	short		nbytes;			// size per sample, must set to 2
  short		nchannels; 	// num of channels, must set to 1
  int	 		bDBoff;			// off DB real time,def2 true(1)
public:
	int 		nfss; 			// frame shift size
  int  		nfsz;				// frame size= 2 times the fss
  int			nframerate;	// num of frames per second
  int			nframefreq;	// time in msec  per frame
public:
  int 		nsamprate; 	// sampling rate, num of samples per second
  int	 		nsampfreq;	// time in 10^-7 seconds per sample
protected:
  void clear() 	{ memset(this, 0, sizeof(*this)); }
	void set00()	{ nbytes=2; nchannels=1; bDBoff=1; }
  void setsamp	(int nsamprate1	)       // def2 16K
  							{	nsamprate=nsamprate1;
                	nsampfreq=int(10000000.1/nsamprate);} //def2 625
  void setframe	(int nframerate1)        // def2 50 frames persecond
  							{	nframerate=nframerate1;
                	nframefreq=int(1000.1/nframerate);//def2 20msec
                  nfsz=int(nframefreq/1000.0*nsamprate); //def2 320samp
                  nfss=nfsz/2;							}				//def2 160samp
public:
	void setsamp_frame(int nsamprate1, 			int nframerate1)
  				{ setsamp(nsamprate1); setframe(nframerate1);}
  dqsoptions_(int nsamprate1=16000,		int nframerate1=50)
  			 	{ clear(); set00(); setsamp_frame(nsamprate1,nframerate1);}
};
// dqsoptions_ dqs16k;


class owave_ {	// the waveout agent, real worker is owave0_
public: 				// iwave0_ is in the .cpp file
	int		open		 (pcmfmt_* wfmt1=0);
	int		close		 ();
	int		play		 (short* sh, int sz);
	int		playclose(short* sh, int sz){int r=play(sh,sz);close();return r;}
	int		stopclose();
  int		isplaying();
	void	wait2end ();
}; extern owave_ owdef;




class qiimbuf_{ public:
		 ~qiimbuf_(						 ) { del(); }
			qiimbuf_(int nshorts=0):sh(0) { init0();init2(nshorts); }
			qiimbuf_(char* fname  ):sh(0) { init0();read(fname); }
public:
	short*  sh; int k, K;
	int nshused, nshalloc;
	int nshbsil, nsheqiim, nshesil; //nsheqiim includes nshbsil
	wavhdr_ wh; htkfmt_ hh; pcmfmt_ pcm;
	void clear() { memset(this,0,sizeof(*this)); }
	void init0() { clear(); }
public:
	int  isOK () { return (sh!=0); }
	void del  (      		  ){if(sh) { delete[] sh; sh=0; } }
	int  init2(int nshorts){if(nshorts<=0)return 0;
								if(nshalloc<nshorts)
									{del(); sh=new short[nshorts];nshalloc=(sh)?nshorts:0;}
								nshused=0; return((sh)?1:0);}
	int  set2 (short* sh1, int nsh1) { if(!init2(nsh1)) return 0;
								memmove(sh, sh1, sizeof(short)*nsh1); nshused=nsh1;
								return 1; }
	int	 set2 (qiimbuf_* buf){return set2(buf->sh, buf->nshused);}
	int	 set2 (qiimbuf_& buf){return set2(buf. sh, buf. nshused);}
public:
	void hdr2htk();
	void hdr2wav();
public:
	int	 readwav	(tyio& io);
	int  readhtk	(tyio& io);
	int  read			(char* fn);
public:
	int  write(tyio& io, int writewav  );
	int  write(char* fn, int writewav=0);
	void writehtk			(char* fname){write(fname);}
	void writewav			(char* fname, char* pname=NULL);
	int  writehtklabel   (char* label, char* fname);
public:
	void 	 play 	(int bskip=0, int eskip=0){if(sh) owdef.playclose
								(sh+nshbsil+bskip,nsheqiim-nshbsil-bskip-eskip);}
	short* wdata	(){ return sh; 							}
	int		 bsize 	(){ return nshused*2;				}
	int		 ssize	(){ return nshused;					}
	int		 frmsz	(){ return nDQS_FSS; 				}
  int		 nspec  (int frmsz, int shftsz){if(shftsz<=0) return nshused;
  															return((nshused-frmsz)/shftsz+1);}
	void	 play(char* fname) { if(read(fname)) play(); }
	short& operator[](int ith) { return sh[ith]; }
public:
	int		 shiftsz;
	void	 setshiftsz(int shiftsz1=64) { shiftsz=shiftsz1; }
	int		 numframe(int framesz=nDQS_FSS){if(shiftsz<=0)shiftsz=1;
														return (ssize()-framesz)/shiftsz+1;}
	short* nthframe(int nth) { return sh+nth*shiftsz; }
};

class feabuf_{ public:
		 ~feabuf_(						 ) { del(); }
			feabuf_(int nfloats=0):ft(0) { init0();init2(nfloats); }
public:
	float*  ft; int owned;
	int nftused, nftalloc;
	htkfmt_ hh;
	void clear() { memset(this,0,sizeof(*this)); }
	void init0() { clear(); }
public:
	void del  (      		  ){if(ft&&owned){delete[]ft;ft=0;owned=0;}}
	int  init2(int nfloats){if(nfloats>0)ft=new float[nfloats];
												  if(ft)nftalloc=nfloats;return((ft)?1:0);}
public:
	int		read	(char* fn);
public:
	int		shiftmsec(){return hh.sampPeriod/10000;}//badname in htk's part
	int		numframe (){return hh.totSamp;}
	int   nfloatsPerFrame()  { return hh.sizePerSamp/sizeof(float);}
	float*nthframe(int nth)  { return ft+nth*nfloatsPerFrame(); }
	float*operator[](int nth){ return nthframe(nth); }
};



class WTS2_  { // weighted sum of the trancated spectrogram
//protected:
	int   nobs, nhrfft, CUTCNT; int initOK_;
	float *flt, *spc, *cut, *ct2; // working arrays to be alloc-ed
  qiimbuf_ *qbuf; // qiimbuf to receive the bkg noise
	void	setbelws(); // depends on nhrfft
	void  del();
	int   init2     (int nshort);
	void  conv2spec (float* ft, short* sh); // using nobs, nhrfft
	int   convNtrunc(short* sh);// 2 flt
public:
	WTS2_(int nshort, float sigmatimes1,float btimes1,float etimes1, qiimbuf_* qbuf1=NULL)
		:nobs(0),nhrfft(0),qbuf(0),flt(0),spc(0),cut(0),ct2(0),initOK_(0)
		{sigmatimes=sigmatimes1; init2(nshort); setscale(1.0,btimes1,etimes1);qbuf=qbuf1;}
  void setscale(float scale1,float btimes1, float etimes1);
  int  initOK () { return  initOK_; }
  int  initERR() { return !initOK_; }
public:
	int   be4truncate(int nshort=-1);
	int   __4truncate(short* sh);
	int   en4truncate();
	void	setsigrec  (qiimbuf_* qbuf1=0) {qbuf=qbuf1;}
public:
	float wts     (short* sh, float* lws, int nlws);
	int   beexceed(short* sh){return(wts(sh,blws,nblw)>bthresh)?1:0;}
	int   enexceed(short* sh){return(wts(sh,elws,nelw)>ethresh)?1:0;}
	int		openend (					){return(ethresh<0.001)?1:0;}
//private:
	float bthresh, ethresh;
	float sigmatimes; //sigma-times off the mean of cut
  float	btimes;	 // beg threshhold times
  float	etimes;	 // end threshhold times
  float	scale;	 // computed as the sum of the std vector from sil
  float blws[10];// array of limit-weights for beg
  float elws[10];// array of limit-weights for end
  int		nblw;		 // nElem in the array of limit-weights for beg
  int		nelw; 	 // nElem in the array of limit-weights for end
};

typedef WTS2_ WTS_;

class WTS1_  { // weighted sum of the trancated spectrogram
	int   nobs, nhrfft, CUTCNT; int initOK_;
	float *flt, *spc, *cut, *ct2; // working arrays to be alloc-ed
	void	setbelws(); // depends on nhrfft
	void  del();
	int   init2    (int nshort);
	void  conv2spec (float* ft, short* sh); // using nobs, nhrfft
	int   convNtrunc(short* sh);// 2 flt
public:
	WTS1_(int nshort, float sigmatimes1, float btimes1, float etimes1)
		:nobs(0),nhrfft(0),flt(0),spc(0),cut(0),ct2(0),initOK_(0)
    {sigmatimes=sigmatimes1; btimes=btimes1; etimes=etimes1;init2(nshort); }
  int initOK () { return  initOK_; }
  int initERR() { return !initOK_; }
public:
	int   be4truncate(int nshort=-1);
	int   __4truncate(short* sh);
	int   en4truncate();
public:
	float wts     (short* sh, float* lws, int nlws);
	int   beexceed(short* sh){return(wts(sh,blws,nblw)>bthresh)?1:0;}
	int   enexceed(short* sh){return(wts(sh,elws,nelw)>ethresh)?1:0;}
	int		openend (					){return(ethresh<0.001)?1:0;}
//private:
	float bthresh, ethresh;
	float sigmatimes; //sigma-times off the mean of cut
  float	btimes;	 // beg threshhold times
  float	etimes;	 // end threshhold times
  float	scale;	 // computed as the sum of the std vector from sil
  float blws[10];// array of limit-weights for beg
  float elws[10];// array of limit-weights for end
  int		nblw;		 // nElem in the array of limit-weights for beg
	int		nelw; 	 // nElem in the array of limit-weights for end
};



class wavinhdrbuf_ :public WAVEHDR { public:
	//static FFT_<1024> fft;
	static rcfft_ fft;
	int id;	short sh[nDQS_FSS];
	static short dbbias;
  short Lnorm; 					// =1(L1-norm) or 2(L2-norm) def2 L2-norm
	int  init(short Lnorm=1);
public:
	wavinhdrbuf_() { init(); }
 ~wavinhdrbuf_() { }
public: int res;
	int		add   (HWAVEIN hwi) {return res=waveInAddBuffer       ( hwi, (LPWAVEHDR)this, sizeof(WAVEHDR) ); }
	int		prep  (HWAVEIN hwi) {return res=waveInPrepareHeader   ( hwi, (LPWAVEHDR)this, sizeof(WAVEHDR) ); }
	int		unprep(HWAVEIN hwi) {return res=waveInUnprepareHeader ( hwi, (LPWAVEHDR)this, sizeof(WAVEHDR) ); }
	void	copy2 (short* tgt ) {if(sh)memmove(tgt, sh, nDQS_FSS*sizeof(short)); }
public:
	int		bsize() { return dwBufferLength; } // byte size of wavedata
	float avgenergy();
	float bias();
	void  adjust_bias();
  float fftoff(int from, double off);
  float fftoff(int from, float* off);
	float fftoff(float* off, float* offlmtwght, int Nlmtwght);
};

class  bejudger_ {
public:
	virtual int  forbeg   (wavinhdrbuf_* p2whb){return 1;}
	virtual int  forend		(wavinhdrbuf_* p2whb){return 0;}
  virtual int	 openend	(										){return 0;}
	virtual void init4def	(int bDBoff){}
};

class beL12_ : public bejudger_ { public:
	int forbeg(wavinhdrbuf_* p2whb){return(p2whb->avgenergy()>dbthresh)?1:0;}
	int forend(wavinhdrbuf_* p2whb){return(p2whb->avgenergy()<dethresh)?1:0;}
  int	openend(									){return (dethresh<0.001)?1:0;}
	void	init4def			(int bDBoff=1);
public:
	double	dback; 						// background noise
	double	dbtimes,  detimes; // times to determine threshhold
  double	dbthresh, dethresh;//=dtimes* dback
public:
	void	settimes			(double dbtimes1, double fetimes1);
  void	setbackground (double dback1);
  void	setthreshes		(double fbeg, double fend);
};

class beWTS_ : public bejudger_ { WTS_* wts;
public:
	beWTS_(WTS_* wts1):wts(wts1){}
	int forbeg(wavinhdrbuf_* p2whb){return   wts->beexceed(p2whb->sh) ;}
	int forend(wavinhdrbuf_* p2whb){return !(wts->beexceed(p2whb->sh));}
	int	openend(									){return   wts->openend();}
	//void init4def			(int bDBoff=1){endpoint_::init4def(bDBoff);}
};


class  endpoint_ { public:
public:endpoint_(bejudger_ *bejudger1)
	{
		clear(); init4def(1);	setDUR(); setsil(5,5);	init4kaisi();
		bejudger=bejudger1;
	}
	void clear  () { memset(this,0, sizeof(*this)); }
public: 												// b:beg, e:end
	int		nkbDUR, nkeDUR;  				// limit of duration
	int		nkbsil, nkesil;					// silence at beg/end
	int		bblurb, eblurb;         // duration to judge blurb
	void	setDUR(int nkbDUR1=-1, int nkeDUR1=-1);
	void	setsil(int nkbsil1, int nkesil1);
	int		nkfront(){return nkbsil+nkbDUR;}// # of frames at front =nkbsil+nkbDUR
	int		_lesskatend() { int r=(nkeDUR-nkesil);return(r>0)?r:0; }
public:
	short		buf0[1+(2*nDQS_MAXIDLEBUF)*nDQS_FSS];
	short*	buf;
	short*	allbuf;
	void		clearbuf() { memset(buf0,0,1+(nkfront())*nDQS_FSS*2);}
	void		initallbuf (short* allbuf1) { allbuf=allbuf1; }
public:
	int			nxt;
	int			nkbdur, beged;
	int			nkedur, ended;
	int			fillfrontdone;
	void		init4kaisi(){nxt=nkbdur=beged=nkedur=ended=fillfrontdone=0;}
public:
	int			fillfront ();
	char*		status();
	char*		state ();
	int			wavein (wavinhdrbuf_* p2whb, int* p2k)
								 {return (beged)?forend0(p2whb,p2k) : forbeg0(p2whb); }
	int   	forbeg0	(wavinhdrbuf_* p2whb          );
	int   	forend0	(wavinhdrbuf_* p2whb, int* p2k);
	bejudger_ *bejudger;
	int  forbeg   (wavinhdrbuf_* p2whb){
  	return bejudger->forbeg (p2whb);
  }
	int  forend		(wavinhdrbuf_* p2whb){
  	return bejudger->forend (p2whb);
  }
  int	 openend	(										){return bejudger->openend(     );}
	void init4def	(int bDBoff);
};


class idlebuf_ { public:
	wavinhdrbuf_ buf[nDQS_MAXIDLEBUF];
	char idles[nDQS_MAXIDLEBUF]; int n0, n1;
public:
	idlebuf_			 (					 )		{ initidle(); }
	void init			 (HWAVEIN hwi);   // those need hwi
	void initidle  (					 );
	void idles2		 (char to    ){for(int i=0;i<nDQS_MAXIDLEBUF;i++) idles[i]=to;}
	void all2idle  (			     ){for(int i=0;i<nDQS_MAXIDLEBUF;i++) set2idle(i);}
	void set2idle  (int id     ){idles[id]=1; }
	void all2driver(HWAVEIN hwi);
};

class  iwavethread_ {
public:iwavethread_ () { init_thread(); init_iwave(); }
			~iwavethread_ () { dele_thread(); dele_iwave(); }
public:
	virtual void VTVVwave() { }
	virtual int  VTIVSwavein(wavinhdrbuf_* p2whb){return 0;}
	void kaisitw() { begthread(); }
	void kaisiw () { VTVVwave(); }
public: // the thread part
	void init_thread() { hnd=NULL; id=0;}
	void dele_thread() { if(hnd) CloseHandle(hnd); hnd=0;}
	HANDLE hnd; uint id;
	void wait4end(int wtime=INFINITE) { WaitForSingleObject(hnd,wtime); }
	void begthread() {dele_thread();		hnd=(HANDLE)
										_beginthreadex(NULL,0,staticthread,this,0,&id);
										//dele_thread();
										}
	static uint WINAPI staticthread(void*pv) {	iwavethread_*t=(iwavethread_*)pv;
											t->VTVVwave();
											t->dele_thread();
											return 0;	}
public: // the iwave part
	void init_iwave(){bOpened=0;setpcm();res=ispcmsupported();idle_init0();}
	void dele_iwave();
	HWAVEIN         hwi; // handle to the oepned input device
	WAVEFORMATEX    wfx; // struct for (querying?) supportted data format
	MMRESULT        res;
	int bOpened;
	HWAVEIN operator()() { return hwi; }
	static int nblock;
	static void CALLBACK waveInProc	(	HWAVEIN  hwi, UINT uMsg, 		DWORD dwInst,
																		DWORD dwPrm1, DWORD dwPrm2);
public:
	int open();
	int start()     { allidle2driver(); return waveInStart(hwi); }
	int openstart() { if(openfail()) return 0; return start(); }
	int openfail()  { if(!bOpened) open(); return !bOpened; }
	int reset()     { int r=waveInReset(hwi); idles2(1); return r;}
	int stop ()     { return waveInStop (hwi); }
	int close()     { return waveInClose(hwi); }
	int rsc  ()     { reset();stop();return close();}
	int stopclose();// { if(bOpened){stop();reset();}bOpened=0;all2idle();reset();return close(); }
public:
	static idlebuf_   bufs;
	void idle_init0			(){ bufs.initidle		(   );	}
	void idle_init 			(){ bufs.init				(hwi);	}
	void idles2	 (char to){ bufs.idles2			(to );	}
  void all2idle 			(){ bufs.all2idle		(   );	}
  void set2idle (int id){ bufs.set2idle		(id );	}
  void allidle2driver (){ bufs.all2driver	(hwi);	}
	void dowhenidle			(){ bufs.all2driver	(hwi);	}
public:
  int setpcm (){ return setpcm(16000, (nDQS_BYTES==1)?8:16); }
  int setpcm  (int nsamples, int nbits);
  int ispcmsupported();
};

class iwstopper_ { public: char _1cu, loop, _4exit;
	void init4def(){_1cu      =loop         =_4exit=0;}
	void set2(char _1cu1, char loop1,   char _4exit1)
					{ _1cu=_1cu1, loop=loop1, _4exit=_4exit1;}
};

typedef void(*VFNqiim)(qiimbuf_*);

class qiimfns_ { public: VFNqiim beg1cu1, end1cu1, rcg;
			qiimfns_(): 	beg1cu1(NULL),end1cu1(NULL), rcg(NULL) { }
			qiimfns_(VFNqiim beg1cu11, VFNqiim end1cu11, VFNqiim rcg1)
      				{ set2 ( beg1cu11, 				 end1cu11,         rcg1);}
	void set2   (VFNqiim beg1cu11, VFNqiim end1cu11, VFNqiim rcg1)
							{beg1cu1=beg1cu11, end1cu1=end1cu11;		 rcg=rcg1; }
  void operator=(qiimfns_ rhs){set2(rhs.beg1cu1,rhs.end1cu1,rhs.rcg);}
  void beg1cu(qiimbuf_* qbuf)	{ if(beg1cu1) (*beg1cu1)(NULL); }
  void end1cu(qiimbuf_* qbuf) { if(end1cu1) (*end1cu1)(qbuf); }
};


class  adaptation2_:public iwavethread_ {
public:adaptation2_(VFNV getsok1, WTS_* wts1=NULL, int K1=10)
			:iwavethread_(), getsok(getsok1), wts(wts1),K(K1){init();}
			 WTS_ *wts; double nrg1, nrg2; int k, K; VFNV getsok;
	void init()	{ nrg1=nrg2=0.0; k=0; }
	void VTVVwave();
	int  VTIVSwavein(wavinhdrbuf_* p2whb);
	void kaisitw() { init(); wts->be4truncate(); iwavethread_::kaisitw(); }
	void kaisiw () { init(); wts->be4truncate(); iwavethread_::kaisiw (); }
};


class  siuqiim2_ : public iwavethread_ { public:
	siuqiim2_(int seconds, endpoint_* endpt1, qiimfns_ fns1, dqsoptions_ opt1=dqsoptions_() )
		:iwavethread_()
		{
			endpt=endpt1; fns=fns1; opt=opt1;
			bufset2(seconds); init4def();
		}
		void init4def();
		void init4kaisi() { setnextbuf(); endpt->init4kaisi();k=endpt->nkfront();}
		void setendpoint(endpoint_ *endpt1){endpt=endpt1;endpt->init4def(opt.bDBoff);}
public:
	virtual void VTVVwave();
	virtual int  VTIVSwavein(wavinhdrbuf_* p2whb);
public:
	int k, K;	short* buf;
public:
	dqsoptions_ opt;
	iwstopper_  stopper;
	int  done1cu 		(){ return stopper._1cu||endpt->ended; 	}
	int  complete1cu(){ if(!endpt->openend())return endpt->ended;
											else { return 1;} }
	int  doneloop 	(){ return stopper.loop;								}
	int  done4exit	(){ return stopper._4exit;							}
	int  showstatus	();
	int  fillfront 	(){ return endpt->fillfront(); 					}
public:
	static void thread(void*);
	void beg1cu(qiimbuf_* )	{ fns.beg1cu(NULL			); }
	void end1cu(qiimbuf_* ) { if(complete1cu())fns.end1cu(prevbuf());}
	char*		endptstatus() { return endpt->status(); }
	void		stopall (char stop4exit1=0)
				{stopper.set2(1,1,stop4exit1);owdef.stopclose();spmsg.istatus("");}
public: // buffers
	qiimbuf_	qiimbuf[3]; qiimfns_ fns;	endpoint_* endpt;	int nth, NTH;
	void			setnextbuf();
	qiimbuf_* prevbuf() { int n=((nth-1)>=0)?(nth-1):(NTH-1);return &qiimbuf[n];}
	void bufset2(int seconds)
							{
								int K1=seconds*opt.nsamprate;
								NTH=3; for(int i=0; i<NTH; i++) qiimbuf[i].init2(K1);
								nth=0;  K=seconds*opt.nframerate; setnextbuf();
							}
};




class  	siuqiim3_ : public iwavethread_ {
public: siuqiim3_	(int seconds, endpoint_* endpt1, VFNqiim end1cu=0,
									 VFNqiim beg1cu=0, dqsoptions_ opt1=dqsoptions_() )
		:iwavethread_()
		{
			setendpoint(endpt1); e1cu=end1cu; b1cu=beg1cu; opt=opt1;
			bufset2(seconds); init4def(); init4kaisi();
		}
		void init4def();
		void init4kaisi() { endpt->init4kaisi();k=endpt->nkfront();}
		void setendpoint(endpoint_ *endpt1){endpt=endpt1;endpt->init4def(opt.bDBoff);}
public:
	//static  void thread(void*);
	virtual void VTVVwave();
	virtual int  VTIVSwavein(wavinhdrbuf_* p2whb);
public:
	qiimbuf_			qiimbuf;
	endpoint_			*endpt;
	VFNqiim 			b1cu, e1cu;
	dqsoptions_ 	opt;
	int k, K;	short* buf;
	int stopped;
public:
	int	 done()	{ return (stopped||endpt->ended);	}
	int  showstatus	();
	int  fillfront 	(){ return endpt->fillfront(); }//??
public:
	void beg()	{ if(b1cu) b1cu(&qiimbuf); }
	void end()	{ if(!stopped&&e1cu) e1cu(&qiimbuf); }
	char*		endptstatus() { return endpt->status(); }
	void		stopall (char stop4exit1=0)
				{stopped=1;owdef.stopclose();spmsg.istatus("");}
	void bufset2(int seconds)
							{
								int K1=seconds*opt.nsamprate;
								qiimbuf.init2(K1);
								K=seconds*opt.nframerate;
							}
};


class 	qiimpack2_ {
public:	qiimpack2_(VFNqiim fn_end1cu, VFNV fn_adaptgetsok=0)
				:	wts(nDQS_FSS, 7, 2, 3),
					beWTS(&wts),
					endpt(&beWTS),
					adapttn(fn_adaptgetsok,&wts, 100),
					siuqiim(100,&endpt,fn_end1cu)
					{
					}
public:
	HANDLE hnd; uint id;
	void init_thread() { hnd=NULL; id=0;}
	void dele_thread() { if(hnd) CloseHandle(hnd); hnd=0;}
static uint WINAPI
	sithread(void*pv) {	qiimpack2_*t=(qiimpack2_*)pv;	t->siuqiim.begthread();
											//while(t->siuqiim.hnd)Sleep(100);
											t->dele_thread();
											return 0; }
static uint WINAPI
	dsthread(void*pv) {	qiimpack2_*t=(qiimpack2_*)pv;	t->adapttn.begthread();
											//while(t->adapttn.hnd)Sleep(100);
											t->dele_thread();
											return 0; }
	void begsiuim	() { 	dele_thread();	 hnd=(HANDLE)
											_beginthreadex(NULL,0,sithread,this,0,&id);
											//dele_thread();
									 }
	void begadapt	() { 	dele_thread();	 hnd=(HANDLE)
											_beginthreadex(NULL,0,dsthread,this,0,&id);
											//dele_thread();
									 }
public:
	void		adapt		()	{	stopall(100); begadapt();	}
	void		siuim		()	{	stopall(100); begsiuim();	}
	void		stopall	(int msec=200)	{ siuqiim.stopall(); Sleep(msec); }
public:
	WTS_ 						wts;//(nDQS_FSS, 7, 2, 3);
	beL12_  				beL12;
	beWTS_ 					beWTS;//(&wts);
	endpoint_ 			endpt;//(&beWTS);
	adaptation2_  	adapttn;// (0, &wts, 100);
	siuqiim3_      	siuqiim;//(100, &endpoint, qiimfns_(NULL,fn_end1cu,NULL) );
};





#endif //#ifndef SPEECHIO_H




