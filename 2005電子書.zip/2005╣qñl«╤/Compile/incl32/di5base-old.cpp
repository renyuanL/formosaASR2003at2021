//
// di5base.cpp
//

// copyright 1994~2k Gang, IrngZin

#ifndef DI5BASE_CPP
#define DI5BASE_CPP

#include <di5base.h>
//#ifdef _WINDOWS
#include<windows.h>
//#endif //#ifdef _WINDOWS

//////////////////////////////////////
// tos
static
char* tos_buf()
{
	const nMAX=16;
	static char s[nMAX][257];  static int  n=0;
	n++; if(n>=nMAX-4)n=0; return s[n];
}
char
*tosfmtc	="%c",
*tosfmts	="%s",
*tosfmtuh	="%uh",
*tosfmtd	="%d",
*tosfmth	="%h",
*tosfmtld	="%ld",
*tosfmtf	="%f",
*tosfmtlf	="%lf";

// r: result string[128]
char* tos(char   v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(char*  v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(USHORT v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(int    v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(short  v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(long   v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(float  v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(double v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}

char*ntos(char*  v, int   len) // copy at most len char's
{
	if(len>256) len=256; char*s=tos_buf(); char*t=s;int l=0;
	while(*v){if(l++<len)*s++=*v++;else break;} s[l]=0;
	return t;
}
// tos
//////////////////////////////////////

//////////////////////////////////////
// class messagebox_
//#include <iostream.h>

messagebox_ msg;


void messagebox_::mmode_autoset()
{
	#ifdef _CONSOLE
	mm=DI5MSG_MDOS;
	#else
	mm=DI5MSG_MWIN;
	#endif
}

char messagebox_::msg     (cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	if(mm==DI5MSG_MNULL) return '1';
	if(mm==DI5MSG_MAUTO) mmode_autoset();
	if(mm==DI5MSG_MDOS) {
		if(s1)puts(s1);
		if(s2)puts(s2);
		if(s3)puts(s3);
		if(s4)puts(s4);
//		cout<<((s1)?s1:"")
//				<<((s2)?s2:"")
//				<<((s3)?s3:"")
//				<<((s4)?s4:"")<<flush;
		return '1';
	}
	if(mm==DI5MSG_MWIN) {
#ifdef _WINDOWS
		MessageBox(NULL,s2,s1,MB_OK); return '1';
#endif //#ifdef _WINDOWS
	}
	return '1';
}

char messagebox_::pause   (cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	msg(s1,s2,s3,s4);	char c='1';
	if(mm==DI5MSG_MDOS){c=getch();}
	return c;
}

char messagebox_::ask4quit(cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	msg(s1,s2,s3,s4);
	char c=pause("type q or x to quit, others to continue if possible\n");
	if(c=='q'||c=='Q'||c=='x'||c=='X')return 1; return 0;
}
char messagebox_::ask4exit(cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	msg(s1,s2,s3,s4);
	char c=pause("type q or x to exit, others to continue if possible\n");
	if(c=='q'||c=='Q'||c=='x'||c=='X')exit(0); return 0;
}
static
char messagebox(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0)
{ return msgbox(s1,s2,s3,s4); }

//////////////////////////////////////
// class stepmsg_
void stepmsg_::inc()
{ if(++i%ntv==0) messagebox(tos(i/1000), "K\t"); }

void stepmsg_::showfull(const char*pre_s, const char*post_s)
{
	messagebox( ((pre_s)?pre_s:""), tos(i), ((post_s)?post_s:"\t") );
	//	cout<<((pre_s)?pre_s:"")<<i<<((post_s)?post_s:"\t")<<flush;
}
// class stepmsg_
//////////////////////////////////////

void curpath::init()
{
	char s[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,s);
	path=s; sz=strlen(s);
}

char* curpath::get(int withbackslash)
{
	if(sz>0){
		char c=path.s[sz-1];
		if(withbackslash){
			if(c!='\\') {path+="\\";sz++;}
		}else{
			if(c=='\\') {path.s[sz-1]=0;sz--;}
		}
	}
	return path.s;
}
static curpath exepath;
char* getexepath(int withbackslash)
{
	return exepath(withbackslash);
}
//////////////////////////////////////
// class sis_ : all static function
//  except rbytes/lbytes that need AnsiNext/AnsiPrev, so in tyio below

char* str_search4(char* s, char c)
{ //return null if not found
  char* p=0; int n012;
  while(*s){n012=is012(s);if((n012==1)&&(*s==c)){p=s;break;}else s+=n012;}
  return p;
}

char* str_search4crnl(char* s)
{ //return null if not found
  char* p=str_search4(s,'\r');
  if(!p) return 0;
  if(*(p+1)!='\n') return 0;
  return p;
}

int	str_countlet(char* t)
{
	int n=0; char* s;
	while(*t) {
		s=str_search4crnl(t);
		if(!s) { return (*t)?n+1:n; }
		n++; t=s+2;
	}
	return n;
}


char* str_search4crORnl(char*s, int* nbytes_returned)
{ //return null if not found
  char* p=0;
  while( *s!=0 ) { if( (*s =='\r')||(*s == '\n') ) { p=s; break; } else s++; }
  if(*s =='\r') { if(s[1]=='\n') { *nbytes_returned=2; return p; } }
//  if(*s =='\r') {
//  	if(s[1]=='\n') { *nbytes_returned=2; return p; }
//    else if( (s[1]=='\r')&&(s[2]=='\n') ){*nbytes_returned=3; return p; }
//  }
	if(*s =='\n') { *nbytes_returned=(s[1]=='\r')?2:1; return p; }
	//if(*s =='\n') { *nbytes_returned=1; return p; }
	return p;
}
int isbig5punct(char*s)
{
	//int res=is012(s); if(res!=2) return 0;
	if(s[0]=='\xa1') return 1;
	else if( (s[0]=='\xa2')&&
					((unsigned char)(s[1]) <= (unsigned char)'\x4e') ) return 1;
	return 0;
}

int str_delfirstN(char* s, int N)
{
	int len=strlen(s);
	if(N>=len){*s=0; return len;}
	char*t=s; char* src=s+N;
	while(*(src)){*t++=*src++;} *t=0;
	return N;
}

char* str_skipheadblank0   (char* s)
{
	char* t, *sc;
	if(s&&s[0]) {
		sc=s; while(istabspace(sc[0])) sc++;
		if(sc==s) return s;
		t=s;
		while(*sc) *t++=*sc++; *t=0;
	}
	return s;
}

int str_delleadspaces(char* s)
{
	char* t, *sc;
	if(s&&s[0]) {
		//sc=s; while( (*sc)&&istabspace(sc[0]) ) sc++;
		sc=s; while( (*sc)&&is_tsrn(sc[0]) ) sc++;
		if(sc==s) return 0;
		t=s;
		while(*sc) *t++=*sc++;*t=0;
		return sc-s;
	}
	return 0;
}

int str_delltspaces(char* s)
{
	char* t, *sc, *lastblank;
	int len, olen=strlen(s);
	if(s&&s[0]) {
		//sc=s; while( (*sc)&&istabspace(sc[0]) ) sc++;
		sc=s; while( (*sc)&&is_tsrn(sc[0]) ) sc++;
		if(*sc==0) { *s=0; return sc-s; }
		t=s; lastblank=t;
		//while(*sc){ *t=*sc++; if(!istabspace(*t)) { lastblank=t+1; }t++;}*t=0;
		while(*sc){ *t=*sc++; if(!is_tsrn(*t)) { lastblank=t+1; }t++;}*t=0;
		*lastblank=0;
	}
	len=strlen(s);
	return olen-len;
}


int str_deltrailspaces(char* s)
{
	char* t, *sc, *lastblank;
	int len, olen=strlen(s);
	if(s&&s[0]) {
		sc=s;
		t=s; lastblank=t;
		//while(*sc){ *t=*sc++; if(!istabspace(*t)) { lastblank=t+1; }t++;}*t=0;
		while(*sc){ *t=*sc++; if(!is_tsrn(*t)) { lastblank=t+1; }t++;}*t=0;
		*lastblank=0;
	}
	len=strlen(s);
	return olen-len;
}



int		str_isin(char c, char* s)
{
	while(*s) if(c== (*s++)) return 1;
	return 0;
}

void  str_tolower			 (char* s)
{
	int res;
	while(*s) {
		res=is012(s);	if(res==1) { *s=char(tolower(*s)); }
		s+=res;
	}
}

int  str_replacepunct (char*s, char rt)
{
	char*p=s; if(!p) return 0; int nreplaced=0;
	int res;
	while(*s) {
		res=is012(s);
		if(res==1) { if(ispunct(*s)){if(rt)*p++=rt;s++;nreplaced++;} else *p++=*s++;}
		else{
			if(isbig5punct(s)){if(rt){*p++=rt;*p++=rt;}s+=2;nreplaced++;}
			else{*p++=*s++;*p++=*s++;}
		}
	}
	*p=0;
	return nreplaced;
}

int str_replacedigits(char*s, char r)
{// r: replacement
  char*p=s; if(!p) return 0; int nreplaced=0;
  int res;
  while(*s) {
    res=is012(s);
    if(res!=1) { *p++ = *s++; *p++ = *s++; continue; }
    else if(isdigit(*s)) { if(r) *p++=r; s++; nreplaced++; }
		else { *p++ = *s++; }
  }
  *p=0;
	return nreplaced;
}

//void str_replace(char*s, char tobereplaced, char replacement=0);
//=0 default to 0 means for removement
char*dt;
int str_replace(char*s, char tbr, char r)
{//tbr: tobereplaced, r: replacement
	dt=s; int nreplaced=0;
  char*p=s; if(!p) return 0;
  int res;
  while(*s) {
    res=is012(s);
    if(res==2) 				{ *p++ = *s++; *p++ = *s++; continue; }
    else if(*s ==tbr) { if(r) *p++=r; s++; nreplaced++;}
    else							{ *p++ = *s++; }
  }
  *p=0;
	return nreplaced;
}

int str_trts(char* s, char ch2rep) // tr tab/space
{
	char* t=s; int n012; int n=0;
	while(*t) {
		n012=is012(t);
		if(n012!=1) { t+=n012; continue; }
		if((*t==' ')||(*t=='\t')) { *t++=ch2rep; n++; } else t++;
	}
	return n;
}


void str_replacewchar(char*s, char* rt, char r)
{//rt: tobereplaced, r: replacement
  char*p=s; if(!p) return;
  int res;
  while(*s) {
    res=is012(s);
    if(res!=2) { *p++ = *s++; continue; }
    else if( (s[0]==rt[0]) && (s[1]==rt[1]) ){ if(r) *p++=r; s+=2; }
		else { *p++ = *s++; *p++ = *s++; }
  }
  *p=0;
}


int str_ki2it(char*str)
{
	if(isdigit(*str)) return 0;
	char* s=str+1, *t=str+1;
	//bool nopick=true;
	int  nopick=1;
	while(*s) {
		if(nopick&&(isalpha(*s))) { s++; continue; }
		if(isdigit(*s)) { nopick=0; s++; }
		if(*s == '-') { nopick=0; s++; }
		*t ++ = *s++; nopick=1;
	}
	*t=0;
	return strlen(str);
}

void str_deldigits(char*s)
{
  char*p=s; if(!p) return;
  int res;
  //while(*s) if(*s==rt) {if(r)*p=r;else s++;} else *p++ = *s++;
  while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(isdigit(*s)) s++; else *p++=*s++;
	}
	*p=0;
}

void str_delbutdigits(char*s)
{
	char*p=s; if(!p) return;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(!isdigit(*s)) s++; else *p++=*s++;
	}
	*p=0;
}

void str_delbutpuncts(char*s)
{
	char*p=s; if(!p) return;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(!ispunct(*s)) s++; else *p++=*s++;
	}
	*p=0;
}

void str_delbutpunctdigits(char*s)
{
	char*p=s; if(!p) return;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(!(isdigit(*s)||ispunct(*s))) s++; else *p++=*s++;
	}
	*p=0;
}

void str_del4wis(char* s)
{
  char*p=s; if(!p) return;  int res;
  while(*s) {
		res=is012(s);
    if(res==2) break;
    if( isdigit(*s) ) { s++;p++;}  else break;
  }
  while(*s) {
    res=is012(s);
    if(res==2) { *p++=*s++;*p++=*s++; continue; }
    if( isdigit(*s) || (*s =='-') ) s++; else *p++=*s++;
  }
  *p=0;
}

char* orset_1stoption1(char* src)
{
	if(!str_isorset(src)) return src;
	chars* s=getcharsbuf(); *s=src+1; (*s).dellastN(1); // get rid of ()
	if(str_find1(s->s,'(')>=0) return src;
	if(str_find1(s->s,')')>=0) return src;
	int len=s->find('|'); if(len<0) len=s->size(); s->s[len]=0;
	return s->s;
}

char* orset_1stoption(char* src)
{
	static chars s; static charspp spp;
	char chs[2]; chs[0]=ch01; chs[2]=0;
	s=src;
	s.inssep4hanlor(chs);
	s.tr('-',' ');
	spp.set2Ncut(s.s, ch01); s.clear();
	int n,N=0;
	for(n=0; n<spp.size(); n++) {
		if(str_isblank(spp[n])) continue;
		s.app(orset_1stoption1(spp[n]));
		s.app('-');
		N++;
	}
	if(N>0) s.dellastN(1);
	return s.s;
}

int str_all1byte (char*s)
{int n; while(*s){n=is012(s);if(n!=1)return 0;s+=1;}return 1;}

int str_alldigits(char* s)
{int n; while(*s){n=is012(s);if(n!=1)return 0;if(!isdigit(*s))return 0;s+=1;}return 1;}

int str_hasdigit(char* s)
{int n; while(*s){n=is012(s);if(n==1)if(isdigit(*s))return 1;s+=n;}return 0;}

int str_isorset(char* s)// strict, true if is (...), and no l/t spaces
{
	int len=strlen(s);
	if(s[0]=='('&&s[len-1]==')') return 1;
	return 0;
}

int str_hasorset(char* s)// loose, true if has ( or ) or |
{
	char* ss=s; int res;
	while(*ss) {
		res=is012(ss); if(res!=1) { ss+=res; continue; }
		if((*ss == '(')||(*ss == ')')||(*ss == '|')) { return 1; }
		ss++;
	}
	return 0;
}


int str_mayberi(char* s)
{ int n;
  while(*s) {
		n=is012(s);
		if( (n==2) || (s[0]=='*') ) return 1;
		s+=n;
	}
	return 0;
}

int		str_startwith(char* s, char* match, int N)
{
	if(N<0) N=strlen(match);
	return (strncmp(s,match,N)==0);
}

int		str_endwith		 (char* s, char* match, int N)
{
	if(N<0) N=strlen(match);
	int len=strlen(s); if(len<N) return 0;
	return (strncmp(s+len-N,match,N)==0);
}

int		str_find		 (char* s, char* match, int N)
//r startpos of match in s, 0-based, simple match only
{
	if(N<0) N=strlen(match);
	int len=strlen(s); char* t=s;
	while(len>=N) {
		if(strncmp(t,match,N)==0) return (t-s);
		t++; len--;
	}
	return -1;
}

int str_nchar(char* s, char c)
{
	int n=0, n012;
	if(!(s&&s[0])) return n;
	while(*s){
		n012=is012(s);
		if(n012==1&&s[0]==c) n++;
		s+=n012;
	}
	return n;
}


int   str_isSS(char*s)    // slash slash
{
  char* p=s;
  while( istabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' ) return 1;
	int n=strlen(p); if(n<2) return 0;
	p+=n-2;
  if( p[0]=='/' && p[1]=='/' ) return 1;
  return 0;
}

int   str_isSSEE(char*s)  // slash slash exclamation exclamation
{
  char* p=s;
  while( istabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' && p[3]=='!' && p[4]=='!' ) return 1;
  return 0;  // p[2] not checked for section note
}

int   str_isblank(char*s) // is blank
{
  char* p=s;
  while( istabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 1;
  return 0;
}

int		str_isgline	 (char* s)
{
  char* p=s;
  while( istabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  return !str_isSS(p);
}

int   str_isPBC (char* s, char c1st, char clast, char c)
{
  while( istabspace(*s) ) if( *s==0) break; else s++;
  if(*s==0) return 0; // strip off leading space

  if(s[0]!=c1st) return 0;
  char* p= s+1; p += strlen(p);     // p point to null
  p--; while( istabspace(*p) ) p--; // c1st should not be tabspace,
                                    // strip off trailing sapce
	int ll=p-s;  // now ll is strlen of str -1(-1 4 c1st), p points to last char
  if(ll==1) { if(c!=0) return 0; return (*p == clast)? 1:0; }
  if(*p != clast) return 0;
  if(c) { if( p[-1] != c) return 0; }
	return 1;
}

str_hashanri(char* t)
{
  while(*t) if(is012(t)>1) { return 1;}else t++;
  return 0;
}


void str_tokendelimpos(char*s, voids<int>* p)
{
	p->clear();
  if( (!s)&&(!s[0]) ) return;
  char* t=s; int n012;
  int zingsitoken;
  zingsitoken=(istabspace(t[0]))?1:0;
  while(*t) {
  	n012=is012(t);
    if( (n012==1)&&istabspace(*t) ) {
			if(zingsitoken==1) p->app(t-s);
      zingsitoken=0;
    }else{
			if(zingsitoken==0) p->app(t-s);
      zingsitoken=1;
    }
    t+=n012;
  }
  p->app(t-s);
}

void str_auto_simple_bendiau(chars* im, int lastdanridiau)
{
	static chars s; s.clear(); char* last=0;
  int n012; char bendiau;
  char*fm=im->s;//, *to=im->s;
  while((*fm)&&(isdigit(*fm))) { s.app(fm,1); fm++; } // safe guard against leading digits
	while(*fm) {
  	n012=is012(fm);
    if(n012==2) 			{ s.app(fm,2); fm+=2; continue; }
		if(!isdigit(*fm)) { s.app(fm,1); fm++ ; continue; }
    if(fm[1]&&isdigit(fm[1])) {
    	if(fm[2]&&isdigit(fm[2])){ // 3 or more digits in a row
      	while( (fm[0])&&(isdigit(fm[0])) ) { s.app(fm, 1); fm++; }
        continue;
      }
      s.app(fm,2); last=0; fm+=2;  continue;
    }else{
    	switch(*fm){
      case '1': bendiau='2'; break;
			case '2': bendiau='3'; break;
      case '3': bendiau='4'; break;
      case '4': bendiau='1'; break;
      case '5': bendiau='2'; break;
      case '6': bendiau='8'; break;
      case '7': bendiau='6'; break;
      }
      s.app(fm,1); last=im->s+s.size(); fm++; s.app(bendiau); continue;
    }
  }
	int ndel;
  if(last&&lastdanridiau) {
  	ndel=last-im->s;
  	s.s[ndel]=s.s[ndel-1];
  }
  im->set2(s.s);
}

void  str_kauqidiau_pos(char*s, voids<int>* p, int singlediau)
{
	int n012;
	char*fm=s, *to=s; p->clear();
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ fm+=2; continue; }
		if(!isdigit(*fm)) { fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2])) // 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) fm++; continue; }
			fm++; p->app(fm-to); fm++; continue;
		}else{
			if(singlediau)
				{ p->app(fm-to); fm++; continue; }
		}
		fm++;
	}
}

int  str_kauqidiau_pos(char*s, vector<int>& p, int singlediau)
{
	int n012;
	char*fm=s, *to=s; p.clear();
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ fm+=2; continue; }
		if(!isdigit(*fm)) { fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2]))// 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) fm++; continue; }
			fm++; p.push_back(fm-to); fm++; continue;
		}else{
			if(singlediau)
				{ p.push_back(fm-to); fm++; continue; }
		}
		fm++;
	}
	return p.size();
}

int  str_danridiau_pos(char*s, vector<int>& p)
{
	int n012;
	char*fm=s, *to=s; p.clear();
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ fm+=2; continue; }
		if(!isdigit(*fm)) { fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2]))// 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) fm++; continue; }
			p.push_back(fm-to); fm+=2; continue;
		}else{
			//if(singlediau)
				{ p.push_back(fm-to); fm++; continue; }
		}
		//fm++;
	}
	return p.size();
}

void  str_del4kauqidiau(char*s)
{
	//int n=strlen(s);
	int n012;
	char*fm=s, *to=s;
	//for(int ii=0; ii<n; ii++) {
	while(*fm) {
		n012=is012(fm);
		if(n012==2) { *to++=*fm++; *to++=*fm++; continue; }
		if(!isdigit(*fm)) { *to++=*fm++; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2])) // 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) *to++=*fm++; continue; }
			if( (to!=s)&&(to[-1]=='h')&&
					(	(fm[1]=='1')||(fm[1]=='2')||
						(fm[1]=='3')||(fm[1]=='4')||(fm[1]=='5'))
				) {
					to--;
					//if(fm[1]=='6')fm[1]='4';
					//if(fm[1]=='8')fm[1]='3';
			}
			fm++; *to++=*fm++; continue;
		}
		*to++=*fm++;
	}
	*to=0;
}

void  str_del4danridiau(char*s)
{
	//int n=strlen(s);
	int n012;
	char*fm=s, *to=s;
	//for(int ii=0; ii<n; ii++) {
	while(*fm) {
		n012=is012(fm);
		if(n012==2) { *to++=*fm++; *to++=*fm++; continue; }
		if(!isdigit(*fm)) { *to++=*fm++; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2])) // 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) *to++=*fm++; continue; }
			else {
				*to++=*fm++; fm++; continue;
			}
		}
		*to++=*fm++;
	}
	*to=0;
}


char* str_daiqibendiau(char* danridiau)
{
	static chars s; s.set2(danridiau);
	char c=s.lastbyte(); s.dellastbyte();
	switch(c) {
		case'1': c='2';break;
		case'2': c='3';break;
		case'3': c='4';break;
		case'4': c='1';break;
		case'5': c='2';break;
		case'6': if(s.lastbyte()=='h') { s.dellastbyte();c='3';}
						 else c='8';break;
		case'7': if(s.lastbyte()=='h') { s.dellastbyte();c='4';}
						 else c='6';break;
	}
	s.app(c);
	return s.s;
}



#ifdef OLDOLDOLDOLD

int sis_:: big5punct	(char* s)
{
	if(s[0]=='\xa1') return 1;
	else if( (s[0]=='\xa2')&&
					((uchar)(s[1]) <= (uchar)'\x4e') ) return 1;
	return 0;
}

int sis_:: in					(char  c, char*s)
{	while(*s) if(c== (*s++)) return 1;  return 0; }

int sis_:: alldigits	(char* s)
{int n; while(*s){n=is012(s);if(n!=1)return 0;if(!isdigit(*s))return 0;s+=1;}return 1;}

int sis_:: hasdigit		(char* s)
{int n; while(*s){n=is012(s);if(n==1)if(isdigit(*s))return 1;s+=n;}return 0;}

int sis_:: hashanri		(char* s)
{
  while(*s) if(is012(s)>1) { return 1;}else s++;
  return 0;
}

int sis_:: hasorset		(char* s)
{
	char* ss=s; int res;
	while(*ss) {
		res=is012(ss); if(res!=1) { ss+=res; continue; }
		if((*ss == '(')||(*ss == ')')||(*ss == '|')) { return 1; }
		ss++;
  }
	return 0;
}

int sis_:: mayberi		(char* s)
{ int n;
  while(*s) {
		n=is012(s);
		if( (n==2) || (s[0]=='*') ) return 1;
		s+=n;
	}
	return 0;
}


int sis_:: all1byte		(char* s)
{int n; while(*s){n=is012(s);if(n!=1)return 0;s+=1;}return 1;}

char* sis_:: skiptabsp0(char* s)
{
  char* p=s;
  while( tabspace(*p) ) if( *p==0) break; else p++;
	return p;
}

int sis_:: blank			(char* s)
{
  char* p=skiptabspace(s);
  if(*p==0) return 1;
  return 0;
}

int sis_:: gline		(char* s)
{
  char* p=skiptabspace(s);
  if(*p==0) return 0;
  return !SS(p);
}



int sis_:: SS  (char* s)// slash slash at beg or at end
{
  char* p=s;
  while( tabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' ) return 1;
	int n=strlen(p); if(n<2) return 0;
	p+=n-2;
  if( p[0]=='/' && p[1]=='/' ) return 1;
  return 0;
}

int sis_:: SSEE(char* s)// slash slash exclamation exclamation
{
  char* p=s;
  while( tabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' && p[3]=='!' && p[4]=='!' ) return 1;
	return 0;  // p[2] not checked for section note
}


int sis_:: PBC (char* s, char c1st, char clast, char c)
{
  while( tabspace(*s) ) if( *s==0) break; else s++;
  if(*s==0) return 0; // strip off leading space

  if(s[0]!=c1st) return 0;
  char* p= s+1; p += strlen(p);     // p point to null
  p--; while( tabspace(*p) ) p--; // c1st should not be tabspace,
                                    // strip off trailing sapce
  int ll=p-s;  // now ll is strlen of str -1(-1 4 c1st), p points to last char
  if(ll==1) { if(c!=0) return 0; return (*p == clast)? 1:0; }
  if(*p != clast) return 0;
  if(c) { if( p[-1] != c) return 0; }
  return 1;
}

/*
char* sis_:: tolower(char* s)
{
	int res;
	while(*s) {
		res=is012(s);	if(res==1) { *s=tolower(*s); }
    s+=res;
	}
}
*/

int sis_:: sw(char* s, char* match, int N)
{
	if(N<0) N=strlen(match);
	return (strncmp(s,match,N)==0);
}


int sis_:: ew(char* s, char* match, int N)
{
	if(N<0) N=strlen(match);
  int len=strlen(s);
  if(N>len) return 0;
  return (strcmp(s+len-N, match)==0);
}




char* sis_:: search4			(char* s, char c)
{ //return null if not found
  char* p=0; int n012;
  while(*s){n012=is012(s);if((n012==1)&&(*s==c)){p=s;break;}else s+=n012;}
  return p;
}

char* sis_:: search4crnl	(char* s)
{ //return null if not found
  char* p=search4(s,'\r');
  if(!p) return 0;
  if(*(p+1)!='\n') return 0;
  return p;
}

char* sis_:: search4crORnl(char* s, int* nbytes_returned)
{ //return null if not found
  char* p=0;
  while( *s!=0 ) 
		{ if( (*s =='\r')||(*s == '\n') ) { p=s; break; } else s++; }
  if(*s =='\r') { if(s[1]=='\n') { *nbytes_returned=2; return p; } }
  if(*s =='\n') { *nbytes_returned=(s[1]=='\r')?2:1; return p; }
  return p;
}



int sis_:: replacepunct (char* s, char r)
{// r: replacement
	char*p=s; if(!p) return 0; int nreplaced=0;
	int res;
	while(*s) {
		res=is012(s);
		if(res==1) { 
			if(ispunct(*s)){if(r)*p++=r;s++;nreplaced++;} 
			else *p++=*s++;
		}else{
			if(big5punct(s)){if(r){*p++=r;*p++=r;}s+=2;nreplaced++;}
			else{*p++=*s++;*p++=*s++;}
		}
	}
  *p=0;
	return nreplaced;
}


int sis_:: replacedigits(char* s, char r)
{// r: replacement
  char*p=s; if(!p) return 0; int nreplaced=0;
  int res;
  while(*s) {
    res=is012(s);
    if(res!=1) { *p++ = *s++; *p++ = *s++; continue; }
    else if(isdigit(*s)) { if(r) *p++=r; s++; nreplaced++; }
		else { *p++ = *s++; }
  }
  *p=0;
	return nreplaced;
}

int sis_:: replacewchar(char*s, char* tbr, char r)
{//tbr: tobereplaced, r: replacement
  char*p=s; if(!p) return 0;
  int res;
	int nreplaced=0;
  while(*s) {
    res=is012(s);
    if(res!=2) { *p++ = *s++; continue; }
    else if( (s[0]==tbr[0]) && (s[1]==tbr[1]) ){ if(r) *p++=r; s+=2; nreplaced++;}
		else { *p++ = *s++; *p++ = *s++; }
  }
  *p=0;
	return nreplaced;
}

int sis_:: 
replace (char*s, char tbr, char r)  // ret: num replaced
{//tbr: tobereplaced, r: replacement
	int nreplaced=0;
  char*p=s; if(!p) return 0;
  int res;
  while(*s) {
		res=is012(s);
    if(res==2) 				{ *p++ = *s++; *p++ = *s++; continue; }
    else if(*s ==tbr) { if(r) *p++=r; s++; nreplaced++; }
    else							{ *p++ = *s++; }
	}
  *p=0;
	return nreplaced;
}

#endif //#ifdef OLDOLDOLDOLD


// class sis_ : all static function
//////////////////////////////////////


//////////////////////////////////////
// binary search routine

int __cdecl wislower (
        const void *key,
        const void *base,
        size_t num_elements,
        size_t width,
        int (__cdecl *wis)(const void *, const void *)
        )
{
  unsigned int half, num=num_elements;
  char *lo = (char *)base;
  char *hi = (char *)base + (num - 1) * width;
  char *mid;
	int result;

	if( (*wis)(key, lo) <= 0 ) return 0;
//if( (*wis)(hi, key) <  0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi) >  0 ) return num_elements; // in stl sense
	// so keep  lo < key <= hi

  while ( ( num=(hi - lo)/ width) > 1 ) {
    half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid);
		if(result<=0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

int __cdecl wisupper (
        const void *key,
        const void *base,
        size_t num_elements,
        size_t width,
        int (__cdecl *wis)(const void *, const void *)
        )
{
  unsigned int half, num=num_elements;
  char *lo = (char *)base;
  char *hi = (char *)base + (num - 1) * width;
	char *mid;
  int result;

	if( (*wis)(key, lo) <  0 ) return 0;
//if( (*wis)(hi, key) <= 0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi) >= 0 ) return num_elements; // in stl sense
	// so keep  lo <= key < hi

  while ( ( num=(hi - lo)/ width) > 1 ) {
    half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid);
		if(result< 0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

int __cdecl wislower1 (
        const void *key,
        const void *base,
        size_t num_elements,
        size_t width,
        int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
        )
{
  unsigned int half, num=num_elements;
	char *lo = (char *)base;
  char *hi = (char *)base + (num - 1) * width;
  char *mid;
  int result;

	if( (*wis)(key, lo, database) <= 0 ) return 0;
//if( (*wis)(hi, key) <  0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi, database) >  0 ) return num_elements; // in stl sense
	// so keep  lo < key <= hi

  while ( ( num=(hi - lo)/ width) > 1 ) {
    half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid, database);
		if(result<=0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

int __cdecl wisupper1 (
        const void *key,
        const void *base,
        size_t num_elements,
        size_t width,
        int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
        )
{
  unsigned int half, num=num_elements;
  char *lo = (char *)base;
  char *hi = (char *)base + (num - 1) * width;
  char *mid;
  int result;

	if( (*wis)(key, lo, database) <  0 ) return 0;
//if( (*wis)(hi, key) <= 0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi, database) >= 0 ) return num_elements; // in stl sense
	// so keep  lo <= key < hi

  while ( ( num=(hi - lo)/ width) > 1 ) {
    half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid, database);
		if(result< 0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

static void * __cdecl bfind0 ( // copied from bsearch
        const void *key,
        const void *base,
        size_t num, // num_elem
        size_t width,
        int (__cdecl *compare)(const void *, const void *)
				)
{
        char *lo = (char *)base;
        char *hi = (char *)base + (num - 1) * width;
        char *mid;
        unsigned int half;
        int result;

				while (lo <= hi){
								//if (half = num / 2)
								half=num/2; if (half)
								{
												mid = lo + (num & 1 ? half : (half - 1)) * width;
												//if (!(result = (*compare)(key,mid)))
												result = (*compare)(key,mid);if (!(result))
																return(mid);
												else if (result < 0)
												{
																hi = mid - width;
																num = num & 1 ? half : half-1;
												}
												else    {
																lo = mid + width;
																num = half;
												}
								}
								else if (num)
												return((*compare)(key,lo) ? NULL : lo);
								else
												break;
				}

				return(NULL);
}

int __cdecl bfind ( // same as bsearch
				const void *key,
				const void *base,
				size_t num, // num_elem
				size_t width,
				int (__cdecl *compare)(const void *, const void *)
				)
{
	void*r=bfind0(key,base,num,width,compare);
	if(!r) return -1;
	return ((char*)r-(char*)base)/width;
}

int bfindlast(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res< 0) {return -1;}
	res=strcmp(s, dt[N*(NSZ-1)]); if(res> 0) {return -1;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])<0) up=md;else lo=md;
	}
	if(strcmp(s,dt[N*lo])!=0) return -1;
	return lo;
}

int bfind(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res< 0) {return -1;} if(res==0) return 0;
	res=strcmp(s, dt[N*(NSZ-1)]); if(res> 0) {return -1;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])<=0) up=md;else lo=md;
	}
	if(strcmp(s,dt[N*up])!=0) return -1;
	return up;
}

int lower(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res<= 0) {return 0;}
	res=strcmp(s, dt[N*(NSZ-1)]); if(res>  0) {return NSZ;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])<=0) up=md;else lo=md;
	}
	return up;
}

int upper(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res<  0) {return 0;}
	res=strcmp(s, dt[N*(NSZ-1)]); if(res>= 0) {return NSZ;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])< 0) up=md;else lo=md;
	}
	return up;
}




// binary search routine
//////////////////////////////////////


//////////////////////////////////////
// chars pool
enum CHARSSTYR_ {MAX_TYSTATICS_=60};

class charsbufs_{ 
	chars ss[MAX_TYSTATICS_]; int i;
public:  
	charsbufs_():i(0){}
	chars* operator()() 
		{ i++; if(i>=MAX_TYSTATICS_) i=0; ss[i].set20();return &ss[i];}
}; 
static charsbufs_ charsbufs_1; // these are actually buf's

chars* getcharsbuf() 
{ return charsbufs_1(); } // return a chars from a poll


int chars_hunNbohun(charpp& pp, chars& ss, int N, char crnl_replacement)
{ // ss pp are resizable
	pp.clear();
  char* p=ss.s; int n;
  str_replace(p,'\r',crnl_replacement);
  str_replace(p,'\n',crnl_replacement);
	str_replacewchar(p,"�@",' '); // zuanhing space to buannhing space

  while( istabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;

  pp.set20();
  for(n=0; n<N; n++) {
    pp.app(p);
    while(!istabspace(*p)) if( *p==0) break; else p++;
		if( (*p==0)||(pp.sz==N) ) return pp.sz;
    *p=0; p++;
    while( istabspace(*p)) if( *p==0) break; else p++;
    if(*p==0) return pp.sz;
  }
  return N;
}

int chars_cut(charpp&pp, chars& s, char ch, int N)
{ // s pp are resizable
  pp.clear(); 
  char* p=s.s; int n; int n012;
  if(*p==0) return 0;
	pp.app(p); n=1;
	while(*p) {
		if(pp.size()>N) return n;
		n012=is012(p);
		if(n012!=1)
			{ p+=n012; continue; }
		if(*p==ch)
			{*p=0; p++; pp.app(p);}
		else p++;
	}
	return pp.size();
}


int chars_hunNlet(charpp& pp, chars& ss, int N)
{ // ss pp are resizable
	if(!ss.s) return 0;
  char* p=ss.s; //char* s=p;
  int crnlbytes; int n;
  pp.set20();
  for(n=0; n<N; n++) {
		if(*p ==0) break;
    pp.app(p);
    p=str_search4crORnl(p, &crnlbytes);
		if( (!p)||(pp.sz==N) ) return pp.sz;
		*p=0;
		p+= crnlbytes;
  }
  return pp.sz;
}


// chars pool
//////////////////////////////////////



//////////////////////////////////////
// class chars

int  chars::
resize(int size)
{
	if(size<=asize)return 1;// resize will own mem
	int oldsz=asize; s=(char*)realloc(s,size);
	if(s){
		asize=size;
		if(oldsz==0) s[0]=0;
		return 1;
	}
	return 0;
}

int  chars::
nextsize(int newsize)
{
	int n=asize;
	if(n<newsize)n=newsize;
	if(n<asize)return asize;
	if(n<=16)return 16;
	if(n<=1024)return 2*n;
	return int(n*1.1);
}

char*	chars::
tosxa	 (char* ki, int begWspace)//tos to xml attribute: ki="..."
{
	chars* t=getcharsbuf();
	if((ki&&ki[0])) {
		if(begWspace) t->app(" ");
		t->app(ki); t->app("\""); t->app(s);t->app("\"");
	}
	return t->s;
}


int  chars::
inssep4012(char* sep)
{
	chars ts; char* t; int n012;
	t=s;
	while(*t) {
		n012=is012(t);
		ts.app(t,n012); ts+=sep;
		t+=n012;
	}
	set2(ts.s);
	return 1;
}

int  chars::
inssep4hanlor(char* sep, int hunguao)// def to "\t"/0
{
	chars ts; char* t;
	int tauzing=0, henzai, n012; int nHANRI=10;
	t=s;
	while(*t) {
		n012=is012(t);
		switch (n012) {
			case 0: break;
			case 1: if(isalpha(*t)) henzai=1; else
              if(*t=='\\')    henzai=1; else
							if(isdigit(*t)) henzai=2; else
							if(ispunct(*t)) henzai=3;
							if((!hunguao)&&(*t=='(')) {
								char* tt=str_search4(t, ')');
								if((tt)&&(*tt)) n012=tt-t+1; else n012=strlen(t);
								henzai=4;
							}//note that n012 maynot be 012, lazy to use another name
							break;
			case 2: henzai=nHANRI; //hanri
		}
		if(n012) {
			if(tauzing!=0) {
				if((henzai ==nHANRI     )) ts.app(sep); else
				if((tauzing!=henzai)&&(!((tauzing==1)&&(henzai==2)))) ts.app(sep);
				else if(henzai==4) ts.app(sep);
			}
			ts.app(t,n012);
			t+=n012;
			tauzing=henzai;
		}
	}
	if(ts.size()) { set2(ts.s); return 1; }// copy the result
	return 0;
}

int  chars::
inssep4tokenizer(char* sep, int hunhanri)// def to "\t"/0
{
	chars ts; char* t; //char ctauzing=0;
	int tauzing=0, henzai, n012; int nHANRI=10;
	t=s;
	while(*t) {
		n012=is012(t);
		switch (n012) {
			case 0: break;
			case 1: if(isalpha(*t)) { henzai=1;  }else //ctauzing =*t; }else
							if(isdigit(*t)) { henzai=2;  }else //ctauzing =*t; }else
							if(ispunct(*t)) { henzai=3;  }     //ctauzing =*t; }
							break;
			case 2: henzai=nHANRI; // ctauzing=0; //hanri
		}
		if(n012) {
			if(tauzing!=0) {
				if(henzai ==3     ) ts.app(sep); else
				if(tauzing==henzai) {
					if((henzai==nHANRI)&&hunhanri) { ts.app(sep); } else{}
				}else{
					if(tauzing==3) { ts.app(sep); } else
					if((tauzing==1)&&(henzai==2)) { } else
					if((tauzing==2)&&(henzai==1)) { ts.app(sep); }
				}
			}
			ts.app(t,n012);
			t+=n012;
			tauzing=henzai;
		}
	}
	if(ts.size()) { set2(ts.s); return 1; }// copy the result
	return 0;
}

/*
int	chars::
hascnt(char c)
{
	char* t=s;
	int n012; int cnt=0;
	while(*t){
		n012=is012(t);
		if((n012==1)&&(t[0]==c))cnt++;
		t+=n012;
	}
	return cnt;
}
*/

int chars::
d1app(const char* s1)//app BYTE(strlen(s1)),then s1. No app if null
{
	int len=strlen(s1);	if(len<=0) return 0; if(len>255) len=255;
	app(uchar(len)); app(s1); return len;
}

int  chars::
set24fep(char* fname, char* ename, char* pname)
{
	if(pname) set2(pname);
	if(pname&&hassome()) { if(!ew("\\")) app('\\'); }
	app(fname);
	if(!ew(ename)) app(ename);
	return 1;
}

int  chars::
ins(int* at, char*s1, int nbytes)
{
	if((!s1)||(!s1[0])||(nbytes<=0))return 0; int n=nbytes+3;//strlen(s1)+3;
  if(s)n+=strlen(s); resize(n);//own_copy_s(n); 

  char *p1, *p2;
  p1=s + (*at); p2 = p1+nbytes;
  memmove(p2, p1, strlen(p1)+1);
  memmove(p1, s1, nbytes);
	// leave *at at the end of ins
	// note other option is leave at the same position.
	(*at) += nbytes;
  return nbytes;
}

int  chars::
goodat(int at)
{
	if(at<0) return 0;
	if(at>(int)strlen(s))return 0;
	return 1;
}


int  chars::
rite(int* at) // del a character at right, 0 or 1 or 2
{
	if((*at)>=(int)strlen(s)) return 0;
	int nbytes;
	nbytes=str_rbytes(s+(*at));
	*at+=nbytes;
  return nbytes;
}

int  chars::
rbytes(int at) // del a character at right, 0 or 1 or 2
{
	if((at)>=(int)strlen(s)) return 0;
	int nbytes;
	nbytes=str_rbytes(s+(at));
	return nbytes;
}

int  chars::
charunits() // in unit of echar and cchar, not in byte
{
	int n=0; int b; char* t=s;
	while(*t) { b=str_rbytes(t); t+=b; n++; }
	return n;
}

int  chars::
del(int* at) // del a character at right, 0 or 1 or 2
{
  if((*at)>=(int)strlen(s)) return 0;
  int nbytes;
  nbytes=str_rbytes(s+(*at));
  return del(at, nbytes);
}

int  chars::
del(int* at, int nbytes)
{
  char* p=s+(*at)+nbytes;
  //str_rmove(p, strlen(p), -nbytes);
	memmove(p-nbytes, p, strlen(p)+1);
	return nbytes;
}


int chars::
dellastbyte()
{
	if(s[0]) { s[size()-1]=0; return 1; } return 0;
}

int str_lastdiauhor(char*t)
{ // not complete
	char*s=t; int n012;
	while(*s) {
		n012=is012(s);
		if(*(s+n012)!=0) {s+=n012; continue;}
		switch(n012) {
		case 1: if(isdigit(*s)) return s-t;
		case 2: return -1; // check hanri diauhor
		}
	}
	return -1;
}

void chars::
dellastdiauhor()
{
	int n=str_lastdiauhor(s);
	if(n>=0) s[n]=0;
}

int  chars::
lbytes(int at) // BS  a character, 0 or 1 or 2
{
	int nbytes; //int len;
	if((at)<=0||(strlen(s))<=0) return 0;
	if(at==1)      nbytes=1;
	else           nbytes=str_lbytes(s, (at)); //???
	return nbytes; // so (*at)>=nbytes
}

int  chars::
left(int* at) // BS  a character, 0 or 1 or 2
{
	int nbytes; //int len;
	if((*at)<=0||(strlen(s))<=0) return 0;
	if(*at==1)      nbytes=1;
	else            nbytes=str_lbytes(s, (*at)); //???
	*at -=nbytes;
	return nbytes; // so (*at)>=nbytes
}

int  chars::
BS (int* at) // BS  a character, 0 or 1 or 2
{
	return BS(at, lbytes(at) );
	/*
  int nbytes; int len;
  if((*at)<=0||(len=strlen(s))<=0) return 0;
  if(len==1) *at=1;
  if(*at==1)      nbytes=1;
  else            nbytes=str_leftQisoBytes(s,(*at)); //???
  return BS(at, nbytes);
	*/
}

void   chars::
fstoption ()
{
	if(!(s&&s[0])) return;
	if(str_hasorset(s))
			set2( orset_1stoption(s) );
}


int  chars::
BS (int* at, int nbytes)
{
	if( (nbytes<=0)||( (*at)<=0 ) ) return 0;
	if( (*at) < nbytes ) nbytes=(*at);
  char* p=s+(*at);
  //str_rmove(p, strlen(p), -nbytes);
	memmove(p-nbytes, p, strlen(p)+1);
	*at -=nbytes;
	return nbytes;
}

char*chars::getfname() // assume chars contains full path name
{
	char* t0=0, *t=s; int n;
  while(*t) {
		n=is012(t);
    if(n==2) { t+=2; continue; }
    if(n==1) { if(*t =='\\') t0=t; t++;}
  }
  chars* ts=getcharsbuf();
  if(t0) { ts->app(t0+1); } else { ts->app(s); }
  return ts->s;
}

char*chars::getpname() // assume chars contains full path name
{
	char* t0=0, *t=s; int n;
  while(*t) {
  	n=is012(t);
    if(n==2) { t+=2; continue; }
    if(n==1) { if(*t =='\\') t0=t; t++;}
  }
  chars* ts=getcharsbuf();
  if(t0) { ts->app(s, t0-s); }
  return ts->s;
}
void chars::appfname(char*fname) // append // if necessary
{
	if(lastbyte()!='\\') app("\\"); app(fname);
}

int  chars::dellastN(int N)
{
	int len=size();
	if(N>len) return 0;
	s[len-N]=0;
	return 1;
}


void chars::set2full(const chars* p2s)
{
	set20(); resize(p2s->asize); memmove(s, p2s->s, p2s->asize);
}

int		echars::onkeydown(WPARAM w)
{
	LRESULT lres=!LM_USED;
	switch (w) {
	case VK_LEFT:    left (); lres=LM_USED; break;
	case VK_RIGHT:   rite (); lres=LM_USED; break;
	case VK_HOME:    home (); lres=LM_USED; break;
	case VK_END:     end  (); lres=LM_USED; break;
	case VK_DELETE:  del  (); lres=LM_USED; break;
	}
	return lres;
}

int		echars::dell_keep1tspace() // del lead space, keep only 1 trail space if any
{
	int nn=str_findnontsrn(cs.s);
	if(nn>0) { cs.delleadspaces(); ip-=nn; if(ip<0) ip=0; }
	char c=cs.lastbyte();
	cs.delltspaces(); if(isspace(c)) cs+=c;
	if(ip>cs.size()) ip=cs.size();
	dirt=1;
	return 1;
}

int		echars::onchar	 (char   c)
{
	if(c==0x8 ) return BS();
	if(c==0x1b) return 0; // ESC
	return ins(c);
}

	/*
 try {
	int res=LM_USED;
	if(!yesDAIIM)			{ on_charcount++;  }
	if(ki==8  )				{ res=diiobuffer.onBS();			} else
	if(isdigit(ki))		{ res=diiobuffer.ondigit(ki);	} else
	if(ki=='\t')			{ res=diiobuffer.ontab( di5ic.shiftisdown() );}else
	if(ki==' ')				{ res=diiobuffer.onspace();		}else
	if(ki=='\r')			{ res=diiobuffer.onenter();		}else
	if(ki=='\x1b')		{ res=diiobuffer.onESC();			}else
	if(ki==charYIMSO)	{ res=diiobuffer.onyingso();	}else
	if(diiobuffer.ib.s.size()>64) { res= LM_USED;		}else // too long for the buffer
	if(ispunct(ki))		{ res=diiobuffer.onpunct(ki);	}else
	res=diiobuffer.onchar(ki);
	return res;  // LM_USED;
 }catch(...){
		diiobuffer.ib.clear();
		//diiobuffer.ob.clear();
		//diiobuffer.ib.ins("OOPS!");
 }
	//repaint();
	return LM_USED;
 */

// class chars
//////////////////////////////////////

//////////////////////////////////////
// class charpp and charss


void charpp::resize		(int size)
{
	if(size<asize)return;
	pp=(char**)realloc(pp,sizeof(char*)*size);
	if(pp){own=1;asize=size;}
}

int  charpp::nextsize	(				 )
{
	if(asize<16)return 16;
	if(asize<=512)return 2*asize;
	return int(asize*1.1);
}

void charpp::set2full(charpp* p2pp)
{
	set20(); resize(p2pp->asize); for(int n=0; n<p2pp->asize; n++) app(p2pp->pp[n]);
	own=1;
}

void charpp::app 			(char*s1			)
{
	if(!s1)return;
	if(sz>=asize){resize(nextsize());}
	if(sz< asize){pp[sz]=s1;sz++;}
}


//int set2Nhun(char* str, int N=100, char crnlrep=' ') { s0.set2(str); return hun(N,crnlrep); }
int  charpp::startwith(const char* str, int N, int from)
{
	if(N<0) N=strlen(str);
	int i, I=size();
  for(i=from; i<I; i++)
  	if(strncmp(pp[i], str, N)==0) {	return i;}
	return -1;
}

int  	charss::startwith(const char* str, int N, int from)
{
	if(N<0) N=strlen(str);
	int i, I=size();
	for(i=from; i<I; i++)
  	if(strncmp(ss[i]->s, str, N)==0) {	return i;}
	return -1;
}

char*  charpp::part_bw(const char* str, int N, int from) // bw: begin with
{
	int i=startwith(str,N, from); if(i<0) return NULL;
	return pp[i];
}

int charpp::delparts_bw(const char* str)
{
	int cnt=0, len=strlen(str), i, I=size();
  if(len<=0) return 0;
  int fm, to;
  fm=to=0;
  for(i=0; i<I; i++) { // remove all
  	if(strncmp(pp[i], str, len)==0) {	cnt++; fm++;}
    else { pp[to++]=pp[fm++]; }
  }
  sz-=cnt;
  return cnt;
}

int charpp::delpart(int i)
{
	if(i>size()-1) return 0;
  for(int ii=i; ii<size()-1; ii++) {
  	pp[ii]=pp[ii+1];
  }
  sz-=1;
  return 1;
}


static chars s4charpp[2]; static i4s4charpp=1;
char*  charpp::
tos(char sep)
{
	i4s4charpp--; if(i4s4charpp<0) i4s4charpp=1;  int id=i4s4charpp;
	s4charpp[id].set20(); if(size()<=0) return s4charpp[id]();
	for(int i=0; i<size()-1; i++) s4charpp[id].apptab(pp[i]);
	s4charpp[id].app(pp[size()-1]); return s4charpp[id]();
}

char* charss::tos		(char*sep,int beg, int end)
{
	cs.clear();
	if(size()<=0) return cs.s;
	cslmt(beg, 0, size()-1); //if(beg<0) beg=0;
	if(end<0) end=size();
	cslmt(end, 0, size()  ); //if(end>size())end=size();
	for(int n=beg;n<end;n++){cs+=ss[n]->s;cs+=sep;}
	if(end-beg>0)cs.dele(strlen(sep));
	return cs.s;
}

int	charss::	set2(charspp* spp, int beg, int end)
{
	clear();
	if(beg<0) beg=0; if(end<0) end=spp->size();
	int sz, SZ=spp->size();
  if(beg>=SZ) beg=SZ; if(end>=SZ) end=SZ;
  if(beg>=end) { sz=beg; beg=end; end=sz; }
	ssresize(end-beg); clear();
	for(sz=beg; sz<end; sz++)
		app( (*spp)[sz] );
	return end-beg;
}

int	charss::ssresize(int newsize)
{
	if(newsize<=ss.allocsize)return 1;
	int oldsz=ss.asz;
	if(newsize>ss.allocsize){
		if(!ss.resize(newsize)) return 0;
	}
	chars* t;
	for(int i=oldsz;i<newsize;i++){
		t=new chars; ss.app(t);
	}
	ss.asz=oldsz;
	return 1;
}

void charss::ssdestroy()
{
	for(int i=0;i<ss.size();i++)
		ss.a[i]->destroy();
	ss.destroy();
	ss.init20();
}

void charss::clearcontent()
{
	for(int i=0;i<ss.size();i++)
		ss.a[i]->clear();
}

void charss::ssclear  ()
{
	for(int i=0;i<ss.size();i++)ss.a[i]->clear();
	ss.asz=0;
}


int 	charss::	insert	(int n, char* s)
{
	int asz=size();
	if(asz>ss.allocsize-1)
		if(!ssresize(asz+10))
			return 0;
	chars* t=ss.a[asz]; t->clear();
	for(int i=asz;i>=n;i--)
		ss.a[i]=ss.a[i-1];
	ss.a[n]=t;
	ss.asz++;
	ss.a[n]->set2(s);
	return 1;
}

int 	charss::	del (int n)
{
	chars* orphan=ss.a[n];//not remove pointer,but clear cntnt
	for(int i=n; i<ss.asz-1;i++)
		ss.a[i]=ss.a[i+1];
	orphan->clear();
	ss.a[ss.asz-1]=orphan;
	ss.asz--;
	return 1;
}


int		charss::	update(int n, const char* s, int expandss)
{
	if(expandss){
		while(n>=ss.size()+1)
			push_back("");
	}
	if(ss.isgood(n)) {
		ss.a[n]->set2(s); return 1;
	}
	//int N=ss.size();
	return 0;
}


// class charpp and charss
//////////////////////////////////////

//////////////////////////////////////
// class charspp

int	charspp::atpart (int ip, int toleft)
{
	int N,sz,SZ=size();
	if(SZ<=0) return 0;
	if(ip<=0) return 0;
	N=pp0[SZ-1]-s0.s; if(ip>=N) return SZ-1;
	for(sz=0; sz<SZ; sz++){
		N=pp0[sz]-s0.s;
		if(ip<=N) {
			if(ip==N) return sz;
			else if(toleft) return (sz>0)?sz-1:sz;
			N+=strlen(pp0[sz]);
			if(ip<=N) return (sz>0)?sz-1:sz;
			return sz;
		}
	}
	return SZ-1;
}


int charspp:: delparts_bw(const char* str)
{
	int N=strlen(str); int n=0;
	while(n<size()) {
		n=pp0.startwith(str, N, n);
		if(n<0) break;
		delpart(n);
	}
	return n>=0;
}

int charspp:: delpart(int i)
{
	if( i>=size()-1 ) return pp0.delpart(i);
	char c=ch01;
	chars* s=getcharsbuf();
	(*s)=tos(c,0,i); if(i>0) (*s)+=c; (*s)+=tos(c,i+1,size());
	return set2Ncut(s->s,c);
}

int charspp:: insert(int n, cchar* str)
{
	//if( (!str)||(!str[0]) ) return 0;
	if( (!str) ) return 0;
	chars &cs=(*getcharsbuf());
	cs=tos(ch01, 0,n);
	cs+=ch01; cs+=str; cs+=ch01;
	cs+=tos(ch01,n,size());
	return set2Ncut(cs.s,ch01);
	/*
	char* end; int N;
	if(n>=size()) {
		if(size()>0) { end=pp0[size()-1]; end += strlen(end)+1;}
		else { end=s0.s; }
		N=strlen(str)+1;
		if(end-s0.s+N<s0.asize) { // there is enough space
			strcpy(end, str);
			pp0.app(end);
			return 1;
		}
	}
	chars s; char c=ch01;
	//s=tos(c, 0, i+1); s+=c; s+=str; s+=c; s+=tos(c, i+1, size());
	s=tos(c, 0, i);
	if(i>0) s+=c;
	s+=str;
	if(i+1<size()) {
		s+=c;
		s+=tos(c, i, size());
	}
	return set2Ncut(s.s, c);
	*/

}

int		charspp::bw	 (int n, char*tt)//is part n bw tt?
{
	if(!inbnd(n)) return 0;
	return str_startwith(pp0[n],tt,strlen(tt));
}

int		charspp::ew  (int n, char*tt)//is part n ew tt?
{
	if(!inbnd(n)) return 0;
	return str_endwith(pp0[n],tt,strlen(tt));
}

int charspp::del4kauqidiau()
{
	int n; char*t;
	for(int ii=0; ii<size(); ii++) {
  	t=pp0[ii];
		n=strlen(t); if(n<2) continue;
    str_del4kauqidiau(t);
    //if(isdigit(t[n-2])&&isdigit(t[n-1])) { t[n-2]=t[n-1];t[n-1]=0;}
  }
  return 1;
}

int charspp::del_kauqidiau()
{
	int n; char*t;
	for(int ii=0; ii<size(); ii++) {
		t=pp0[ii];
    n=strlen(t); if(n<2) continue;
    if(isdigit(t[n-2])&&isdigit(t[n-1])) { t[n-1]=0;}
	}
	return 1;
}

char* charspp::
toline(char sep, int beg, int end)
{
	if(end<0) end=size(); if(end>size())end=size();
	if(beg<0) beg=0;
	chars* s=getcharsbuf();
	for(int i=beg; i<end; i++) {
  	s->app(pp0[i]);
    if(sep&&(i<end-1))s->app(sep);
  }
	//{	if(!pp0[i][0]) continue; s->app(pp0[i]); if(sep&&(i<end-2))s->app(sep);	}
	return s->s;
}

char* charspp::
tos(char* sep, int beg, int end)
{
	chars& cs=(*getcharsbuf());
	cslmt(beg, 0, size()-1);
	if(end<0) end=size();
	cslmt(end, 0, size()  );
	for(int n=beg;n<end;n++){cs+=pp0[n];cs+=sep;}
	if(end-beg>0)cs.dele(strlen(sep));
	return cs.s;
}


char* charspp::
rtos  (char sep, int beg, int end) // reverse tos
{
	if(end<0) end=size(); if(end>size())end=size();
	if(beg<0) beg=0;
	chars* s=getcharsbuf();
	for(int i=end-1; i>=beg; i--)
	{	if(!pp0[i][0]) continue; s->app(pp0[i]); if(sep&&(i>beg))s->app(sep);	}
	return s->s;
}

int  charspp::
set2Nhunplus	(const char* str, int N, char crnlrep)
{
	s0.set2(str);		
	str_replace(s0.s,'+',' ');
	return hun(N,crnlrep); 
}

int  charspp::
hunorset	(int N, char crnlrep)
{
	char* ss=s0.s; int res;
	while(*ss) {
		res=is012(ss); if(res!=1) { ss+=res; continue; }
		if((*ss == '(')||(*ss == ')')||(*ss == '|')) { *ss=' '; }
		ss++;
  }
	return hun(N,crnlrep); 
}

int  charspp::
set2Nhunpinim	(const char* str, int N, char crnlrep, int keepdash)
{
	s0.set2(str);
	s0.inssep4hanlor();
	char* ss=s0.s; int res; int paraON=0;
	while(*ss) {
    res=is012(ss); if(res!=1) { ss+=res; continue; }
		if(*ss == '(') paraON=1; else
		if(*ss == ')') paraON=0;
    //if((!paraON)&&(*ss == '-')) { if(!keepdash) *ss=' '; }
    if( (!paraON)&&ispunct(*ss) ) { if(!keepdash) *ss=' '; }
		ss++;
  }
	return hun(N,crnlrep);
}


int  charspp::
set2Nhunsls		(const char* str) //sls 4 soliong su, f.e. 53van
{
	if(!isdigit(str[0])) return 0;
	s0.set2(str); s0.app("-"); // so that pure number will work
	int len=s0.size();	s0.s[len-1]=0;
	char*t=s0.s;
	while(*t) {	if(isdigit(*t)) t++; else break; }
	len=t-s0.s;
	s0.ins(&len, ' '); s0.s[len-1]=0;
	pp0.clear(); pp0.app(s0.s); pp0.app(s0.s+len);
	return pp0.size();
}

int  charspp::
set2Nhunhanlor(const char* str, int N, char crnlrep, int keepdash)
{
	s0.set2(str);
	s0.inssep4hanlor();
	if(!keepdash) str_replace(s0.s, '-', ' ');
	return hun(N,crnlrep); 
}

int charspp::
hun1d	 (int N) // hun 1d str: (BYTE(strlen),str}...
{
	int lenall=s0.size(), lent=0, len1;
	if(lenall<=0) return 0;
	pp0.set20(); char* p=s0.s;
  for(int n=0; n<N; n++) {
		len1 =uchar(*p); *p++=0;
		if(*p ==0) break;
    pp0.app(p); lent+=1+len1; p+=len1;
		if(lent>=lenall) break;
	}
  return pp0.sz;
}


int charspp::
hunrlet(int N) // rlet : non-empty line
{
	N=hunlet(N); int tgt=0;
	for(int n=0; n<N; n++) {
		if(str_isblank(pp0[n])) continue;
		pp0.pp[tgt++]=pp0.pp[n];
	}
	pp0.sz=tgt; return pp0.sz;
}

int charspp::
hunglet(int N) // glet : non-enpty and not-commented by //
{
	N=hunlet(N); int tgt=0;
	for(int n=0; n<N; n++) {
		if(str_isblank(pp0[n])) continue;
		if(str_isSS   (pp0[n])) continue;
		pp0.pp[tgt++]=pp0.pp[n];
	}
	pp0.sz=tgt; return pp0.sz;
}



int  istr4line::
getline(chars& rline) // get into outside resizable line recursively
{
  rline.set20();
  char* tbuf=now; if(!tbuf) return 0;
	int nbytes;
  char* p=str_search4crORnl(tbuf,&nbytes); //return null if not found
  if(!p) {
    if(tbuf[0]) {rline.app(tbuf); now=0; }
	return (rline.s)?strlen(rline.s):0;
  }
  *p=0;	// \r is temporary replaced
  rline.app(tbuf); *p='\r'; p+=nbytes; 
  now=p;
  return (rline.s)?strlen(rline.s):0;
}


int istr4line::
getrline(chars&buf) //rline: real(nonblank) line
{
  getline(buf);
  if(buf.hassome()) return 1;
  if(!hasmore()) return 0; //if( (s)&&(*now==0) )return 0;
  return getrline(buf);
}

int istr4line::
getgline(chars&buf) //gline: rline and not startting with //
{
  getline(buf);
  if(buf.hassome()) 
		{ if( (buf.s[0]!='/')||(buf.s[1]!='/') ) return 1; }
  if(!hasmore()) return 0; //if( (s)&&(*now==0) )return 0;
  return getgline(buf);
}




int  istr4line::
getsentence(chars&buf) // includes last huhor.
{//r: 2 if juanhing, 1 if buannhing, 0 if not end with huhor(so check buf[0])
  char period[]="�C",comma[]="�A",question[]="�H",exclam[]="�I";
  char* p=now; buf.clear(); if((!p)||(!p[0])) return 0;
	int notfound=1; int n012; int punctbytes=0;

  while( (*p)&&(notfound) ) {
		n012=is012(p);
		if(n012==2) { // juanhing
		  if((p[0]==period  [0])&&(p[1]==period  [1])) notfound=0;
			if((p[0]==comma   [0])&&(p[1]==comma   [1])) notfound=0;
		  if((p[0]==question[0])&&(p[1]==question[1])) notfound=0;
		  if((p[0]==exclam  [0])&&(p[1]==exclam  [1])) notfound=0;
			buf.app(p,2);
			p+=2;
			if(!notfound) punctbytes=2;
		}else {   // buannhing
			if( (p[0]=='.')||(p[0]==',')||(p[0]=='?')||(p[0]=='!') ) notfound=0;
			buf.app(p,1);
			p+=1;
			if(!notfound) punctbytes=1;
		}
  }
	now=p;
  return punctbytes;
}


int charspp::
set2Nhungu(const char* s1, int keeppunct,  int N)
{
	clear();	istr4line istr((char*)s1);
	chars s; char x01=ch01; int punctbytes;
	while(1) {
		punctbytes=istr.getsentence(s);
		if(!s.size()) break;
		if(!keeppunct) { s.dele(punctbytes); }
		s0+=s.s; s0+=x01; s.clear();
	}
	char* p=s0.s;  pp0.set20();
	for(int n=0; n<N; n++) {
		pp0.app(p);
		while(*p!=x01) if( *p==0) break; else p++;
		if( (*p==0)||(pp0.sz==N) ) return pp0.sz;
		*p=0; p++;			 if(*p==0) return pp0.sz;
	}
	return pp0.sz;
}


// class charspp
//////////////////////////////////////

//////////////////////////////////////
// class pairss

chars pairss::nulls;

int pairss::getndx(char* lhs)
{
	int i;
	if(sorted)
		i=2*bfind(lhs, pp0(), size()/2, sizeof(char**)*2, wis.sNsp);
	else
		for(i=0;i<size(); i+=2)
			if(strcmp(pp0[i], lhs)==0) break;
	if(i<0||i>=size()) return -1;
	return i;
}

int pairss::set(char* lhs, char*rhs)
{
	if(!(lhs&&lhs[0])) return 0;
	//if(!(rhs&&rhs[0])) return 0;
	char tt[]=""; char*t=(rhs)?rhs:tt;
	app(lhs);
	app(t);
	sorted=0;
	return 2;
}


int pairss::reset(char* lhs, char*rhs)
{
	if(!(rhs&&rhs[0])) return 0;
	int i=getndx(lhs);
	if(i<0) return 0;
	i++; delpart(i); insert(i,rhs);////??????insert after??????
	return 1;
}

char* pairss::get(char* lhs)
{
	int i=getndx(lhs);
	return (i<0)?nulls.s : pp0[i+1];
}


void pairss::qsort()
{
	::qsort(pp0.pp, size()/2, sizeof(char**)*2, wis.spNsp);
	sorted=1;
	char* t=tos(ch01,0,size());
	set2Ncut(t,ch01);
}

// class pairss
//////////////////////////////////////

//////////////////////////////////////
// class tyio

#ifndef __WINDOWS
  #include <windows.h>
#endif

int str_rbytes			(cchar* s)
{	return AnsiNext(s)-s;   }

int str_lbytes(cchar* s, int at)
{	char* t=AnsiPrev(s, s+at);	return (s+at)-t;	}

int askOK4_file_overwrite(char*fname)
{
	lreader rd; rd.open(fname);
	if(rd.isOK()) {	rd.close();
		msgbox("\n\n!!!!!\noutput file:  ", fname,"  already exist. \n");
		msgbox("It will be overwrited.\n");
		msgbox("type y to confirm the overwriting or abort(y/n)?");
		char ki=getch(); msgbox("\n");
		if((ki=='y')||(ki=='Y')) return 1;
		return 0;
	}
	return 1;
}


int tyio::
open(char* filename, int ioflag)
{
	if(hfile) { close(); }
  if( (filename==NULL) || (filename[0]==0) )return 0;
  hfile=_lopen(filename, ioflag);
  if(hfile==-1) hfile=0;
  if(hfile) closable=1;
  return hfile;
}
int tyio::
creat(char* filename, int ioflag)
{
  if(hfile) { close(); }
  if( (filename==NULL) || (filename[0]==0) )return 0;
  hfile=_lcreat(filename, ioflag);
	if(hfile==-1) hfile=0;
  if(hfile) closable=1;
  return hfile;
}

int tyio::
close()
{
  if(closable) { 
    closable=0;
    if(hfile) _lclose(hfile); hfile=0;
  }
  return 1;
}







// isOK(...) provides an oppurtunity to close the ap w/o too much ado?
int tyio::
isOK(char* fname)
{  if(isOK()) pause(fname); return isOK(); }

int tyio::
openOWmes (char* fname, char* pname, char* mes)
{
  int res=open(fname, pname);
  if(!res) 
	{ if(mes) messagebox(mes);else messagebox("can't open ",pname,fname); }
  return res;
}

int tyio::
openERRMES (char* fname, char* pname)
{
	int res=open(fname, pname);
	if(!res) { messagebox("can't open ", pname, fname); }
  return res;
}


int tyio::
open4append (char* fname, char *pname)
{
  chars ss=pname;  ss.app(fname);
  open(ss.s,OF_READWRITE);
	if(!isOK()) {
    creat(ss.s);
    if(!isOK()) return 0;
	}
	_llseek(hfile, 0L, 2);  // move to end of file
	return hfile;
}

int tyio::
open (char* fname, char *pname)
{
	chars ss;
	if(pname) { ss=pname;	if(!ss.ew('\\')) ss+="\\"; }
	ss.app(fname);// malloc only at app
	return open(ss.s,0);
}

int tyio::
creat(char* fname, char *pname)
{
	chars ss;
	if(pname) { ss=pname;	if(!ss.ew('\\')) ss+="\\"; }
	ss.app(fname);
	return creat(ss.s,0);
}

int tyio::
creatERRMES(char* fname, char *pname)
{
	int res=creat(fname,pname);
  if(!res) { messagebox("can't create ", pname, fname); }
	return res;
}


int tyio::
exist (char* fname, char *pname)
{
  int res=open(fname, pname); close();
  return res;
}

long tyio::
filesize()
{ // copied from PW3.1 of Petzold
  long lCurr=_llseek(hfile, 0L, 1); //from curr
  long lLsst=_llseek(hfile, 0L, 2); //from end
  _llseek(hfile, lCurr, 0);  // restore file pos pointer
  return lLsst;
}

long tyio::
rmoveto(long nbytes)
//{return _llseek(hfile, nbytes, FILE_CURRENT);}
{
  //cout<<"before _llseek()\n";
  return _llseek(hfile, nbytes, FILE_CURRENT);
}

unsigned int tyio::
read(void * p, unsigned int len)
{ return _lread(hfile, p, len); }

unsigned int tyio::
write(void * p, unsigned int len)
{ if(!hfile) return 0; return _lwrite(hfile, (char*)p, len); }

//void tyio::flush()
//{ _flush(hfile); }

// class tyio
//////////////////////////////////////

//////////////////////////////////////
// class lreader

int  lreader::
open (char* fname, char *pname)
{
	EOF_reached=0;
	return tyio:: open(fname,pname);
}


int lreader::
init_tbuf(int buflength )
{
  if(tbuf) delete[] tbuf;  tbuf=0;
  tbuflen=buflength;
  //ty32.ime will not use this part, and thus will be kept same as exe case
#ifdef WIN32DLL
  tbuf=new char[tbuflen+1];
  // may/do not know how to when to delete
#else //WIN32DLL
  tbuf=new char[tbuflen+1];
#endif //WIN32DLL
	if(tbuf) { tbuf[0]=0; tbuf[tbuflen]=0; }
  else { tbuflen=0; }
  return 1;
}

int lreader::
del_tbuf()
{
  if(deletable) delete tbuf; init_tbuf0(); return 0;
}

int lreader::
fill_tbuf()
{
  int len=strlen(tbuf);
  char* p=tbuf+len; len=tbuflen-len;
  int nRead=_lread(hfile, p, len);
  *(p+nRead)=0;
  if(nRead<len) 
    EOF_reached=1;
  return nRead;
}

void lreader::
move_tbuf(char* from)
{ // move the content to (left) top of tbuf 
  //str_rmove(from, strlen(from), int(tbuf-from) );//move content of tbuf to top
	str_rmove(from, strlen(from), int(tbuf-from) );//move content of tbuf to top
}

int  lreader::
getline_rec(chars& rline) // get into outside resizable line recursively
{ // this version works for unix system too
  if(!tbuf[0]) fill_tbuf();
  char* p=str_search4(tbuf,'\n'); //return null if not found
  if( (!p) ) { // p[1]==0 means \r\n is separated
    //if(p) { p[0]=0; }
    if(tbuf[0]) {rline.app(tbuf);}
		//if(p) { p[0]='\r'; }
    //if(p)str_rmove(p, strlen(p), int(tbuf-p) );//move content of tbuf to top
		//else tbuf[0]=0;
		tbuf[0]=0;
    if(EOF_reached) return (rline.s)?strlen(rline.s):0;
    fill_tbuf();
    return getline_rec(rline);
  }
	if(p-tbuf>=1) {
  	if(p[-1]=='\r') p[-1]=0;
  } // \r need to be removed too
	//else { // then \r could be already in buf
  //if(p-tbuf<=1){
		int sz=rline.size();
		if((sz>0)&&(rline.s[sz-1]=='\r')) rline.s[sz-1]=0;
	//}
	*p=0;p++;   rline.app(tbuf);
  move_tbuf(p);//move content of tbuf to top
  //str_rmove(p, strlen(p), int(tbuf-p) );
  return (rline.s)?strlen(rline.s):0;
}
/*
int  lreader::
getline_rec(chars& rline) // get into outside resizable line recursively
{
  if(!tbuf[0]) fill_tbuf();
  char* p=str_search4(tbuf,'\r'); //return null if not found
  if( (!p) || (p[1]==0) ) { // p[1]==0 means \r\n is separated
    if(p) { p[0]=0; }
    if(tbuf[0]) {rline.app(tbuf);}
		if(p) { p[0]='\r'; }
		if(p)str_rmove(p, strlen(p), int(tbuf-p) );//move content of tbuf to top
		else tbuf[0]=0;
    if(EOF_reached) return (rline.s)?strlen(rline.s):0;
    fill_tbuf();    return getline_rec(rline);
  }
  *p=0;p++; if(p[0]=='\n') p++; // \n need to be removed too
  rline.app(tbuf);
  move_tbuf(p);//move content of tbuf to top
  //str_rmove(p, strlen(p), int(tbuf-p) );
  return (rline.s)?strlen(rline.s):0;
}
*/

int lreader::
getsentence_rec(chars&buf) // includes lasst huhor.
{//r: 2 if juanhing, 1 if buannhing, 0 if not end with huhor(so check buf[0])
  char period[]="�C",comma[]="�A",question[]="�H";
  if( (!tbuf[0]) && EOF_reached ) return 0;
  if( (!tbuf[0]) )  fill_tbuf();
  if( (tbuf[0]) && (tbuf[1]==0) ) fill_tbuf(); // prevent 1/2 hanzi
  int notfound=1; int n012;
  char* p=tbuf;
  while( (*p)&&(notfound) ) {
    if( (*p) && (*(p+1)==0) ) { //prevent 1/2 hanzi
		  move_tbuf(p); p=tbuf; 
			if(!EOF_reached) { // can still read
				fill_tbuf();  continue;
			}// otherwise falls thru, data left are all in tbuf(only 1 byte).
		}
		n012=is012(p);
		if(n012==2) { // juanhing
			buf.app(p,2);
		  if((p[0]==period  [0])&&(p[1]==period  [1])) notfound=0;
			if((p[0]==comma   [0])&&(p[1]==comma   [1])) notfound=0;
		  if((p[0]==question[0])&&(p[1]==question[1])) notfound=0;
			p+=2;
		}else {   // buannhing
			buf.app(p,1);
		  if( (p[0]=='.')||(p[0]==',')||(p[0]=='?') ) notfound=0;
			p+=1;
		}
		if(*p==0) {fill_tbuf();}
	}
	if( *p ==0 ) { // means reach end of tbuf;
		tbuf[0]=0; fill_tbuf();
		if(notfound) {if(isEOF()) return 0; }else return getsentence_rec(buf);
		// otherwise, happens to have huhoe/punt at the end
		return (buf.size()>0);//(t[1])?2:1;
	}
  // otherwise, *p not point to end, and  !notfound or found 
  move_tbuf(p);//move content of tbuf to top
  //str_rmove(p, strlen(p), int(tbuf-p) );
  return buf.size();//(t[1])?2:1;
}

/*
int lreader::
getsentence_rec(chars&buf) // includes lasst huhor.
{//r: 2 if juanhing, 1 if buannhing, 0 if not end with huhor(so check buf[0])
  char period[]="�C",comma[]="�A",question[]="�H";
  if( (!tbuf[0]) && EOF_reached ) return 0;
  if( (!tbuf[0]) )  fill_tbuf();
	if( (tbuf[0]) && (tbuf[1]==0) ) fill_tbuf(); // prevent 1/2 hanzi
  unsigned short ser; char t[3]; t[2]=0;
  int notfound=1;
  char* p=tbuf;
	while( (*p)&&(notfound) ) {
    if( (*p) && (*(p+1)==0) ) { //prevent 1/2 hanzi
	  move_tbuf(p); p=tbuf; 
	  if(!EOF_reached) { // can still read
	    fill_tbuf();  continue;
	  }// otherwise falls thru, data left are all in tbuf(only 1 byte).
	}
    //ser=big52ser(p[0],p[1]);//not working
	ser=(unsigned short)str_rightQisoBytes(p);
	//if(ser) { // juanhing
	if(ser==2) { // juanhing
	  t[0]=p[0];t[1]=p[1];	  p+=2; 
	  buf.appexpand(t);
	  //if(ser<unsigned(0x8800)) notfound=0;//not working
	  if((t[0]==period  [0])&&(t[1]==period  [1])) notfound=0;
	  if((t[0]==comma   [0])&&(t[1]==comma   [1])) notfound=0;
	  if((t[0]==question[0])&&(t[1]==question[1])) notfound=0;
	}else {   // buannhing
	  t[0]=p[0];t[1]=0; 	  p++;
	  buf.appexpand(t);
	  //if(ispunct(t[0])) notfound=0;
	  if( (t[0]=='.')||(t[0]==',')||(t[0]=='?') ) notfound=0;
	}
	if(*p==0) {fill_tbuf();}
  }
  if( *p ==0 ) { // means reach end of tbuf;
    tbuf[0]=0; fill_tbuf();
	if(notfound) {if(isEOF()) return 0; }else return getsentence_rec(buf);
	// otherwise, happens to have huhoe/punt at the end
	return (t[1])?2:1;
  }
  // otherwise, *p not point to end, and  !notfound or found 
  move_tbuf(p);//move content of tbuf to top
  //str_rmove(p, strlen(p), int(tbuf-p) );
  return (t[1])?2:1;
}
*/

int lreader::
getrline(chars&buf) //rline: real(nonblank) line
{
  getline(buf);
  if(buf.hassome()) return 1;
  if(isEOF()) return 0;
  return getrline(buf);
}

int lreader::
getgline(chars&buf) //gline: rline and not startting with //
{
  getline(buf);
	str_skipheadblank0(buf.s);
  if(buf.hassome()) { 
		if( (buf.s[0]!='/')||(buf.s[1]!='/') ) return 1; 
	}
  if(isEOF()) return 0;
  return getgline(buf);
}

int lreader::
getall(charspp&buf, int appendit)
{
	int n=0; chars s; if(!appendit) buf.s0.clear();
	while(!isEOF()) {
  	getline(s);
  	buf.s0.appln(s.s);
    n++;
  }
	return n;
}

int lreader::
getgline(charspp&buf, int appendit)
{
	chars s; if(!appendit) buf.s0.clear();
	while(!isEOF()) {
  	getgline(s);
		//if( s.s[0]=='/' && s.s[1]=='/' ) continue;
	  //if(s.isgline()) continue;
  	buf.s0.appln(s.s);
  }
	buf.hunlet();
	return buf.size();
}

int lreader::
getrline(charspp&buf, int appendit)
{
	chars s; if(!appendit) buf.s0.clear();
	while(!isEOF()) {
  	getrline(s);
	  if(s.isempty()) continue;
  	buf.s0.appln(s.s);
  }
	buf.hunlet();
	return buf.size();
}

int  lread2gline(char*fn, charspp&buf, int appendit)
{
	lreader r; r.open(fn); if(r.isERR()) return 0;
	if(!appendit) buf.clear();
	r.getgline(buf); r.close();
  return buf.size();
}

int  lread2rline(char*fn, charspp&buf, int appendit)
{
	lreader r; r.open(fn); if(r.isERR()) return 0;
	if(!appendit) buf.clear();
	r.getrline(buf); r.close();
  return buf.size();
}

int  lread2line(char*fn, charspp&buf, int appendit)
{
	if(!appendit) buf.clear();
	lreader r; r.open(fn); if(r.isERR()) return 0;
	r.getall(buf); r.close();
  return buf.hunlet();
}


// class lreader
//////////////////////////////////////


//////////////////////////////////////
// class writer


unsigned int writer::
writeNbohun(char** pps, int N, char* separator)
{
  if(!hfile) return 0;
	int n,linelen=0;
  int seplen=strlen(separator);
  for(n=0; n<N; n++) {
    linelen +=writestr(pps[n]);
    if(n<N-1) linelen += tyio::write(separator,seplen);
  }
  return linelen;
}

unsigned int writer::
writelnNbohun(char** pps, int N, char* separator)
{ int linelen=writeNbohun(pps,N,separator); return linelen+writeln(); }

// class writer
//////////////////////////////////////

//////////////////////////////////////
// class madis

int	madis::writepair(writer&w, char* lhs)
{
	char* t=get(lhs); if( (!t)||(!t[0]) ) return 0;
  w.write(lhs);w.write("=");w.write(t); return 1;
}

int madis::initini(int argcini1, char* argvini1[])
{
	argcini=argcini1; argvini=argvini1; argcini=argcini/2*2;
  if(!argvini) return 0;
  for(int i=0; i<argcini-1; i+=2) {
  	resetset(argvini[i], argvini[i+1]);
  }
  return argcini;
}


int madis::readini(char* inifname)
{
	charspp lns, spp; char nulls[]=""; char* t;
  lread2gline(inifname, lns);
  for(int i=0; i<lns.size(); i++) {
  	t=lns[i];
  	if(str_find(t,"=")>=0)
    			spp.set2Ncut(t,'=',2); // 2: 2 part are needed
    else 	spp.set2Nhun(t);
  	if(spp.size()<2) t=nulls; else t=spp[1];
    resetset(spp[0],t);
	}
	resetset("inifname", inifname);
	return lns.size();
}

int madis::writeini(char* inifname)
{
	if(!argvini) return writeiniVTI(inifname);
	char* t=inifname; if(!t) t=getinifname(); if(!t[0]) return 0;
  writer w; w.creat(inifname); if(w.isERR()) return 0;
  for(int i=0; i<argcini-1; i+=2){
		writepairln(w, argvini[i]);
  }
  return argcini;
}

int madis::writeiniVTI(char* inifname)
{
	char* t=inifname; if(!t) t=getinifname(); if(!t[0]) return 0;
  writer w; w.creat(inifname); if(w.isERR()) return 0;
  char* tt=getcomment();
  if(tt&&tt[0]) w.writeln(tt);
  VTIwriteini(w);
  w.close();
	return 1;
}

// class madis
//////////////////////////////////////

//////////////////////////////////////
// class tcpreader

char *xmlline1alone="<?xml version=\"1.0\" encoding=\"Big5\" standalone=\"yes\" ?>";

int spp_hunattr(charspp& spp, char* data)
// makes a str of the form att="something" att2="2" into
// spp[0] contains att, and spp[1] contains something and so on
{
	static chars cs; cs.clear();
	if(data) spp.set2(data);
	spp.s0.delltspaces();
	spp.cut('=',2);
	cs=spp[1]; cs.delltspaces();
	int bq=0,eq=0;
	if(cs[0]=='\"') bq=1;
	if(bq) { eq=cs.find("\"",bq); cs[eq]=0; }
	strcpy(spp[1],cs.s+bq);
	return spp.size();
}

int str_find1(char* s, char c)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2||t[0]!=c) {t+=n012; continue;}
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}
/*
int str_findts(char* s)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2||!istabspace(t[0])){t+=n012; continue;}
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}

int str_findnonts(char* s)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2) {t+=n012; continue; }
		if(n012==1&&istabspace(t[0])){t+=n012; continue; }
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}
*/
int is_tsrn(char c)//tab space \r \n
{
	return (c==' '||c=='\t'||c=='\r'||c=='\n')?1:0;
}


int str_findtsrn(char* s)//tab space \r \n
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2||!is_tsrn(t[0])){t+=n012; continue;}
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}

int str_findnontsrn(char* s) //tab space \r \n
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2) {t+=n012; continue; }
		if(n012==1&&is_tsrn(t[0])){t+=n012; continue; }
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}

int		str_sametoken	(cchar* tocheck, cchar* token)
{
	int len=strlen(token);
	if(strncmp(tocheck, token, len)!=0) return 0;
	char c=tocheck[len];
	if(is_tsrn(c)||ispunct(c)) return 1;
	return 0;
}



int		xmltag::set2Nhun	(const char* data)
{
	tg=data; return hun();
}


int		xmltag::hun (const char* data)
{
	char* t=(char*)data; if(!t) t=tg.s; if(!t) return -1;
	str_delltspaces(t);
	static chars cs; cs.clear();
	int len;
	if(t[0]=='<') { // if true, check having > or />
		len=strlen(t);
		if(t[len-1]!='>') return -1; // no match in <>
		if(len>2&&t[len-2]=='/') {t[len-2]=0;mpt=1;}else t[len-1]=0;
		t++;
	}
	int n;
	n=str_findnontsrn(t); if(n>0) t+=n;
	n=str_findtsrn   (t); if(n<0){tg=t;return 0;}
	t[n]=0; tg=t; t+=(n+1);
	while(*t) {
		n=str_findnontsrn(t ); if(n<0) break; t+=n;
		n=str_find1  (t,'=' ); if(n<0) break; t[n]=0; cs+=t; cs+=ch01; t+=n+1;
		n=str_find1  (t,'\"'); if(n<0) break; t[n]=0; t+=n+1;
		n=str_find1  (t,'\"'); if(n<0) break; t[n]=0; cs+=t; cs+=ch01; t+=n+1;
	}
	//if(*t) {// means err or no attr
	//	as.clear(); return 0;
	//}
	cs.dellastbyte();//last byte is ch01;
	as.clear();
	as.set2Ncut(cs.s,ch01);
	return as.size()/2;
}

int		xmltag::hasattr		(cchar*att)
{
	for(int i=0; i<as.size();i+=2) {
		if(strcmp(att,as[i])==0) return 1;
	}
	return 0;
}

char* xmltag::operator[](cchar*att) //return value for the given att
{
	for(int i=0; i<as.size();i+=2) {
		if(strcmp(att,as[i])==0) return as[i+1];
	}
	static char junk[]="";
	return junk;
}

int  	xmltag::read(tcpreader& r)
{
	return r.getnexttag(tg);
}

int		xmltag::tis	(cchar* tag) // tag is
{
	if(!(tag&&tag[0])) return 0;
	if(tg[0]!='<') return 0;
	int b=1; if(tg[1]=='/') b=2;
	return str_sametoken(tg.s+b, tag);
}

char* xmltag::tos (char sep)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf();
	t->app("<");t->app(tg.s);
	int n,N=as.size();
	for(n=0;n<N;n++){
		t->app(sep); t->app(as[2*n]);t->app("=\"");t->app(as[2*n+1]);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

char* xmltagrw::tos (char sep)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf();
	t->app("<");t->app(tg.s);
	int n,N=as.size();
	for(n=0;n<N;n+=2){
		t->app(sep); t->app(as[n]);t->app("=\"");t->app(as[n+1]);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

char* xmltag::tos (charspp& spp, char sep)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf();
	if(spp.size()<=0) return t->s;
	t->app("<");t->app(spp[0]);
	int n,N=spp.size();
	for(n=1;n<N;n++){
		t->app(sep); t->app(spp[n]);t->app("=\"");t->app((*this)[spp[n]]);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

char* xmltagrw::tos (charspp& spp, char sep)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf();
	if(spp.size()<=0) return t->s;
	t->app("<");t->app(spp[0]);
	int n,N=spp.size();
	for(n=1;n<N;n++){
		t->app(sep); t->app(spp[n]);t->app("=\"");t->app((*this)[spp[n]]);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

int		xmltagrw::hun (char* data)
{
	char* t=data; if(t)tg=t;else t=tg.s; if(!t) return -1;
	xmltag tmp; as.clear();
	if(tmp.hun(t)<0) return -1;
	tg=tmp.tg;
	as.set2(&(tmp.as));
	mpt=tmp.mpt;
	return size();
}
int		xmltagrw::app (char*ki, char*val)
{
	if(!(ki&&ki[0])) return 0;
	char sp[]="";
	if(!(val&&val[0])) val=sp;
	if(hasattr(ki)) return set2(ki, val);
	as.push_back(ki);
	as.push_back(val);
	return 1;
}

int		xmltagrw::set2(char*ki, char*val)
{
	int i;
	for(i=0; i<as.size()-1;i+=2) {
		if(strcmp(ki,as[i])==0)
			break;
	}
	if(i<as.size()-1) {
		as.ss.a[i+1]->set2(val);
		return 1;
	}
	return 0;
}

int		xmltagrw::hasattr		(cchar*att)
{
	for(int i=0; i<as.size();i+=2) {
		if(strcmp(att,as[i])==0) return 1;
	}
	return 0;
}


char* xmltagrw::operator[](char*att) //return value for the given att
{
	for(int i=0; i<as.size()-1;i+=2) {
		if(strcmp(att,as[i])==0) return as[i+1];
	}
	static char junk[]="";
	return junk;
}

int		xmltagrw::att2ith		(char*att)
{
	for(int i=0; i<as.size()-1;i+=2) {
		if(strcmp(att,as[i])==0) return i+1;
	}
	return -1;
}

int  	xmltagrw::read(tcpreader& r)
{
	return r.getnexttag(tg);
}

int		xmltagrw::tis	(cchar* tag) // tag is
{
	if(!(tag&&tag[0])) return 0;
	if(tg[0]!='<') return 0;
	int b=1; if(tg[1]=='/') b=2;
	return str_sametoken(tg.s+b, tag);
}

/*
int		tcpreader::skip2root(char* rootname)
// return 0 if rootname not match
{
	chars cs;
	if(!nextistag("xml")) return 0;
	getnexttag(cs);
	if(rootname)
		if(!nextistag(rootname)) return 0;
	return 1;
}
*/

int		tcpreader::getnexttag0(chars& cs, int keepSB)//SB sharp bracket
{
	getlnbuf(nxtln);cs.clear();
	while(nxtln.bw("\r\n")) nxtln.delb(2);
	if(nxtln[0]!='<') return 0;
	int n012; char*t=nxtln.s; int n=0;
	if(!keepSB){t++; n=1;}
	int done=0;
	while(!done){
		n012=is012(t);
		if     (n012==2) { cs.app(t,2); n+=n012; t+=n012; }
		else if(n012==1) {
			if(*t=='>') done=1;else { cs.app(t,1); t++; }
			n++; //n++ so that > is always exlcuded
		}else{
			n=0; nxtln.clear(); getlnbuf(nxtln);   t=nxtln.s;
			//cs.app(" ");
			if(!nxtln[0]) return 0; //error in data file
		}
	}
	if(keepSB) { cs.app(">",1); }
	nxtln.delfirstN(n);//nxtln.delltspaces();
	int lnend=0;
	if(nxtln[0]=='\r'||nxtln[0]=='\n') lnend++;
	if(nxtln[1]=='\r'||nxtln[1]=='\n') lnend++;
	if(lnend) nxtln.delfirstN(lnend);
	return (nxtln[0])?1:0;
}

int		tcpreader::getnextdta0(chars& cs)
{
	getlnbuf(nxtln);cs.clear();if(nxtln[0]=='<') return 0;
	int n012; char*t=nxtln.s; int n=0;
	int done=0;
	while(!done){
		n012=is012(t);
		if     (n012==2) { cs.app(t,2); n+=n012; t+=n012;}
		else if(n012==1) {
			if(*t=='<') done=1;else { cs.app(t,1); n++; t++;}
		}else{
			n=0; nxtln.clear(); getlnbuf(nxtln);   t=nxtln.s;
			if(!nxtln[0]) return 0; //error in data file
		}
	}
	nxtln.delfirstN(n);
	return (nxtln[0])?1:0;
}

int		tcpreader::getlnbuf(chars& cs)
{
	//cs.delltspaces();
	if(cs.s[0]) return 1;
	while(!isEOF()) {
		//if(!getgline(cs)) return 0;
		getline(cs); if(kplnbr) cs+="\r\n";
		lnnow++;
		//cs.delltspaces();
		if(cs.s[0]) break;
	}
	return 1;
}
/*
int		tcpreader::nextistag(char* tag)
{
	if(!nextistag()) return 0;
	//return strncmp(tag, nxtln.s+1, strlen(tag));
	int len=1; char c=nxtln.s[1];
	if(c=='?'||c=='!') len=2;
	int res=strncmp(tag, nxtln.s+len, strlen(tag));
	return res==0;
	// will not work if tag pass line bnd, modify later
}

int		tcpreader::nextistag()
{
	getlnbuf(nxtln);
	return (nxtln[0]=='<')? 1: 0;
}
*/

int		tcpreader::getnext(chars& cs, int keepSB)
{
	return (nextistag())?getnexttag0(cs,keepSB):getnextdta0(cs);
	/*
	cs.clear();
	if(nxt[0]){
		if(keepSB&&nxt[0]=='<'){
			cs.set2(nxt.s+1);cs.dellastN(1);
		}else cs.set2(nxt.s);
	}
	getnext(); // always keep nxt entity in nxt
	return cs[0];
	*/
}
/*
int		tcpreader::getnext()
{
	int keepSB=1; //nxt.clear();
	(nextistag())?getnexttag0(nxttmp,keepSB):getnextdta0(nxttmp);
	return nxttmp[0];
}
*/
/*
	if(!nextistag()) return 0;
	//return strncmp(tag, nxtln.s+1, strlen(tag));
	int len=1; char c=nxtln.s[1];
	if(c=='?'||c=='!') len=2;
	int res=strncmp(tag, nxtln.s+len, strlen(tag));
	return res==0;
	// will not work if tag pass line bnd, modify later
*/
int		tcpreader::sametoken	(char* tocheck, char* token)
{
	return str_sametoken(tocheck, token);
	/*
	int len=strlen(token);
	if(strncmp(tocheck, token, len)!=0) return 0;
	char c=tocheck[len];
	if(is_tsrn(c)||ispunct(c)) return 1;
	return 0;
	*/
}
int	 chars::isxtag (char* tg)
{
	int n=find('<'); if(n<0) return 0;
	char* t=s+n+1; if(t[0]=='/'||t[0]=='?'||t[0]=='!') t++;
	return (tg)?str_sametoken(t,tg):1;
}

int	 chars::isxcomment()
{
	int n=find('<'); if(n<0) return 0;
	return (strncmp(s+n,"<!--",4)==0);
}

int	 chars::isnl()
{
	int sz=size(); if(sz>2) return 0;
	if(sz==2) if(s[0]=='\r'&&s[1]=='\n') return 1;
	else if(sz==1) if(s[0]=='\n') return 1;
	return 0;
}

int	 chars::isxetag(char* tg)//empty tag, note can have attr
{
	chars* ps=getcharsbuf();
	ps->set2(s); ps->delltspaces(); char* t=ps->s;
	if(t[0]!='<')return 0;
	int sz=ps->size(); if(sz<3) return 0;
	if( !(ps->s[sz-2]=='/'&&ps->s[sz-1]=='>') ) return 0;
	return (tg)?str_sametoken(t,tg):1;
}

int	 chars::isxotag(char* tg)//open tag
{
	int n=find('<'); if(n<0) return 0;
	char* t=s+n+1; if(t[0]=='/') return 0;
	return (tg)?str_sametoken(t, tg):1;
}

int	 chars::isxctag(char* tg)//close tag
{
	int n=find('<'); if(n<0) return 0;
	char* t=s+n+1; if(t[0]!='/') return 0;
	t++;	return (tg)?str_sametoken(t, tg):1;
}

int		tcpreader::nisotag		(char* tag)
{
	if(!nxtln[0]) getlnbuf(nxtln);
	if( (nxtln[0]=='<'&&nxtln[1]!='/') ) {
			return (tag)?sametoken(nxtln.s+1, tag):1;
	}
	return 0;
}

int		tcpreader::nisctag		(char* tag)
{
	if(!nxtln[0]) getlnbuf(nxtln);
	if( (nxtln[0]=='<'&&nxtln[1]=='/') ) {
			return (tag)?sametoken(nxtln.s+2, tag):1;
	}
	return 0;
}

int		tcpreader::nistag(char* tag)
{
	if( !nxtln[0]) getlnbuf(nxtln);
	if( (nxtln[0]=='<') ) {
		int b=1;		if(tag&&tag[0]!='/'&&nxtln[1]=='/') b=2;
		return (tag)?sametoken(nxtln.s+b, tag):1;
	}
	return 0;
}

int		tcpreader::nisln	 		()
{
	if(!nxtln[0]) getlnbuf(nxtln);
	return (nxtln[0]=='\r'&&nxtln[1]=='\n')?1:0;
}

int		tcpreader::nisdata		()
{
	if(!nxtln[0]) getlnbuf(nxtln);
	return (nxtln[0]!='<')?1:0;
}

int		tcpreader::niscommand()
{
	if(!nxtln[0]) getlnbuf(nxtln);
	return (nxtln[0]=='<'&&nxtln[1]=='?')?1:0;
}

void tcpreader::testread()
{
	chars cs;
	open("test.txt");
	while(!isEOF()){
		getnext(cs);
	}
	cs="ssss";
}

void tcpreader::testdel()
{
	char* ts[]={""
	,"this is"
	,"this is "
	," this is"
	,"  this is   "
	,"  �~�rthis is"
	,"�~�rthis is   "
	,"  \t�~�r\tthis is"
	,"  this is\t �~�r"
	,"  this�~�r is "
	,"  this�~�r is �~�r    "
	,""};
	char *t;   chars tt, ss;
	for(int i=1;i<10000;i++){
		t=ts[i]; if(!t[0]) break;
		tt=t;
		ss=t;ss.delleadspaces();
		ss=t;ss.deltrailspaces();
		ss=t;ss.delltspaces();
	}
}
// class tcpreader
//////////////////////////////////////

//////////////////////////////////////
// class config_

int 	config_::load(char* fname)
{
	tcpreader r; chars cs; xmltag tg1;
	//cs=curdir;
	cs=fname;
	r.open(cs.s, curdir.s);
	if(r.isERR()) return 0;
	int found=0;
	while(!r.isEOF()){
		r.getnext(cs);
		if(cs.isxtag("xml")) continue;
		if(cs.isxtag()){ found=1;
			tg1.set2Nhun(cs.s);
			for(int n=0; n<tg1.size(); n++)
				tg.set2(tg1.nth0(2*n),tg1.nth0(2*n+1));
			found=1;
		}
	}
	r.close();
	loadOK=1;
	return found;
}


int 	config_::save(char* fname)
{
	tg.setmpttag(1);
	writer w; chars cs;
	//cs=curdir;
	cs=fname;
	w.creat(cs.s,curdir.s);
	if(w.isERR()) return 0;
	w.writeln(xmlline1alone);
	cs=tg.tos(' ');
	w.writeln(cs.s);
	w.close();
	return 1;
}

/*
int 	config_::load(char* fname)
{
	tcpreader r; chars cs;
	cs=curdir; cs+=fname;
	r.open(cs.s);
	if(r.isERR()) return 0;
	int found=0;
	while(!r.isEOF()){
		r.getnext(cs);
		if(cs.isxtag("config")){
			tg.set2Nhun(cs.s);
			found=1;
		}
	}
	r.close();
	return found;
}


int 	config_::save(char* fname)
{
	tg.setmpttag(1);
	writer w; chars cs;
	cs=curdir; cs+=fname;
	w.creat(cs.s);
	if(w.isERR()) return 0;
	w.writeln(xmlline1alone);
	w.writeln("<body>");
	cs=tg.tos(' ');
	w.writeln(cs.s);
	w.writeln("</body>");
	w.close();
	return 1;
}
*/
// class config_
//////////////////////////////////////



//////////////////////////////////////
// class mainarg_


int mainarg_::
set1(char c, char* v)
{
	int nn=ndx(c);
	fg[nn]=1;
	if(v) av[nn]=v;
	return 1;
}

int mainarg_::
set(int argc, char* argv[])
{
	preset();
	if(argc<=1) return 0;
	chars s, sa;
	int nn=1; //int hasnodash=0;
	ac=argc;
	s=argv[nn];
	if( (s.s[0]=='?')||(s.bw("help")) ) {
		forhelp=1;
		if(argc<3) { msgbox("mainarg: help what?\n\n"); return 1; }
		nn++; s=argv[nn]; set1('?', s.s);//fg[ndx('?')]=1; av[ndx('?')]=s;
		//hasnodash=1;
		return 1;
	}else	if(s.s[0]!='-') {
		set1('o', s.s);
		//av[ndx('o')]=s.s; // 1st argument default2 output, if not specified
		if(argc>=3) {	nn++; s=argv[nn]; }
		//hasnodash=1;
	}
	// other arguments should lead with - flag
	while( nn< argc ) {
		if( (s.s[0]!='-')||( (!isalpha(s.s[1]))&&(!isdigit(s.s[1])) ) ) {
			msgbox("mainarg: argument '",s.s, "' should \n  lead with - and then a single char flag\n");
			err=1;	return 0;
		}
		sa.clear(); if(nn+1<argc) sa=argv[nn+1];
		if( (sa.s[0]=='-') ) {
			sa.clear();
			//msgbox(sa.s, "\tmainarg: argument follows -flag should not start with '-'\n");
			//err=1;	return 0;
		}
		set1(s.s[1], sa.s); //fg[ndx(s.s[1])]=1; av[ndx(s.s[1])]=sa.s;
		if(sa.s[0]) nn+=2; else nn++;
		if(nn<argc) s=argv[nn];
	}
	return ac;
}

// class mainarg_
//////////////////////////////////////



//////////////////////////////////////
// struct szmio
int  szmiohs::hdrbsz=sizeof(rdhdr);

void szmio::
del()//{if(pm) UnmapViewOfFile(pm);pm=0;sz=0;}
{
	if(!pm) return;
  #ifdef WIN32DLL
  if(pm)UnmapViewOfFile(pm);
	//msgbox9("pm deleted");
  #else
	delete[] pm;
  #endif
	pm=0;sz=0;
}

char* szmio::
new2(long bsize, int extra)//extra default2 0
{
	#ifdef WIN32DLL
	HANDLE h;
	h=CreateFileMapping( (HANDLE)-1,NULL,PAGE_READWRITE,0,1+bsize+extra,NULL);
	if(!h)return NULL;
	pm=(PSTR)MapViewOfFile(h,FILE_MAP_WRITE,0,0,0);
	sz=(pm)?bsize:0;
	return pm;
	#else //WIN32DLL
	pm=new char[1+bsize+extra];pm[bsize+extra]=0;//return pm;
	sz=(pm)?bsize:0; return pm;
	#endif //WIN32DLL
}
long	szmio::
bszasinhdr() //treat pm as hdr_, return the bsz
{
	rdhdr* hd=(rdhdr*)pm;
	return hd->bsz;
}

// struct szmio
//////////////////////////////////////

chars di5wis_::ll;
chars di5wis_::rr;
di53rd_ rdnull;


int wisdirikive(const void* l, const void* r)
{
	rikive* ll,*rr; ll=(rikive*)l; rr=(rikive*)r;
	int res;
	res=(uchar)(ll->r[0])-(uchar)(rr->r[0]);
	if(res) return res;
	res=(uchar)(ll->r[1])-(uchar)(rr->r[1]);
	if(res) return res;
	res=ll->k-rr->k;
	return res;
}

int __cdecl wisc1su(const void* l, const void* r)
{ return strcmp( (cchar*)l, (cchar*)r ); }



int dilaives::afterread()
{
	if(!( mmrkv.s()&&mmki.s() ) ) return 0;
	rdhdr* hd;
	hd  =(rdhdr *) mmrkv.h();
	rkvs=(rikive*) mmrkv.s(); nRKVS=hd->asz;
	hd  =(rdhdr *) mmki.h();
	kis =(char  *) mmki.s(); nKIS=hd->asz; kilen=hd->usz;
	return 1;
}

char* dilaives ::
ki	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	ps->set2( kis+ (rkvs[n.n].k)*kilen );
	return ps->s;
}


char* dilaives ::
ki0	( dilaive &n )
{
	char* t=ki(n);
	str_del4wis(t);
	return t;
}

char* dilaives ::
ri	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	if(rkvs[n.n].ishanri()){ps->app(rkvs[n.n].r,2);return ps->s;}
	return ki0(n);
}

char* dilaives ::
line	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	ps->apptab(ri(n));
	ps->app(ki(n));
	return ps->s;
}



char* dilaives ::
imtau	( dilaive *a, int K)
{
	chars* ps=getcharsbuf(); char t; int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		t= kis[ (rkvs[a[k].n].k)*kilen ];
		ps->app(t);
	}
	return ps->s;
}


char* dilaives ::
ri	( dilaive *a, int K, char sep )
{
	chars* ps=getcharsbuf();	int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ri (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* dilaives ::
ki	( dilaive *a, int K, char sep )
{
	chars* ps=getcharsbuf();   int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* dilaives ::
ki0	( dilaive *a, int K, char sep ) // remove digits except leading ones and no sep
{
	chars* ps=getcharsbuf();	int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki0(a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}


char* dilaives ::
line( dilaive *a, int K, char sep ) //use full info with sep='-'
{
	chars* ps=getcharsbuf();
	ps->app(ki(a,K,'-'));
	if(sep)ps->app(sep);
	ps->app(ri(a,K));
	return ps->s;
}

rikive dilaives ::
torikive (const char* ri, const char* ki)
{
	rikive rk; static chars s;
	//int n=kis.ndx(ki);
	int n=bfind(ki, kis, nKIS, kilen, wisc1su);
	if(n<=0)
		return rk;
	rk.k=n;
	s.set2(ki); s.trdigits();//s.dellastdigit();
	if( (strcmp(ri,s.s)==0)||(ri[0]=='*') ) {	rk.r[0]='*';rk.r[1]='*'; }
	else  {	rk.r[0]=ri[0]; rk.r[1]=ri[1]; }
	return rk;
}

int dilaives ::
kindx (cchar* ki)							// works for 1 ri/ki
{
	return bfind(ki, kis, nKIS, kilen, wisc1su);
}

int dilaives ::
ndx (const char* ri, const char* ki)
{
	rikive rk=torikive(ri, ki);
	int n=bfind(&rk, rkvs, nRKVS, sizeof(rikive), wisdirikive);
	return n;
}


int di5wis_:: nrK(const void*l, const void*r, dilaivesNxtr* lvx)
{
	ll=(char*)l;
	rr=lvx->lv->ki0( (dilaive*)r, lvx->K);
	return strcmp(ll.s,rr.s);
}

int di5wis_:: nit(const void*l, const void*r, di53rd_* rd)
{
	ll=(char*)l;
	rr=rd->it( *((ushort*)r) );
	//rr=rd->lvx.lv->it( (dilaive*)r, rd->lvx.K);
	return strcmp(ll.s,rr.s);
}

int pfit1vun  (const char* kiin, const char* rr)
{
	char* lll=(char*)kiin;
	while(*lll) { if(*lll != *rr) return 0; lll++; rr++;}
	return lll-kiin;
}

int pfit1py(const char* kiin, const char* rr, int mustfit_diau)
	//pfit1:partial fit, assuem ll is kiin, and shorter
	// r: #bytes in ll that is partially used by rr
{ // ignore digit and -
	char* l=(char*)kiin; char* r=(char*)rr;
	while( (*l) && (*r) ) {
		if(*r == '-') { r++; if(*l == '-')  { l++;} continue; }
		if(*l=='-') { if(!isdigit(*r)) return 0;  l++; r++;  continue; }
		if(isdigit(*l)) {
			if(l[1]==0)  // so that last diauhor will work
				{ if(*l != *r) return 0;  l++; r++;  continue;} // next loop will exit
			if(mustfit_diau) { if(*l != *r)    return 0;l++;r++;if(*l=='-')l++;continue; }
			else             { if(!isdigit(*r))return 0;l++;r++;if(*l=='-')l++;continue; }
		}
		//if(isdigit(*r)) { r++; if(isdigit(*l)) l++;if(*l=='-'){l++;}continue; }// ll is kiin
		if(isdigit(*r)) {
			if(r[1]==0)
			{ r++; continue; }// next loop will exit
			if(mustfit_diau) { if(*l != *r ) return 0; l++; r++; if(*l=='-')l++;continue;}
			else             { r++; if(isdigit(*l)) l++;if(*l=='-')l++;continue; }// ll is kiin
		}
		//if(isdigit(*r)) { r++; if(isdigit(*l)) l++;continue; }// ll is kiin
		if( (*l) == (*r) ) { l++; r++; continue; } else break;
		//return (*l)-(*r);
	}
	if(*l) return 0; // some ki is not equal
	return (r-rr);
}




int di53rd_::
isnit()
{
	char* t=hd_->idfier();
	return(t[0]=='n'&&t[1]=='i'&&t[2]=='t')?1:0;
}

int di53rd_::
lower(char*s)
{
	switch (luibet()) {
	case DIRD_NRK:
		return wislower1(smd(s), dt_, size(), lvx.usz, wisx, &lvx);
	case DIRD_NIT:
		return wislower1(smd(s), dt_, size(), sizeof(ushort), wisx, base4nit);
	case DIRD_DZB:
	case DIRD_DZB3:
		return wislower (smd(s),dst_,size(),sizeof(char**),wis);
	}
	return -1;
	//return (wisx)?
	//wislower1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
	//wislower (smd(s),dst_,size(),sizeof(char**),wis);
}

int di53rd_::
upper(char*s)
{
	switch (luibet()) {
	case DIRD_NRK:
		return wisupper1(smd(s), dt_, size(), lvx.usz, wisx, &lvx);
	case DIRD_NIT:
		return wisupper1(smd(s), dt_, size(), sizeof(ushort), wisx, base4nit);
	case DIRD_DZB:
	case DIRD_DZB3:
		return wisupper (smd(s),dst_,size(),sizeof(char**),wis);
	}
	return -1;
	//return (wisx)?
	//wisupper1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
	//wisupper (smd(s),dst_,size(),sizeof(char**),wis);
}
int di53rd_::
lu  (char*s, int*l, int*u)
{
	*l=lower(s); *u=upper(s);
	return 0; // 0 is nonsense
}

int di53rd_::
lmu  (char*s, int*l, int*m, int*u)
{
	char c=char(255); static chars ss; ss=s;
	*l=lower(s);
	*m=upper(s); ss+=c;
	*u=upper(ss.s);
	return 0; // 0 is nonsense
}

char* di53rd_::
ki (USHORT n)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n;
		return (lvx.lv)->ki(rkn, K);
	case DIRD_NIT:
		return base4nit->it(((ushort*)dt_)[n]);
	case DIRD_DZB:
	case DIRD_DZB3:
		return (keyi())?d0(n):d1(n);
	}
	return s4null;
}

char* di53rd_::
im (USHORT n)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n;
		return (lvx.lv)->ki(rkn, K);
	case DIRD_NIT:
		return base4nit->ki(((ushort*)dt_)[n]);
	case DIRD_DZB:
		return (keyi())?d0(n):d1(n);
	case DIRD_DZB3:
		return d2(n);
	}
	return s4null;
}

char* di53rd_::
ri (USHORT n)
{
	dilaive *rkn; rikive rk;// static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n;
		return (lvx.lv)->ri(rkn, K);
	case DIRD_NIT:
		return base4nit->ri(((ushort*)dt_)[n]);
		//rkn=( (dilaive*)(base4nit->dt_) )+ K*((ushort*)dt_)[n];
		//return (lvx.lv)->ri(rkn, K);
	case DIRD_DZB:
	case DIRD_DZB3:
		return (keyi())?d1(n):d1(n);
	}
	return s4null;
}

char* di53rd_::
it (ushort n) // only nrK will return imtau, nit should use ki
{
	if(luibet()!=DIRD_NRK) return s4null;
	dilaive *rkn; rikive rk;
	rkn=((dilaive*)dt_)+K*n;
	return (lvx.lv)->it(rkn, K);
}

char* 	 di53rd_::
ki (USHORT n, int nthpart) // depends on luibet
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+nthpart;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}

char*    di53rd_::
ri (USHORT n, int nthpart) // depends on luibet
{
	dilaive *rkn; rikive rk;// static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+nthpart;
		return (lvx.lv)->ri(rkn, 1);
	}
	return s4null;
}

char*		 di53rd_::
im (ushort n, int nthpart)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+nthpart;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}


char*    di53rd_::
eki (USHORT n) // depends on luibet
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+K-1;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}

char*    di53rd_::
eri (USHORT n) // depends on luibet
{
	dilaive *rkn; rikive rk;// static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+K-1;
		return (lvx.lv)->ri(rkn, 1);
	}
	return s4null;
}

char*		 di53rd_::
eim (ushort n)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+K-1;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}




int di53rd_::
afterread()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(void*)(mm.s)();
	switch (luibet()) {
	case DIRD_NRK: //return 1;
		wisx=(int(*) (const void *, const void *, const void*))di5wis.nrK;
		K=(hd_->usz)/sizeof(ushort); lvx.K= K;
		return 1;
	case DIRD_NIT: // need 2 set base
		wisx=(int(*) (const void *, const void *, const void*))di5wis.nit;
		K=1;
		return 1;
	case DIRD_DZB:
		setinnr(); return 1;
	case DIRD_DZB3:
		setinnr(); return 1;
	}
	return 0;
}

void di53rd_::
setinnr()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	//if(hd_->frq) jumpbyte=1+sizeof(float); else jumpbyte=0;
	if(hd_->frq) jumpbyte=1+(hd_->frq)*sizeof(int); else jumpbyte=0;
	if(hd_->key=='r')
		wis = (jumpbyte)?di5wis.byki  : di5wis.byki;
	else
		wis = (jumpbyte)?di5wis.byki0 : di5wis.byki0;
	//int hasfreq=jumpbyte?1:0;
	hsd2= cols_is()>=2;
	hsd3= cols_is()>=3;
	hsd4= cols_is()>=4;
	hsd5= cols_is()>=5;
	int i, items=hd_->asz;
	dst_=new char*[items+1];
	dst_[items]=0;
	//int ll;
	char* p=(char*)dt_; uchar llc;
	if(!jumpbyte) {
		llc= *p++;
		for(i=0; i<items; i++) {
			dst_[i]=p;
			p += llc;				    llc = (*p);		*p++ =0;
			if(hsd2) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd3) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd4) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd5) {p += llc; llc = (*p);		*p++ =0;}
		}
	}else{
		for(i=0; i<items; i++) {
			*p=0; 		p+=jumpbyte;
			llc=(uchar)(*p); *p++=0;  dst_[i]=p;	p+=llc;
			if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		}
		//for(i=0; i<items; i++) {
			//dst_[i]=p;		p+=(jumpbyte-1);
			//llc = (uchar)(*p);         *p++=0; p+=llc;
			//if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			//if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			//if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			//if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		//}
	}
	jumpbyte=0;
}

int		ustmio::
read (tyio& io)
{
	h.read(io);
	if(!h.isOK()) return 0;
	ph=(hust*)h();
	v.read(io);
	if(!v.isOK()) return 0;
	pv=(UCHAR*)v();
	return (h.sz+v.sz);
}

int ustmio::
new2(long asize)
{
	int bsize=asize;
	h.new2(sizeof(hust));
	ph=(hust*)h();
	v.new2(bsize);
	pv=(UCHAR*)v();
	if(!( (ph)&&(pv) )) return 0;
	ph->setidfv(); ph->setabu(asize,bsize,0);
	int b;UCHAR*t=pv;for(b=0;b<bsize;b++)*t++=0;
	return 1;
}

int ustmio::
status(USHORT n)
{if(!isOK(n))return 0;return (pv[n]);}

void ustmio::
suaned(USHORT n, USHORT n0, USHORT n9) //[n0,n9):range
{
  if(!isOK(n))return; USHORT nn; 
	for(nn=n0;nn<n9;nn++) pv[nn]=0;
	//if(n>=0)
	pv[n]=1;
}

void ustmio::
unsuaned(USHORT n0, USHORT n9) //[n0,n9):range
{
  USHORT nn; 
	for(nn=n0;nn<n9;nn++) pv[nn]=0;
}




#ifdef OLDOLDOLDOLDOLD

//////////////////////////////////////
// class riki, nriki, laivetos

char* laivetos ::
tos_ki	( rikin n )
{
	chars* ps=getcharsbuf();
	ps->set2( kis+ (ns[n.n].k)*WKI );
	return ps->s;
}


char* laivetos ::
tos_ki0	( rikin n )
{
	char* t=tos_ki(n);
	str_del4wis(t);
	return t;
}

char* laivetos ::
tos_ri	( rikin n )
{
	chars* ps=getcharsbuf();
	if(ns[n.n].ishanri()){ps->app((char*)(ns+n.n),2);return ps->s;}
	return tos_ki0(n);
}

char* laivetos ::
tos_line	( rikin n )
{
	chars* ps=getcharsbuf();
	ps->apptab(tos_ri(n));
	ps->app(tos_ki(n));
	return ps->s;
}


char* laivetos ::
tos_imtau	( rikin *a, int K)
{
	chars* ps=getcharsbuf(); char t;
	for(int k=0; k<K; k++) {
		t= kis[ (ns[a[k].n].k)*WKI ];
		ps->app(t);
	}
	return ps->s;
}


char* laivetos ::
tos_ri	( rikin *a, int K, char sep )
{
	chars* ps=getcharsbuf();
	int k;
	for(k=0; k<K; k++) {
		ps->app( tos_ri (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* laivetos ::
tos_ki	( rikin *a, int K, char sep )
{
	chars* ps=getcharsbuf();
	if(!a[0].n) return ps->s;
	int k;
	for(k=0; k<K; k++) {
		ps->app( tos_ki (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* laivetos ::
tos_ki0	( rikin *a, int K, char sep ) // remove digits except leading ones and no sep
{
	chars* ps=getcharsbuf();
	int k;
	for(k=0; k<K; k++) {
		ps->app( tos_ki0(a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}


char* laivetos ::
tos_line( rikin *a, int K, char sep ) //use full info with sep='-'
{
	chars* ps=getcharsbuf();
	ps->app(tos_ki(a,K,'-'));
	if(sep)ps->app(sep);
	ps->app(tos_ri(a,K));
	return ps->s;
}

//static int __cdecl wisc1su(const void* l, const void* r)
//{ return strcmp( (cchar*)l, (cchar*)r ); }

riki laivetos ::
toriki (const char* ri, const char* ki)
{
	riki rk; static chars s; s.set2(ki); //s.dellastdigit();
	//int n=kis.ndx(ki);
	int n=bfind(ki, kis, kislen, WKI, wisc1su);
	if(n<=0)
		return rk;
	rk.k=n;  s.dellastbyte();
	if( (strcmp(ri,s.s)==0)||(ri[0]=='*') ) {	rk.r[0]='*';rk.r[1]=0; }
	else  {	rk.r[0]=ri[0]; rk.r[1]=ri[1]; }
	return rk;
}


int di53rd_::
lmu  (char*s, int*l, int*m, int*u)
{
	char c=char('0x\255'); static chars ss; ss=s;
	*l=lower(s); *m=upper(s); ss+=c; *u=upper(ss.s);
	return 0; // 0 is nonsense
}

char* di53rd_::
ki (USHORT n)
{
	rikin *rkn; riki rk; char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((rikin*)dt_)+n;
		return (lvK->lv)->tos_ki(rkn, lvK->K);
	case DIRD_NIT:
		rkn=( (rikin*)(base4nit->dt_) )+ ((ushort*)dt_)[n];
		return (lvK->lv)->tos_it(rkn, lvK->K);
	case DIRD_DZB:
		return (keyi())?d1(n):d2(n);
	case DIRD_LAIVE:
		rk=((riki*)dt_)[n];
		return (lvK->lv)->tos_ki(rk.k);
	case DIRD_C1SU:
		//ki1=( (char*)dt_+(hd_->usz)*n );//w/ fixed length char array
		ki1=( dst_[n] ); // w/ c1dzb
		return ki1;
	}
	return s4null;
}

char* di53rd_::
ri (USHORT n)
{
	rikin *rkn; riki rk; static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((rikin*)dt_)+n;
		return (lvK->lv)->tos_ri(rkn, lvK->K);
	case DIRD_NIT:
		rkn=( (rikin*)(base4nit->dt_) )+ ((ushort*)dt_)[n];
		return (lvK->lv)->tos_ri(rkn, lvK->K);
	case DIRD_DZB:
		return (keyi())?d2(n):d2(n);
	case DIRD_LAIVE:
		rk=((riki*)dt_)[n];	s[0]=rk.r[0]; s[1]=rk.r[1]; s[2]=0;
		return s;
	case DIRD_C1SU:
		return s4null;
	}
	return s4null;
}

int di53rd_::
afterread()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(void*)(mm.s)();
	switch (luibet()) {
	case DIRD_NRK: return 1;
	case DIRD_NIT: return 1; // need 2 set base
	case DIRD_DZB:
		setinnr(); return 1;
	case DIRD_LAIVE: return 1;
	case DIRD_C1SU: // array of fixed size(usz)
		//usz=hd_->usz;
		setinnr();
		return 1;
	}
	return 0;
}

void di53rd_::
setinnr()
{
  hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	if(hd_->frq) jumpbyte=1+sizeof(float); else jumpbyte=0;
	if(hd_->key=='r') wis = (jumpbyte)?di5wis.r2if : di5wis.r2i; 
	else wis = (jumpbyte)?di5wis.i2rf : di5wis.i2r;
	int hasfreq=jumpbyte?1:0;
	hsd2= (cols_is()-hasfreq)>=2;
	hsd3= (cols_is()-hasfreq)>=3;
	hsd4= (cols_is()-hasfreq)>=4;
	hsd5= (cols_is()-hasfreq)>=5;
	int i, items=hd_->asz;
  dst_=new char*[items+1];
	dst_[items]=0;
	//int ll;
  char* p=(char*)dt_; uchar llc;
  if(!jumpbyte) {
		llc= *p++;
	  for(i=0; i<items; i++) {
			dst_[i]=p;
			p += llc;				    llc = (*p);		*p++ =0;
			if(hsd2) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd3) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd4) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd5) {p += llc; llc = (*p);		*p++ =0;}
		}
	}else{
		for(i=0; i<items; i++) {
			dst_[i]=p; p+=(jumpbyte-1); 
			llc = (uchar)(*p);         *p++=0; p+=llc;
			if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		}
  }
}


// class riki, nriki, laivetos
//////////////////////////////////////

void dzb53_::
setinnr()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	if(hd_->frq) jumpbyte=1+sizeof(float); else jumpbyte=0;
	if(hd_->key=='r') wis = (jumpbyte)?di5wis.r2if : di5wis.r2i;
	else wis = (jumpbyte)?di5wis.i2rf : di5wis.i2r;
	int hasfreq=jumpbyte?1:0;
	hsd2= (cols_is()-hasfreq)>=2;
	hsd3= (cols_is()-hasfreq)>=3;
	hsd4= (cols_is()-hasfreq)>=4;
	hsd5= (cols_is()-hasfreq)>=5;
	int i, items=hd_->asz;
	dst_=new char*[items+1];
	dst_[items]=0;
	//int ll;
	char* p=dt_; uchar llc;
	if(!jumpbyte) {
		llc= *p++;
		for(i=0; i<items; i++) {
			dst_[i]=p;
			p += llc;				    llc = (*p);		*p++ =0;
			if(hsd2) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd3) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd4) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd5) {p += llc; llc = (*p);		*p++ =0;}
		}
	}else{
		for(i=0; i<items; i++) {
			dst_[i]=p; p+=(jumpbyte-1);
			llc = (uchar)(*p);         *p++=0; p+=llc;
			if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		}
	}
}

int dzb53_::
lmu  (char*s, int*l, int*m, int*u)
{
	char c=char('0x\255'); static chars ss; ss=s;
	*l=lower(s); *m=upper(s); ss+=c; *u=upper(ss.s);
	return 0; // 0 is nonsense
}

#endif //#ifdef OLDOLDOLDOLDOLD





//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// for pinimexpander
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

class vbnum { public: voids<short> N,n;
	int  app(short Ni) { short i=0; N.app(Ni); n.app(i); return 1;}
	int  operator= (int i);
	int  operator++(int  );
	int  isinbound();
	int  size() { return N.size(); }
	void clear(){ N.clear(); n.clear(); }
	void reset(){ clear(); }
};

int vbnum::operator=(int i)
{// note that this is kind of reversed
	int pos; int j;
	for(pos=0; pos<N.size(); pos++) {
		j=i%N[pos]; i=i/N[pos]; n[pos]=j; 
	}
	if(i) return 0; return 1;
}

int vbnum::operator++(int)
{// note that this is kind of reversed
	int pos;
	for(pos=0; pos<N.size(); pos++) {
		n[pos]++; 
		if(n[pos]<N[pos]) break; 
		else {if(pos<N.size()-1) n[pos]=0; }
	}
	return 1;
}

int vbnum::isinbound()
{// note that this is kind of reversed
	int pos;
	for(pos=0; pos<N.size(); pos++) {
		if(n[pos]>=N[pos]) return 0;
	}
	return 1;
}

class charspps : public voids<charspp> { public:
	void		hun();
	void    setvbnum(vbnum* vbn);
	chars*operator[](vbnum* vbn);
};

void charspps::setvbnum(vbnum* vbn)
{
	int pos; vbn->clear();
	for(pos=0;pos<size();pos++) {
		vbn->app(a[pos].size());
	}
}

void charspps::hun()
{
	int pos;
	for(pos=0;pos<size();pos++) a[pos].hunorset();
}

chars*charspps::operator[](vbnum* vbn)
{
	int pos; chars* ps=getcharsbuf();
	for(pos=0;pos<size();pos++){
		ps->app(a[pos][(vbn->n[pos])]);
		if(pos<size()-1) ps->app("-");
	}
	return ps;
}


int pinimexpander::set2Nexpand(char*s)
{
	//clear();
	output.clear();
	static charspp pinims; int N,n;
	N=pinims.set2Nhunpinim(s); if(N<1) return 0;
	static charspps spps; static charspp sppbuf; static vbnum vbn;
	static chars sbuf;
	spps.clear();
	for(n=0;n<pinims.size();n++)	{
		sppbuf.set2(pinims[n]);
		spps.app(sppbuf);
	}
	spps.hun();
	spps.setvbnum(&vbn);
	for(vbn=0; vbn.isinbound(); vbn++) {
		sbuf.set2((*(spps[&vbn])).s);
		output.s0.apptab(sbuf.s);
	}
	output.hun();
	return output.size();
}

int tcpmlexpander::set2Nexpand(char*x)
{
	static xmltagrw tg; static pinimexpander xpd;
	tg.set2Nhun(x); char* im;
	im=tg["i"];
	if(!str_hasorset(im))
		{ output.s0.set2(x);output.pp0.set20();output.pp0.app(output.s0.s);return 1;}
	xpd.set2Nexpand(im); output.s0.clear();
	for(int n=0; n<xpd.size(); n++){
		tg.set2("i", xpd[n]);
		output.s0.app(tg.tos()); if(n<xpd.size()-1) output.s0.app(ch01);
	}
	output.cut(ch01);
	return output.size();
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

int		segtr_::check4skip(char*s)
{
	static char pt []="�C�A�H�I�F";
	static char pt1[]=".,?!;";
	int n012=str_rbytes(s);
	if(n012==2)	for(int n=0; n<10; n+=2){
		if( (s[0]==pt[n])&&(s[1]==pt[n+1]) ) return pt1[n/2];
	}
	if(n012==1) if(ispunct(*s)) return 1;
	if(str_alldigits(s)) return 1;
	int sz, SZ=strlen(s); char* t=s;
	for(sz=0; sz<SZ; sz++){
		n012=str_rbytes(t);
		if(n012!=1) return 0;
		if(!isalnum(*t)) return 0;
	}
	if(SZ>0) if(isdigit(t[SZ-1])) return 1;
	return 0;
}

int		segtr_::
smmseg		(chars& ocs, charspp& in, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs; int CNT=0;
	int n, b,e,B=0,E=in.size();
	ocs.clear();
	b=B;
	while(b<E){
		e=b+maxsu; csbe(e, b, E);
		while(b<e){
			cs=in.tos("",b,e);
			if(e-b<=1) { ocs+=cs.s; ocs+=sep; b=e; CNT++; break; }
			lu.clear();
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) break;
			}
			if(lu.l<lu.u){
				ocs+=cs.s; ocs+=sep; b=e; CNT++;
			}else e--;
		}
	}
	if(CNT>0) ocs.dele(1);
	return ocs.size();
}
int		segtr_::
mmseg		(chars& ocs, charspp& in, char sep)
{
	if(nwrds<=0) return 0;
	int B=0,E=in.size();
	int nmsu=maxsu; if(nmsu>E-B) nmsu=E-B;
	ocs.clear();
	int CNT=mmseg(ocs, in, B, E, nmsu, sep);
	if(CNT>0) ocs.dele(1);
	return CNT;
}

int		segtr_::
mmseg		(chars& ocs, charspp& in, int B, int E, int nmsu, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs;
	int n, b,e, nsu; if(nmsu>E-B) nmsu=E-B;
	int found=0;	lu.clear();
	if(E-B>1) for(nsu=nmsu; nsu>1; nsu--){
		for(b=B; b<E-1; b++){
			e=b+nsu; if(e>E) break;
			cs=in.tos("",b,e);
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) {found=1; break;}
			}
			if(found) break;
		}
		if(found)break;
	}
	int CNT=0;
	if(found){
		if(B<b) CNT+=mmseg(ocs, in, B, b, nsu-1, sep);
		ocs+=cs.s; ocs+=sep; CNT++;
		if(e<E) CNT+=mmseg(ocs, in, e, E, nsu,   sep);
	}else{
		for(b=B; b<E; b++){
			ocs+=in[b]; ocs+=sep;
		}
		CNT=E-B;
	}
	return CNT;
}

char* segtr_::
seg(char* s, int domm, char sep){ //charspp spp, ispp;
	static chars ocs;
	chars ocs1;
	ocs.clear();//      chars tmp;
	ispp.set2Nhungu(s,1);
	int IK=ispp.size();
	for(int n=0; n<IK; n++){
		tspp.set2Nhunhanlor(ispp[n]); //!!!!!!!!!
		if(domm)		mmseg(ocs1, tspp, '=');
		else			 smmseg(ocs1, tspp, '=');
		ocs+=ocs1; if(n<IK-1) ocs+="\r\n";
	}
	return ocs.s;
}

char* segtr_::
tr(char* s, int domm, char sep){ //charspp spp, ispp;
	static chars ocs;
	chars ocs0, ocs1;
	ocs.clear();//      chars tmp;
	ispp.set2Nhungu(s,1);
	int IK=ispp.size();
	for(int n=0; n<IK; n++){
		tspp.set2Nhunhanlor(ispp[n]); //!!!!!!!!!
		if(domm)		mmtr(ocs0, ocs1, tspp, sep);
		else			 smmtr(ocs0, ocs1, tspp, sep);
		ocs+=ocs0;  if(n<IK-1) ocs+="\r\n"; ocs+="\t";
		ocs+=ocs1;  if(n<IK-1) ocs+="\r\n";
	}
	return ocs.s;
}


int		segtr_::
smmtr		(chars& ocs0,chars& ocs1, charspp& in, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs; int CNT=0;
	int n, b,e,B=0,E=in.size();
	ocs0.clear(); ocs1.clear();
	b=B;
	while(b<E){
		e=b+maxsu; csbe(e, b, E);
		while(b<e){
			cs=in.tos("",b,e);
			//if(e-b<=1) { ocs+=cs.s; ocs+=sep; b=e; break; }
			lu.clear();
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) break;
			}
			if(lu.l<lu.u){
				ocs0+=cs.s; ocs0+=sep;
				ocs1+=wrds[n]->d1(lu.l); ocs1+=sep;
				b=e; CNT++;
			}else {
				e--;
				if(e<=b) { // this single entry can not be found in wrds
					ocs0+=cs.s; ocs0+=sep;
					int ck=check4skip(cs.s);
					if(ck){if(ck>1)ocs1+=(char)ck;else ocs1+=cs.s;}else ocs1+="???";
					ocs1+=sep;
					b++; CNT++;
				}
			}
		}
	}
	if(CNT>0) { ocs0.dele(1);ocs1.dele(1);}
	return CNT;
}

int		segtr_::
mmtr		(chars& ocs0,chars& ocs1, charspp& in, char sep)
{
	if(nwrds<=0) return 0;
	int B=0,E=in.size();
	int nmsu=maxsu; if(nmsu>E-B) nmsu=E-B;
	ocs0.clear();	ocs1.clear();
	int CNT=mmtr(ocs0,ocs1, in, B, E, nmsu, sep);
	if(CNT>0) { ocs0.dele(1); ocs1.dele(1);}
	return CNT;
}

int		segtr_::
mmtr		(chars& ocs0,chars& ocs1, charspp& in, int B, int E, int nmsu, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs;
	int n, b,e, nsu; if(nmsu>E-B) nmsu=E-B;
	int found=0;	lu.clear();
	//if(E-B>1)
	for(nsu=nmsu; nsu>0; nsu--){ //0: not 1, since need check downto 1 entry
		for(b=B; b<E; b++){ // E: not E-1, since need check downto 1 entry
			e=b+nsu; if(e>E) break;
			cs=in.tos("",b,e);
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) {found=1; break;}
			}
			if(found) break;
		}
		if(found)break;
	}
	int CNT=0;
	if(found){
		if(B<b) CNT+=mmtr(ocs0,ocs1, in, B, b, nsu-1, sep);
		ocs0+=cs.s; ocs0+=sep; ocs1+=wrds[n]->d1(lu.l); ocs1+=sep; CNT++;
		if(e<E) CNT+=mmtr(ocs0,ocs1, in, e, E, nsu,   sep);
	}else{
		for(b=B; b<E; b++){
			ocs0+=in[b]; ocs0+=sep;
			int ck=check4skip(in[b]);
			if(ck){if(ck>1)ocs1+=(char)ck;else ocs1+=in[b];}else ocs1+="???";
			//if(check4skip(in[b])){ocs1+=in[b];}else ocs1+="???";
			ocs1+=sep;
		}
		CNT=E-B;
	}
	return CNT;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

int	 	csfname4play1daiqi(chars& cs, char* ext, float& emph)
{
	emph=-1;
	if(cs.hasnone()) return 0;
	if(cs.ew(".sp")) cs.dele(3);
	char c,cd=cs.lastbyte();
	if(isdigit(cd)){
		cs.dele(1);
		c=cs.lastbyte();
		if(!(c=='p'||c=='t'||c=='k'||c=='h')){
			switch (cd) {
			case '6': cd='1';break;
			case '7': cd='2';break;
			case '8': cd='3';break;
			}
		}else
		if((c=='p'||c=='t'||c=='k')){
			switch (cd) {
			case '1': cd='6';break;
			case '2': cd='7';break;
			case '3': cd='8';break;
			}
		}else
		if(c=='h'){
			switch (cd) {
			case '3': cs.dele(1);break;
			case '4': cs.dele(1);break;
			case '8': cs.dele(1);cd='3';break;
			}
		}
		if(cs.is("m")||cs.is("hm"))
				emph=3;
		else if(cs[1]=='n'&&cs[2]=='g'&&str_isin(cs[0],"bpmvdtnlgkqzcsrh"))
				emph=2;
		else if(cs[0]=='n'&&cs[1]=='g')
				emph=3;

		if(cd=='3'||cd=='8') {
			if(cs.is("m")||cs.is("hm"))
				emph=8;
			else if(str_isin(cs[0],"mnvqaeiou"))
				emph=2;
			else if(cs[1]=='n'&&cs[2]=='g'&&str_isin(cs[0],"bpmvdtnlgkqzcsrh"))
				emph=4.5;
			else if(cs[0]=='n'&&cs[1]=='g')
				emph=6;
			else if(emph<0)
				emph=2;
		}else
		if(cd=='5')
			emph=2;
		cs+=cd;
	}
	cs+=".sp";
	return 1;
}

int	 	csfname4play1daiqi(chars& cs) 												// check/set
{
	char ext[]="sp"; float emph;
	return	csfname4play1daiqi(cs,ext,emph);
}
int	 	csfname4play1daiqi(chars& cs, char* ext) 							// check/set
{
	float emph;
	return	csfname4play1daiqi(cs,ext,emph);
}
int	 	csfname4play1daiqi(chars& cs, float& emph) 						// check/set
{
	char ext[]="sp";
	return	csfname4play1daiqi(cs,ext,emph);
}
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////


#endif //#ifndef DIBASE_CPP



#ifdef OLDOLDOLDOLDOLD

struct rdhdr51 { // riden header, note: sizeof(di51rdhdr) is 28, different from previous version 32
  char idf[8];
  long asz;		// size of data in unit of usize (array size)
  long bsz;		// size of data in unit of byte  (array size in bytes)
  long usz;		// size of each unit, 0 if not const
  long K;			// under anybody's interpretation
	USHORT vM; USHORT vm;
  rdhdr51() {  setidfv(); setabuK(0,0,0,0); idf[0]=0; }
	void setidfier (char*s,int n=8){ if(n>8)n=8;strncpy(idf,s,n); }
  void getidfier (char*s        ){ strncpy(s,idf,8);s[8]=0; }
  void peekidfier(tyio& r, char* s){int i; r.read(&i,4); read(r);r.rmoveto(-(long)(sizeof(int)+sizeof(*this))); getidfier(s);}
	char*idfier		 ( ){return idf;}
  void setidfv	 ( ){setidfier("dif");vM=5;vm=1;}
  void setabuK	 (long asiz,long bsiz,long usiz,long k=0)
										{asz=asiz; bsz=bsiz; usz=usiz; K=k; }
	long  read		 (tyio& r){return r.read (this, sizeof(*this));}
  long  write		 (tyio& w){return w.write(this, sizeof(*this));}
};

struct rdhdr52 { // riden header, note: sizeof(di51rdhdr) is 28, different from previous version 32
	long asz;		// size of data in unit of usize (array size)
  long bsz;		// size of data in unit of byte  (array size in bytes)
  long usz;		// size of each unit, 0 if not const
  char idf[8];
  char qqn,key,col,knd;//qiqen(d/k/h),key(dikey),col(1/2/3),kind(dirdkind)
  USHORT vM; USHORT vm;
  rdhdr52() {  setidfv(); setabu(0,0,0); idf[0]=0; }
  void setidfier (char*s,int n=8){ if(n>8)n=8;strncpy(idf,s,n); }
  void getidfier (char*s        ){ strncpy(s,idf,8);s[8]=0; }
	void peekidfier(tyio& r, char* s){int i; r.read(&i,4); read(r);r.rmoveto(-(long)(sizeof(int)+sizeof(*this))); getidfier(s);}
  char*idfier		 ( ){return idf;}
  void setidfv	 ( ){setidfier("dif");vM=5;vm=2;}
  void setabu		 (long asiz,long bsiz,long usiz)
										{asz=asiz; bsz=bsiz; usz=usiz; }
	void setqkck	 (char qiqen, char key1, char c2c3, char kind)
										{qqn=qiqen; key=key1; col=c2c3; knd=kind; }
  long  read		 (tyio& r){return r.read (this, sizeof(*this));}
  long  write		 (tyio& w){return w.write(this, sizeof(*this));}
};

class dzb52_ { // 2 or 3 column
protected:
	tyio    io;   szmiohs mm;
  rdhdr* hd_;  char*   dt_;  char**  dst_;
  short id;
  void  setinnr();
	//int	isc2c3() {char s[10], c3[]="c3"; hd_->getidfier(s); 
	//							return ( (str_find(s, c3, 2)>=0)? 3 : 2 ); }
	int	isc2c3() { return ( ('3'==hd_->col)? 3 : 2 ); }
	int (__cdecl *wis ) (const void *, const void *);//the wis function
public:
	int lower(char*s) { return wislower(s,dst_,size(),sizeof(char**),wis);}
	int upper(char*s) { return wisupper(s,dst_,size(),sizeof(char**),wis);}
public:
	dzb52_()				:	wis(di5wis.i2r) { }
	dzb52_(char* fn): wis(di5wis.i2r) { read(fn); }
public:
  int read(tyio& r ){ mm.read(r ); setinnr(); return 1; }
  int read(char* fn){ tyio io; if(!io.open(fn))return 0; mm.read(io); setinnr(); io.close(); return 1; }
public:
	uint size  () { return (uint)(hd_->asz);			}
	int  isc3  ()	{ return ('3'==hd_->col)? 1: 0; }
	char key   () { return hd_->key; }
	char qiqien() { return hd_->qqn; }
	char luibet() { return hd_->knd; }
public:
  char* d1(USHORT n) { return dst_[n]; }
  char* d2(USHORT n) { return dst_[n] + strlen(d1(n)) +1; }
	char* d3(USHORT n) { return dst_[n] + strlen(d1(n)) +1+ strlen(d2(n)) +isc3(); }
	//char* d3(USHORT n) { return dst_[n] + strlen(d1(n)) +1+ strlen(d2(n)) +1; }
};


inline void dzb52_::
setinnr()
{
  hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	if(hd_->key=='r') wis = di5wis.r2i; else wis = di5wis.i2r;
	int c3=isc3();
  int i, items=hd_->asz;
  dst_=new char*[items+1];
  dst_[items]=0;
  int ll;
  char* p=dt_;
  ll= *p++;
  for(i=0; i<items; i++) {
		dst_[i]=p;
		p += ll;				ll = (unsigned short)(*p);		*p++ =0;
		p += ll;				ll = (unsigned short)(*p);		*p++ =0;
		if(c3) {p += ll;ll = (unsigned short)(*p);		*p++ =0;}
  }
}

//typedef dzb_ i2rdzb_;
//
//class r2idzb_ :public dzb_ {public:
//	r2idzb_()					{wis=(di5wis.r2i); }
//	r2idzb_(char* fn) {wis=(di5wis.r2i); read(fn); }
//};


#endif //#ifdef OLDOLDOLDOLDOLD
