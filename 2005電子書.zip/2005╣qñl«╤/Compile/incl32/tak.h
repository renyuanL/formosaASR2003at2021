//---------------------------------------------------------------------------
//file "tak.h"
//---------------------------------------------------------------------------
#include "chars.h"
#include "htype.h"
#include "tyio8.h"
#include "tos.h"

// tak is an extern object defined in tyio8.cpp


