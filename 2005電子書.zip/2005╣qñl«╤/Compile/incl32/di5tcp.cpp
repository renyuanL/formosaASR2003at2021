//
// di5tcp.cpp
//


#ifndef DI5TCP_CPP
#define DI5TCP_CPP

#include "di5tcp.h"
#include <speechio.h>

void  tcp3_::clear0()
{
	ss.clear();
	clearcparts();
	null=" "; null.clear();
	ndllines.clear();
	cln=-1;
}
void  tcp3_::clear()
{
	clear0();
}


void  tcp3_::clearcparts()
{
  cparts.set2Nhun(" = = =");for(int n=0; n<3; n++) *(cparts[n])=0;
}

void  tcp3_::getset4    (uint n)
{
  if(!nG(n)) {clearcparts(); cln=-1; return; }
  if( nC(n)) return;
  static chars cs;
  cs=ss[n]; cs+=" = = = ";
  cparts.set2Nhun(cs.s); int L=cparts.size()-1;
  for(int nn=0; nn<3; nn++) *(cparts[L-nn])=0;
  cln=n;
}

char  tcp3_::qiqen1c   (      )
{
	char c='d';//for daiqi
	if(qiqen.is("sindikkeh" ))c='s';else
	if(qiqen.is("sindik"    ))c='s';else
	if(qiqen.is("viaulikkeh"))c='v';else
	if(qiqen.is("viaulik"   ))c='v';else
	if(qiqen.is("miaulikkeh"))c='v';else
	if(qiqen.is("miaulik"   ))c='v';else
	if(qiqen.is("ingqi"   	))c='e';else
	if(qiqen.is("english"   ))c='e';else
	if(qiqen.is("gitann"   	))c='g';else
	if(qiqen.is("huaqi"     ))c='h';
	return c;
}

char*  tcp3_::qiqenhanri   (char c)
{
	static chars cs=" ";
	switch (c){
	case 's': cs="�s�˫Ȼy";break;
	case 'v': cs="�]�߫Ȼy";break;
	case 'h': cs="�ػy";break;
	case 'e': cs="�^�y";break;
	case 'g': cs="����";break;
	case 'd':
	default : cs="�x�y";break;
	}
	return cs.s;
}


uint   tcp3_::readtcp1(xreader& r, chars& prev)
{
	chars cs;
	clear0();//not clear, since file names set
	cs=prev; cs.delleadspaces();
	ndllines.push_back(ss.size());
  if(!cs.bw('#'))ss.app(cs.s);
  while(r.snEOF()){
    r.getgline(cs); cs.delleadspaces();
    if(cs.bw('#')) { ndllines.push_back(ss.size());continue; }
    ss.app(cs.s);
  }
  if(ss.size()>0) getset4(0);
  ndllines.push_back(ss.size());
  return ss.size();
}

uint   tcp3_::readxml (xreader& r)
{
  chars cs, cst;  cs=" "; cs.clear();
	clear0();//not clear, since file names set
	xmltag tgv;
	int res=r.getnexttag(cst);
	if(!res) return 0;
	tgv.set2Nhun(cst.s); qiqen=tgv["qiqen"];
	while(r.snEOF()){     // inside vunziunn
		if(r.nisctag(tgv.tag())) break;
		//r.getnexttag(cst);
		r.getnext(cst);
		if     (cst.isxotag("dl")){ ndllines.push_back(ss.size());    }
		else if(cst.isxctag("dl")){ cs.clear(); }
		else if(cst.isxotag("gu")){ cs=cst; cs+=ch01; }
    else if(cst.isxctag("gu")){ cs.deleif(ch01);zogu(cs.s);cs.clear();  }
    else if(cst.isxtag ("su")){ cs+=cst;cs+=ch01; }
  }
  if(ss.size()<=0) {ndllines.clear();}else ndllines.push_back(ss.size());
  if(ss.size()>0) getset4(0);
  return ss.size();
}

int    tcp3_::zogu(char* s)
{
  charspp spp; static chars cs, cst;
  spp.set2Ncet(s,ch01);if(spp.size()<=0) return 0;
  xmltag tg;
  tg.set2Nhun(spp[0]);
  cs=tg["sp"]; if(cs.hasnone())cs=tg["siann"]; if(cs.hasnone())cs="sp";
	cs+="  "; int n,N=spp.size();
  for(n=1;n<N; n++) {
    tg.set2Nhun(spp[n]);
    cst=tg["v"];
    cst.trts('=');
    cs+=cst.s;
    cs+="=";
    //tg.set2Nhun(spp[n]); cs+=tg["v"]; cs+="=";
  }
  if(cs.ew("=")) cs.dele(1);
	cs+="   ";
	for(n=1;n<spp.size(); n++) {
		tg.set2Nhun(spp[n]); cst=tg["y"];
		//cst.delltspaces(); if(cst.hasnone()) emptyyim=1;
		cst.trts('=');cs+=cst.s;  cs+="=";
		//tg.set2Nhun(spp[n]); cs+=tg["y"]; cs+="=";
	}
	if(cs.ew("=")) cs.dele(1);
	ss.app(cs.s);
	return 1;
}

uint   tcp3_::read    (char* fname, char* pname)
{
	chars cs; cs.setpfname(fname,pname);
	xreader r;
	if(!r.open(cs.s)) {
		clear();
		return 0;
	}
	pfn=cs;pn=pname;if(pn.hasnone())pn=cs.getpname();
	if(pn.hassome()) pn.appifen("\\");
	while(r.snEOF()) if(r.getgline(cs))break;
	if(cs.isxtag("xml"))
		return readxml(r);
	return readtcp1(r, cs);
}

/*
int		xtext_::	readml (char* fn, char* pn)
{
	tcpreader r;
	r.open(fn,pn); if(!r.isOK()) return 0;
	css.clear();
	chars cs, cs1;
	while(!r.isEOF()){
		r.getnexttag(cs); cs.delltspaces();
		if(!cs.isxotag(tggu.s)){
			css.app(cs.s);
		}else{
			cs.appln();
			while(!r.isEOF()){
				r.getnexttag(cs1);cs1.delltspaces();
				cs.app(cs1.s,"\r\n");
				if(cs1.isxctag(tggu.s)) break;
			}
			if(cs.ew("\r\n"))cs.dele(2);
			css.app(cs.s);
		}
	}
	setndxs();
	return css.size();
}

int		xtext_::	readtcp2 (char* fn, char* pn)
{
	lreader r;
	r.open(fn,pn); if(!r.isOK()) return 0;
	chars cs, cs1;
	if(!r.getgline(cs)) {r.close();return 0;}
	css.clear();
	int tcp1=0;
	if(!cs.isxtag("xml")) {
		tcp1=1;
		css.app(xmlline1alone);
		cs1="<vunziunn qiqen=\"daiqi\" sphead=\"ziamsi\" spdir=\"\" >";
		css.app(cs1.s);
		cs1="<dl>";
		css.app(cs1.s);
	}
	if(cs.isxtag()) css.app(cs.s);
	else{
		cs.delltspaces();
		if(ispunct(cs[0])){
			cs1="<!-- "; cs1+=cs; cs1+=" -->";
			css.app(cs1.s);
		}else{
			svy2gu(cs1, cs.s);
			css.app(cs.s);
		}
	}
	while(r.getgline(cs)){
		if(cs.isxtag()) css.app(cs.s);
		else {
			cs.delltspaces();
			if(ispunct(cs[0])){
				cs1="<!-- "; cs1+=cs; cs1+=" -->";
				css.app(cs1.s);
			}else{
				svy2gu(cs1, cs.s);
				css.app(cs1.s);
			}
		}
	}
	if(tcp1){
		css.app("</dl>");
		css.app("</vunziunn>");
	}
	r.close();
	setndxs();
	return 1;
}
*/






char* duligtcp_::spf			(uint bb)
{
	if(!ckbe( int(bb),0,ss.size() )) {sppln.set2Nhun(" ");}
	else sppln.set2Nhun(ss[bb ]);
	return sppln[0];
}


char* duligtcp_::spfnext	()
{
	static chars fn;
	fn=sphd;
	fn+=tos(nxt,"%05d");
	return fn.s;
}

char*	duligtcp_::oxvz()
{
	static char s[]=
	"<vunziunn exe=\"dulig\" qiqen=\"unknown\" smprate=\"\" sphd=\"\" cln=\"\" nxt=\"\" >";
	return s;
}

char *duligstarttext="_�osiVoRsIaNn�i��eee�o�͢�dAizI...";

int		duligtcp_::setclnvun(chars& cs)
{
	if(cs.s[0]=='_')if(cs.is(duligstarttext))return 0;
	if(cs.hasnone()) return 0;
	if(!ss.goodappndx(cln)) return 0;
	static charspp spp;  static chars css;
	spp.clear(); css.clear(); spp.set2Nhun(cs.s); cs=spp.tos("=");
	spp.set2Nhun(ss[cln]);
	//cs.trts('=');
	if(spp.size()>1)if(cs.is(spp[1]))return 0; // same vun
	if(spp.size()>0) css+=spp[0];	css+="\t";
	css+=cs; css+="\t";
	if(spp.size()>2) css+=spp[2]; css+="\t";
	if(spp.size()>3) css+=spp[3];
	ss.set2(cln,css.s);
	dirty=1;
	return 1;
}

int		duligtcp_::setclnyim(chars& cs)
{
	if(cs.s[0]=='_')if(cs.is(duligstarttext))return 0;
	if(cs.hasnone()) return 0;
	if(!ss.goodndx(cln)) return 0;
	static charspp spp;  static chars css;
	spp.clear(); css.clear(); spp.set2Nhun(cs.s); cs=spp.tos("=");
	spp.set2Nhun(ss[cln]);
	//cs.trts('=');
	if(spp.size()>2)if(cs.is(spp[2]))return 0;  //same yim
	if(spp.size()>0) css+=spp[0];	css+="\t";
	if(spp.size()>1) css+=spp[1]; else css+="="; css+="\t";
	css+=cs;                                     css+="\t";
	if(spp.size()>3) css+=spp[3]; else css+="=";
	ss.set2(cln,css.s);
	dirty=1;
	return 1;
}

int		duligtcp_::setclnki(chars& cs)
{
	if(cs.s[0]=='_')if(cs.is(duligstarttext))return 0;
	if(cs.hasnone()) return 0;
	if(!ss.goodappndx(cln)) return 0;
	static charspp spp;  static chars css;
	spp.clear(); css.clear(); spp.set2Nhun(cs.s); cs=spp.tos("=");
	spp.set2Nhun(ss[cln]);
	//cs.trts('=');
	if(spp.size()>3)if(cs.is(spp[3]))return 0; // same ki
	if(spp.size()>0) css+=spp[0];	css+="\t";
	if(spp.size()>1) css+=spp[1]; else css+="="; css+="\t";
	if(spp.size()>2) css+=spp[2]; else css+="="; css+="\t";
	css+=cs; // now for ki
	ss.set2(cln,css.s);
	dirty=1;
	return 1;
}



int		duligtcp_::getki (int nln, chars& cs)
{
	cs.clear();
	if(!ss.goodndx(nln)) return 0;
	static charspp spp;  //static chars css;css.clear();
	spp.clear();
	spp.set2Nhun(ss[nln]);
	if(spp.size()>3) cs=spp[3];
	cs.tr('=',' ');
	return cs.hassome();
}

int		duligtcp_::getvun(int nln, chars& cs)
{
	cs.clear();
	if(!ss.goodndx(nln)) return 0;
	static charspp spp;  //static chars css;css.clear();
	spp.clear();
	spp.set2Nhun(ss[nln]);
	if(spp.size()>1) cs=spp[1];
	cs.tr('=',' ');
	return cs.hassome();
}


int		duligtcp_::getyim(int nln, chars& cs)
{
	cs.clear();
	if(!ss.goodndx(nln)) return 0;
	static charspp spp;  //static chars css;css.clear();
	spp.clear();
	spp.set2Nhun(ss[nln]);
	if(spp.size()>2) cs=spp[2];
	cs.tr('=',' ');
	return cs.hassome();
}

/*
int		duligtcp_::getvunyim(int nln, chars& cs, char sep1, char sep2)
{
	cs.clear();
	if(!ss.goodndx(nln)) return 0;
	static charspp spp;  //static chars css;css.clear();
	spp.clear();
	spp.set2Nhun(ss[nln]);
	if(spp.size()>1) cs+=spp[1];cs+="  ";
	//if(sep) cs+=sep;
	cs+=ch01;
	if(spp.size()>2) { cs+=spp[2]; }
	cs.tr('=',' ');
	if(!sep1)sep1=' '; cs.tr(ch01,sep1);
	if(!sep2)sep2=' '; cs.app(sep2);
	return cs.hassome();
}
*/

int		duligtcp_::delcur(				)
{
	if( ckbe(cln,0,ss.size()) ){
		dirty=1;
		return ss.del(cln);
	}
	return 0;
}

int		duligtcp_::delxgu(int ngu)
{
	//if(ckbe(ngu,0,ss.size()-1)){
	if(ckbe(ngu,0,ss.size())){
		dirty=1;
		return ss.del(ngu);
	}
	return 0;
	//should del sp file too
}

int	duligtcp_::setxgu(char* spfn, int replacemode)
{
	static chars cs;
	//xtg.set2Nhun(oxgu());xtg.set2("sp",spfn);
	//cs=xtg.tos(' '); cs+=xsu(); cs+=cxgu();
	cs=spfn;
	if(replacemode) delxgu(cln);
	csbe(cln,0,ss.size());
	int res=0;
	if(ss.insert(cln,cs.s)){
		res=1; //inccln();
	}
	dirty=1;
	return res;
}

int			duligtcp_::creat	(chars& newfn, char* sphead, int nthsmprate)
{
	clear();
	setnthsmprate(nthsmprate);
	pn=newfn.getpname(); pn.appifen("\\");
	fn=newfn.getfname();
	if(sphead&&sphead[0])
		sphd=sphead;
	else
		{sphd=fn;int len=sphd.findlast('.');if(len>=0)sphd[len]=0;}
	dirty=1; save();
	ndllines.push_back(0);
	//Form1->ud4lineno1_->Position=0;
	//Form1->ed4linetotal1_->Text="0";
	return 1;
}

int			duligtcp_::setnthsmprate(int nthsmprt)
{
	smprate=srdef.nth2rate(nthsmprt);
	return smprate;
}

int		duligtcp_::getnthsmprate	(							)
{	return srdef.rate2nth(smprate);	}

char*	duligtcp_::getsrstr	(							)
{	return srdef.rate2sstr(smprate);	}


uint		duligtcp_::save(char* tcpfn)
{
	if(!dirty) return 0;
	chars cstcpfn; charspp spp;
	if(!(tcpfn&&tcpfn[0])){cstcpfn=pn; cstcpfn+=fn; tcpfn=cstcpfn.s;}
	writer w; w.creat(tcpfn); if(w.isERR())return 0;
	w.writeln(xmlline1alone);
	xtg.set2Nhun(oxvz());
	xtg.set2("sphd",sphd.s);
	xtg.set2("cln",tos(cln));
	xtg.set2("nxt",tos(nxt));
	xtg.set2("smprate",tos(smprate));
	w.writeln(xtg.tos(' '));
	w.writeln("<dl>");
	chars cs, cst;
	for(int ii=0; ii<ss.size(); ii++){
		xtg.set2Nhun(oxgu());
		spp.set2Nhun(ss[ii]);		//xtg.set2("sp", spf(ii));
		if(spp.size()>0) xtg.set2("sp",spp[0]);
		cs=xtg.tos(' ');
		xtg.set2Nhun(xsu());
		if(spp.size()>1) { cst=spp[1]; cst.tr('=',' '); xtg.set2("v",cst.s); }
		if(spp.size()>2) { cst=spp[2]; cst.tr('=',' '); xtg.set2("y",cst.s); }
		if(spp.size()>3) { cst=spp[3]; cst.tr('=',' '); xtg.set2("k",cst.s); }
		cs+=xtg.tos(' ');//xsu();
		cs+=cxgu();
		w.writeln(cs.s);
	}
	w.writeln("</dl>");
	w.writeln("</vunziunn>");
	w.close();
	dirty=0;
	ndllines.clear();ndllines.push_back(0);ndllines.push_back(ss.size());
	return 1;
}

uint		duligtcp_::read(char* tcpfn, char* tcppn)
{
	chars cs;cs.clear();
	if(tcpfn&&tcpfn[0]) cs.setpfname(tcpfn,tcppn);
	//else{cs=ini.curdir;cs+="test\\test.tml";}
	if(cs.hasnone())return 0;
	xreader r;
	if(!r.open(cs.s)) {
		int at=0;
		cs.ins(&at,"�L�k�ץ��}�ɮ� \r\n\r\n");
		MessageBox(NULL, cs.s, "dulig.exe ���i",MB_OK);// show error here
		clear();
		return 0;
	}
	pn=cs.getpname(); fn=cs.getfname();pn.appifen("\\");//pfn=cs;
	uint res;
	while(r.snEOF()) if(r.getgline(cs))break;
	if(cs.isxtag("xml")) res=read(r);
	//if(res<=0){pn="";fn="";}
	return res;
}

uint		duligtcp_::read(xreader& r)
{
	chars cs, cst;  cs=" "; cs.clear();
	clear();
	xmltag tgv;
	int res=r.getnexttag(cst);
	if(!res) return 0;
	tgv.set2Nhun(cst.s); //qiqen=tgv["qiqen"];
	if(strcmp("dulig", tgv["exe"])!=0){
		return 0;
	}
	sphd=tgv["sphd"]; cln=s2i(tgv["cln"]); nxt=s2i(tgv["nxt"]);
	smprate=s2i(tgv["smprate"]);
	while(r.snEOF()){     // inside vunziunn
		if(r.nisctag(tgv.tag())) break;
		//r.getnexttag(cst);
		r.getnext(cst);
		if     (cst.isxotag("dl")){ ndllines.push_back(ss.size());    }
		else if(cst.isxctag("dl")){ cs.clear(); }
		else if(cst.isxotag("gu")){ cs=cst; cs+=ch01; }
		else if(cst.isxctag("gu")){ cs.deleif(ch01);zogu(cs.s);cs.clear();  }
		else if(cst.isxtag ("su")){ cs+=cst;cs+=ch01; }
	}
	int N=ss.size();
	if(N<=0) {ndllines.clear();}else ndllines.push_back(N);
	//if(ss.size()>0) getset4(0);
	//if(N>=0)cln=ss.size();
	return N;
}

int    duligtcp_::zogu(char* s)
{
	charspp spp; static chars cs, cst;
	spp.set2Ncet(s,ch01);if(spp.size()<=0) return 0;
	xmltag tg;
	tg.set2Nhun(spp[0]);
	cs=tg["sp"]; if(cs.hasnone())cs=tg["siann"]; if(cs.hasnone())cs="sp";
	cs+="  "; int n,N=spp.size();
	for(n=1;n<N; n++) {
		tg.set2Nhun(spp[n]);
		cst=tg["v"];
		cst.trts('=');
		cs+=cst.s;
		cs+="=";
		//tg.set2Nhun(spp[n]); cs+=tg["v"]; cs+="=";
	}
	if(cs.ew("=")) cs.dele(1);
	cs+="   ";
	for(n=1;n<spp.size(); n++) {
		tg.set2Nhun(spp[n]); cst=tg["y"]; cst.trts('=');cs+=cst.s;  cs+="=";
		//tg.set2Nhun(spp[n]); cs+=tg["y"]; cs+="=";
	}
	cs+="   ";
	for(n=1;n<spp.size(); n++) {
		tg.set2Nhun(spp[n]); cst=tg["k"];
		cst.trts('=');cs+=cst.s;  cs+="=";
		//tg.set2Nhun(spp[n]); cs+=tg["y"]; cs+="=";
	}
	if(cs.ew("=")) cs.dele(1);
	ss.app(cs.s);
	return 1;
}




#endif  DI5TCP_CPP
