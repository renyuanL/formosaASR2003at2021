//
// di5base.cpp
//

// copyright 1994~2k Gang, IrngZin

#ifndef DI5BASE_CPP
#define DI5BASE_CPP

#include <di5base.h>
//#ifdef _WINDOWS
#include<windows.h>
//#endif //#ifdef _WINDOWS


byteswap_ bswap;


//////////////////////////////////////
// tos
static
char* tos_buf()
{
	const nMAX=16;
	static char s[nMAX][257];  static int  n=0;
	n++; if(n>=nMAX-4)n=0; return s[n];
}
char
*tosfmtc	="%c",
*tosfmts	="%s",
*tosfmtuh	="%uh",
*tosfmtd	="%d",
*tosfmtui	="%u",
*tosfmth	="%h",
*tosfmtld	="%ld",
*tosfmtf	="%f",
*tosfmtlf	="%lf";

// r: result string[128]
char* tos(char   v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(char*  v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(USHORT v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(int    v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(uint   v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(short  v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(long   v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(float  v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}
char* tos(double v, char* fmt){char*s=tos_buf();tos(s,v,fmt);return s;}

char*ntos(char*  v, int   len) // copy at most len char's
{
	if(len>256) len=256; char*s=tos_buf(); char*t=s;int l=0;
	while(*v){if(l++<len)*s++=*v++;else break;} s[l]=0;
	return t;
}
// tos
//////////////////////////////////////

//////////////////////////////////////
//////////////////////////////////////
COLORREF clr768 (int ndx)
{ //idea from Ong ZongKai
	if(ndx<=  0) return 0;
	if(ndx>=768) return RGB(255,255,255);
	if(ndx<  52) return RGB(  0,  0,ndx);//52 is 0x33
	ndx-=52;
	if(ndx< 256) return RGB(ndx,  0, 52);
	ndx-=256;
	if(ndx< 256) return RGB(255,ndx, 52);
	ndx-=256;    return RGB(255,255,ndx+52);
}
//////////////////////////////////////
//////////////////////////////////////

//////////////////////////////////////
// class messagebox_
//#include <iostream.h>

messagebox_ msg;


void messagebox_::mmode_autoset()
{
	#ifdef _CONSOLE
	mm=DI5MSG_MDOS;
	#else
	mm=DI5MSG_MWIN;
	#endif
}

char messagebox_::msg     (cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	if(mm==DI5MSG_MNULL) return '1';
	if(mm==DI5MSG_MAUTO) mmode_autoset();
	if(mm==DI5MSG_MDOS) {
		if(s1)puts(s1);
		if(s2)puts(s2);
		if(s3)puts(s3);
		if(s4)puts(s4);
//		cout<<((s1)?s1:"")
//				<<((s2)?s2:"")
//				<<((s3)?s3:"")
//				<<((s4)?s4:"")<<flush;
		return '1';
	}
	if(mm==DI5MSG_MWIN) {
#ifdef _WINDOWS
		MessageBox(NULL,s2,s1,MB_OK); return '1';
#endif //#ifdef _WINDOWS
	}
	return '1';
}

char messagebox_::pause   (cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	msg(s1,s2,s3,s4);	char c='1';
	if(mm==DI5MSG_MDOS){c=getch();}
	return c;
}

char messagebox_::ask4quit(cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	msg(s1,s2,s3,s4);
	char c=pause("type q or x to quit, others to continue if possible\n");
	if(c=='q'||c=='Q'||c=='x'||c=='X')return 1; return 0;
}
char messagebox_::ask4exit(cchar*s1, cchar* s2, cchar* s3, cchar* s4)
{
	msg(s1,s2,s3,s4);
	char c=pause("type q or x to exit, others to continue if possible\n");
	if(c=='q'||c=='Q'||c=='x'||c=='X')exit(0); return 0;
}
static
char messagebox(cchar*s1=0, cchar* s2=0, cchar* s3=0, cchar* s4=0)
{ return msgbox(s1,s2,s3,s4); }

//////////////////////////////////////
// class stepmsg_
void stepmsg_::inc()
{ if(++i%ntv==0) messagebox(tos(i/1000), "K\t"); }

void stepmsg_::showfull(const char*pre_s, const char*post_s)
{
	messagebox( ((pre_s)?pre_s:""), tos(i), ((post_s)?post_s:"\t") );
	//	cout<<((pre_s)?pre_s:"")<<i<<((post_s)?post_s:"\t")<<flush;
}
// class stepmsg_
//////////////////////////////////////

void curpath::init()
{
	char s[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,s);
	path=s; sz=strlen(s);
	s[3]=0;
	drivetype=GetDriveType(s);
}

int	 curpath::	isCD		()
{
	return (drivetype==DRIVE_CDROM);
}

char* curpath::get(int withbackslash)
{
	if(sz>0){
		char c=path.s[sz-1];
		if(withbackslash){
			if(c!='\\') {path+="\\";sz++;}
		}else{
			if(c=='\\') {path.s[sz-1]=0;sz--;}
		}
	}
	return path.s;
}

curpath exepath;

char* getexepath(int withbackslash)
{
	return exepath(withbackslash);
}
//////////////////////////////////////
// class sis_ : all static function
//  except rbytes/lbytes that need AnsiNext/AnsiPrev, so in tyio below

unsigned short big52ser(char* s1);												//ret: ser
unsigned short ser2big5(unsigned short sernum, char* s);	//s has least 3B, ret 2 if succ

int inbig5range(char* s, ushort base, int beg, int end)
{
	int us=big52ser(s);	us -=base;
	if(beg<=us && us<end)
		return 1;
	return 0;
}

unsigned short big52ser(unsigned short us1st, unsigned short us2nd)
{
	USHORT serbase, sernum;
	if(us1st== 0xc6 && us2nd>= 0xa1) { // huhor: rare part 1
		us1st -= (USHORT)0xc6;   us2nd =(USHORT)(us2nd-0xa1); serbase = 0x8001;
	sernum =(USHORT)( us1st*0x9d +us2nd+ serbase);
	return sernum;
	}

			 if(us1st >= 0xa1 && us1st <= 0xa3) { //huhor: common part
				us1st -=(USHORT) 0xa1; serbase  = 0x8400;
	}
	else if(us1st >= 0xa4 && us1st <= 0xc6) { //freq used
				us1st -=(USHORT) 0xa4; serbase  = 0x8800;
	}
	else if(us1st >= 0xc7 && us1st <= 0xc8) { //huhor: rare part 2
				us1st -=(USHORT) 0xc7; serbase  = 0x805f;
	}
	else if(us1st >= 0xc9 && us1st <= 0xf9) { // less freq used
				us1st -=(USHORT) 0xc9; serbase  = 0x9d19;
	}
	else return 0;

			 if (us2nd >= 0x40 && us2nd <= 0x7e) us2nd -=(USHORT) 0x40;
	else if (us2nd >= 0xa1 && us2nd <= 0xfe) us2nd  =(USHORT)( us2nd- 0xa1+0x3f);
	else return 0;

	sernum =(USHORT)( us1st*0x9d+ us2nd+ serbase);
	return sernum;
}

unsigned short big52ser(char* s1) //ret: ser num
{
	UCHAR* s=(UCHAR*)s1;
	return big52ser( (unsigned short)s[0], (unsigned short)s[1]);
}

unsigned short ser2big5(unsigned short sernum)
{
	union { UCHAR c[2]; USHORT n; } big5;
	USHORT serbase, big5base;

	if(sernum>= 0x8001 && sernum<= 0x805e) { // huhor: rare part 1
		big5.c[0]=(UCHAR)( (sernum-0x8001)/0x9d+0xc6);
		big5.c[1]=(UCHAR)( (sernum-0x8001)%0x9d+0xa1);
		return big5.n;
	}

			 if(sernum>= 0x8400 && sernum<= 0x8597) { // huhor: common part
					serbase= 0x8400;  big5base= 0xa1;
	}
	else if(sernum>= 0x8800 && sernum<= 0x9d18) {// freq used
					serbase= 0x8800;  big5base= 0xa4;
	}
	else if(sernum>= 0x9d19 && sernum<= 0xbb25) {// less freq used
					serbase= 0x9d19;  big5base= 0xc9;
	}
	else if(sernum>= 0x805f && sernum<= 0x816d) {//  huhor: rare part 2
					serbase= 0x805f;  big5base= 0xc7;
	}
	else return 0;

	big5.c[0]=(UCHAR)( (sernum-serbase) / 0x9d + big5base);
	big5.c[1]=(UCHAR)( (sernum-serbase) % 0x9d);
	if( big5.c[1]< 0x3f) big5.c[1]  =(UCHAR)( big5.c[1]+ 0x40);
	else                 big5.c[1]  =(UCHAR)( big5.c[1]-0x3f+0xa1);

	return big5.n;
}

unsigned short ser2big5(unsigned short sernum, char* s)//s has least 3B
{
	union { UCHAR c[2]; USHORT n; } big5;
	big5.n= ser2big5(sernum); s[0]=big5.c[0]; s[1]=big5.c[1]; s[2]=0;
	return (USHORT)((big5.n)? 2: 0);
}

int 	str_uzorri (char*s)
{
	if(!(s&&s[0])) return 0;
	int n012; char*t=s;
	while(*t){
		n012=is012(t);
		if(n012!=2){t+=n012;continue;}
		if(!isEThanri(t))
			if(!isbig5huhor(t))
				return 1;
		t+=2;
	}
	return 0;
}


void big5testwrite(int riNOThuhor)
{
	char h[3];
	ushort cnt, CNT;	ushort serbeg, ser,ser1;
	//CNT=13053; serbeg=0x8800;
	if(riNOThuhor){CNT=13094; serbeg=0x8800;}
	else  				{CNT=  408; serbeg=0x8400;}
	//CNT=365; serbeg=0x8001;
	chars cs;
	writer w;
	w.creat("big5test.txt");
	if(w.isERR()) return;
	for(cnt=0; cnt<CNT; cnt++){
		cs.clear();
		ser=serbeg+cnt;
		cs+=tos(ser,"%x"); cs+="\t";
		ser2big5(ser, h);
		ser1=big52ser(h);
		cs+=tos(ser1,"%x"); cs+="\t";
		cs+=h;   cs+="\t";
		cs+=tos( *(ushort*)(h),"%x"); cs+="\t";
		if(isbig5si   (h))cs+="s";else cs+="N";
		if(isbig5csi  (h))cs+="s";else cs+="N";
		if(isbig5sicsi(h))cs+="s";else cs+="N";
		if(isbig5huhor(h))cs+="s";else cs+="N";
		if(ser1!=ser)
			cs+="\tXXX";
		w.writeln(cs.s);
	}
}









char* str_search4(char* s, char c)
{ //return null if not found
	if(!(s&&s[0])) return NULL;
	char* p=0; int n012;
	while(*s){n012=is012(s);if((n012==1)&&(*s==c)){p=s;break;}else s+=n012;}
	return p;
}

char* str_search4crnl(char* s)
{ //return null if not found
	char* p=str_search4(s,'\r');
	if(!p) return 0;
	if(*(p+1)!='\n') return 0;
	return p;
}

int	str_countlet(char* t)
{
	if(!(t&&t[0])) return 0;
	int n=0; char* s;
	while(*t) {
		s=str_search4crnl(t);
		if(!s) { return (*t)?n+1:n; }
		n++; t=s+2;
	}
	return n;
}


char* str_search4crORnl(char*s, int* nbytes_returned)
{ //return null if not found
	if(!(s&&s[0])) return s;
	char* p=0;
  while( *s!=0 ) { if( (*s =='\r')||(*s == '\n') ) { p=s; break; } else s++; }
  if(*s =='\r') { if(s[1]=='\n') { *nbytes_returned=2; return p; } }
//  if(*s =='\r') {
//  	if(s[1]=='\n') { *nbytes_returned=2; return p; }
//    else if( (s[1]=='\r')&&(s[2]=='\n') ){*nbytes_returned=3; return p; }
//  }
	if(*s =='\n') { *nbytes_returned=(s[1]=='\r')?2:1; return p; }
	//if(*s =='\n') { *nbytes_returned=1; return p; }
	return p;
}
int isbig5punct(char*s)
{
	//int res=is012(s); if(res!=2) return 0;
	if(s[0]=='\xa1') return 1;
	else if( (s[0]=='\xa2')&&
					((unsigned char)(s[1]) <= (unsigned char)'\x4e') ) return 1;
	return 0;
}

int str_nexthanlor(char*s, int& hanlorpunct)//hanlorpunct:1/2/3
{
	hanlorpunct=0;
	if(!(s&&s[0])) return 0;
	int n=is012(s);
	if(n==2) {hanlorpunct=1; return 2;}
	int ad=isalnum(*s); // alpha/digit
	if(!ad) {hanlorpunct=3; return 1;}// should be punctuation etc
	hanlorpunct=2;
	char*t=s+1; int henzai, zingvin=isalpha(*s);
	while(*t){
		n=is012(t);
		if(n==1){
			if(*t=='-') return t-s+1;
			if(!isalnum(*t)){return t-s;}
			henzai=isalpha(*t);
			if(zingvin!=henzai &&zingvin==0) {return t-s;}
			zingvin=henzai;
			t++;
		}else{return t-s;}
	}
	return t-s;
}

int str_nexthanlor(char*s)
{
	int hanlorpunct; return str_nexthanlor(s,hanlorpunct);
}


int str_delfirstN(char* s, int N)
{
	if(!(s&&s[0])) return 0;
	int len=strlen(s);
	if(N>=len){*s=0; return len;}
	char*t=s; char* src=s+N;
	while(*(src)){*t++=*src++;} *t=0;
	return N;
}

char* str_skipheadblank0   (char* s)
{
	char* t, *sc;
	if(s&&s[0]) {
		sc=s; while(istabspace(sc[0])) sc++;
		if(sc==s) return s;
		t=s;
		while(*sc) *t++=*sc++; *t=0;
	}
	return s;
}

int str_delleadspaces(char* s)
{
	char* t, *sc;
	if(s&&s[0]) {
		//sc=s; while( (*sc)&&istabspace(sc[0]) ) sc++;
		sc=s; while( (*sc)&&is_tsrn(sc[0]) ) sc++;
		if(sc==s) return 0;
		t=s;
		while(*sc) *t++=*sc++;*t=0;
		return sc-s;
	}
	return 0;
}

int str_delltspaces(char* s)
{
	char* t, *sc, *lastblank;
	int len, olen=strlen(s);
	if(s&&s[0]) {
		//sc=s; while( (*sc)&&istabspace(sc[0]) ) sc++;
		sc=s; while( (*sc)&&is_tsrn(sc[0]) ) sc++;
		if(*sc==0) { *s=0; return sc-s; }
		t=s; lastblank=t;
		//while(*sc){ *t=*sc++; if(!istabspace(*t)) { lastblank=t+1; }t++;}*t=0;
		while(*sc){ *t=*sc++; if(!is_tsrn(*t)) { lastblank=t+1; }t++;}*t=0;
		*lastblank=0;
	}
	len=strlen(s);
	return olen-len;
}


int str_deltrailspaces(char* s)
{
	char* t, *sc, *lastblank;
	int len, olen=strlen(s);
	if(s&&s[0]) {
		sc=s;
		t=s; lastblank=t;
		//while(*sc){ *t=*sc++; if(!istabspace(*t)) { lastblank=t+1; }t++;}*t=0;
		while(*sc){ *t=*sc++; if(!is_tsrn(*t)) { lastblank=t+1; }t++;}*t=0;
		*lastblank=0;
	}
	len=strlen(s);
	return olen-len;
}



int		str_isin(char c, char* s)
{
	if(!(s&&s[0])) return 0;
	while(*s) if(c== (*s++)) return 1;
	return 0;
}

void  str_tolower			 (char* s)
{
	if(!(s&&s[0])) return ;
	int res;
	while(*s) {
		res=is012(s);	if(res==1) { *s=char(tolower(*s)); }
		s+=res;
	}
}

int  str_replacepunct (char*s, char rt)
{
	if(!(s&&s[0])) return 0;
	char*p=s; if(!p) return 0; int nreplaced=0;
	int res;
	while(*s) {
		res=is012(s);
		if(res==1) { if(ispunct(*s)){if(rt)*p++=rt;s++;nreplaced++;} else *p++=*s++;}
		else{
			if(isbig5punct(s)){if(rt){*p++=rt;*p++=rt;}s+=2;nreplaced++;}
			else{*p++=*s++;*p++=*s++;}
		}
	}
	*p=0;
	return nreplaced;
}

int str_replacedigits(char*s, char r)
{// r: replacement
	if(!(s&&s[0])) return 0;
	char*p=s; if(!p) return 0; int nreplaced=0;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++ = *s++; *p++ = *s++; continue; }
		else if(isdigit(*s)) { if(r) *p++=r; s++; nreplaced++; }
		else { *p++ = *s++; }
	}
	*p=0;
	return nreplaced;
}

//void str_replace(char*s, char tobereplaced, char replacement=0);
//=0 default to 0 means for removement
//char*dt;
int str_replace(char*s, char tbr, char r)
{//tbr: tobereplaced, r: replacement
	//dt=s;
	if(!(s&&s[0])) return 0;
	int nreplaced=0;
	char*p=s; if(!p) return 0;
	int res;
	while(*s) {
		res=is012(s);
		if(res==2) 				{ *p++ = *s++; *p++ = *s++; continue; }
		else if(*s ==tbr) { if(r) *p++=r; s++; nreplaced++;}
		else							{ *p++ = *s++; }
	}
	*p=0;
	return nreplaced;
}

int str_replacecrnl(char*s, char r)
{//tbr: tobereplaced, r: replacement
	//dt=s;
	if(!(s&&s[0])) return 0;
	int nreplaced=0;
	char*p=s; if(!p) return 0;
	int res;
	while(*s) {
		res=is012(s);
		if(res==2) 				{ *p++ = *s++; *p++ = *s++; continue; }
		else if(*s =='\r'){ if(r) *p++=r; s++; nreplaced++;}
		else if(*s =='\n'){ if(r) *p++=r; s++; nreplaced++;}
		else							{ *p++ = *s++; }
	}
	*p=0;
	return nreplaced;
}

int str_trts(char* s, char ch2rep) // tr tab/space
{
	if(!(s&&s[0])) return 0;
	char* t=s; int n012; int n=0;
	while(*t) {
		n012=is012(t);
		if(n012!=1) { t+=n012; continue; }
		if((*t==' ')||(*t=='\t')) { *t++=ch2rep; n++; } else t++;
	}
	return n;
}


void str_replacewchar(char*s, char* rt, char r)
{//rt: tobereplaced, r: replacement
	if(!(s&&s[0])) return ;
	char*p=s; if(!p) return;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=2) { *p++ = *s++; continue; }
		else if( (s[0]==rt[0]) && (s[1]==rt[1]) ){ if(r) *p++=r; s+=2; }
		else { *p++ = *s++; *p++ = *s++; }
	}
	*p=0;
}


int str_ki2it(char*str)
{
	if(!(str&&str[0])) return 0;
	if(isdigit(*str)) return 0;
	char* s=str+1, *t=str+1;
	//bool nopick=true;
	int  nopick=1;
	while(*s) {
		if(nopick&&(isalpha(*s))) { s++; continue; }
		if(isdigit(*s)) { nopick=0; s++; }
		if(*s == '-') { nopick=0; s++; }
		*t ++ = *s++; nopick=1;
	}
	*t=0;
	return strlen(str);
}

void str_deldigits(char*s)
{
	if(!(s&&s[0])) return;
	char*p=s; if(!p) return;
	int res;
	//while(*s) if(*s==rt) {if(r)*p=r;else s++;} else *p++ = *s++;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(isdigit(*s)) s++; else *p++=*s++;
	}
	*p=0;
}

void str_delbutdigits(char*s)
{
	if(!(s&&s[0])) return;
	char*p=s; if(!p) return;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(!isdigit(*s)) s++; else *p++=*s++;
	}
	*p=0;
}

void str_delbutpuncts(char*s)
{
	if(!(s&&s[0])) return ;
	char*p=s; if(!p) return;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(!ispunct(*s)) s++; else *p++=*s++;
	}
	*p=0;
}

void str_delbutpunctdigits(char*s)
{
	if(!(s&&s[0])) return ;
	char*p=s; if(!p) return;
	int res;
	while(*s) {
		res=is012(s);
		if(res!=1) { *p++=*s++;*p++=*s++; continue; }
		if(!(isdigit(*s)||ispunct(*s))) s++; else *p++=*s++;
	}
	*p=0;
}

void str_del4wis(char* s)
{
	if(!(s&&s[0])) return ;
	char*p=s; if(!p) return;  int res;
  while(*s) {
		res=is012(s);
    if(res==2) break;
		if( isdigit(*s) || (*s =='-') ) { s++;p++;}  else break;
		//skipping the leading digits and -
  }
  while(*s) {
    res=is012(s);
    if(res==2) { *p++=*s++;*p++=*s++; continue; }
    if( isdigit(*s) || (*s =='-') ) s++; else *p++=*s++;
  }
  *p=0;
}

char* orset_1stoption1(char* src)
{
	if(!(src&&src[0])) return 0;
	if(!str_isorset(src)) return src;
	chars* s=getcharsbuf(); *s=src+1; (*s).dellastN(1); // get rid of ()
	if(str_find1(s->s,'(')>=0) return src;
	if(str_find1(s->s,')')>=0) return src;
	int len=s->find('|'); if(len<0) len=s->size(); s->s[len]=0;
	return s->s;
}

char* orset_1stoption(char* src)
{
	static chars s; static charspp spp;
	char chs[2]; chs[0]=ch01; chs[2]=0;
	s=src;
	s.inssep4hanlor(chs);
	s.tr('-',' ');
	spp.set2Ncut(s.s, ch01); s.clear();
	int n,N=0;
	for(n=0; n<spp.size(); n++) {
		if(str_isblank(spp[n])) continue;
		s.app(orset_1stoption1(spp[n]));
		s.app('-');
		N++;
	}
	if(N>0) s.dellastN(1);
	return s.s;
}

int str_all1byte (char*s)
{
	if(!(s&&s[0])) return 0;
	int n;
	while(*s){n=is012(s);if(n!=1)return 0;s+=1;}
	return 1;
}

int str_all2byte (char*s)
{
	if(!(s&&s[0])) return 0;
	int n;
	while(*s){n=is012(s);if(n!=2)return 0;s+=2;}
	return 1;
}

int str_alldigits(char* s)
{
	if(!(s&&s[0])) return 0;
	int n;
	while(*s){n=is012(s);if(n!=1)return 0;if(!isdigit(*s))return 0;s+=1;}
	return 1;
}

int str_hasdigit(char* s)
{
	if(!(s&&s[0])) return 0;
	int n;
	while(*s){n=is012(s);if(n==1)if(isdigit(*s))return 1;s+=n;}
	return 0;
}

int str_hastabspace(char* s)
{
	int n;
	if(!(s&&s[0])) return 0;
	while(*s){n=is012(s);if(n==1)if(*s==' '||*s=='\t')return 1;s+=n;}
	return 0;
}

int str_isorset(char* s)// strict, true if is (...), and no l/t spaces
{
	if(!(s&&s[0])) return 0;
	int len=strlen(s);
	if(s[0]=='('&&s[len-1]==')') return 1;
	return 0;
}

int str_hasorset(char* s)// loose, true if has ( or ) or |
{
	if(!(s&&s[0])) return 0;
	char* ss=s; int res;
	while(*ss) {
		res=is012(ss); if(res!=1) { ss+=res; continue; }
		if((*ss == '(')||(*ss == ')')||(*ss == '|')) { return 1; }
		ss++;
	}
	return 0;
}


int str_mayberi(char* s)
{ int n;
	if(!(s&&s[0])) return 0;
	while(*s) {
		n=is012(s);
		if( (n==2) || (s[0]=='*') ) return 1;
		s+=n;
	}
	return 0;
}

int		str_startwith(char* s, char* match, int N)
{
	if(!(s&&s[0])) return 0;
	if(!(match&&match[0])) return 0;
	if(N<0) N=strlen(match);
	return (strncmp(s,match,N)==0);
}

int		str_endwith		 (char* s, char* match, int N)
{
	if(!(s&&s[0])) return 0;
	if(!(match&&match[0])) return 0;
	if(N<0) N=strlen(match);
	int len=strlen(s); if(len<N) return 0;
	return (strncmp(s+len-N,match,N)==0);
}

int		str_find		 (char* s, char* match, int N)
//r startpos of match in s, 0-based, simple match only
{
	if(!(s&&s[0])) return -1;
	if(!(match&&match[0])) return -1;
	if(N<0) N=strlen(match);
	int hashanri=str_hashanri(s);
	int n012, len=strlen(s); char* t=s;
	while(len>=N) {
		if(strncmp(t,match,N)==0) return (t-s);
		if(!hashanri){t++;len--;}
		else{
			n012=is012(t);
			if(n012==2){t+=2;len-=2;}
			else{	t++; len--; }
		}
	}
	return -1;
}

int isdigit2(char* s)
{
	char d2[]="�@�G�T�|�����C�K�E���Q�ʤd�d���������������������¢�������������������";
	return (str_find(d2,s,2)>=0);
}

int   str_finddigit   (char* t)// find 1stpos that is digit
{
	if(!(t&&t[0])) return -1;
	int n; char* s=t;
	while(*s){
		n=is012(s);
		if( (n==1)&&(isdigit(*s)) ) return s-t;
		s+=n;
	}
	return -1;
}

int		str_findedigits	(char* t)// find begpos of trailing digit str
{
	if(!(t&&t[0])) return -1;
	int n; int found=0,pos=-1; char* s=t;
	while(*s){
		n=is012(s);
		if( (n==1)&&(isdigit(*s)) ) {
			if(!found){found=1;pos=s-t;}
		}else{found=0;pos=-1;}
		s+=n;
	}
	return (found)?pos:-1;
}

int   str_findnondigit(char* t)
{
	if(!(t&&t[0])) return -1;
	int n; char* s=t;
	while(*s){
		n=is012(s);
		if( (n!=1)||(!isdigit(*s)) ) return s-t;
		s+=n;
	}
  return -1;
}

int str_nchar(char* s, char c)
{
	int n=0, n012;
	if(!(s&&s[0])) return n;
	while(*s){
		n012=is012(s);
		if(n012==1&&s[0]==c) n++;
		s+=n012;
	}
	return n;
}


int   str_isSS(char*s)    // slash slash
{
	if(!(s&&s[0])) return 0;
	char* p=s;
	while( istabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' ) return 1;
	int n=strlen(p); if(n<2) return 0;
	p+=n-2;
  if( p[0]=='/' && p[1]=='/' ) return 1;
  return 0;
}

int   str_isSSEE(char*s)  // slash slash exclamation exclamation
{
	if(!(s&&s[0])) return 0;
	char* p=s;
  while( istabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' && p[3]=='!' && p[4]=='!' ) return 1;
  return 0;  // p[2] not checked for section note
}

int   str_isblank(char*s) // is blank
{
	if(!(s&&s[0])) return 1;
	char* p=s;
	while( istabspace(*p) ) if( *p==0) break; else p++;
	if(*p==0) return 1;
	return 0;
}

int		str_isgline	 (char* s)
{
	if(!(s&&s[0])) return 0;
	char* p=s;
//while( istabspace(*p) ) if( *p==0) break; else p++;
	while( isspace(*p) ) if( *p==0) break; else p++;
	if(*p==0) return 0;
	return !str_isSS(p);
}

int   str_isPBC (char* s, char c1st, char clast, char c)
{
	if(!(s&&s[0])) return 0;
	while( istabspace(*s) ) if( *s==0) break; else s++;
	if(*s==0) return 0; // strip off leading space

	if(s[0]!=c1st) return 0;
	char* p= s+1; p += strlen(p);     // p point to null
	p--; while( istabspace(*p) ) p--; // c1st should not be tabspace,
																		// strip off trailing sapce
	int ll=p-s;  // now ll is strlen of str -1(-1 4 c1st), p points to last char
	if(ll==1) { if(c!=0) return 0; return (*p == clast)? 1:0; }
	if(*p != clast) return 0;
	if(c) { if( p[-1] != c) return 0; }
	return 1;
}

str_hashanri(char* t)
{
	if(!(t&&t[0])) return 0;
	while(*t) if(is012(t)>1) { return 1;}else t++;
  return 0;
}


void str_tokendelimpos(char*s, voids<int>* p)
{
	if(!(s&&s[0])) return ;
	p->clear();
  if( (!s)&&(!s[0]) ) return;
  char* t=s; int n012;
  int zingsitoken;
  zingsitoken=(istabspace(t[0]))?1:0;
  while(*t) {
  	n012=is012(t);
    if( (n012==1)&&istabspace(*t) ) {
			if(zingsitoken==1) p->app(t-s);
      zingsitoken=0;
		}else{
			if(zingsitoken==0) p->app(t-s);
			zingsitoken=1;
		}
		t+=n012;
	}
	p->app(t-s);
}

void str_auto_simple_bendiau(chars* im, int lastdanridiau)
{
	static	chars s; s.clear(); char* last=0;
	int n012; char bendiau;
	char*fm=im->s;//, *to=im->s;
	while((*fm)&&(isdigit(*fm))) { s.app(fm,1); fm++; } // safe guard against leading digits
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ s.app(fm,2); fm+=2; continue; }
		if(!isdigit(*fm)) { s.app(fm,1); fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&isdigit(fm[2])){ // 3 or more digits in a row
				while( (fm[0])&&(isdigit(fm[0])) ) { s.app(fm, 1); fm++; }
				continue;
			}
			s.app(fm,2); last=0; fm+=2;  continue;
		}else{
			switch(*fm){
			case '1': bendiau='2'; break;
			case '2': bendiau='3'; break;
			case '3': bendiau='4'; break;
			case '4': bendiau='1'; break;
			case '5': bendiau='2'; break;
			case '6': bendiau='8'; break;
			case '7': bendiau='6'; break;
			}
			s.app(fm,1); last=im->s+s.size(); fm++; s.app(bendiau); continue;
		}
	}
	int ndel;
	if(last&&lastdanridiau) {
		ndel=last-im->s;
		s.s[ndel]=s.s[ndel-1];
	}
	im->set2(s.s);
}

void str_auto_simple_bendiau2(chars* im)
{
	static	chars s; s.clear(); char* last=0;
	int n012; char bendiau;
	char*fm=im->s;//, *to=im->s;
	while((*fm)&&(isdigit(*fm))) { s.app(fm,1); fm++; } // safe guard against leading digits
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ s.app(fm,2); fm+=2; continue; }
		if(!isdigit(*fm)) { s.app(fm,1); fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&isdigit(fm[2])){ // 3 or more digits in a row
				while( (fm[0])&&(isdigit(fm[0])) ) { s.app(fm, 1); fm++; }
				continue;
			}
			s.app(fm,2); last=0; fm+=2;  continue;
		}else{
			switch(*fm){
			case '1': bendiau='2'; break;
			case '2': bendiau='3'; break;
			case '3': bendiau='4'; break;
			case '4': bendiau='1'; break;
			case '5': bendiau='2'; break;
			case '6': bendiau='8'; break;
			case '7': bendiau='6'; break;
			}
			s.app(fm,1); last=im->s+s.size(); fm++; s.app(bendiau); continue;
		}
	}
	int ndel;
	if(last) {
		ndel=last-im->s;
		if(s.s[ndel+1]==0)
		s.s[ndel]=s.s[ndel-1];
	}
	im->set2(s.s);
	char cc=im->lastbyte1();
	if(!isdigit(cc)) {
		if(im->s[1]&& //s[1] so that its length is >1
			(cc=='p'||cc=='t'||cc=='k'||cc=='h') )
				cc='6'; 
		else 
			cc='1';
		im->app(cc);
	}
}


void  str_kauqidiau_pos(char*s, voids<int>* p, int singlediau)
{
	int n012;
	char*fm=s, *to=s; p->clear();
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ fm+=2; continue; }
		if(!isdigit(*fm)) { fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2])) // 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) fm++; continue; }
			fm++; p->app(fm-to); fm++; continue;
		}else{
			if(singlediau)
				{ p->app(fm-to); fm++; continue; }
		}
		fm++;
	}
}

int  str_kauqidiau_pos(char*s, vector<int>& p, int singlediau)
{
	int n012;
	char*fm=s, *to=s; p.clear();
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ fm+=2; continue; }
		if(!isdigit(*fm)) { fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2]))// 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) fm++; continue; }
			fm++; p.push_back(fm-to); fm++; continue;
		}else{
			if(singlediau)
				{ p.push_back(fm-to); fm++; continue; }
		}
		fm++;
	}
	return p.size();
}

int  str_danridiau_pos(char*s, vector<int>& p)
{
	int n012;
	char*fm=s, *to=s; p.clear();
	while(*fm) {
		n012=is012(fm);
		if(n012==2) 			{ fm+=2; continue; }
		if(!isdigit(*fm)) { fm++ ; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2]))// 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) fm++; continue; }
			p.push_back(fm-to); fm+=2; continue;
		}else{
			//if(singlediau)
				{ p.push_back(fm-to); fm++; continue; }
		}
		//fm++;
	}
	return p.size();
}

void  str_del2kauqidiau(char*s)
{
	//int n=strlen(s);
	int n012;
	char*fm=s, *to=s;
	//for(int ii=0; ii<n; ii++) {
	while(*fm) {
		n012=is012(fm);
		if(n012==2) { *to++=*fm++; *to++=*fm++; continue; }
		if(!isdigit(*fm)) { *to++=*fm++; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2])) // 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) *to++=*fm++; continue; }
			if( (to!=s)&&(to[-1]=='h')&&
					(	(fm[1]=='1')||(fm[1]=='2')||
						(fm[1]=='3')||(fm[1]=='4')||(fm[1]=='5'))
				) {
					to--;
					//if(fm[1]=='6')fm[1]='4';
					//if(fm[1]=='8')fm[1]='3';
			}
			fm++; *to++=*fm++; continue;
		}
		*to++=*fm++;
	}
	*to=0;
}

void  str_del2danridiau(char*s)
{
	//int n=strlen(s);
	int n012;
	char*fm=s, *to=s;
	//for(int ii=0; ii<n; ii++) {
	while(*fm) {
		n012=is012(fm);
		if(n012==2) { *to++=*fm++; *to++=*fm++; continue; }
		if(!isdigit(*fm)) { *to++=*fm++; continue; }
		if(fm[1]&&isdigit(fm[1])) {
			if(fm[2]&&(is012(fm+2)==1)&&isdigit(fm[2])) // 3 or more digits in a row
				{while( (fm[0])&&(isdigit(fm[0])) ) *to++=*fm++; continue; }
			else {
				*to++=*fm++; fm++; continue;
			}
		}
		*to++=*fm++;
	}
	*to=0;
}


char* str_daiqidanribendiau(char* danridiau)
{
	static chars s; s.set2(danridiau);
	char c=s.lastbyte(); s.dellastbyte();
	switch(c) {
		case'1': c='2';break;
		case'2': c='3';break;
		case'3': c='4';break;
		case'4': c='1';break;
		case'5': c='2';break;
		case'6': if(s.lastbyte()=='h') { s.dellastbyte();c='3';}
						 else c='8';break;
		case'7': if(s.lastbyte()=='h') { s.dellastbyte();c='4';}
						 else c='6';break;
	}
	s.app(c);
	return s.s;
}

char* str_daiqibendiau(char* s)
{
	static chars cs; cs=s;
	str_auto_simple_bendiau(&cs,1);
	return cs.s;
}



#ifdef OLDOLDOLDOLD

int sis_:: big5punct	(char* s)
{
	if(s[0]=='\xa1') return 1;
	else if( (s[0]=='\xa2')&&
					((uchar)(s[1]) <= (uchar)'\x4e') ) return 1;
	return 0;
}

int sis_:: in					(char  c, char*s)
{	while(*s) if(c== (*s++)) return 1;  return 0; }

int sis_:: alldigits	(char* s)
{int n; while(*s){n=is012(s);if(n!=1)return 0;if(!isdigit(*s))return 0;s+=1;}return 1;}

int sis_:: hasdigit		(char* s)
{int n; while(*s){n=is012(s);if(n==1)if(isdigit(*s))return 1;s+=n;}return 0;}

int sis_:: hashanri		(char* s)
{
  while(*s) if(is012(s)>1) { return 1;}else s++;
  return 0;
}

int sis_:: hasorset		(char* s)
{
	char* ss=s; int res;
	while(*ss) {
		res=is012(ss); if(res!=1) { ss+=res; continue; }
		if((*ss == '(')||(*ss == ')')||(*ss == '|')) { return 1; }
		ss++;
  }
	return 0;
}

int sis_:: mayberi		(char* s)
{ int n;
  while(*s) {
		n=is012(s);
		if( (n==2) || (s[0]=='*') ) return 1;
		s+=n;
	}
	return 0;
}


int sis_:: all1byte		(char* s)
{int n; while(*s){n=is012(s);if(n!=1)return 0;s+=1;}return 1;}

char* sis_:: skiptabsp0(char* s)
{
  char* p=s;
  while( tabspace(*p) ) if( *p==0) break; else p++;
	return p;
}

int sis_:: blank			(char* s)
{
  char* p=skiptabspace(s);
  if(*p==0) return 1;
  return 0;
}

int sis_:: gline		(char* s)
{
  char* p=skiptabspace(s);
  if(*p==0) return 0;
  return !SS(p);
}



int sis_:: SS  (char* s)// slash slash at beg or at end
{
  char* p=s;
  while( tabspace(*p) ) if( *p==0) break; else p++;
  if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' ) return 1;
	int n=strlen(p); if(n<2) return 0;
	p+=n-2;
  if( p[0]=='/' && p[1]=='/' ) return 1;
  return 0;
}

int sis_:: SSEE(char* s)// slash slash exclamation exclamation
{
  char* p=s;
  while( tabspace(*p) ) if( *p==0) break; else p++;
	if(*p==0) return 0;
  if( p[0]=='/' && p[1]=='/' && p[3]=='!' && p[4]=='!' ) return 1;
	return 0;  // p[2] not checked for section note
}


int sis_:: PBC (char* s, char c1st, char clast, char c)
{
  while( tabspace(*s) ) if( *s==0) break; else s++;
  if(*s==0) return 0; // strip off leading space

  if(s[0]!=c1st) return 0;
  char* p= s+1; p += strlen(p);     // p point to null
  p--; while( tabspace(*p) ) p--; // c1st should not be tabspace,
                                    // strip off trailing sapce
  int ll=p-s;  // now ll is strlen of str -1(-1 4 c1st), p points to last char
  if(ll==1) { if(c!=0) return 0; return (*p == clast)? 1:0; }
  if(*p != clast) return 0;
  if(c) { if( p[-1] != c) return 0; }
  return 1;
}

/*
char* sis_:: tolower(char* s)
{
	int res;
	while(*s) {
		res=is012(s);	if(res==1) { *s=tolower(*s); }
    s+=res;
	}
}
*/

int sis_:: sw(char* s, char* match, int N)
{
	if(N<0) N=strlen(match);
	return (strncmp(s,match,N)==0);
}


int sis_:: ew(char* s, char* match, int N)
{
	if(N<0) N=strlen(match);
  int len=strlen(s);
  if(N>len) return 0;
  return (strcmp(s+len-N, match)==0);
}




char* sis_:: search4			(char* s, char c)
{ //return null if not found
  char* p=0; int n012;
  while(*s){n012=is012(s);if((n012==1)&&(*s==c)){p=s;break;}else s+=n012;}
  return p;
}

char* sis_:: search4crnl	(char* s)
{ //return null if not found
  char* p=search4(s,'\r');
  if(!p) return 0;
  if(*(p+1)!='\n') return 0;
  return p;
}

char* sis_:: search4crORnl(char* s, int* nbytes_returned)
{ //return null if not found
  char* p=0;
  while( *s!=0 ) 
		{ if( (*s =='\r')||(*s == '\n') ) { p=s; break; } else s++; }
  if(*s =='\r') { if(s[1]=='\n') { *nbytes_returned=2; return p; } }
  if(*s =='\n') { *nbytes_returned=(s[1]=='\r')?2:1; return p; }
  return p;
}



int sis_:: replacepunct (char* s, char r)
{// r: replacement
	char*p=s; if(!p) return 0; int nreplaced=0;
	int res;
	while(*s) {
		res=is012(s);
		if(res==1) { 
			if(ispunct(*s)){if(r)*p++=r;s++;nreplaced++;} 
			else *p++=*s++;
		}else{
			if(big5punct(s)){if(r){*p++=r;*p++=r;}s+=2;nreplaced++;}
			else{*p++=*s++;*p++=*s++;}
		}
	}
  *p=0;
	return nreplaced;
}


int sis_:: replacedigits(char* s, char r)
{// r: replacement
  char*p=s; if(!p) return 0; int nreplaced=0;
  int res;
  while(*s) {
    res=is012(s);
    if(res!=1) { *p++ = *s++; *p++ = *s++; continue; }
		else if(isdigit(*s)) { if(r) *p++=r; s++; nreplaced++; }
		else { *p++ = *s++; }
  }
  *p=0;
	return nreplaced;
}

int sis_:: replacewchar(char*s, char* tbr, char r)
{//tbr: tobereplaced, r: replacement
  char*p=s; if(!p) return 0;
  int res;
	int nreplaced=0;
  while(*s) {
    res=is012(s);
    if(res!=2) { *p++ = *s++; continue; }
    else if( (s[0]==tbr[0]) && (s[1]==tbr[1]) ){ if(r) *p++=r; s+=2; nreplaced++;}
		else { *p++ = *s++; *p++ = *s++; }
	}
	*p=0;
	return nreplaced;
}

int sis_::
replace (char*s, char tbr, char r)  // ret: num replaced
{//tbr: tobereplaced, r: replacement
	int nreplaced=0;
	char*p=s; if(!p) return 0;
	int res;
	while(*s) {
		res=is012(s);
		if(res==2) 				{ *p++ = *s++; *p++ = *s++; continue; }
		else if(*s ==tbr) { if(r) *p++=r; s++; nreplaced++; }
		else							{ *p++ = *s++; }
	}
	*p=0;
	return nreplaced;
}

#endif //#ifdef OLDOLDOLDOLD


// class sis_ : all static function
//////////////////////////////////////


//////////////////////////////////////
// binary search routine

//
// bfind requires an wis function that always has key on the first postion
//

int __cdecl wislower (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *)
				)
{
	unsigned int half, num=num_elements;
	char *lo = (char *)base;
	char *hi = (char *)base + (num - 1) * width;
	char *mid;
	int result;

	if( (*wis)(key, lo) <= 0 ) return 0;
//if( (*wis)(hi, key) <  0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi) >  0 ) return num_elements; // in stl sense
	// so keep  lo < key <= hi

	while ( ( num=(hi - lo)/ width) > 1 ) {
		half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid);
		if(result<=0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

int __cdecl wisupper (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *)
				)
{
	unsigned int half, num=num_elements;
	char *lo = (char *)base;
	char *hi = (char *)base + (num - 1) * width;
	char *mid;
	int result;

	if( (*wis)(key, lo) <  0 ) return 0;
//if( (*wis)(hi, key) <= 0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi) >= 0 ) return num_elements; // in stl sense
	// so keep  lo <= key < hi

	while ( ( num=(hi - lo)/ width) > 1 ) {
		half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid);
		if(result< 0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

int __cdecl wislower1 (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
				)
{
	unsigned int half, num=num_elements;
	char *lo = (char *)base;
	char *hi = (char *)base + (num - 1) * width;
	char *mid;
	int result;

	if( (*wis)(key, lo, database) <= 0 ) return 0;
//if( (*wis)(hi, key) <  0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi, database) >  0 ) return num_elements; // in stl sense
	// so keep  lo < key <= hi

	while ( ( num=(hi - lo)/ width) > 1 ) {
		half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid, database);
		if(result<=0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

int __cdecl wisupper1 (
				const void *key,
				const void *base,
				size_t num_elements,
				size_t width,
				int (__cdecl *wis)(const void *, const void *, const void *),
				const void* database
				)
{
	unsigned int half, num=num_elements;
	char *lo = (char *)base;
	char *hi = (char *)base + (num - 1) * width;
	char *mid;
	int result;

	if( (*wis)(key, lo, database) <  0 ) return 0;
//if( (*wis)(hi, key) <= 0 ) return num_elements; // in stl sense
	if( (*wis)(key, hi, database) >= 0 ) return num_elements; // in stl sense
	// so keep  lo <= key < hi

	while ( ( num=(hi - lo)/ width) > 1 ) {
		half = num / 2; mid = lo + half*width;
		result = (*wis)(key,mid, database);
		if(result< 0) { hi=mid; }
		else          { lo=mid; }
	}
	return (hi-(char*)base)/width;
}

static void * __cdecl bfind0 ( // copied from bsearch
				const void *key,
				const void *base,
				size_t num, // num_elem
				size_t width,
				int (__cdecl *compare)(const void *, const void *)
				)
{
				char *lo = (char *)base;
				char *hi = (char *)base + (num - 1) * width;
				char *mid;
				unsigned int half;
				int result;

				while (lo <= hi){
								//if (half = num / 2)
								half=num/2; if (half)
								{
												mid = lo + (num & 1 ? half : (half - 1)) * width;
												//if (!(result = (*compare)(key,mid)))
												result = (*compare)(key,mid);if (!(result))
																return(mid);
												else if (result < 0)
												{
																hi = mid - width;
																num = num & 1 ? half : half-1;
												}
												else    {
																lo = mid + width;
																num = half;
												}
								}
								else if (num)
												return((*compare)(key,lo) ? NULL : lo);
								else
												break;
				}

				return(NULL);
}

int __cdecl bfind ( // same as bsearch
				const void *key,
				const void *base,
				size_t num, // num_elem
				size_t width,
				int (__cdecl *compare)(const void *, const void *)
				)
{
	void*r=bfind0(key,base,num,width,compare);
	if(!r) return -1;
	return ((char*)r-(char*)base)/width;
}

int bfindlast(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res< 0) {return -1;}
	res=strcmp(s, dt[N*(NSZ-1)]); if(res> 0) {return -1;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])<0) up=md;else lo=md;
	}
	if(strcmp(s,dt[N*lo])!=0) return -1;
	return lo;
}

int bfind(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res< 0) {return -1;} if(res==0) return 0;
	res=strcmp(s, dt[N*(NSZ-1)]); if(res> 0) {return -1;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])<=0) up=md;else lo=md;
	}
	if(strcmp(s,dt[N*up])!=0) return -1;
	return up;
}

int lower(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res<= 0) {return 0;}
	res=strcmp(s, dt[N*(NSZ-1)]); if(res>  0) {return NSZ;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])<=0) up=md;else lo=md;
	}
	return up;
}

int upper(char*s, char**dt, int N, int NSZ)//so sizeof(dt) is N*NSZ
{
	int lo=0, up=NSZ, md, res=0;
	res=strcmp(s, dt[0]   		 ); if(res<  0) {return 0;}
	res=strcmp(s, dt[N*(NSZ-1)]); if(res>= 0) {return NSZ;}
	while(lo<up-1) {
		md=(lo+up)/2;
		if(strcmp(s,dt[N*md])< 0) up=md;else lo=md;
	}
	return up;
}




// binary search routine
//////////////////////////////////////


//////////////////////////////////////
// chars pool

class charsbufs_{
	enum CHARSSTYR_ {MAX_TYSTATICS_=60};
	chars ss[MAX_TYSTATICS_];
	int i;
public:
	charsbufs_():i(0){}
	chars* operator()()
		{ i++; if(i>=MAX_TYSTATICS_) i=0; ss[i].set20();return &(ss[i]);}
};
static charsbufs_ charsbufs_1; // these are actually buf's

chars* getcharsbuf()
{ return charsbufs_1(); } // return a chars from a poll


int chars_hunNbohun(charpp& pp0, chars& ss, int N, char crnl_replacement)
{ // ss pp are resizable
	pp0.clear();
	char* p=ss.s; int n;
	str_replace(p,'\r',crnl_replacement);
	str_replace(p,'\n',crnl_replacement);
	str_replacewchar(p,"�@",' '); // zuanhing space to buannhing space

	while( istabspace(*p) ) if( *p==0) break; else p++;
	if(*p==0) return 0;

	pp0.set20();
	for(n=0; n<N; n++) {
		pp0.app(p);
		while(!istabspace(*p)) if( *p==0) break; else p++;
		if( (*p==0)||((int)(pp0.sz)==N) ) return pp0.sz;
		*p=0; p++;
		while( istabspace(*p)) if( *p==0) break; else p++;
		if(*p==0) return pp0.sz;
	}
	return n;
}

int chars_cut(charpp&pp, chars& s, char ch, int N)
{ // s pp are resizable
	pp.clear();
	char* p=s.s; int n; int n012;
	if(*p==0) return 0;
	pp.app(p); n=1;
	while(*p) {
		if((int)(pp.size())>N) return n;
		n012=is012(p);
		if(n012!=1) { p+=n012; continue; }
		if(*p==ch) {
			*p=0; p++;
			pp.app(p);
		}	else
			p++;
	}
	return pp.size();
}

//ccut, careful cut, tr the and \\ and \ch into  \ and ch
int chars_ccut(charpp&pp, chars& s, char ch, int N)
{ // s pp are resizable
	pp.clear();
	char* p=s.s; int n; int n012;
	if(*p==0) return 0;
	pp.app(p); n=1;
	while(*p) {
		if((int)(pp.size())>N) return n;
		n012=is012(p);
		if(n012!=1) { p+=n012; continue; }
		if(*p=='\''){
			if(p[1]=='\''||p[1]== ch ){strcpy(p,p+1); p++; continue;} // remove 1st bslash and keep the next
		}
		if(*p=='/'){
			if(p[1]=='/' ||p[1]== ch ){strcpy(p,p+1); p++; continue;} // remove 1st  slash and keep the next
		}
		if(*p==ch) {
			*p=0; p++;
			pp.app(p);
		}	else
			p++;
	}
	return pp.size();
}



int chars_hunNlet(charpp& pp, chars& ss, int N)
{ // ss pp are resizable
	if(!ss.s) return 0;
	char* p=ss.s; //char* s=p;
	int crnlbytes; int n;
	pp.set20();
	for(n=0; n<N; n++) {
		if(*p ==0) break;
		pp.app(p);
		p=str_search4crORnl(p, &crnlbytes);
		if( (!p)||((int)(pp.sz)==N) ) return pp.sz;
		*p=0;
		p+= crnlbytes;
	}
	return pp.sz;
}

int chars_eshun(charpp& pp, chars& ss, int N, char crnl_replacement)
{ // eshun: text in ".." will be treated as 1 part, \\ 4 \, and \" 4 "
	pp.clear();
	char* p=ss.s; int n;
	str_replace(p,'\r',crnl_replacement);
	str_replace(p,'\n',crnl_replacement);
	str_replacewchar(p,"�@",' '); // zuanhing space to buannhing space

	while( istabspace(*p) ) if( *p==0) break; else p++;
	if(*p==0) return 0;

	pp.set20();
	for(n=0; n<N; n++) {
		if(*p=='"'){
			pp.app(p+1); p++;
			int nnn=str_esfind1(p,'"');
			if(nnn<0){//this is err, put them as a whole str
				return pp.sz;
			}else{
				p[nnn]=0;
				p+=nnn+1;
				while(istabspace(*p)) if( *p==0) break; else p++;
			}
			if(int(pp.sz)>=N) // if there are some left, it is lost,
				return N; 			// but that should be an error
		}else{
			pp.app(p);
			while(!istabspace(*p)) if( *p==0) break; else p++;
			if( (*p==0)||((int)(pp.sz)==N) ) return pp.sz;
			*p=0; p++;
			while( istabspace(*p)) if( *p==0) break; else p++;
			if(*p==0) return pp.sz;
		}
	}
	return N;
}



// chars pool
//////////////////////////////////////



//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
// those nextsize and resize

//capool chars ::cap;
//pppool charpp::ppp;

void chars::show()
{MessageBox(NULL,s,"quick show by MEssageBox", MB_OK);}

void chars::show(char* caption)
{if(!caption)caption="chars";MessageBox(NULL,s,caption, MB_OK);}

int  chars::
resize(size_t size)
{
	if(size+1<=allcsize)return 1;
	//int oldsz=asize;
	size_t nsize=nextsize(size);
	//char*t=cap.allc(nsize);
	char*t=(char*)malloc(nsize);
	if(t) {
		t[0]=0;
		if(s&&s[0])strcpy(t,s);// else t[0]=0;
		//cap.dllc(s,allcsize);
		free(s);
		s=t;
		allcsize=nsize;
		return 1;
	}
	return 0;
}

int charpp::resize		(uint size)
{
	if(size<=allcsize)return 1;
	uint nsz=nextsize(size);
	//char** t=ppp.allc(nsz);
	char** t=(char**)malloc(nsz*sizeof(char*));
	if(t){
		memmove(t, pp, sizeof(char*)*sz);
		//ppp.dllc(pp, allcsize);
		free(pp);
		allcsize=nsz;
		pp=t;
		return 1;
	}
	return 0;
}

/*
int  chars::
resize(int size)
{
	if(size<=asize)return 1;// resize will own mem
	int oldsz=asize; s=(char*)realloc(s,size);
	if(s){
		asize=size;
		if(oldsz==0) s[0]=0;
		return 1;
	}
	return 0;
}
*/



size_t  chars::
nextsize(size_t newsize)
{
	newsize++;
	size_t n=allcsize;
	if(n<newsize)n=newsize;
	//if(n<cap.sz1()) return cap.sz1();
	//if(n<cap.sz1()) return cap.sz2();
	return int(n*1.2);
}


/*
uint  chars::
nextsize(uint newsize)
{
	newsize++;
	uint n=allcsize;
	if(n<newsize)n=newsize;
	if(n<allcsize)return allcsize;
	if(n<=16)return 16;
	if(n<=1024)return 2*n;
	return uint(n*1.1);
}
*/

uint  charpp::nextsize	(uint newsize)
{
	//if(allcsize<ppp.sz())return ppp.sz();//this line looks wrong
	uint n=allcsize;
	if(n<newsize)n=newsize;
	if(n<allcsize)return allcsize;
	if(n< 16)return 16;
	if(n<=1024)return 2*n;
	return uint(n*1.1);
	//if(allcsize<16)return 16;
	//if(allcsize<=512)return 2*allcsize;
	//return int(allcsize*1.1);
}


// those nextsize and resize
//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////


//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
// class chars


int  chars::set2  (cchar*s1)
{
	if(s==s1) return 1;
	if(s) s[0]=0;
	if(!s1)return 0;
	if(!s1[0])return 0;
	int n=strlen(s1)+1;
	if(resize(n)){
		strcpy(s,s1);
		return 1;
	}
	return 0;
}

int  chars::set2  (cchar*s1,int N)
{
	if(!s1)return 0;
	if(set2(s1)){
		if((int)strlen(s1)>N)s[N]=0;
		return 1;
	}
	return 0;
}

void chars::app   (const char*s1)
{
	//if((!s1)||(!s1[0]))return;
	if(!(s1&&s1[0]))return;
	uint n=strlen(s1)+3; if(s)n+=strlen(s);
	if(resize(n))
		strcat(s,s1);
}

void chars::app   (char*s1,int N)
{
	if(N<=0) return;
	char c[2]=" ";c[0]=s1[N-1];s1[N-1]=0;
	app(s1);app(c);
	s1[N-1]=c[0];
}

void chars::app1   (char c)
{
	char s1[2]=" ";s1[0]=c;
	app(s1);
}


void chars::apptimes(char c,int times)
{
	if((!c)||times<=0) return ;
	for(int n=0; n<times; n++)
		app(c);
}

int str_has1oneof(char* str, char*oneof)
{
  if(!(str&&str[0])) return 0;
  if(!(oneof&&oneof[0]))return 0;
  int n;
	while(*str){
    n=is012(str);
    if(n==1) if(str_isin(*str,oneof)) return 1;
    str+=n;
  }
  return 0;
}

int		chars::yimtr_begwy(int& begdeleted)
{
	int res=0; begdeleted=0;
	if		 (s[0]=='w'){res=1;if(s[1]=='u'){begdeleted=1;delb(1);}else s[0]='u';}
	else if(s[0]=='y'){res=1;if(s[1]=='i'){begdeleted=1;delb(1);}else s[0]='i';}
	else if(s[0]=='W'){res=1;if(s[1]=='u'){begdeleted=1;delb(1);}else s[0]='U';}
	else if(s[0]=='Y'){res=1;if(s[1]=='i'){begdeleted=1;delb(1);}else s[0]='I';}
	return res;
}

int		chars::tolower		()
{
	char* t; int n;
	t=s;
	while(*t){
		n=is012(t);
		if(n!=1){t+=n;continue;}
		*t=::tolower(*t);
		t+=1;
	}
	return 0;
}

int		chars::toupper		()
{
	char* t; int n;
	t=s;
	while(*t){
		n=is012(t);
		if(n!=1){t+=n;continue;}
		*t=::toupper(*t);
		t+=1;
	}
	return 0;
}



//& &amp;
//> &gt;
//< &lt;
//" &quot;
//' &apos;


void chars::tr2xml         ()
{
	char xpunt[]="&<>\"'";
	if(!str_has1oneof(s,xpunt)) return;
	static chars cs;cs=s;
	s[0]=0;
	char* t=cs.s;int n;
	while(*t){
		n=is012(t);
		if(n==1&&str_isin(*t, xpunt)){
			if      (*t=='&') app("&amp;");
			else if (*t=='>') app("&gt;");
			else if (*t=='<') app("&lt;");
			else if (*t=='"') app("&quot;");
			else if (*t=='\'')app("&apos;");
			else app(t,1);
		}else app(t,n);
		t+=n;
	}
}

void chars::trfromxml      ()
{
	if(!has('&')) return;
	char* tgt=s, *src=s;int n;
	while(*src){
		n=is012(src);
		if(n==1){
			if(*src=='&'){
				if      (strncmp(src,"&amp;",  5)==0){*tgt++='&' ; src+=5;}
				else if (strncmp(src,"&gt;",   4)==0){*tgt++='>' ; src+=4;}
				else if (strncmp(src,"&lt;",   4)==0){*tgt++='<' ; src+=4;}
				else if (strncmp(src,"&quot;", 6)==0){*tgt++='"' ; src+=6;}
				else if (strncmp(src,"&quote;",7)==0){*tgt++='"' ; src+=7;}
				else if (strncmp(src,"&apos;", 6)==0){*tgt++='\''; src+=6;}
				else {*tgt++=*src++;}
			}else {*tgt++=*src++;}
		}if(n==2){
			*tgt++=*src++;*tgt++=*src++;
		}else{
			// how come this can happen
			strncpy(tgt,src,n);
		}
	}
	*tgt=0;
}


int		chars::esfind	(char c, uint begfrom)
{ // find c but not \c
	if(begfrom>=size()) return -1;
	int pos;
	pos=str_esfind1(s+begfrom, c);
	return (pos>=0)?begfrom+pos: -1;
}

int		chars::find	(char c, uint begfrom)
{
	if(begfrom>=size()) return -1;
	int pos;
	pos=str_find1(s+begfrom, c);
	return (pos>=0)?begfrom+pos: -1;
}

int		chars::find(char*sstr, uint startfrom)
{
	if(startfrom>=size())return -1;
	int pos;
	pos=str_find(s+startfrom, sstr);
	return (pos>=0)?startfrom+pos: -1;
}

int  chars::laupart0(          )
{
	dellts();int n=findblank( );if(n>=0)s[n]=0;return(n>=0)?1:0;
}

int  chars::laupart0(char sep    )
{
  dellts();int n=find(sep);if(n>=0)s[n]=0;return(n>=0)?1:0;
}

int  chars::kidiaupart0(          )
{
  dellts();int n=findblank( );if(n>=0)delb(n); dellts(); return(n>=0)?1:0;
}

int  chars::kidiaupart0(char sep    )
{
  dellts();int n=find(sep);if(n>=0)delb(n+1); dellts(); return(n>=0)?1:0;
}





char*	chars::
tosxa	 (char* ki, int begWspace)//tos to xml attribute: ki="..."
{
	chars* t=getcharsbuf();
	if((ki&&ki[0])) {
		if(begWspace) t->app(" ");
		t->app(ki); t->app("\""); t->app(s);t->app("\"");
	}
	return t->s;
}

int  chars::
ew_nB	(       )
{
	char* t; int n012=0;
	t=s;
	while(*t) {
		n012=is012(t);
		if(t[n012]==0) break;
		t+=n012;
	}
	return n012;
}

int  chars::
inssep4012(char* sep)
{
	chars ts; char* t; int n012;
	if(!sep) sep="\t";
	t=s;
	while(*t) {
		n012=is012(t);
		ts.app(t,n012); ts+=sep;
		t+=n012;
	}
	set2(ts.s);
	return 1;
}

int  chars::
inssep4hanlor(char* sep, int hunguao)// sep def to "\t"/0
{
	if(hasnone())return 0;
	if(!sep) sep="\t";
	chars ts; char* t;
	int tauzing=0, henzai, n012; int nHANRI=10;
	t=s;
	while(*t) {
		n012=is012(t);
		switch (n012) {
			case 0: break;
			case 1: if(isalpha(*t)) henzai=1; else
			  if(*t=='\\')    henzai=1; else
							if(isdigit(*t)) henzai=2; else
							if(ispunct(*t)) henzai=3;
							if((!hunguao)&&(*t=='(')) {
								char* tt=str_search4(t, ')');
								if((tt)&&(*tt)) n012=tt-t+1; else n012=strlen(t);
								henzai=4;
							}//note that n012 maynot be 012, lazy to use another name
							break;
			case 2: henzai=nHANRI; //hanri
		}
		if(n012) {
			if(tauzing!=0) {
				if((henzai ==nHANRI     )) ts.app(sep); else
				if((tauzing!=henzai)&&(!((tauzing==1)&&(henzai==2)))) ts.app(sep);
				else if(henzai==4) ts.app(sep);
			}
			ts.app(t,n012);
			t+=n012;
			tauzing=henzai;
		}
	}
	if(ts.size()) { set2(ts.s); return 1; }// copy the result
	return 0;
}

int  chars::
inssep4tokenizer(char* sep, int hunhanri)// def to "\t"/0
{
	chars ts; char* t; //char ctauzing=0;
	if(!sep) sep="\t";
	int tauzing=0, henzai, n012; int nHANRI=10;
	t=s;
	while(*t) {
		n012=is012(t);
		switch (n012) {
			case 0: break;
			case 1: if(isalpha(*t)) { henzai=1;  }else //ctauzing =*t; }else
							if(isdigit(*t)) { henzai=2;  }else //ctauzing =*t; }else
							if(ispunct(*t)) { henzai=3;  }     //ctauzing =*t; }
							break;
			case 2: henzai=nHANRI; // ctauzing=0; //hanri
		}
		if(n012) {
			if(tauzing!=0) {
				if(henzai ==3     ) ts.app(sep); else
				if(tauzing==henzai) {
					if((henzai==nHANRI)&&hunhanri) { ts.app(sep); } else{}
				}else{
					if(tauzing==3) { ts.app(sep); } else
					if((tauzing==1)&&(henzai==2)) { } else
					if((tauzing==2)&&(henzai==1)) { ts.app(sep); }
				}
			}
			ts.app(t,n012);
			t+=n012;
			tauzing=henzai;
		}
	}
	if(ts.size()) { set2(ts.s); return 1; }// copy the result
	return 0;
}

/*
int	chars::
hascnt(char c)
{
	char* t=s;
	int n012; int cnt=0;
	while(*t){
		n012=is012(t);
		if((n012==1)&&(t[0]==c))cnt++;
		t+=n012;
	}
	return cnt;
}

int chars::
d1app(const char* s1)//app BYTE(strlen(s1)),then s1. No app if null
{
	int len=strlen(s1);	if(len<=0) return 0; if(len>255) len=255;
	app(uchar(len)); app(s1); return len;
}

void chars::set2full(const chars* p2s)
{
	set20(); resize(p2s->asize); memmove(s, p2s->s, p2s->asize);
}

*/

int  chars::
setpfname(char* fname, char* pname)
{
	clear();
	if(pname&&pname[0]) set2(pname);
	if(hassome()) appifen("\\");
	app(fname);
	return hassome();
	/*
	if(pname) set2(pname);
	if(pname&&hassome()) { if(!ew("\\")) app('\\'); }
	app(fname);
	return 1;
	*/
}

int  chars::
set24fep(char* fname, char* ename, char* pname)
{
	clear();
	if(pname&&pname[0]) set2(pname);
	if(hassome()) appifen("\\");
	app(fname);
	if(ename&&ename[0])appifen(ename);
	return hassome();
	/*
	if(pname) set2(pname);
	if(pname&&hassome()) { if(!ew("\\")) app('\\'); }
	app(fname);
	if(!ew(ename)) app(ename);
	return 1;
	*/
}

int  chars::
ins1(int* at, char c )
{
  char s1[2]=" ";s1[0]=c;
  return ins(at,s1,1);
}


int  chars::
ins(int* at, char*s1, int nbytes)
{
	if((!s1)||(!s1[0])||(nbytes<=0))return 0; int n=nbytes+3;//strlen(s1)+3;
	if(s)n+=strlen(s);
	if(!resize(n)) return 0;//own_copy_s(n);

	char *p1, *p2;
	p1=s + (*at); p2 = p1+nbytes;
	memmove(p2, p1, strlen(p1)+1);
  memmove(p1, s1, nbytes);
	// leave *at at the end of ins
	// note other option is leave at the same position.
	(*at) += nbytes;
	return nbytes;
}

int chars::insb(char*s, int at_fromb)//if(at>size())then regress2 app
{
	if(at_fromb<0) return 0;
	if(at_fromb>=int(size())) app(s);
	else ins(at_fromb,s);
	return 1;
}

int chars::inse(char*s, int at_frome)//if(at>size())then regress2 ins at 0
{
	if(at_frome<0) return 0;
	int at=size()-at_frome;
	if(at<0) ins(0,s);
	else ins(at,s);
	return 1;
}
int chars::insb(char c, int at_fromb)
{char s[2];s[0]=c;s[1]=0;return insb(s,at_fromb);}

int chars::inse(char c, int at_frome)
{char s[2];s[0]=c;s[1]=0;return inse(s,at_frome);}

int chars::floor  (int  n) // return good char boundary
{
  int nt=0; int n012; char* t=s;
  while(*t){
    n012=is012(t);
    if(nt+n012>=n) return n;
    nt+=n012; t+=n012;
  }
  return size();
}

int chars::ceiling(int  n) // return good char boundary
{
  int nt=0; int n012; char* t=s;
  while(*t){
    n012=is012(t);
    if(nt+n012>n) return n;
    nt+=n012; t+=n012;
  }
  return size();
}

int  chars::
goodat(int at)
{
	if(at<0) return 0;
	if(at>(int)strlen(s))return 0;
	return 1;
}


int  chars::
rite(int* at) // del a character at right, 0 or 1 or 2
{
	if((*at)>=(int)strlen(s)) return 0;
	int nbytes;
	nbytes=str_rbytes(s+(*at));
	*at+=nbytes;
  return nbytes;
}

int  chars::
rbytes(int at) // del a character at right, 0 or 1 or 2
{
	if((at)>=(int)strlen(s)) return 0;
	int nbytes;
	nbytes=str_rbytes(s+(at));
	return nbytes;
}

int  chars::
charunits() // in unit of echar and cchar, not in byte
{
	int n=0; int b; char* t=s;
	while(*t) { b=str_rbytes(t); t+=b; n++; }
	return n;
}

int  chars::
charunits(int bytenn) // num of units to pass/upto n
{
	if(bytenn<=0) return 0;
	int n=0; int b; char* t=s;
	while(*t) { b=str_rbytes(t); t+=b; n++; if(t-s>=bytenn) break;}
	return n;
}

int  chars::
del(int* at) // del a character at right, 0 or 1 or 2
{
  if((*at)>=(int)strlen(s)) return 0;
  int nbytes;
  nbytes=str_rbytes(s+(*at));
	return del(at, nbytes);
}

int  chars::
del(int* at, int nbytes)
{
  char* p=s+(*at)+nbytes;
  //str_rmove(p, strlen(p), -nbytes);
	memmove(p-nbytes, p, strlen(p)+1);
	return nbytes;
}


int chars::
dellastbyte()
{
	if(s[0]) { s[size()-1]=0; return 1; } return 0;
}

char chars::
lastbyte1   		()//return non-0 only if last is 1byte;
{
	int n=0; char*t; t=s;
	while(*t){
		n=is012(t);
		t+=n;
	}
	if(n!=1) return 0;
	return t[-1];
}

int str_lastdiauhor(char*t)
{ // not complete
	char*s=t; int n012;
	while(*s) {
		n012=is012(s);
		if(*(s+n012)!=0) {s+=n012; continue;}
		switch(n012) {
		case 1: if(isdigit(*s)) return s-t;
		case 2: return -1; // check hanri diauhor
		}
	}
	return -1;
}

void chars::
dellastdiauhor()
{
	int n=str_lastdiauhor(s);
	if(n>=0) s[n]=0;
}

int  chars::
lbytes(int at) // BS  a character, 0 or 1 or 2
{
	int nbytes; //int len;
	if((at)<=0||(strlen(s))<=0) return 0;
	if(at==1)      nbytes=1;
	else           nbytes=str_lbytes(s, (at)); //???
	return nbytes; // so (*at)>=nbytes
}

int  chars::
left(int* at) // BS  a character, 0 or 1 or 2
{
	int nbytes; //int len;
	if((*at)<=0||(strlen(s))<=0) return 0;
	if(*at==1)      nbytes=1;
	else            nbytes=str_lbytes(s, (*at)); //???
	*at -=nbytes;
	return nbytes; // so (*at)>=nbytes
}

int  chars::
BS (int* at) // BS  a character, 0 or 1 or 2
{
	return BS(at, lbytes(at) );
}

void   chars::
fstoption ()
{
	if(!(s&&s[0])) return;
	if(str_hasorset(s))
			set2( orset_1stoption(s) );
}


int  chars::
BS (int* at, int nbytes)
{
	if( (nbytes<=0)||( (*at)<=0 ) ) return 0;
	if( (*at) < nbytes ) nbytes=(*at);
  char* p=s+(*at);
  //str_rmove(p, strlen(p), -nbytes);
	memmove(p-nbytes, p, strlen(p)+1);
	*at -=nbytes;
	return nbytes;
}

int	 chars::getsetpname(char* s) // s is full path name ( maybe not)
{
	chars* ts=getcharsbuf(); ts->set2(s);
	return set2(ts->getpname());
}
int	 chars::getsetfname(char* s)
{
	chars* ts=getcharsbuf(); ts->set2(s);
	return set2(ts->getfname());
}
int	 chars::getsetename	 (char* s)
{
	chars* ts=getcharsbuf(); ts->set2(s);
	return set2(ts->getename());
}

char*chars::getfname()const // assume chars contains full path name
{
	char* t0=0, *t=s; int n;
	while(*t) {
		n=is012(t);
		if(n==2) { t+=2; continue; }
		if(n==1) { if(*t =='\\') t0=t; t++;}
	}
	chars* ts=getcharsbuf();
	if(t0) { ts->app(t0+1); } else { ts->app(s); }
	return ts->s;
}

char*chars::getpname()const // assume chars contains full path name
{
	char* t0=0, *t=s; int n;
	while(*t) {
		n=is012(t);
		if(n==2) { t+=2; continue; }
		if(n==1) { if(*t =='\\') t0=t; t++;}
	}
	chars* ts=getcharsbuf();
	if(t0) { ts->app(s, t0-s); }
	return ts->s;
}

char*chars::getename()const // assume chars contains full path name
{
	chars* ts=getcharsbuf();
	int slash=findlast('\\');
	int dot=findlast('.');
	if(dot<0) return ts->s;
	//if(slash<0||dot<0)return ts->s;
	if(slash>=0 && slash>dot) return ts->s;
	*ts = s+dot+1;//so no dot is returned
	return ts->s;
}

int  chars::hasfileext ()
{
	int dot=findlast('.');
	if(dot<0) return 0;
	int slash=findlast('\\');
	if(slash>=0 && slash>dot) return 0;
	return 1;
}

int  chars::insifnotone(char c)
{
	if(!c) c='1';
	char* ts=delename();
	char cc=lastbyte1();
	if(!isdigit(cc)){app(c);}
	if(ts&&ts[0])app(ts);
	return 0;
}

int  chars::insifnotone(int &isptkh, char c)
{
	if(!c) c='1';
	char* ts=delename();
	char cc=lastbyte1();
	if(!isdigit(cc)){isptkh=(cc=='p'||cc=='t'||cc=='k'||cc=='h')?1:0;app(c);}
	else{dele(1);c=lastbyte1();isptkh=(c=='p'||c=='t'||c=='k'||c=='h')?1:0;app(cc);}
	if(ts&&ts[0])app(ts);
	return 0;
}


char*	chars::delename() // assume chars contains full path name
{
	chars* ts=getcharsbuf();
	int slash=findlast('\\');
	int dot=findlast('.');
	if(dot<0) return ts->s;
	//if(slash<0||dot<0)return ts->s;
	if(slash>=0 && slash>dot) return ts->s;
	*ts = s+dot;//so dot is returned
	s[dot]=0;
	return ts->s;
}


void chars::appfname(char*fname) // append // if necessary
{
	if(lastbyte()!='\\') app("\\"); app(fname);
}

int  chars::dellastN(int N)
{
	int len=size();
	if(N>len) return 0;
	s[len-N]=0;
	return 1;
}



int		echars::onkeydown(WPARAM w)
{
	LRESULT lres=!LM_USED;
	switch (w) {
	case VK_LEFT:    left (); lres=LM_USED; break;
	case VK_RIGHT:   rite (); lres=LM_USED; break;
	case VK_HOME:    home (); lres=LM_USED; break;
	case VK_END:     end  (); lres=LM_USED; break;
	case VK_DELETE:  del  (); lres=LM_USED; break;
	}
	return lres;
}

int		echars::dell_keep1tspace() // del lead space, keep only 1 trail space if any
{
	int nn=str_findnontsrn(cs.s);
	if(nn>0) { cs.delleadspaces(); ip-=nn; if(ip<0) ip=0; }
	char c=cs.lastbyte();
	cs.delltspaces(); if(isspace(c)) cs+=c;
	if(ip>int(cs.size())) ip=cs.size();
	dirt=1;
	return 1;
}

int		echars::onchar	 (char   c)
{
	if(c==0x8 ) return BS();
	if(c==0x1b) return 0; // ESC
	return ins(c);
}

	/*
 try {
	int res=LM_USED;
	if(!yesDAIIM)			{ on_charcount++;  }
	if(ki==8  )				{ res=diiobuffer.onBS();			} else
	if(isdigit(ki))		{ res=diiobuffer.ondigit(ki);	} else
	if(ki=='\t')			{ res=diiobuffer.ontab( di5ic.shiftisdown() );}else
	if(ki==' ')				{ res=diiobuffer.onspace();		}else
	if(ki=='\r')			{ res=diiobuffer.onenter();		}else
	if(ki=='\x1b')		{ res=diiobuffer.onESC();			}else
	if(ki==charYIMSO)	{ res=diiobuffer.onyingso();	}else
	if(diiobuffer.ib.s.size()>64) { res= LM_USED;		}else // too long for the buffer
	if(ispunct(ki))		{ res=diiobuffer.onpunct(ki);	}else
	res=diiobuffer.onchar(ki);
	return res;  // LM_USED;
 }catch(...){
		diiobuffer.ib.clear();
		//diiobuffer.ob.clear();
		//diiobuffer.ib.ins("OOPS!");
 }
	//repaint();
	return LM_USED;
 */

// class chars
//////////////////////////////////////

//////////////////////////////////////
// class charpp and charss

/*
int charpp::set2(charpp& pp1)
{ // this makes no sense since charpp is for charspp, and
	// charpp's valuew must be pointer2 mem owned by chars
	set20();
	if(resize(pp1.allcsize)){
		for(uint n=0; n<pp1.allcsize; n++) app(pp1.pp[n]);
		return 1;
	}
	return 0;
}
*/


char* charpp::nullstr4charpp="";

int charpp::app 			(cchar*s1			)
{
	if(!s1)return 0;
	if(sz>=allcsize){resize(nextsize(allcsize));}
	if(sz< allcsize){pp[sz]=(char*)s1;sz++; return 1;}
	return 0;
}


//int set2Nhun(char* str, int N=100, char crnlrep=' ') { s0.set2(str); return hun(N,crnlrep); }
int  charpp::startwith(const char* str, int N, int from)
{
	if(N<0) N=strlen(str);
	int i, I=size();
	for(i=from; i<I; i++)
		if(strncmp(pp[i], str, N)==0) {	return i;}
	return -1;
}

int  	charss::startwith(const char* str, int N, int from)
{
	if(N<0) N=strlen(str);
	int i, I=size();
	for(i=from; i<I; i++)
		if(strncmp(ss[i]->s, str, N)==0) {	return i;}
	return -1;
}

char*  charpp::part_bw(const char* str, int N, int from) // bw: begin with
{
	int i=startwith(str,N, from); if(i<0) return NULL;
	return pp[i];
}

int charpp::delparts_bw(const char* str)
{
	int cnt=0, len=strlen(str), i, I=size();
  if(len<=0) return 0;
  int fm, to;
  fm=to=0;
  for(i=0; i<I; i++) { // remove all
  	if(strncmp(pp[i], str, len)==0) {	cnt++; fm++;}
		else { pp[to++]=pp[fm++]; }
  }
  sz-=cnt;
  return cnt;
}

int charpp::delpart(uint i)
{
	if(i>size()-1) return 0;
	for(uint ii=i; ii<size()-1; ii++) {
  	pp[ii]=pp[ii+1];
  }
  sz-=1;
  return 1;
}

/*
static chars s4charpp[2]; static i4s4charpp=1;
char*  charpp::
tos(char sep)
{
	i4s4charpp--; if(i4s4charpp<0) i4s4charpp=1;  int id=i4s4charpp;
	s4charpp[id].set20(); if(size()<=0) return s4charpp[id]();
	for(int i=0; i<size()-1; i++) s4charpp[id].apptab(pp[i]);
	s4charpp[id].app(pp[size()-1]); return s4charpp[id]();
}
*/


chars charss::nullcs;

int		charss::	fillupto  (int upto, char*s)//resize upto upto, and fill each with s
{
	ssresize(upto);
	//if(!(s&&s[0])) s="";
	int n,N=size();
	if(s) for(n=0; n<N; n++) nth(n)->set2(s);
	if(N>upto){
		for(n=upto;n<N;n++)dele();
		return upto;
	}
	if(!(s&&s[0])) s="";
	for(n=N; n<upto; n++)push_back(s);
	return upto;
}

int		charss::	resize  (int upto, char*s)//resize upto upto, and fill extra chars with s
{
	ssresize(upto);
	//if(!(s&&s[0])) s="";
	int n,N=size();
	//if(s) for(n=0; n<N; n++) nth(n)->set2(s);
	if(N>upto){
		for(n=upto;n<N;n++)dele();
		return upto;
	}
	if(!(s&&s[0])) s="";
	for(n=N; n<upto; n++)push_back(s);
	return upto;
}

char* charss::tos		(char*sep,int beg, int end)
{
	cs.clear();
	if(size()<=0) return cs.s;
	cslmt(beg, 0, size()-1); //if(beg<0) beg=0;
	if(end<0) end=size();
	cslmt(end, 0, size()  ); //if(end>size())end=size();
	for(int n=beg;n<end;n++){cs+=ss[n]->s;cs+=sep;}
	if(end-beg>0)cs.dele(strlen(sep));
	return cs.s;
}

int	charss::	set2(charspp* spp, int beg, int end)
{
	clear();
	if(beg<0) beg=0; if(end<0) end=spp->size();
	int sz, SZ=spp->size();
	if(beg>=SZ) beg=SZ; if(end>=SZ) end=SZ;
  if(beg>=end) { sz=beg; beg=end; end=sz; }
	ssresize(end-beg); 
	clear();
	for(sz=beg; sz<end; sz++)
		app( (*spp)[sz] );
	return end-beg;
}

int	charss::ssresize(int newsize)
{
	if(newsize<=ss.allocsize)return 1;
	int oldsz=ss.asz;
	int oldallcsz=ss.allocsize;

	if(newsize>ss.allocsize){
		if(!ss.resize(newsize)) return 0;
	}
	chars* t;
	for(int i=oldallcsz;i<newsize;i++){
		t=new chars;
		ss.a[i]=t;
	}
	/*
	for(int i=oldallcsz;i<newsize;i++){
		t=new chars; 
		ss.app(t);
	}
	*/
	ss.asz=oldsz;
	return 1;
}

/*
int	charss::ssresize(int newsize)
{
	if(newsize<=ss.allocsize)return 1;
	int oldsz=ss.asz;
	int oldallcsz=ss.allocsize;

	if(newsize>ss.allocsize){
		if(!ss.resize(newsize)) return 0;
	}
	chars* t;
	for(int i=oldsz;i<newsize;i++){
		t=new chars; 
		ss.app(t);
	}
	ss.asz=oldsz;
	return 1;
}
*/

void charss::ssdestroy()
{
	if(!ss.a)return;
	int N=ss.size();
	int i=0;
	for(;i<N;i++)
		ss.a[i]->destroy();
	ss.destroy();
	ss.init20();
}

void charss::clearcontent()
{
	if(!ss.a)return;
	int n,N=ss.size();
	for(n=0;n<N;n++)
		ss.a[n]->clear();
}

void charss::ssclear  ()
{
	if(!ss.a)return;
	int n,N=ss.size();
	for(n=0;n<N;n++)
		ss.a[n]->clear();
	ss.asz=0;
}


int 	charss::	insert	(int n, char* s)
{
	int asz=size();
	if(asz>ss.allocsize-1)
		if(!ssresize(asz+10))
			return 0;
	chars* t=ss.a[asz]; 
	t->clear();int i;
	for(i=asz;i> n;i--)
		ss.a[i]=ss.a[i-1];
	ss.a[n]=t;
	ss.asz++;
	ss.a[n]->set2(s);
	return 1;
}

int 	charss::	del (int n)
{
	if(!ss.a)return 0;
	if(n>=ss.asz)return 0;
	chars* orphan=ss.a[n];//not remove pointer,but clear cntnt
	for(int i=n; i<ss.asz-1;i++)
		ss.a[i]=ss.a[i+1];
	orphan->clear();
	ss.a[ss.asz-1]=orphan;
	ss.asz--;
	return 1;
}


int		charss::	update(int n, const char* s, int expandss)
{
	if(expandss){
		while(n>=ss.size())
			push_back("");
	}
	if(ss.isgood(n)) {
		ss.a[n]->set2(s); return 1;
	}
	//int N=ss.size();
	return 0;
}


// class charpp and charss
//////////////////////////////////////

//////////////////////////////////////
// class charspp

int  charspp::set2			(charspp&    spp)// not checked yet 4/9/2k1
{
	if(!s0.resize(spp.s0.allcsize)) return 0;
	memmove(s0.s, spp.s0.s, spp.s0.allcsize);
	char* t=spp.s0.s;
	if(!pp0.resize(spp.pp0.allcsize)) return 0;
	for(uint i=0; i<spp.pp0.size(); i++) {
		pp0.app(s0.s+ (int)(spp.pp0.pp[i]-t) );
	}
	return 1;
}


int	charspp::atpart (int ip, int toleft)
{
	int N,sz,SZ=size();
	if(SZ<=0) return 0;
	if(ip<=0) return 0;
	N=pp0[SZ-1]-s0.s; if(ip>=N) return SZ-1;
	for(sz=0; sz<SZ; sz++){
		N=pp0[sz]-s0.s;
		if(ip<=N) {
			if(ip==N) return sz;
			else if(toleft) return (sz>0)?sz-1:sz;
			N+=strlen(pp0[sz]);
			if(ip<=N) return (sz>0)?sz-1:sz;
			return sz;
		}
	}
	return SZ-1;
}


int charspp:: delparts_bw(const char* str)
{
	int N=strlen(str); int n=0;
	while(n<size()) {
		n=pp0.startwith(str, N, n);
		if(n<0) break;
		delpart(n);
	}
	return n>=0;
}

int charspp:: delpart(int i)
{
	if( i>=size()-1 ) return pp0.delpart(i);
	char c=ch01;
	chars* s=getcharsbuf();
	(*s)=tos(c,0,i); if(i>0) (*s)+=c; (*s)+=tos(c,i+1,size());
	return set2Ncut(s->s,c);
}

int charspp:: insert(int n, cchar* str)
{
	//if( (!str)||(!str[0]) ) return 0;
	if( (!str) ) return 0;
	chars &cs=(*getcharsbuf());
	cs=tos(ch01, 0,n);
	cs+=ch01; cs+=str; cs+=ch01;
	cs+=tos(ch01,n,size());
	return set2Ncut(cs.s,ch01);
	/*
	char* end; int N;
	if(n>=size()) {
		if(size()>0) { end=pp0[size()-1]; end += strlen(end)+1;}
		else { end=s0.s; }
		N=strlen(str)+1;
		if(end-s0.s+N<s0.asize) { // there is enough space
			strcpy(end, str);
			pp0.app(end);
			return 1;
		}
	}
	chars s; char c=ch01;
	//s=tos(c, 0, i+1); s+=c; s+=str; s+=c; s+=tos(c, i+1, size());
	s=tos(c, 0, i);
	if(i>0) s+=c;
	s+=str;
	if(i+1<size()) {
		s+=c;
		s+=tos(c, i, size());
	}
	return set2Ncut(s.s, c);
	*/

}

int		charspp::bw	 (int n, char*tt)//is part n bw tt?
{
	if(!inbnd(n)) return 0;
	return str_startwith(pp0[n],tt,strlen(tt));
}

int		charspp::ew  (int n, char*tt)//is part n ew tt?
{
	if(!inbnd(n)) return 0;
	return str_endwith(pp0[n],tt,strlen(tt));
}

int charspp::del2kauqidiau()
{
	int n; char*t;
	for(int ii=0; ii<size(); ii++) {
  	t=pp0[ii];
		n=strlen(t); if(n<2) continue;
    str_del2kauqidiau(t);
    //if(isdigit(t[n-2])&&isdigit(t[n-1])) { t[n-2]=t[n-1];t[n-1]=0;}
  }
  return 1;
}

int charspp::del_kauqidiau()
{
	int n; char*t;
	for(int ii=0; ii<size(); ii++) {
		t=pp0[ii];
    n=strlen(t); if(n<2) continue;
    if(isdigit(t[n-2])&&isdigit(t[n-1])) { t[n-1]=0;}
	}
	return 1;
}

char* charspp::
toline(char sep, int beg, int end)
{
	if(end<0) end=size(); if(end>size())end=size();
	if(beg<0) beg=0;
	chars* s=getcharsbuf();
	for(int i=beg; i<end; i++) {
		s->app(pp0[i]);
		if(sep&&(i<end-1))s->app(sep);
	}
	//{	if(!pp0[i][0]) continue; s->app(pp0[i]); if(sep&&(i<end-2))s->app(sep);	}
	return s->s;
}

char* charspp::
tos(char* sep, int beg, int end)
{
	chars& cs=(*getcharsbuf());
	cslmt(beg, 0, size()-1);
	if(end<0) end=size();
	cslmt(end, 0, size()  );
	int n;
	for(n=beg;n<end;n++){
		cs+=pp0[n];
		if(n < end-1)
			cs+=sep;
	}
	//if(end-beg>0)cs.dele(strlen(sep));
	return cs.s;
}


char* charspp::
rtos  (char sep, int beg, int end) // reverse tos
{
	if(end<0) end=size(); if(end>size())end=size();
	if(beg<0) beg=0;
	chars* s=getcharsbuf();
	for(int i=end-1; i>=beg; i--)
	{	if(!pp0[i][0]) continue; s->app(pp0[i]); if(sep&&(i>beg))s->app(sep);	}
	return s->s;
}

int		charspp::rm_esmark(          )
{
	int n, N=size();
	for(n=0;n<N;n++)
		str_rm_esmark(pp0[n]);
	return 1;
}

char* charspp::
xtagtos			()
{
	chars& cs =*getcharsbuf();
	return xtagtos(cs);
}

char* charspp::
xtagtos			(chars& cs)
{
	//chars& cs =*getcharsbuf();
	cs.clear();
	chars& cst=*getcharsbuf();
	char sep='\t';
	cs+="<"; cs+=pp0[0]; cs+=sep;
	int n,N=size();
	for(n=1;n<N;n+=2){
		cs+=pp0[n];cs+="=\"";
		cst.clear();
		cst+=pp0[n+1];
		//cst.rm_esmark();
		cst.tr2xml();
		cs+=cst.s;
		cs+="\""; cs+=sep;
	}
	cs+=" />";
	return cs.s;
}



char* charspp::
xtos			(char* tagname, charspp& fieldnames, char sep)
{ //do rm_esmark, then tr2xml
	chars& cs =*getcharsbuf();
	chars& cst=*getcharsbuf();
	if(!(tagname&&tagname[0])) return cs.s;
	int n,N=fieldnames.size();
	cs+="<"; cs+=tagname; cs+=sep;
	int NN=size();
	for(n=0; n<N; n++){
		cs+=fieldnames[n];
		cs+="=\"";
		if(n<NN){
			cst.clear();
			cst+=pp0[n];
			cst.rm_esmark();
			cst.tr2xml();
			cs+=cst.s;
		}
		cs+="\" ";
	}
	cs+=" />";
	return cs.s;
}

char* charspp::
xtos			(char* tagname, charspp& fieldnames, int* positions, char sep)
{
	if(!positions)return xtos(tagname,fieldnames,sep);
	chars& cs =*getcharsbuf();
	chars& cst=*getcharsbuf();
	if(!(tagname&&tagname[0])) return cs.s;
	int n,N=fieldnames.size();
	//int NN=size();
	cs+="<"; cs+=tagname; cs+=sep;
	int pos;
	int NN=size();
	for(n=0; n<N; n++){
		pos=positions[n];
		if(0<=pos && pos<N){
			cs+=fieldnames[pos];
			cs+="=\"";
			if(pos<NN){
				cst.clear();
				cst+=pp0[positions[n]];
				cst.rm_esmark();
				cst.tr2xml();
				cs+=cst.s;
			}
			cs+="\" ";
		}
	}
	cs+=" />";
	return cs.s;
}


int  charspp::
set2Nhunplus	(const char* str, int N, char crnlrep)
{
	s0.set2(str);
	str_replace(s0.s,'+',' ');
	return hun(N,crnlrep);
}

int  charspp::
hunorset	(int N, char crnlrep)
{
	char* ss=s0.s; int res;
	while(*ss) {
		res=is012(ss); if(res!=1) { ss+=res; continue; }
		if((*ss == '(')||(*ss == ')')||(*ss == '|')) { *ss=' '; }
		ss++;
	}
	return hun(N,crnlrep);
}

int  charspp::
set2Nhunpinim	(const char* str, int N, char crnlrep, int keepdash)
{
	s0.set2(str);
	s0.inssep4hanlor();
	char* ss=s0.s; int res; int paraON=0;
	while(*ss) {
    res=is012(ss); if(res!=1) { ss+=res; continue; }
		if(*ss == '(') paraON=1; else
		if(*ss == ')') paraON=0;
		//if((!paraON)&&(*ss == '-')) { if(!keepdash) *ss=' '; }
    if( (!paraON)&&ispunct(*ss) ) { if(!keepdash) *ss=' '; }
		ss++;
  }
	return hun(N,crnlrep);
}


int  charspp::
set2Nhunsls		(const char* str) //sls 4 soliong su, f.e. 53van
{
	if(!isdigit(str[0])) return 0;
	s0.set2(str); s0.app("-"); // so that pure number will work
	int len=s0.size();	s0.s[len-1]=0;
	char*t=s0.s;
	while(*t) {	if(isdigit(*t)) t++; else break; }
	len=t-s0.s;
	s0.ins(&len, ' '); s0.s[len-1]=0;
	pp0.clear(); pp0.app(s0.s); pp0.app(s0.s+len);
	return pp0.size();
}

int  charspp::
set2Nhunhanlor(const char* str, int N, char crnlrep, int keepdash)
{
	s0.set2(str);
	s0.inssep4hanlor();
	if(!keepdash) str_replace(s0.s, '-', ' ');
	return hun(N,crnlrep); 
}

int charspp::
hun1d	 (int N) // hun 1d str: (BYTE(strlen),str}...
{
	int lenall=s0.size(), lent=0, len1;
	if(lenall<=0) return 0;
	pp0.set20(); char* p=s0.s;
  for(int n=0; n<N; n++) {
		len1 =uchar(*p); *p++=0;
		if(*p ==0) break;
    pp0.app(p); lent+=1+len1; p+=len1;
		if(lent>=lenall) break;
	}
  return pp0.sz;
}


int charspp::
hunrlet(int N) // rlet : non-empty line
{
	N=hunlet(N); int tgt=0;
	for(int n=0; n<N; n++) {
		if(str_isblank(pp0[n])) continue;
		pp0.pp[tgt++]=pp0.pp[n];
	}
	pp0.sz=tgt; return pp0.sz;
}

int charspp::
hunglet(int N) // glet : non-enpty and not-commented by //
{
	N=hunlet(N); int tgt=0;
	for(int n=0; n<N; n++) {
		if(str_isblank(pp0[n])) continue;
		if(str_isSS   (pp0[n])) continue;
		pp0.pp[tgt++]=pp0.pp[n];
	}
	pp0.sz=tgt; return pp0.sz;
}



int  istr4line::
getline(chars& rline) // get into outside resizable line recursively
{
  rline.set20();
  char* tbuf=now; if(!tbuf) return 0;
	int nbytes;
	char* p=str_search4crORnl(tbuf,&nbytes); //return null if not found
  if(!p) {
    if(tbuf[0]) {rline.app(tbuf); now=0; }
	return (rline.s)?strlen(rline.s):0;
  }
  *p=0;	// \r is temporary replaced
  rline.app(tbuf); *p='\r'; p+=nbytes; 
  now=p;
  return (rline.s)?strlen(rline.s):0;
}


int istr4line::
getrline(chars&buf) //rline: real(nonblank) line
{
  getline(buf);
  if(buf.hassome()) return 1;
  if(!hasmore()) return 0; //if( (s)&&(*now==0) )return 0;
  return getrline(buf);
}

int istr4line::
getgline(chars&buf) //gline: rline and not startting with //
{
  getline(buf);
  if(buf.hassome()) 
		{ if( (buf.s[0]!='/')||(buf.s[1]!='/') ) return 1; }
  if(!hasmore()) return 0; //if( (s)&&(*now==0) )return 0;
  return getgline(buf);
}




int  istr4line::
getsentence(chars&buf) // includes last huhor.
{//r: 2 if juanhing, 1 if buannhing, 0 if not end with huhor(so check buf[0])
  char period[]="�C",comma[]="�A",question[]="�H",exclam[]="�I",
        semic[]="�F",colon[]="�G";
  char* p=now; buf.clear(); if((!p)||(!p[0])) return 0;
	int notfound=1; int n012; int punctbytes=0;

  while( (*p)&&(notfound) ) {
		n012=is012(p);
		if(n012==2) { // juanhing
		  if((p[0]==period  [0])&&(p[1]==period  [1])) notfound=0;
			if((p[0]==comma   [0])&&(p[1]==comma   [1])) notfound=0;
		  if((p[0]==question[0])&&(p[1]==question[1])) notfound=0;
		  if((p[0]==exclam  [0])&&(p[1]==exclam  [1])) notfound=0;
		  if((p[0]==semic   [0])&&(p[1]==semic   [1])) notfound=0;
		  if((p[0]==colon   [0])&&(p[1]==colon   [1])) notfound=0;
			buf.app(p,2);
			p+=2;
			if(!notfound) punctbytes=2;
		}else {   // buannhing
			if( (p[0]=='.')||(p[0]==',')||(p[0]=='?')||(p[0]=='!')
          ||(p[0]==';')||(p[0]==':') ) notfound=0;
			buf.app(p,1);
			p+=1;
			if(!notfound) punctbytes=1;
		}
  }
	now=p;
  return punctbytes;
}


int charspp::
set2Nhungu(const char* s1, int keeppunct,  int N)
{
	clear();	istr4line istr((char*)s1);
	chars s; char x01=ch01; int punctbytes;
	while(1) {
		punctbytes=istr.getsentence(s);
		if(!s.size()) break;
		if(!keeppunct) { s.dele(punctbytes); }
		s0+=s.s; s0+=x01; s.clear();
	}
	char* p=s0.s;  pp0.set20();
	for(int n=0; n<N; n++) {
		pp0.app(p);
		while(*p!=x01) if( *p==0) break; else p++;
		if( (*p==0)||((int)(pp0.sz)==N) ) return pp0.sz;
		*p=0; p++;			 if(*p==0) return pp0.sz;
	}
	return pp0.sz;
}


// class charspp
//////////////////////////////////////



//////////////////////////////////////
// class pairss

chars pairss::nulls;

int pairss::getndx(char* lhs)
{
	int i;
	if(sorted)
		i=2*bfind(lhs, pp0(), size()/2, sizeof(char**)*2, wis.sNsp);
	else
		for(i=0;i<size(); i+=2)
			if(strcmp(pp0[i], lhs)==0) break;
	if(i<0||i>=size()) return -1;
	return i;
}

int pairss::set(char* lhs, char*rhs)
{
	if(!(lhs&&lhs[0])) return 0;
	//if(!(rhs&&rhs[0])) return 0;
	char tt[]=""; char*t=(rhs)?rhs:tt;
	app(lhs);
	app(t);
	sorted=0;
	return 2;
}


int pairss::reset(char* lhs, char*rhs)
{
	if(!(rhs&&rhs[0])) return 0;
	int i=getndx(lhs);
	if(i<0) return 0;
	i++; delpart(i); insert(i,rhs);////??????insert after??????
	return 1;
}

char* pairss::get(char* lhs)
{
	int i=getndx(lhs);
	return (i<0)?nulls.s : pp0[i+1];
}


void pairss::qsort()
{
	::qsort(pp0.pp, size()/2, sizeof(char**)*2, wis.spNsp);
	sorted=1;
	char* t=tos(ch01,0,size());
	set2Ncut(t,ch01);
}

// class pairss
//////////////////////////////////////

int	mpfe_::next0(chars* pn1, chars& fn1, chars* en1)
{
	int n,N=spp.size();
	fn1.clear(); if(pn1)pn1->clear();
	if(N<=0) return 0;
	chars t; int found=0;
	for(n=curr+1;n<N;n++){
		t=spp[n]; t.dellts();
		if(!t[0])continue;
		if(t[0]=='/'&&t[1]=='/') continue;
		if(t[0]=='#'){
			switch(t[1]){
			case 'p':case 'P': if(t[2]==':')pn=t.s+3;else pn=t.s+2;
				pn.dellts(); break;
			case 'e':case 'E': if(t[2]==':')en=t.s+3;else en=t.s+2;
				en.dellts(); break;
			default: found=1; break;
			}
		}else found=1;
		if(found) break;
	}
	if(!found) return 0;
	curr=n;
	if(pn1)(*pn1)=pn; fn1=spp[curr]; if(en1)(*en1)=en;
	return 1;
}

int mpfe_::set2Nhun(char*ss,char sep)
{
	clear(); spp.set2Nhun(ss,sep);
	if(spp.size()<=0) return 0;
	return 1;
}

int mpfe_::set2Nhunlet(char*ss)
{
	clear(); spp.set2Nhunlet(ss);
	if(spp.size()<=0) return 0;
	return 1;
}



//////////////////////////////////////
// class tyio

#ifndef __WINDOWS
  #include <windows.h>
#endif

int str_rbytes			(cchar* s)
{	return AnsiNext(s)-s;   }

int str_lbytes(cchar* s, int at)
{	char* t=AnsiPrev(s, s+at);	return (s+at)-t;	}

int askOK4_file_overwrite(char*fname)
{
	lreader rd; rd.open(fname);
	if(rd.isOK()) {	rd.close();
		msgbox("\n\n!!!!!\noutput file:  ", fname,"  already exist. \n");
		msgbox("It will be overwrited.\n");
		msgbox("type y to confirm the overwriting or abort(y/n)?");
		char ki=getch(); msgbox("\n");
		if((ki=='y')||(ki=='Y')) return 1;
		return 0;
	}
	return 1;
}


int tyio::
open(char* filename, int ioflag)
{
	if(hfile) { close(); }
  if( (filename==NULL) || (filename[0]==0) )return 0;
  hfile=_lopen(filename, ioflag);
	if(hfile==-1) hfile=0;
  if(hfile) closable=1;
	return hfile;
}
int tyio::
creat(char* filename, int ioflag)
{
	if(hfile) { close(); }
  if( (filename==NULL) || (filename[0]==0) )return 0;
  hfile=_lcreat(filename, ioflag);
	if(hfile==-1) hfile=0;
  if(hfile) closable=1;
  return hfile;
}

int tyio::
close()
{
  if(closable) { 
    closable=0;
    if(hfile) _lclose(hfile); hfile=0;
	}
  return 1;
}

long  tyio::rewind(){return _llseek(hfile,0,FILE_BEGIN);}






// isOK(...) provides an oppurtunity to close the ap w/o too much ado?
int tyio::
isOK(char* fname)
{  if(isOK()) pause(fname); return isOK(); }

int tyio::
openOWmes (char* fname, char* pname, char* mes)
{
  int res=open(fname, pname);
	if(!res)
		if(mes&&mes[0]) { messagebox(mes);}
		//else messagebox("can't open ",pname,fname); }
  return res;
}

int tyio::
openERRMES (char* fname, char* pname)
{
	int res=open(fname, pname);
	if(!res) { messagebox("can't open ", pname, fname); }
  return res;
}


int tyio::
open4append (char* fname, char *pname)
{
	chars ss;ss.setpfname(fname,pname);//=pname;  ss.app(fname);
  open(ss.s,OF_READWRITE);
	if(!isOK()) {
    creat(ss.s);
    if(!isOK()) return 0;
	}
	_llseek(hfile, 0L, 2);  // move to end of file
	return hfile;
}

int tyio::
open (char* fname, char *pname)
{
	chars ss;
	ss.setpfname(fname,pname);//if(pname) { ss=pname;	if(!ss.ew('\\')) ss+="\\"; }
	//ss.app(fname);// malloc only at app
	return open(ss.s,0);
}

int tyio::
creat(char* fname, char *pname)
{
	chars ss;
	ss.setpfname(fname,pname);//if(pname&&pname[0]) { ss=pname;	if(!ss.ew('\\')) ss+="\\"; }
	//ss.app(fname);
	return creat(ss.s,0);
}

int tyio::
creatERRMES(char* fname, char *pname)
{
	int res=creat(fname,pname);
	if(!res) { messagebox("can't create ", pname, fname); }
	return res;
}


int tyio::
exist (char* fname, char *pname)
{
	int res=open(fname, pname); close();
	return res;
}

long tyio::
filesize()
{ // copied from PW3.1 of Petzold
	long lCurr=_llseek(hfile, 0L, 1); //from curr
	long lLsst=_llseek(hfile, 0L, 2); //from end
	_llseek(hfile, lCurr, 0);  // restore file pos pointer
	return lLsst;
}

long tyio::
rmoveto(long nbytes)
{
	//cout<<"before _llseek()\n";
	return _llseek(hfile, nbytes, FILE_CURRENT);
}

unsigned int tyio::
read(void * p, unsigned int len)
{ return _lread(hfile, p, len); }

unsigned int tyio::
write(void * p, unsigned int len)
{ if((!hfile)||(len<=0)) return 0; return _lwrite(hfile, (char*)p, len); }

unsigned int tyio::
appfile(tyio& io)
{
	if(io.isERR()) return 0;
	char buf[2048]; uint len, LEN=0;
	while(1){//!io.isEOF()){
		len=io.read(buf, 2048);
		if(len>0) LEN+=write(buf,len);
		if(len<2048) break;
	}
	return LEN;
}

unsigned int tyio::
appfile(char* fn, char* pn)
{
	tyio io; io.open(fn,pn);
	if(io.isERR()) return 0;
	int LEN=appfile(io);
	io.close();
	return LEN;
}


//void tyio::flush()
//{ _flush(hfile); }

// class tyio
//////////////////////////////////////


//////////////////////////////////////
// class lreader

int  lreader::
open (char* fname, char *pname)
{
	EOF_reached=0;
	return tyio:: open(fname,pname);
}


int lreader::
init_tbuf(int buflength )
{
  if(tbuf) delete[] tbuf;  tbuf=0;
  tbuflen=buflength;
	//ty32.ime will not use this part, and thus will be kept same as exe case
#ifdef WIN32DLL
	tbuf=new char[tbuflen+1];
  // may/do not know how to when to delete
#else //WIN32DLL
	tbuf=new char[tbuflen+1];
#endif //WIN32DLL
	if(tbuf) { tbuf[0]=0; tbuf[tbuflen]=0; }
  else { tbuflen=0; }
  return 1;
}

int lreader::
del_tbuf()
{
  if(deletable) delete tbuf; init_tbuf0(); return 0;
}

int lreader::
fill_tbuf()
{
  int len=strlen(tbuf);
  char* p=tbuf+len; len=tbuflen-len;
  int nRead=_lread(hfile, p, len);
  *(p+nRead)=0;
  if(nRead<len) 
    EOF_reached=1;
	return nRead;
}

void lreader::
move_tbuf(char* from)
{ // move the content to (left) top of tbuf
	//str_rmove(from, strlen(from), int(tbuf-from) );//move content of tbuf to top
	str_rmove(from, strlen(from), int(tbuf-from) );//move content of tbuf to top
}

int  lreader::
getline_rec(chars& rline, int clearbuf) // get into outside resizable line recursively
{ // this version works for unix system too
	if(clearbuf) rline.clear();
	if(isERR())return 0;
	if(!tbuf[0]) fill_tbuf();
	char* p=str_search4(tbuf,'\n'); //return null if not found
	if( (!p) ) { // p[1]==0 means \r\n is separated
		//if(p) { p[0]=0; }
		if(tbuf[0]) {rline.app(tbuf);}
		//if(p) { p[0]='\r'; }
		//if(p)str_rmove(p, strlen(p), int(tbuf-p) );//move content of tbuf to top
		//else tbuf[0]=0;
		tbuf[0]=0;
		if(EOF_reached) return (rline.s)?strlen(rline.s):0;
		fill_tbuf();
		return getline_rec(rline,0);
	}
	if(p-tbuf>=1) {
		if(p[-1]=='\r') p[-1]=0;
	} // \r need to be removed too
	//else { // then \r could be already in buf
	//if(p-tbuf<=1){
		int sz=rline.size();
		if((sz>0)&&(rline.s[sz-1]=='\r')) rline.s[sz-1]=0;
	//}
	*p=0;p++;   rline.app(tbuf);
	move_tbuf(p);//move content of tbuf to top
	//str_rmove(p, strlen(p), int(tbuf-p) );
	return (rline.s)?strlen(rline.s):0;
}
/*
int  lreader::
getline_rec(chars& rline) // get into outside resizable line recursively
{
  if(!tbuf[0]) fill_tbuf();
	char* p=str_search4(tbuf,'\r'); //return null if not found
	if( (!p) || (p[1]==0) ) { // p[1]==0 means \r\n is separated
    if(p) { p[0]=0; }
		if(tbuf[0]) {rline.app(tbuf);}
		if(p) { p[0]='\r'; }
		if(p)str_rmove(p, strlen(p), int(tbuf-p) );//move content of tbuf to top
		else tbuf[0]=0;
    if(EOF_reached) return (rline.s)?strlen(rline.s):0;
    fill_tbuf();    return getline_rec(rline);
  }
	*p=0;p++; if(p[0]=='\n') p++; // \n need to be removed too
  rline.app(tbuf);
	move_tbuf(p);//move content of tbuf to top
	//str_rmove(p, strlen(p), int(tbuf-p) );
	return (rline.s)?strlen(rline.s):0;
}
*/

int lreader::
getsentence_rec(chars&buf, int clearbuf) // includes lasst huhor.
{//r: 2 if juanhing, 1 if buannhing, 0 if not end with huhor(so check buf[0])
	//char period[]="�C",comma[]="�A",question[]="�H";
	if(clearbuf) buf.clear(); if(isERR())return 0;
	char period[]="�C",comma[]="�A",question[]="�H",exclam[]="�I",
				semic[]="�F",colon[]="�G";
	if( (!tbuf[0]) && EOF_reached ) return 0;
	if( (!tbuf[0]) )  fill_tbuf();
	if( (tbuf[0]) && (tbuf[1]==0) ) fill_tbuf(); // prevent 1/2 hanzi
	int notfound=1; int n012;
	char* p=tbuf;
	while( (*p)&&(notfound) ) {
		if( (*p) && (*(p+1)==0) ) { //prevent 1/2 hanzi
			move_tbuf(p); p=tbuf;
			if(!EOF_reached) { // can still read
				fill_tbuf();  continue;
			}// otherwise falls thru, data left are all in tbuf(only 1 byte).
		}
		n012=is012(p);
		if(n012==2) { // juanhing
			buf.app(p,2);
			if((p[0]==period  [0])&&(p[1]==period  [1])) notfound=0;
			if((p[0]==comma   [0])&&(p[1]==comma   [1])) notfound=0;
			if((p[0]==question[0])&&(p[1]==question[1])) notfound=0;
			if((p[0]==exclam  [0])&&(p[1]==exclam  [1])) notfound=0;
			if((p[0]==semic   [0])&&(p[1]==semic   [1])) notfound=0;
			if((p[0]==colon   [0])&&(p[1]==colon   [1])) notfound=0;
			p+=2;
		}else {   // buannhing
			buf.app(p,1);
			if( (p[0]=='.')||(p[0]==',')||(p[0]=='?')||(p[0]=='!')
					||(p[0]==';')||(p[0]==':') ) notfound=0;
			p+=1;
		}
		if(*p==0) {fill_tbuf();}
	}
	if( *p ==0 ) { // means reach end of tbuf;
		tbuf[0]=0; fill_tbuf();
		if(notfound) {if(isEOF()) return 0; }else return getsentence_rec(buf,0);
		// otherwise, happens to have huhoe/punt at the end
		return (buf.size()>0);//(t[1])?2:1;
	}
	// otherwise, *p not point to end, and  !notfound or found
	move_tbuf(p);//move content of tbuf to top
	//str_rmove(p, strlen(p), int(tbuf-p) );
	return buf.size();//(t[1])?2:1;
}

/*
int lreader::
getsentence_rec(chars&buf) // includes lasst huhor.
{//r: 2 if juanhing, 1 if buannhing, 0 if not end with huhor(so check buf[0])
  char period[]="�C",comma[]="�A",question[]="�H";
	if( (!tbuf[0]) && EOF_reached ) return 0;
  if( (!tbuf[0]) )  fill_tbuf();
	if( (tbuf[0]) && (tbuf[1]==0) ) fill_tbuf(); // prevent 1/2 hanzi
	unsigned short ser; char t[3]; t[2]=0;
  int notfound=1;
	char* p=tbuf;
	while( (*p)&&(notfound) ) {
		if( (*p) && (*(p+1)==0) ) { //prevent 1/2 hanzi
	  move_tbuf(p); p=tbuf; 
	  if(!EOF_reached) { // can still read
	    fill_tbuf();  continue;
		}// otherwise falls thru, data left are all in tbuf(only 1 byte).
	}
    //ser=big52ser(p[0],p[1]);//not working
	ser=(unsigned short)str_rightQisoBytes(p);
	//if(ser) { // juanhing
	if(ser==2) { // juanhing
	  t[0]=p[0];t[1]=p[1];	  p+=2; 
	  buf.appexpand(t);
	  //if(ser<unsigned(0x8800)) notfound=0;//not working
	  if((t[0]==period  [0])&&(t[1]==period  [1])) notfound=0;
		if((t[0]==comma   [0])&&(t[1]==comma   [1])) notfound=0;
	  if((t[0]==question[0])&&(t[1]==question[1])) notfound=0;
	}else {   // buannhing
		t[0]=p[0];t[1]=0; 	  p++;
		buf.appexpand(t);
	  //if(ispunct(t[0])) notfound=0;
		if( (t[0]=='.')||(t[0]==',')||(t[0]=='?') ) notfound=0;
	}
	if(*p==0) {fill_tbuf();}
	}
	if( *p ==0 ) { // means reach end of tbuf;
    tbuf[0]=0; fill_tbuf();
	if(notfound) {if(isEOF()) return 0; }else return getsentence_rec(buf);
	// otherwise, happens to have huhoe/punt at the end
	return (t[1])?2:1;
  }
  // otherwise, *p not point to end, and  !notfound or found 
	move_tbuf(p);//move content of tbuf to top
	//str_rmove(p, strlen(p), int(tbuf-p) );
	return (t[1])?2:1;
}
*/

int  lreader::
peekline(chars& cs) // //at most 136 due to tbuflen
{ // this version works for unix system too
	cs.clear();
	if(isERR())return 0;
	fill_tbuf();
	char* p=str_search4(tbuf,'\n'); //return null if not found
	if( !p ) { // '\n' not found, means no more text or too long
		cs=tbuf;
	}else{
		if(p-tbuf>=1)
			if(p[-1]=='\r') --p;
		cs.set2(tbuf, p-tbuf);
	}
	return cs.hassome();
}

int lreader::
getrline(chars&buf) //rline: real(nonblank) line
{
	buf.clear(); if(isERR())return 0;
	getline(buf);
	if(buf.hassome()) return 1;
	if(isEOF()) return 0;
  return getrline(buf);
}

int lreader::
getgline(chars&buf) //gline: rline and not startting with //
{
	buf.clear(); if(isERR())return 0;
	getline(buf);
	str_skipheadblank0(buf.s);
	if(buf.hassome()) {
		if( (buf.s[0]!='/')||(buf.s[1]!='/') ) return 1;
	}
	if(isEOF()) return 0;
	return getgline(buf);
}

int lreader::
getall(charspp&buf, int appendit)
{
	int n=0; chars s; if(!appendit) buf.s0.clear();
	while(!isEOF()) {
		getline(s);
		buf.s0.appln(s.s);
		n++;
	}
	return n;
}

int lreader::
getgline(charspp&buf, int appendit)
{
	chars s; if(!appendit) buf.s0.clear();
	while(!isEOF()) {
		if(getgline(s))
			buf.s0.appln(s.s);
	}
	buf.hunlet();
	return buf.size();
}

int lreader::
getrline(charspp&buf, int appendit)
{
	chars s; if(!appendit) buf.s0.clear();
	while(!isEOF()) {
		if(!getrline(s)) continue;
		if(s.isempty()) continue;
		buf.s0.appln(s.s);
	}
	buf.hunlet();
	return buf.size();
}

int  lread2gline(char*fn, charspp&buf, int appendit)
{
	lreader r; r.open(fn); if(r.isERR()) return 0;
	if(!appendit) buf.clear();
	r.getgline(buf); r.close();
	return buf.size();
}

int  lread2rline(char*fn, charspp&buf, int appendit)
{
	lreader r; r.open(fn); if(r.isERR()) return 0;
	if(!appendit) buf.clear();
	r.getrline(buf); r.close();
	return buf.size();
}

int  lread2line(char*fn, charspp&buf, int appendit)
{
	if(!appendit) buf.clear();
	lreader r; r.open(fn); if(r.isERR()) return 0;
	r.getall(buf); r.close();
	return buf.hunlet();
}

int  lreadNlines(char*fn, chars  &cs,  int N)//N=-1 for all lines
{
	chars tmp;
	cs.clear();
	if(N==0) return 0;
	lreader r; r.open(fn); if(r.isERR()) { cs="can not open\r\n";cs+=fn;return 0;}
	int n=0;
	while(!r.isEOF()){
		r.getline(tmp);
		cs.appln(tmp.s);
		n++;
		if(N>0) if(n>=N) break;
	}
	r.close();
	return n;
}

int  lreadNglines(char*fn, chars  &cs,  int N)//N=-1 for all lines
{
	chars tmp;
	cs.clear();
	if(N==0) return 0;
	lreader r; r.open(fn); if(r.isERR()) { cs="can not open\r\n";cs+=fn;return 0;}
	int n=0;
	while(!r.isEOF()){
		r.getgline(tmp);
		cs.appln(tmp.s);
		n++;
		if(N>0) if(n>=N) break;
	}
	r.close();
	return n;
}



// class lreader
//////////////////////////////////////


//////////////////////////////////////
// class writer


unsigned int writer::
writeNbohun(char** pps, int N, char* separator)
{
	if(!hfile) return 0;
	int n,linelen=0;
  int seplen=strlen(separator);
  for(n=0; n<N; n++) {
    linelen +=writestr(pps[n]);
    if(n<N-1) linelen += tyio::write(separator,seplen);
  }
	return linelen;
}

unsigned int writer::
writelnNbohun(char** pps, int N, char* separator)
{ int linelen=writeNbohun(pps,N,separator); return linelen+writeln(); }

unsigned int writer::
out	(charss& ss, char* aftereach)
{
	for(int i=0; i<ss.size();i++){
		out(ss[i]);
		if(aftereach)out(aftereach);
	}
	return ss.size();
}

// class writer
//////////////////////////////////////

//////////////////////////////////////
// class madis

int	madis::writepair(writer&w, char* lhs)
{
	char* t=get(lhs); if( (!t)||(!t[0]) ) return 0;
  w.write(lhs);w.write("=");w.write(t); return 1;
}

int madis::initini(int argcini1, char* argvini1[])
{
	argcini=argcini1; argvini=argvini1; argcini=argcini/2*2;
	if(!argvini) return 0;
  for(int i=0; i<argcini-1; i+=2) {
		resetset(argvini[i], argvini[i+1]);
	}
  return argcini;
}


int madis::readini(char* inifname)
{
	charspp lns, spp; char nulls[]=""; char* t;
  lread2gline(inifname, lns);
  for(int i=0; i<lns.size(); i++) {
  	t=lns[i];
  	if(str_find(t,"=")>=0)
					spp.set2Ncut(t,'=',2); // 2: 2 part are needed
    else 	spp.set2Nhun(t);
		if(spp.size()<2) t=nulls; else t=spp[1];
    resetset(spp[0],t);
	}
	resetset("inifname", inifname);
	return lns.size();
}

int madis::writeini(char* inifname)
{
	if(!argvini) return writeiniVTI(inifname);
	char* t=inifname; if(!t) t=getinifname(); if(!t[0]) return 0;
  writer w; w.creat(inifname); if(w.isERR()) return 0;
  for(int i=0; i<argcini-1; i+=2){
		writepairln(w, argvini[i]);
	}
  return argcini;
}

int madis::writeiniVTI(char* inifname)
{
	char* t=inifname; if(!t) t=getinifname(); if(!t[0]) return 0;
  writer w; w.creat(inifname); if(w.isERR()) return 0;
  char* tt=getcomment();
  if(tt&&tt[0]) w.writeln(tt);
  VTIwriteini(w);
	w.close();
	return 1;
}

// class madis
//////////////////////////////////////

//////////////////////////////////////
// class tcpreader

char *xmlline1alone="<?xml version=\"1.0\" encoding=\"Big5\" standalone=\"yes\" ?>";
char *xmlline1only=xmlline1alone;

int spp_hunattr(charspp& spp, char* data)
// makes a str of the form att="something" att2="2" into
// spp[0] contains att, and spp[1] contains something and so on
{
	static chars cs; cs.clear();
	if(data) spp.set2(data);
	spp.s0.delltspaces();
	spp.cut('=',2);
	cs=spp[1]; cs.delltspaces();
	int bq=0,eq=0;
	if(cs[0]=='\"') bq=1;
	if(bq) { eq=cs.find("\"",bq); cs[eq]=0; }
	strcpy(spp[1],cs.s+bq);
	return spp.size();
}

int str_rm_esmark(char* s)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012; char* tgt=s;
	while(*t) {
		n012=is012(t);
		if(n012==1){
			if(*t=='\\'){
				int n0122=is012(t+1);
				if(n0122==2){*tgt++=*t++;*tgt++=*t++;*tgt++=*t++;continue;}
				else if(n0122==1){
					switch(t[1]){
					case '"' : *tgt++='"';  t+=2; break;
					case '\\': *tgt++='\\'; t+=2; break;
					case 'r' : *tgt++='\r'; t+=2; break;
					case 'n' : *tgt++='\n'; t+=2; break;
					case 't' : *tgt++='\t'; t+=2; break;
					case ' ' : *tgt++=' ';  t+=2; break;
					default  : *tgt++=*t++; *tgt++=*t++; break;
					}
				}else if(n0122) return 0; // should be 0 here
				continue;
//		}else if(*t=='/'){
//			int n0122=is012(t+1);
//			if(n0122==2){*tgt++=*t++;*tgt++=*t++;*tgt++=*t++;continue;}
//			else if(n0122==1){if(t[1]=='=') {*tgt++='='; t+=2;}else *tgt++=*t++;continue;}
//			else if(n0122) return 0; //should be 0 here
			}else{//not backslash and not slash
				*tgt++=*t++;
			}
		}else if(n012==2){
				*tgt++=*t++;
				*tgt++=*t++;
		}
	}
	*tgt=0;
	return 1;
	//if(t[0]) return t-s;
	//return -1;
}

int str_control_ch2ch1(char* s, char control, char ch, char ch1)
{
	char* t=s; int cnt=0;
	if(!t||!t[0]) return -1;
	int n012; char* tgt=s;
	while(*t) {
		n012=is012(t);
		switch(n012){
		case 2: *tgt++=*t++;*tgt++=*t++;break;
		case 1: if(*t==ch) {if(ch1) *tgt=ch1; t++; cnt++; break; }
						if(*t!=control){*tgt++=*t++; break;}
						if(t[1]!=ch){*tgt++=*t++;break;}
						*tgt++=ch; t+=2; cnt++; break;
		case 0:return 0; //error
		}
	}*tgt=0;
	return cnt;
}



int str_esfind1(char* s, char c)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012; int prev_bslash=0;
	while(*t) {
		n012=is012(t);
		if(prev_bslash){prev_bslash=0;
			if(c=='\\'&& n012==1&&*t=='\\') break;
			t+=n012; continue;
		}
		if(t[0]=='\\'){prev_bslash=1;t+=n012;continue;}
		if(n012==2||t[0]!=c) {t+=n012; continue;}
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}


int str_find1(char* s, char c)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2||t[0]!=c) {t+=n012; continue;}
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}

int 	str_find2		    (char* s2, char*match2) // r:-1 if not find
{
	char* t=s2;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==1) {t+=n012; continue;}
		if(t[0]==match2[0]&&t[1]==match2[1]) break;
		t+=n012;
	}
	if(t[0]) return t-s2;
	return -1;
}

int str_findlast(char*s, char c)
{
	int no=-1,nw; char* t=s;
  while(1){
    nw=str_find1(t,c);
		if(nw<0) break;
		no=nw; t+=nw+1;
  }
  if(no<0) return no;
	return t-s-1;
}

/*
int str_findts(char* s)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2||!istabspace(t[0])){t+=n012; continue;}
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}

int str_findnonts(char* s)
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2) {t+=n012; continue; }
		if(n012==1&&istabspace(t[0])){t+=n012; continue; }
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}
*/
int is_tsrn(char c)//tab space \r \n
{
	return (c==' '||c=='\t'||c=='\r'||c=='\n')?1:0;
}


int str_findtsrn(char* s)//tab space \r \n
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2||!is_tsrn(t[0])){t+=n012; continue;}
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}

int str_findnontsrn(char* s) //tab space \r \n
{
	char* t=s;
	if(!t||!t[0]) return -1;
	int n012;
	while(*t) {
		n012=is012(t);
		if(n012==2) {t+=n012; continue; }
		if(n012==1&&is_tsrn(t[0])){t+=n012; continue; }
		else break;
	}
	if(t[0]) return t-s;
	return -1;
}

int		str_sametoken	(cchar* tocheck, cchar* token)
{
	//int len=strlen(token);
  char*t=(char*)token;
  while(*t){if(istabspace(*t))t++;else break;}
  if(*t=='<')t++;      if(*t=='/') t++;
  while(*t){if(istabspace(*t))t++;else break;}

  int len=str_findtsrn((char*)t); if(len<0) len=strlen(t);
	if(strncmp(tocheck, t, len)!=0) return 0;
	char c=tocheck[len];
	if(is_tsrn(c)||ispunct(c)) return 1;
	return 0;
}

int		str_sametoken_old	(cchar* tocheck, cchar* token)
{
//int len=strlen(token);
  int len=str_findtsrn((char*)token); if(len<0) len=strlen(token);
	if(strncmp(tocheck, token, len)!=0) return 0;
	char c=tocheck[len];
	if(is_tsrn(c)||ispunct(c)) return 1;
	return 0;
}



int		xmltag::set2Nhun	(const char* data)
{
	tg=data;
	return hun();
}


int		xmltag::hun (const char* data)
{
	char* t=(char*)data; if(!t) t=tg.s; if(!t) return -1;
	str_delltspaces(t);
	static chars cs; cs.clear();
	int len;
	if(t[0]=='<') { // if true, check having > or />
		len=strlen(t);
		if(t[len-1]!='>') return -1; // no match in <>
		if(len>2&&t[len-2]=='/') {t[len-2]=0;mpt=1;}else t[len-1]=0;
		t++;
	}
	int n;
	n=str_findnontsrn(t); if(n>0) t+=n;
	n=str_findtsrn   (t); if(n<0){tg=t;return 0;}
	t[n]=0; tg=t; t+=(n+1);
	while(*t) {
		n=str_findnontsrn(t ); if(n<0) break; t+=n;
		n=str_find1  (t,'=' ); if(n<0) break; int n1=str_findtsrn(t);if(n1>0&&n1<n) t[n1]=0;
																					t[n]=0; cs+=t; cs+=ch01; t+=n+1;
		n=str_find1  (t,'\"'); if(n<0) break; t[n]=0; t+=n+1;
		n=str_find1  (t,'\"'); if(n<0) break; t[n]=0; cs+=t; cs+=ch01; t+=n+1;
	}
	//if(*t) {// means err or no attr
	//	as.clear(); return 0;
	//}
	cs.dellastbyte();//last byte is ch01;
  cs.trfromxml(); // tr &amp;/&gt;/&lt;&quot;/&apos; into &/>/</"/'
	as.clear();
	as.set2Ncut(cs.s,ch01);
	return as.size()/2;
}

int		xmltag::hasattr		(cchar*att)
{
	for(int i=0; i<as.size();i+=2) {
		if(strcmp(att,as[i])==0) return 1;
	}
	return 0;
}

char* xmltag::operator[](cchar*att) //return value for the given att
{
	for(int i=0; i<as.size();i+=2) {
		if(strcmp(att,as[i])==0) return as[i+1];
	}
	static char junk[]="";
	return junk;
}

int  	xmltag::read(xreader& r)
{
	return r.getnexttag(tg);
}

int		xmltag::tis	(cchar* tag) // tag is
{
	if(!(tag&&tag[0])) return 0;
	if(tg[0]!='<') return 0;
	int b=1; if(tg[1]=='/') b=2;
	return str_sametoken(tg.s+b, tag);
}

char* xmltag::tos (char* sep)
{
	if(!(sep&&sep[0])) sep="\t";
	chars* t=getcharsbuf(), *tt=getcharsbuf();
	t->app("<");t->app(tg.s);
	int n,N=as.size();
	for(n=0;n<N;n+=2){
		t->app(sep); t->app(as[n]);t->app("=\"");
		*tt=as[n+1]; tt->tr2xml();
		t->app(tt->s);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

char* xmltag::tos (char sep)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf(), *tt=getcharsbuf();
	t->app("<");t->app(tg.s);
	int n,N=as.size();
	for(n=0;n<N;n+=2){
		t->app(sep); t->app(as[n]);t->app("=\"");
		*tt=as[n+1]; tt->tr2xml();
		t->app(tt->s);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

char* xmltagrw::tos (char sep, int dotr2xml)
{
	if(!sep) sep=' ';
	chars& t=*getcharsbuf(), &tt=*getcharsbuf();
	t.app("<");t.app(tg.s);
	int n,N=as.size();
	for(n=0;n<N;n+=2){
		t.app(sep);
		t.app(as[n]);
		t.app("=\"");
		tt=as[n+1];
		if(dotr2xml) tt.tr2xml();
		t.app(tt.s);
		t.app("\"");
	}
	if(N>0) t.app(sep);
	if(mpt) t.app("/>"); else t.app(">");
	return t.s;
}

char* xmltagrw::tos (char *sep, int dotr2xml)
{
	if(!(sep&&sep[0])) sep="\t";
	chars& t=*getcharsbuf(), &tt=*getcharsbuf();
	t.app("<");t.app(tg.s);
	int n,N=as.size();
	for(n=0;n<N;n+=2){
		t.app(sep);
		t.app(as[n]);
		t.app("=\"");
		tt=as[n+1];
		if(dotr2xml) tt.tr2xml();
		t.app(tt.s);
		t.app("\"");
	}
	if(N>0) t.app(sep);
	if(mpt) t.app("/>"); else t.app(">");
	return t.s;
}

/*
char* xmltagrw::tos (char sep, int dotr2xml)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf(), *tt=getcharsbuf();
	t->app("<");t->app(tg.s);
	int n,N=as.size();
	for(n=0;n<N;n+=2){
		t->app(sep); t->app(as[n]);t->app("=\"");
		*tt=as[n+1]; if(dotr2xml) tt->tr2xml();
		t->app(tt->s);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}
*/

char* xmltag::tos (charspp& spp, char sep)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf(), *tt=getcharsbuf();
	if(spp.size()<=0) return t->s;
	t->app("<");t->app(spp[0]);
	int n,N=spp.size();
	for(n=1;n<N;n++){
		t->app(sep); t->app(spp[n]);t->app("=\"");
		*tt=(*this)[spp[n]]; tt->tr2xml();
    t->app(tt->s);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

char* xmltagrw::tos (charspp& spp, char sep)
{
	if(!sep) sep=' ';
	chars* t=getcharsbuf(), *tt=getcharsbuf();
	if(spp.size()<=0) return t->s;
	t->app("<");t->app(spp[0]);
	int n,N=spp.size();
	for(n=1;n<N;n++){
		t->app(sep); t->app(spp[n]);t->app("=\"");
    *tt=(*this)[spp[n]]; tt->tr2xml();
		t->app(tt->s);t->app("\"");
	}
	if(N>0) t->app(sep); if(mpt) t->app("/>"); else t->app(">");
	return t->s;
}

int		xmltagrw::hun (char* data)
{
	char* t=data; if(t)tg=t;else t=tg.s; if(!t) return -1;
	xmltag tmp; 
	as.clear();
	if(tmp.hun(t)<0) return -1;
	tg=tmp.tg;
	as.set2(&(tmp.as));
	mpt=tmp.mpt;
	return size();
}
int		xmltagrw::app (char*ki, char*val)
{
	if(!(ki&&ki[0])) return 0;
	char sp[]="";
	if(!(val&&val[0])) val=sp;
	if(hasattr(ki)) return set2(ki, val);
	as.push_back(ki);
	as.push_back(val);
	return 1;
}

int		xmltagrw::set2(char*ki, char*val)
{
	int i;
	for(i=0; i<as.size()-1;i+=2) {
		if(strcmp(ki,as[i])==0)
			break;
	}
	if(i<as.size()-1) {
		as.ss.a[i+1]->set2(val);
		return 1;
	}
	return 0;
}

int		xmltagrw::set2(int nth, char*val)
{
	if(nth<as.size()-1) {
		as.ss.a[nth*2+1]->set2(val);
		return 1;
	}
	return 0;
}

int		xmltagrw::hasattr		(cchar*att)
{
	for(int i=0; i<as.size();i+=2) {
		if(strcmp(att,as[i])==0) return 1;
	}
	return 0;
}


char* xmltagrw::operator[](char*att) //return value for the given att
{
	for(int i=0; i<as.size()-1;i+=2) {
		if(strcmp(att,as[i])==0) return as[i+1];
	}
	static char junk[]="";
	return junk;
}

int		xmltagrw::att2ith		(char*att)
{
	for(int i=0; i<as.size()-1;i+=2) {
		if(strcmp(att,as[i])==0) return i+1;
	}
	return -1;
}

int  	xmltagrw::read(xreader& r)
{
	return r.getnexttag(tg);
}

int		xmltagrw::tis	(cchar* tag) // tag is
{
	if(!(tag&&tag[0])) return 0;
	if(tg[0]!='<') return 0;
	int b=1; if(tg[1]=='/') b=2;
	return str_sametoken(tg.s+b, tag);
}

int   xmltagrw::issamectag(cchar* tag)//* is opening tag (tg) is same as tag?
{
	if(!(tag&&tag[0])) return 0;
  int b;
	if(tag[0]=='<'&&tag[1]=='/') b=2;else
  if(tag[0]=='<')b=1;else
  b=0;
	return str_sametoken(tag+b, tg.s);
}

/*
int		xreader::skip2root(char* rootname)
// return 0 if rootname not match
{
	chars cs;
	if(!nextistag("xml")) return 0;
	getnexttag(cs);
	if(rootname)
		if(!nextistag(rootname)) return 0;
	return 1;
}
*/



int		xreader::getlnbuf(chars& res)
{
	//cs.delltspaces();
//	if(cs.s[0]) return 1;
  if(res.isgline()) return 0;
  static chars cs;cs.clear();
	while(!isEOF()) {
		//if(!getgline(cs)) return 0;
		getline(cs); if(kplnbr) cs+="\r\n";
		lnnow++;
		//cs.delltspaces();
    if(cs.isgline()) break;
		//if(cs.s[0]) break;
	}
  res+=cs.s;
	return 1;
}


int		xreader::skipnextdata()
{
	if(!nxtln[0])getlnbuf(nxtln);
	if(nxtln[0]=='<') return 1;
	int n012; char*t=nxtln.s; int n=0;
	int done=0;
	while(!done){
		n012=is012(t);
		if     (n012==2) { n+=n012; t+=n012;}
		else if(n012==1) {
			if(*t=='<') done=1;else { n++; t++;}
		}else{
			n=0; nxtln.clear(); getlnbuf(nxtln);   t=nxtln.s;
			if(!nxtln[0]) return 0; //error in data file
		}
	}
	if(n>0)nxtln.delfirstN(n);
	return 1;
}

int		xreader::getnextdta0(chars& cs)
{
	if(!nxtln[0])getlnbuf(nxtln);
	cs.clear();if(nxtln[0]=='<') return 0;
	int n012; char*t=nxtln.s; int n=0;
	int done=0;
	while(!done){
		n012=is012(t);
		if     (n012==2) { cs.app(t,2); n+=n012; t+=n012;}
		else if(n012==1) {
			if(*t=='<') done=1;else { cs.app(t,1); n++; t++;}
		}else{
			n=0; nxtln.clear(); getlnbuf(nxtln);   t=nxtln.s;
			if(!nxtln[0]) return 0; //error in data file
		}
	}
	if(n>0)nxtln.delfirstN(n);
	return 1;//cs.hassome();
}


int		xreader::getnexttag0(chars& cs, int keepSB, int keepln)//SB sharp bracket
{
	cs.clear();
	nxtln.delbif();
	if(!nxtln[0])getlnbuf(nxtln);
	//while(nxtln.bw("\r\n")) nxtln.delb(2);
	nxtln.delbif();
	if(!nxtln[0])getlnbuf(nxtln);
	nxtln.delbif();
	if(nxtln[0]!='<') return 0;
	int n012; char*t=nxtln.s; int n=0;
	if(!keepSB){t++; n=1;}
	int done=0;
	while(!done){
		n012=is012(t);
		if     (n012==2) { cs.app(t,2); n+=n012; t+=n012; }
		else if(n012==1) {
			if(*t=='>') done=1;else { cs.app(t,1); t++; }
			n++; //n++ so that > is always exlcuded
		}else{
			n=0; nxtln.clear(); getlnbuf(nxtln);   t=nxtln.s;
			//cs.app(" ");
			if(!nxtln[0]) return 0; //error in data file
		}
	}
	if(keepSB) { cs.app(">",1); }
	nxtln.delfirstN(n);//nxtln.delltspaces();
	if(!keepln){
	int lnend=0;
	if(nxtln[0]=='\r'||nxtln[0]=='\n') lnend++;
	if(nxtln[1]=='\r'||nxtln[1]=='\n') lnend++;
	if(lnend) nxtln.delfirstN(lnend);
	}
	//return (nxtln[0])?1:0;
	return 1;//cs.hassome();
}

int xreader::xmlNroot(chars& xmlline1, xmltag& root)
{
  if(!nistag("?xml")) return 0;
  getnext(xmlline1);
  if(!nistag()) return 0;
  chars cs;
  getnext(cs);
  root.set2Nhun(cs.s);
  return 2;
}

int xreader::xmlNroot(chars& xmlline1, chars& root)
{
  if(!nistag("?xml")) return 0;
  getnext(xmlline1);
  if(!nistag()) return 0;
  getnext(root);
  return 2;
}


int		xreader::xget				(chars& cs)//get tag or data, whatever it has now
{
	cs.clear(); if(isERR())return 0;
	int res, keepSB=1, keepln=1;
	if(nextistag())
		res=getnexttag0(cs,keepSB,keepln);
	else
		res=getnextdta0(cs);
	return res;
}

int		xreader::tget				(chars& cs)
{//will skip leading data if any
	cs.clear(); if(isERR())return 0;
	int res, keepSB=1, keepln=1;
	if(!nextistag())
		skipnextdata();
	res=getnexttag0(cs,keepSB,keepln);
	return res;
}

int   xreader::tgetoce     (chars& res, char sep, int keepctag)//* get empty tag, or otag upto ctag using sep to sep
{
  chars cs; getnext(res);
  if(res.isxetag())
    return 1;
  if(res[0]!='<') return 1;
//  int from=1;
//  char* t=res.s+from; while(*t){if(istabspace(*t))from++;else break;t++;}
  while(hasmore()){
//    if(nisctag(res.s+from)){
    if(nisctag(res.s)){
      getnext(cs);
      if(keepctag) {res+=sep; res+=cs;}
      break;
    }
    getnext(cs);
    res+=sep; res+=cs;
  }
  return 1;

}

int		xreader::tgeto				(chars& cs, char* tagname)
{//will skip leading data if any
	cs.clear(); if(isERR())return 0;
	int res;//keepSB=1, keepln=1;
	while(1){
		res=xget(cs);
		if(!res) break;
		if(cs.isxotag(tagname))
			break;
	}
	return res;
}


int		xreader::getnext(chars& cs, int keepSB, int keepln)
{
	cs.clear(); if(isERR())return 0;
	int res;
	if(nextistag())
		res=getnexttag0(cs,keepSB,keepln);
	else
		res=getnextdta0(cs);
	return res;
}


int		xreader::sametoken	(char* tocheck, char* token)
{
	return str_sametoken(tocheck, token);
}


int xreadNtags000(char* fname, chars& cs, char* sep0, int N, int keeproot)
{
	cs.clear(); if(N==0) return 0;
	char* sep=(sep0&&sep0[0])?sep0:"\r\n";
	//char cn2=0, tab2=0;
	//if(sep[0]=='\r'&&sep[1]=='\n') cn2=' ';
	//if(sep[0]=='\t'&&sep[1]==0   ) tab2=' ';
	xreader xr; xr.open(fname);
	if(xr.isERR()){
		cs="err in xrader.open, cannot open "; cs+=fname;return 0;
	}
	int n=0;
	chars cs1,cs2;
	xr.tget(cs1);
	if(keeproot&& !cs1.isxtag("xml"))
							{cs="bad format in 1st tag";cs+=fname;return 0;}
	if(keeproot){ cs=cs1.s;n++;}
	if(N>0&&n>=N) return n;
	xr.tget(cs1);while(cs1.isxcomment()){xr.tget(cs1);if(cs1.isempty())break;}
	if(keeproot&& !cs1.isxtag(     ))
							{cs="bad format in 2nd tag";cs+=fname;return 0;}// no root?
	if(keeproot){ cs+=sep;cs+=cs1;cs+=sep;n++;}
	if(N>0&&n>=N) return n;
	while(1){
		xr.tget(cs1);
		if(cs1.hasnone()) break;
		if(!keeproot)
		if(!cs1.isxetag())continue;
		cs+=cs1.s; cs+=sep;
		n++;
		if(N>0) if(n>=N) break;
	}
	if(sep&&sep[0])cs.deleif(sep);
	return n;
}

int xsaveastag(char* fname, charspp& spp, char* tagname, char* attrname, char* rootname)
{
	writer w;
	w.creat(fname); if(w.isERR())return 0;
	if(!(rootname&&rootname[0])) rootname="rootname";
	if(!(attrname&&attrname[0])) attrname="attr";
	chars cs; charspp tmpspp;
	w.writeln(xmlline1alone);
	cs="<"; cs+=rootname; cs+=">";	w.writeln(cs.s);
	int n,N=spp.size();
	for(n=0;n<N;n++){
		cs=tagname; cs+=ch01; cs+=attrname; cs+=ch01;  cs+=spp[n]; tmpspp.set2Ncet(cs.s,ch01);
		cs=tmpspp.xtagtos();
		w.writeln(cs.s);
	}
	cs="</"; cs+=rootname; cs+=">";	w.writeln(cs.s);
	w.close();
	return N;
}

int xsaveastag(char* fname, charss& ss, char* tagname, char* attrname, char* rootname)
{
	writer w;
	w.creat(fname); if(w.isERR())return 0;
	if(!(rootname&&rootname[0])) rootname="rootname";
	if(!(attrname&&attrname[0])) attrname="attr";
	chars cs; charspp tmpspp;
	w.writeln(xmlline1alone);
	cs="<"; cs+=rootname; cs+=">";	w.writeln(cs.s);
	int n,N=ss.size();
	for(n=0;n<N;n++){
		cs=tagname; cs+=ch01; cs+=attrname; cs+=ch01; cs+=ss [n]; tmpspp.set2Ncet(cs.s,ch01);
		cs=tmpspp.xtagtos();
		w.writeln(cs.s);
	}
	cs="</"; cs+=rootname; cs+=">";	w.writeln(cs.s);
	w.close();
	return N;
}


int xreadNtagname(char* fname, char* tagname, chars& cs, char* sep0, int N)
{
	cs.clear(); if(N==0) return 0;
	char* sep=(sep0&&sep0[0])?sep0:"\r\n";
	xreader xr; xr.open(fname);
	if(xr.isERR()){
		cs="err in xrader.open, cannot open "; cs+=fname;return 0;
	}
	int n=0;
	chars cs1,cs2;
	while(1){
		xr.tget(cs1);
		if(cs1.hasnone()) break;
		if(!cs1.isxtag(tagname))continue;
		if(!cs1.isxetag())continue;
		cs+=cs1.s; cs+=sep;
		n++;
		if(N>0) if(n>=N) break;
	}
	if(sep&&sep[0])cs.deleif(sep);
	return n;
}






int	xtsreader::getnext (chars& cs, int kind)
{
	cs.clear();
	int res;
	switch(kind){
	case XTS_GLINE	:res=xr.getgline(cs);break;
	case XTS_TGET		:res=xr.tget(cs);    break;
	case XTS_XGET		:res=xr.xget(cs);    break;
	case XTS_LINE 	:res=xr.getline(cs); break;
	case XTS_RLINE 	:res=xr.getrline(cs);break;
	}
	if(res) return res;
	if(xr.isEOF()) // do not use isEOF in the class here
		res=(hasmorefile())?opennext():0;
	if(!res) return 0;
	return getnext(cs,kind);
}
//;//{return lr.getline (cs);}


int xtsreader::opennext()//open each line of sppfns in turn
{ // \/:*?"<>| can not be part of the file name
	int NNN=sppfns.size();
	if(NNN<=0||nnn>=NNN) { xr.close(); return 0; }
	chars& cs=cswork;   int n, res=0;
	for(n=nnn+1; n<NNN; n++){
		cs=sppfns[n];
		if(cs.bw(":p")|cs.bw(":P")) { cspname=cs.s+2; continue; }
		if(cs.bw(":e")|cs.bw(":E")) { csename=cs.s+2; continue; }
		cs.set24fep(sppfns[n], csename.s, cspname.s);
		res=xr.open(cs.s);
		if(res) break;
	}
	if(res) { nnn=n; return res; }
	nnn=NNN; return 0;
}


int xtsreader::open0(char* fnames, char sep, int openByLet)
{	//if sep is 0, is separated by blank
	clear0();
	charspp& spp=sppfns;
	if(openByLet) {
						spp.set2Nhunlet	(fnames);
	}else{
		if(sep) spp.set2Ncet		(fnames,sep);
		else		spp.set2Nhun	 	(fnames);
	}
	nnn=-1;
	return opennext();
}

int str_isxtag(char* s, char* tg)
{
	if(!(s&&s[0]))return 0;
	int n=0;
	if(isspace(s[0])){n=str_findnontsrn(s); if(n<0) return 0;}
	char* t=s+n;
	if(t[0]!='<')return 0;t++;
	if(t[0]=='/'||t[0]=='?'||t[0]=='!') t++;
	return (tg)?str_sametoken(t,tg):1;
}



int	 chars::isxtag (char* tg)
{
	int n=find('<'); if(n<0) return 0;
	char* t=s+n+1;
	if(t[0]=='/'||t[0]=='?'||t[0]=='!') t++;
	return (tg)?str_sametoken(t,tg):1;
}

int	 chars::isxcomment()
{
	int n=find('<'); if(n<0) return 0;
	return (strncmp(s+n,"<!--",4)==0);
}

int	 chars::isnl()
{
	int sz=size(); if(sz>2) return 0;
	if(sz==2) if(s[0]=='\r'&&s[1]=='\n') return 1;
	else if(sz==1) if(s[0]=='\n') return 1;
	return 0;
}

int	 chars::isxetag(char* tg)//empty tag, note can have attr
{
	chars* ps=getcharsbuf();
	ps->set2(s); ps->delltspaces(); char* t=ps->s;
	if(t[0]!='<')return 0;
	int sz=ps->size(); if(sz<3) return 0;
	if( !(ps->s[sz-2]=='/'&&ps->s[sz-1]=='>') ) return 0;
	return (tg)?str_sametoken(t,tg):1;
}

int	 chars::isxotag(char* tg)//open tag
{
	int n=find('<'); if(n<0) return 0;
	char* t=s+n+1; if(t[0]=='/') return 0;
	return (tg)?str_sametoken(t, tg):1;
}

int	 chars::isxctag(char* tg)//close tag
{
	int n=find('<'); if(n<0) return 0;
	char* t=s+n+1; if(t[0]!='/') return 0;
	t++;	return (tg)?str_sametoken(t, tg):1;
}



int		xreader::nisotag		(char* tag)
{
	char c=nxtln[0];
  if((!c)||c=='\r'||c=='\n') getlnbuf(nxtln);
	if(!nxtln[0]) getlnbuf(nxtln);
  char*t=nxtln.s; int n=str_findnontsrn(t); if(n<0) return 0; t+=n;
	if( (t[0]=='<'&&t[1]!='/') ) {
			return (tag)?sametoken(t+1, tag):1;
	}
	return 0;
}

int		xreader::nisctag		(char* tag)
{
	char c=nxtln[0]; if((!c)||c=='\r'||c=='\n') getlnbuf(nxtln);
  if(!nxtln[0]) getlnbuf(nxtln);
  char*t=nxtln.s; int n=str_findnontsrn(t); if(n<0) return 0; t+=n;
	if( (t[0]=='<'&&t[1]=='/') ) {
			return (tag)?sametoken(t+2, tag):1;
	}
	return 0;
}

int		xreader::nistag(char* tag)
{
	char c=nxtln[0]; if((!c)||c=='\r'||c=='\n') getlnbuf(nxtln);
	if( !nxtln[0]) getlnbuf(nxtln);
  char*t=nxtln.s; int n=str_findnontsrn(t); if(n<0) return 0; t+=n;
	if( (t[0]=='<') ) {
		int b=1;		if(tag&&tag[0]!='/'&&t[1]=='/') b=2;
		return (tag)?sametoken(t+b, tag):1;
	}
	return 0;
}
/*
int		xreader::nisotag		(char* tag)
{
	if(!nxtln[0]) getlnbuf(nxtln);
	if( (nxtln[0]=='<'&&nxtln[1]!='/') ) {
			return (tag)?sametoken(nxtln.s+1, tag):1;
	}
	return 0;
}

int		xreader::nisctag		(char* tag)
{
	if(!nxtln[0]) getlnbuf(nxtln);
	if( (nxtln[0]=='<'&&nxtln[1]=='/') ) {
			return (tag)?sametoken(nxtln.s+2, tag):1;
	}
	return 0;
}

int		xreader::nistag(char* tag)
{
	if( !nxtln[0]) getlnbuf(nxtln);
  char*t=nxtln.s; t+=str_findnonts(t);
	if( (nxtln[0]=='<') ) {
		int b=1;		if(tag&&tag[0]!='/'&&nxtln[1]=='/') b=2;
		return (tag)?sametoken(nxtln.s+b, tag):1;
	}
	return 0;
}
*/
int		xreader::nisln	 		()
{
	if(!nxtln[0]) getlnbuf(nxtln);
	return (nxtln[0]=='\r'&&nxtln[1]=='\n')?1:0;
}

int		xreader::nisdata		()
{
	if(!nxtln[0]) getlnbuf(nxtln);
	return (nxtln[0]!='<')?1:0;
}

int		xreader::niscommand()
{
	if(!nxtln[0]) getlnbuf(nxtln);
	if(!nextistag())
		skipnextdata();
	if(!nxtln[0]) getlnbuf(nxtln);
	return (nxtln[0]=='<'&&nxtln[1]=='?')?1:0;
}

void xreader::testread()
{
	chars cs;
	open("test.txt");
	while(!isEOF()){
		getnext(cs);
	}
	cs="ssss";
}

void xreader::testdel()
{
	char* ts[]={""
	,"this is"
	,"this is "
	," this is"
	,"  this is   "
	,"  �~�rthis is"
	,"�~�rthis is   "
	,"  \t�~�r\tthis is"
	,"  this is\t �~�r"
	,"  this�~�r is "
	,"  this�~�r is �~�r    "
	,""};
	char *t;   chars tt, ss;
	for(int i=1;i<10000;i++){
		t=ts[i]; if(!t[0]) break;
		tt=t;
		ss=t;ss.delleadspaces();
		ss=t;ss.deltrailspaces();
		ss=t;ss.delltspaces();
	}
}
// class xreader
//////////////////////////////////////

//////////////////////////////////////
// class config_

int 	config_::load(char* fname)
{
	xreader r; chars cs; xmltag tg1;
	//cs=curdir;
	cs=fname; if(cs.hasnone()) return 0;
	r.open(cs.s, curdir.s);
	if(r.isERR()) return 0;
	inifname=cs;
	int found=0;
	while(!r.isEOF()){
		r.getnext(cs);
		if(cs.isxtag("xml")) continue;
		if(cs.isxtag()){ found=1;
			tg1.set2Nhun(cs.s);
			for(int n=0; n<tg1.size(); n++)
				tg.app(tg1.nth0(2*n),tg1.nth0(2*n+1));
				//tg.set2(tg1.nth0(2*n),tg1.nth0(2*n+1));
			found=1;
		}
	}
	r.close();
	loadOK=1;
	return found;
}


int 	config_::save(char* fname)
{
	if(!(fname&&fname[0])) return 0;
	tg.setmpttag(1);
	writer w; chars cs;
	//cs=curdir;
	cs=fname;
	w.creat(cs.s,curdir.s);
	if(w.isERR()) return 0;
	w.writeln(xmlline1alone);
	cs=tg.tos(' ');
	w.writeln(cs.s);
	w.close();
	return 1;
}

/*
int 	config_::load(char* fname)
{
	xreader r; chars cs;
	cs=curdir; cs+=fname;
	r.open(cs.s);
	if(r.isERR()) return 0;
	int found=0;
	while(!r.isEOF()){
		r.getnext(cs);
		if(cs.isxtag("config")){
			tg.set2Nhun(cs.s);
			found=1;
		}
	}
	r.close();
	return found;
}


int 	config_::save(char* fname)
{
	tg.setmpttag(1);
	writer w; chars cs;
	cs=curdir; cs+=fname;
	w.creat(cs.s);
	if(w.isERR()) return 0;
	w.writeln(xmlline1alone);
	w.writeln("<body>");
	cs=tg.tos(' ');
	w.writeln(cs.s);
	w.writeln("</body>");
	w.close();
	return 1;
}
*/
// class config_
//////////////////////////////////////



//////////////////////////////////////
// class mainarg_


int mainarg_::
set1(char c, char* v)
{
	int nn=ndx(c);
	fg[nn]=1;
	if(v) av[nn]=v;
	return 1;
}

int mainarg_::
set(int argc, char* argv[])
{
	preset();
	if(argc<=1) return 0;
	chars s, sa;
	int nn=1; //int hasnodash=0;
	ac=argc;
	s=argv[nn];
	if( (s.s[0]=='?')||(s.bw("help")) ) {
		forhelp=1;
		if(argc<3) { msgbox("mainarg: help what?\n\n"); return 1; }
		nn++; s=argv[nn]; set1('?', s.s);//fg[ndx('?')]=1; av[ndx('?')]=s;
		//hasnodash=1;
		return 1;
	}else	if(s.s[0]!='-') {
		set1('o', s.s);
		//av[ndx('o')]=s.s; // 1st argument default2 output, if not specified
		if(argc>=3) {	nn++; s=argv[nn]; }
		//hasnodash=1;
	}
	// other arguments should lead with - flag
	while( nn< argc ) {
		if( (s.s[0]!='-')||( (!isalpha(s.s[1]))&&(!isdigit(s.s[1])) ) ) {
			msgbox("mainarg: argument '",s.s, "' should \n  lead with - and then a single char flag\n");
			err=1;	return 0;
		}
		sa.clear(); if(nn+1<argc) sa=argv[nn+1];
		if( (sa.s[0]=='-') ) {
			sa.clear();
			//msgbox(sa.s, "\tmainarg: argument follows -flag should not start with '-'\n");
			//err=1;	return 0;
		}
		set1(s.s[1], sa.s); //fg[ndx(s.s[1])]=1; av[ndx(s.s[1])]=sa.s;
		if(sa.s[0]) nn+=2; else nn++;
		if(nn<argc) s=argv[nn];
	}
	return ac;
}

// class mainarg_
//////////////////////////////////////
//                            0       1         2         3       4          5        6         7           8           9    
static int   t2dh_daiqi	 []={	vorbiau,gorbenn,  diongbenn,gegang ,gorgang,   gorgau ,	gorbenn,  diongbenn,  gegang ,  gorsing				 };
static int   t2dh_kehqi	 []={	vorbiau,gorgang,  gorsing,  gebenn ,gorbenn,   gorbenn,	vorbiau,  diongbenn,  gebenn ,  vorbiau				 };
static int   t2dh_miaulik[]={	vorbiau,gorsing,  gorgang,  gorbenn,gegang,    gebenn ,	vorbiau,  vorbiau,    gorbenn,  vorbiau				 };
static int   t2dh_huaqi	 []={	gordiam,gorbenn,  gorsing,  gorgau ,gorgang,   gordiam,	vorbiau,  gordit ,    divor  ,  vorbiau,vorbiau};
//static int t2dh_gauhue []={ vorbiau,vorbiau,  gorgang,  gorsing,vorbiau,   divor,	  vorbiau,  gorbenn,    gordit ,    vorbiau,vorbiau};

extern tone2diauhing_set1diau_ tone2diauhing_set1diau;

void tone2diauhing_set1diau_::set1D(int ubiau)
{
	if(ubiau){
		t2dh_daiqi  [1]=gorbenn;	t2dh_daiqi  [2]=diongbenn;
		t2dh_daiqi  [6]=gorbenn;	t2dh_daiqi  [7]=diongbenn;
		t2dh_kehqi  [4]=gorbenn;	t2dh_kehqi  [5]=gorbenn;
		t2dh_kehqi  [8]=gebenn;
		t2dh_miaulik[4]=gebenn;		t2dh_miaulik[3]=gorbenn;
		t2dh_miaulik[8]=gorbenn;
		t2dh_huaqi  [1]=gorbenn;
		ubiau1D_=1;
	}
}


int tone2diauhing(int tone,char qiqen)
{
	if(tone<0||tone>9) return 0;//always set2 vorbiau
	switch(qiqen){
	case 'd': return t2dh_daiqi  [tone];
	case 's': return t2dh_kehqi  [tone];
	case 'k': return t2dh_kehqi  [tone];
	case 'm': return t2dh_miaulik[tone];
	case 'v': return t2dh_miaulik[tone];
	case 'h': return t2dh_huaqi  [tone];
	default : return t2dh_daiqi  [tone];
	}
}

char* diauhing_2markup(diauhing_ dh)
{
	static char t[100]; 
	int n=0;t[0]=0;
	if(dh<0||dh>=diauhing_end) return t;
	char c;
	t[n++]=ch02; c=diTS_TONECHAR; t[n++]=c; c=1; t[n++]=c;
	c=(char)dh; t[n++]=c; t[n++]=0;
	return t;
}


//////////////////////////////////////
//////////////////////////////////////
// class yimvun_

yimvun_ yimvun;

int yimvun_::yvpos2pos(char* yim, char* vun, int srcpos, int srcisyim)
{
	int srclen=0;
	if(srcpos<=0) return 0;
	srclen=strlen(yim); if(srcpos>srclen)srcpos=srclen;
	srclen=0;

	chars 	&csy	=csyim0, 		&csv	=csvun0;
	charspp &sppy	=sppyim0, 	&sppv	=sppvun0;
	//chars csy,csv; charspp sppy,sppv;
	csy=yim; csv=vun;
	int res;
	res=insNhun(csy,csv,sppy,sppv,ch01);
	if(!res)return 0;
	if(srcisyim)
		return spp1pos2spp2pos(sppy,sppv,srcpos);
	else
		return spp1pos2spp2pos(sppv,sppy,srcpos);
}

int yimvun_::spp1pos2spp2pos(charspp& spp1, charspp& spp2, int pos)
{
	int n, len=0;
	for(n=0;n<spp1.size();n++){
		len+=strlen(spp1[n]);
		if(len>=pos) break;
	}
	int N=n+1; len=0;
	for(n=0;n<N;n++){
		len+=strlen(spp2[n]);
	}
	return len;
}

int yimvun_::insNhun0(chars&csy, chars&csv, charspp&sppy, charspp&sppv, char sepc, chars& csyy, chars& csvv)
{ // assume there is no space in-between
	// no local variables with mem-alloc is declared
	if(csy.hasnone()) return 0;
	if(csv.hasnone()) return 0;
	if(!sepc) sepc=ch01;
	char sep[2]; sep[0]=sepc; sep[1]=0;
	sppy.set2Nhunhanlor(csy.s);
	sppv.set2Nhunhanlor(csv.s);
	if(sppy.size()==sppv.size()){
		csy=sppy.tos(sepc);
		csv=sppv.tos(sepc);
		return sppy.size();
	}
	if(csy.hashanri()) return 0; // pinim should not have zuanhing
	//what if csv is all digits?
	csy.clear(); csv.clear();
	//chars csyy, csvv;
	int ny=0,Ny=sppy.size(), nv=0, Nv=sppv.size();
	while(1){
		if(ny>=Ny||nv>=Nv) break;
		csyy=sppy[ny];csyy.trdigits();
		csvv=sppv[nv];
		int lenyy, lenvv;		int wychanged, vbegdeleted;
		char vunleadchar=(csvv.rbytes()==2)?0:csvv[0];
		int tocontinue=0;
		if(csyy==csvv||csvv.rbytes()==2)tocontinue=1;
		if(!tocontinue){
			csyy.tolower();						csyy.yimtr_begwy();
			csvv.tolower(); wychanged=csvv.yimtr_begwy(vbegdeleted);
			if(csyy==csvv) tocontinue=1;
			if(!tocontinue){lenyy=csyy.size();lenvv=csvv.size();}
			if(lenyy==lenvv)tocontinue=1;
		}
		if(tocontinue){
			csy.app(sppy[ny],sep);
			csv.app(sppv[ny],sep);
			ny++; nv++; continue;
		}
		//so now both csy and csv are pinimri's, lenyy and lenvv redefined
		if(lenyy<lenvv){
			if(!csvv.bw(csyy.s)){//how come this should happen: do nothing
				csy.app(sppy[ny],sep);
				csv.app(sppv[nv],sep);
				ny++;nv++;
			}else{//csvv bw csyy
				int ended=0;
				while(1){
					if(ended)break;
					csy.app(sppy[ny],sep); ny++;
					int lvv=csyy.size();
					char c=vunleadchar;
					if(wychanged){
						if(vbegdeleted){csv.app(c);if(isupper(c))csvv[0]=toupper(csvv[0]);}
					}
					csv.app(csvv.s,lvv); csv.app(sep); csvv.delb(lvv);
					if(csvv.hasnone()){nv++;break;}
					//not advancing nv yet, since csvv contains un-matched substring
					if(ny>=sppy.size()) { csv.app(csvv.s,sep); break; }
					csyy=sppy[ny]; csyy.trdigits();
					csyy.tolower();						csyy.yimtr_begwy();
					vunleadchar=csvv[0];
					csvv.tolower(); wychanged=csvv.yimtr_begwy(vbegdeleted);
					if(csvv.bw(csyy.s)) continue;
					// must be error, app all csvv
					if(wychanged){
						if(vbegdeleted){csv.app(c);if(isupper(c))csvv[0]=toupper(csvv[0]);}
					}
					csv.app(csvv.s,sep);	nv++; break;
				}
			}
		}else{//lenyy>lenvv
			//how come this should happen, must be an error in vun/yim: do nothing
				csy.app(sppy[ny],sep);
				csv.app(sppv[nv],sep);
				ny++;nv++;
		}
	}
	//could be not fully processed
	for(;ny<Ny;ny++) csy.app(sppy[ny],sep);
	for(;nv<Nv;nv++) csv.app(sppv[nv],sep);
	/*
	int nysep=csy.hascnt(sepc);
	int nvsep=csv.hascnt(sepc);
	int mm,MM=max(nysep,nvsep);
	for(mm=nysep;mm<MM;mm++) csy.app(sep);
	for(mm=nvsep;mm<MM;mm++) csv.app(sep);
	*/
	csy.deleif(sep); csv.deleif(sep);
	sppy.set2Ncet(csy.s,sepc);
	sppv.set2Ncet(csv.s,sepc);
	if(sppy.size()==sppv.size()) return sppy.size();
	return 0;//should not happen
}

// class yimvun_
//////////////////////////////////////
//////////////////////////////////////






//////////////////////////////////////
// struct szmio
int  szmiohs::hdrbsz=sizeof(rdhdr);

int szmiohs::
readp(char* p)//say, read from pointer/resource stream
{
  int bsz;
  bsz=hdrbsz;
  if(!h.readp(p, bsz)) return 0;
  p+=bsz+4;
  bsz=h.bszasinhdr();
  if(!s.readp(p, bsz)) return 0;
  //p+=bsz+4;
  return (h.sz+s.sz+8);
}


void szmio::
del()//{if(pm) UnmapViewOfFile(pm);pm=0;sz=0;}
{
	if(!pm) return;
  #ifdef WIN32DLL
  if(pm)UnmapViewOfFile(pm);
	//msgbox9("pm deleted");
  #else
	delete[] pm;
  #endif
	pm=0;sz=0;
}

char* szmio::
new2(long bsize, int extra)//extra default2 0
{
	#ifdef WIN32DLL
	HANDLE h;
	h=CreateFileMapping( (HANDLE)-1,NULL,PAGE_READWRITE,0,1+bsize+extra,NULL);
	if(!h)return NULL;
	pm=(PSTR)MapViewOfFile(h,FILE_MAP_WRITE,0,0,0);
	sz=(pm)?bsize:0;
	return pm;
	#else //WIN32DLL
	pm=new char[1+bsize+extra];pm[bsize+extra]=0;//return pm;
	sz=(pm)?bsize:0; return pm;
	#endif //WIN32DLL
}
long	szmio::
bszasinhdr() //treat pm as hdr_, return the bsz
{
	rdhdr* hd=(rdhdr*)pm;
	return hd->bsz;
}

//	char* read(tyio& io, int szdef=-1){long res=io.readsz(&sz);
//							if(res!=(long)sizeof(long)){ sz=0; return 0;	}
//							if(szdef>=0) if(sz!=szdef) {sz=0; return 0; 	}
//							pm=new2(sz,0);	res=io.read(pm, sz);
//							sz=res; return pm;														}
//	char* read(tyio& io, int extra=0){long res=io.readsz(&sz);
//							if(res!=(long)sizeof(long)){ sz=0; return 0; }
//							pm=new2(sz,extra);	res=io.read(pm, sz); sz=res; return pm;}
char*	szmio::
readp(char* p, int szdef)//say, read from pointer/resource stream
{
  sz=*((long*)p);
	if(szdef>=0) if(sz!=szdef) {sz=0; return 0; 	}
  pm=new2(sz,0); if(!pm) return 0;
  memmove(pm,p+sizeof(int), sz);
  return pm;
}
// struct szmio
//////////////////////////////////////

chars di5wis_::ll;
chars di5wis_::rr;
di53rd_ rdnull;
//enum rdkind {DIRD_NRK, DIRD_NIT, DIRD_DZB, DIRD_DZB3, DIRD_LAIVE, DIRD_C1SU};
//enum dikey	{DIRDKEY_IM, DIRDKEY_RI };

rdkind  cs2ridenkind(chars& cs)// return rdkind
{
	if(cs.is("nrk"))return DIRD_NRK;
	if(cs.is("nit"))return DIRD_NIT;
	if(cs.is("dzb"))return DIRD_DZB;
	if(cs.is("zik"))return DIRD_DZB3;
	if(cs.is("hh1"))return DIRD_DZB3;
	if(cs.is("hh2"))return DIRD_DZB3;
	if(cs.is("dbs"))return DIRD_DZB3;
	if(cs.is("ssl"))return DIRD_DZB;
	if(cs.is("laive"))return DIRD_LAIVE;
	if(cs.is("lv"))return DIRD_LAIVE;
	if(cs.is("nrk1"))return DIRD_NRK;
	if(cs.is("nit1"))return DIRD_NIT;
	if(cs.is("nrk2"))return DIRD_NRK;
	if(cs.is("nit2"))return DIRD_NIT;
	if(cs.is("nrk3"))return DIRD_NRK;
	if(cs.is("nit3"))return DIRD_NIT;
	if(cs.is("nrk4"))return DIRD_NRK;
	if(cs.is("nit4"))return DIRD_NIT;
	if(cs.is("nrk5"))return DIRD_NRK;
	if(cs.is("nit5"))return DIRD_NIT;
	return DIRD_UNKNOWN;
}

int wisdirikive(const void* l, const void* r)
{
	rikive* ll,*rr; ll=(rikive*)l; rr=(rikive*)r;
	int res;
	res=(uchar)(ll->r[0])-(uchar)(rr->r[0]);
	if(res) return res;
	res=(uchar)(ll->r[1])-(uchar)(rr->r[1]);
	if(res) return res;
	res=ll->k-rr->k;
	return res;
}

int __cdecl wisc1su(const void* l, const void* r)
{ return strcmp( (cchar*)l, (cchar*)r ); }




int di53laives::
read(tyio& r )
{
	int res;
	del();
	//res=hd_.read(r);	if(!res)return 0;
	res=mmrkv.read(r);if(!res)return 0;
	res=mmki.read(r); if(!res)return 0;
	res=afterread();  if(!res)return 0;
	return res;
}

int di53laives::
afterread()
{
	if(!( mmrkv.s()&&mmki.s() ) ) return 0;
	//rdhdr* hd;
	hdrk_ =(rdhdr *) mmrkv.h();
	rkvs	=(rikive*) mmrkv.s(); nRKVS=hdrk_->asz;
	hdki_ =(rdhdr *) mmki.h();
	kis 	=(char  *) mmki.s(); nKIS=hdki_->asz; kilen=hdki_->usz;
	return 1;
}

char* di53laives ::
ki	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	ps->set2( kis+ (rkvs[n.n].k)*kilen );
	return ps->s;
}


char* di53laives ::
ki0	( dilaive &n )
{
	char* t=ki(n);
	str_del4wis(t);
	return t;
}

char* di53laives ::
ri	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	if(rkvs[n.n].ishanri()){ps->app(rkvs[n.n].r,2);return ps->s;}
	return ki0(n);
}

char* di53laives ::
line	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	ps->apptab(ri(n));
	ps->app(ki(n));
	return ps->s;
}



char* di53laives ::
imtau	( dilaive *a, int K)
{
	chars* ps=getcharsbuf(); char t; int k;
	if(!a) return ps->s;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		t= kis[ (rkvs[a[k].n].k)*kilen ];
		ps->app(t);
	}
	return ps->s;
}


char* di53laives ::
ri	( dilaive *a, int K, char sep )
{
	chars *ps=getcharsbuf();	int k;
	if(!a) return ps->s;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ri (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* di53laives ::
ki	( dilaive *a, int K, char sep )
{
	chars *ps=getcharsbuf();   int k;
	if(!a) return ps->s;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* di53laives ::
ki0	( dilaive *a, int K, char sep ) // remove digits except leading ones and no sep
{
	chars *ps=getcharsbuf();	int k;
	if(!a) return ps->s;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki0(a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* di53laives ::
ki_d	( dilaive *a, int K, char sep ) // remove digits except leading ones and no sep
{
	chars *ps=getcharsbuf();	int k;
	if(!a) return ps->s;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki(a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	del4wis.d(ps->s);
	return ps->s;
}

char* di53laives ::
ki_h	( dilaive *a, int K, char sep ) // remove digits except leading ones and no sep
{
	chars *ps=getcharsbuf();	int k;
	if(!a) return ps->s;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki(a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	del4wis.h(ps->s);
	return ps->s;
}



char* di53laives ::
line( dilaive *a, int K, char sep ) //use full info with sep='-'
{
	chars *ps=getcharsbuf();
	if(!a) return ps->s;
	ps->app(ki(a,K,'-'));
	if(sep)ps->app(sep);
	ps->app(ri(a,K));
	return ps->s;
}

rikive di53laives ::
torikive (const char* ri, const char* ki)
{
	rikive rk; static chars s;
	//int n=kis.ndx(ki);
	int n=bfind(ki, kis, nKIS, kilen, wisc1su);
	if(n<=0)
		return rk;
	rk.k=n;
	s.set2(ki); s.trdigits();//s.dellastdigit();
	if( (strcmp(ri,s.s)==0)||(ri[0]=='*') ) {	rk.r[0]='*';rk.r[1]='*'; }
	else  {	rk.r[0]=ri[0]; rk.r[1]=ri[1]; }
	return rk;
}

int di53laives ::
kindx (cchar* ki)							// works for 1 ri/ki
{
	return bfind(ki, kis, nKIS, kilen, wisc1su);
}



int di53laives ::
ndx (const char* ri, const char* ki)
{
	rikive rk=torikive(ri, ki);
	int n=bfind(&rk, rkvs, nRKVS, sizeof(rikive), wisdirikive);
	return n;
}

int wisOFlaive4LU4ri(const void* l, const void* r)
{
	rikive *ll,*rr; ll=(rikive*)l; rr=(rikive*)r;
	int res;
	res=(uchar)(ll->r[0])-(uchar)(rr->r[0]);
	if(res) return res;
	res=(uchar)(ll->r[1])-(uchar)(rr->r[1]);
	if(res) return res;
	//down1: the only different from wisdirikive
	if(ll->k<65535) //65535=2^16-1 for max ushort,
		res=ll->k-rr->k;
	return res;
}

LU	di53laives::
LU4ri   (cchar* ri)					 	// works for 1 ri/ki
{
	rikive rk;
	int n012=is012(ri);
	if(n012==2){
	rk.r[0]=ri[0];rk.r[1]=ri[1];
	rk.k=65535; // for unknown ki
	}else{
		// so now ri should be pinyim ri, treated as ki,
		//modify later, since ri may have no sianndiau
		int n=bfind(ri, kis, nKIS, kilen, wisc1su);
		if(n<0) rk.k=65535; else rk.k=ushort(n);
		rk.r[0]='*';rk.r[1]='*';
	}
	LU lu;
	lu.l=wislower(&rk,rkvs, nRKVS, sizeof(rikive),wisOFlaive4LU4ri);
	lu.u=wisupper(&rk,rkvs, nRKVS, sizeof(rikive),wisOFlaive4LU4ri);
	return lu;
}



/*

int dilaives::
afterread()
{
	if(!( mmrkv.s()&&mmki.s() ) ) return 0;
	rdhdr* hd;
	hd  =(rdhdr *) mmrkv.h();
	rkvs=(rikive*) mmrkv.s(); nRKVS=hd->asz;
	hd  =(rdhdr *) mmki.h();
	kis =(char  *) mmki.s(); nKIS=hd->asz; kilen=hd->usz;
	return 1;
}

char* dilaives ::
ki	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	ps->set2( kis+ (rkvs[n.n].k)*kilen );
	return ps->s;
}


char* dilaives ::
ki0	( dilaive &n )
{
	char* t=ki(n);
	str_del4wis(t);
	return t;
}

char* dilaives ::
ri	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	if(rkvs[n.n].ishanri()){ps->app(rkvs[n.n].r,2);return ps->s;}
	return ki0(n);
}

char* dilaives ::
line	( dilaive &n )
{
	chars* ps=getcharsbuf();
	if(n.n<=0) return ps->s;
	ps->apptab(ri(n));
	ps->app(ki(n));
	return ps->s;
}



char* dilaives ::
imtau	( dilaive *a, int K)
{
	chars* ps=getcharsbuf(); char t; int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		t= kis[ (rkvs[a[k].n].k)*kilen ];
		ps->app(t);
	}
	return ps->s;
}


char* dilaives ::
ri	( dilaive *a, int K, char sep )
{
	chars* ps=getcharsbuf();	int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ri (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* dilaives ::
ki	( dilaive *a, int K, char sep )
{
	chars* ps=getcharsbuf();   int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* dilaives ::
ki0	( dilaive *a, int K, char sep ) // remove digits except leading ones and no sep
{
	chars* ps=getcharsbuf();	int k;
	for(k=0;k<K;k++) if(a[k].n<=0) return ps->s;
	for(k=0; k<K; k++) {
		ps->app( ki0(a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}


char* dilaives ::
line( dilaive *a, int K, char sep ) //use full info with sep='-'
{
	chars* ps=getcharsbuf();
	ps->app(ki(a,K,'-'));
	if(sep)ps->app(sep);
	ps->app(ri(a,K));
	return ps->s;
}

rikive dilaives ::
torikive (const char* ri, const char* ki)
{
	rikive rk; static chars s;
	//int n=kis.ndx(ki);
	int n=bfind(ki, kis, nKIS, kilen, wisc1su);
	if(n<=0)
		return rk;
	rk.k=n;
	s.set2(ki); s.trdigits();//s.dellastdigit();
	if( (strcmp(ri,s.s)==0)||(ri[0]=='*') ) {	rk.r[0]='*';rk.r[1]='*'; }
	else  {	rk.r[0]=ri[0]; rk.r[1]=ri[1]; }
	return rk;
}

int dilaives ::
kindx (cchar* ki)							// works for 1 ri/ki
{
	return bfind(ki, kis, nKIS, kilen, wisc1su);
}

int dilaives ::
ndx (const char* ri, const char* ki)
{
	rikive rk=torikive(ri, ki);
	int n=bfind(&rk, rkvs, nRKVS, sizeof(rikive), wisdirikive);
	return n;
}

*/

del4wis_ del4wis;
char del4wis_::chku=';';

int del4wis_::dp(char *kiin, char *zuanki)
{ //assume kiin is shorter
	if(!(zuanki&&zuanki[0])) return 0;
	if(!(kiin&&kiin[0])) return 0;
	char *s, *t; s=zuanki; t=kiin;
	while(*s && *t){
		if(*s=='-'){s++; if(*t=='-') t++; continue;}
		if(*t=='-'){if(!isdigit(*s)) return 0; t++; s++; continue;}
		if(isdigit(*t)){if(!t[1]){if(*t!=*s)return 0;else{t++;s++;}continue;} if(!isdigit(*s))return 0;else{s++;t++;}continue;}
		if(isdigit(*s)){if(isdigit(*t)){s++;t++;}else{s++;}continue;}
		if(*s=='a'&& (s[1]=='u'||s[1]=='o') ){if(*t=='a'&&(t[1]=='o'||t[1]=='u')) {s+=2;t+=2;continue;} }
		//if(*s=='o'&&s[1]=='u'){if(*t=='o'){s+=2;t++;if(*t=='u'){t++;}continue;} }
		if(*t=='j'){if(*s=='z'||*s=='j'){s++;t++;} continue;}
		if(*t=='b'&&t[1]=='h'){if(*s=='v') {t+=2; s++; continue;}if(*s=='b'&&s[1]=='h'){t+=2;s+=2;continue;}return 0;}
		if(*t=='g'&&t[1]=='h'){if(*s=='q') {t+=2; s++; continue;}if(*s=='g'&&s[1]=='h'){t+=2;s+=2;continue;}return 0;}
	//if((*s=='i'||*s=='e')&&s[1]=='n'&&s[2]=='g'){	if(!(*t=='i'||*t=='e')){return 0;}s++;t++; if(!*t)continue; if(*t!='n')return 0;s++;t++; if(!*t)continue;if(*t!='g')return 0;s++;t++; continue;}
		if((*s=='i'||*s=='e')&&s[1]=='n'&&s[2]=='g'){	if(*t=='y') {t++; if(*t&& *t!='i')return 0;} if(!(*t=='i'||*t=='e')){return 0;}s++;t++; if(!*t)continue; if(*t=='r'&&t[-1]=='i')t++; if(!*t)continue; if(*t!='n')return 0;s++;t++; if(!*t)continue;if(*t!='g')return 0;s++;t++; continue;}
		if(*s=='e'&&s[1]=='n'&&s[2]!='n'){if(*t=='e'){s++;t++; if(!*t)continue; if(*t!='n')return 0;s++;t++;continue;}
													 if(!(*t=='i'||*t=='y')){return 0;}else {t++; if(!*t)continue; if(*t=='a'||*t=='e'){s++;t++;}if(!*t)continue;if(*t=='n'){s++;t++;}} continue;}
		if(*s=='e'&&s[1]=='t'){if(*t=='e'){s++;t++; if(!*t)continue; if(*t!='t')return 0;s++;t++;continue;}
													 if(!(*t=='i'||*t=='y')){return 0;}else {t++; if(!*t)continue; if(*t=='a'||*t=='e'){s++;t++;}if(!*t)continue;if(*t=='t'){s++;t++;}} continue;}
	//if(*s=='i'&&(s[1]=='a'||s[1]=='e')&&s[2]=='n'&&(s[3]!='g'&&s[3]!='n')){if(*t=='i'){s++;t++;}else return 0;if(!*t)continue; if(*t=='a'||*t=='e'){s++;t++;}else return 0;if(!*t)continue; if(*t=='n'){s++;t++;}else return 0;if(!*t)continue; continue;}
		if(*s=='i'&&(s[1]=='a'||s[1]=='e')&&s[2]=='n'&&(s[3]!='g'&&s[3]!='n')){if(*t=='i'){s++;t++;}else return 0;if(!*t)continue; if(*t=='a'||*t=='e'){s++;t++;}else return 0;if(!*t)continue; if(*t=='n'){s++;t++;}else return 0;if(!*t)continue; continue;}
		//if(*s=='i'&&(s[1]=='a')&&s[2]=='n'&&(s[3]=='g'||s[3]=='n')){
			//if(*t=='i'){s++;t++;}else return 0;if(!*t)continue; if(*t=='a'){s++;t++;}else return 0;if(!*t)continue; if(*t=='n'){s++;t++;}else return 0;if(!*t)continue; if((*s=='g'&&*t=='g')||(*s=='n'&&*t=='n')){s++;t++;} continue;}
		//the case 'y'
	//if(*t=='y'&&t[1]=='i'){if(*s=='i'){s++;t+=2;}else return 0; continue;}
		if(*t=='y'&&t[1]=='i'){if(*s=='i'){t++;}else return 0; continue;}
		if(*t=='y'&&t[1]!= 0 ){if(*s=='i'){s++;t++ ;}else return 0; continue;}
		if(*t=='y'&&t[1]== 0 ){if(*s=='y'||*s=='i'){s++;t++;}else return 0; continue;}
		if(*s=='i'&&s[1]=='a'&&s[2]=='n'&&s[3]=='g'){if(*t=='i'){s++;t++;}else return 0;if(!*t)continue; if(*t=='a'         ){s++;t++;}else return 0;if(!*t)continue; if(*t=='n'){s++;t++;}else return 0;if(!*t)continue; if(*t=='g'){s++;t++;}else return 0; continue;}
		//now the case 'w'
		if(*t=='w'&&t[1]=='u'){if(*s=='u'){s++;t+=2;}else return 0; continue;}
		if(*t=='w'&&t[1]!= 0 ){if(*s=='u'){s++;t++ ;}else return 0; continue;}
		if(*t=='w'&&t[1]== 0 ){if(*s=='u'){s++;t++ ;}else return 0; continue;}
		//now finally the usual most common case
		//if(*t=='n'&&(t[1]=='g'||t[1]=='q') ){if(*s=='n'&&(s[1]=='g'||s[1]=='q')){s+=2;t+=2;}else return 0; continue;}
		//if(*t=='n'&&(t[1]=='g'||t[1]=='q') ){if(*s!='n')return 0; t++;s++; while(*s){if(isdigit(*s)||*s=='-') s++;else break;} if(!*s)continue; if(s[0]=='g'||s[0]=='q'){s++;t++;continue;}else return 0;}
		if(*s=='n'&&s[1]=='g'){if(*t=='n'){s++;t++;}else return 0;if(!*t)continue;if(*t=='g'||*t=='q'){s++;t++;continue;}else return 0;}
		if(*s==*t){s++;t++;continue;}
		else return 0;
	}
	if(!*s && *t) return 0;
	if(*t && isdigit(*t)){if(*t==*s){s++;t++;}else return 0;}
	if(*s=='-'){s++;}
	return s-zuanki;
}

int del4wis_::d(char *src)
{
	if(!(src&&src[0])) return 0; int cnt=0;
	char*s=src;
	char*t=s; if(!t) return 0;  int res;
	while(*s) {
		res=is012(s);
		if(res==2) break;
		if( isdigit(*s) || (*s =='-') ) { s++;t++;}  else break;//skipping the leading digits
	}
	char* ttt=s;
	while(*s) {
		res=is012(s);
		if(res==2) { *t++=*s++;*t++=*s++; continue; }
		if( isdigit(*s) || (*s =='-') ) {	s++; }else
		//if( isdigit(*s) ) {	s++; }else
			*t++=*s++;
	}
	*t=0;
	s=ttt; t=ttt;
	while(*s) {
		res=is012(s);
		if(res==2) { *t++=*s++;*t++=*s++; continue; }
		if( *s=='j' ){*s='z'; continue;}
		if( *s=='a' && s[1]=='o') {*t++=*s++; *t++='u'; s++;} else
		if( *s=='i' && s[1]=='r' && s[2]=='n' && s[3]=='g') {*t++=*s++; s++; *t++=*s++; *t++=*s++; } else
		if( *s=='i' && s[1]=='r' && s[2]=='n' ) {*t++=*s++; s++; *t++=*s++; } else
		if( *s=='n' && (s[1]=='q'|| s[1]=='g') ) {*t++=*s++; *t++='g';  s++; } else
		if( *s=='e' && s[1]=='n' && s[2]=='g'){*t++='i';s++;*t++=*s++;*t++=*s++;}else
		if( (*s=='i'||*s=='y') && ( s[1]=='a'||s[1]=='e') && (s[2]=='n'||s[2]=='t') && (s[3]!='n'&&s[3]!='g') ){*t++='e'; s+=2; *t++=*s++;}else
	//if( (*s=='i'||*s=='y') && ( s[1]=='a'||s[1]=='e') && (s[2]=='n'||s[2]=='t') ){*t++='e'; s+=2; *t++=*s++;}else
		if( (*s=='i'&&s[1]=='e'&&s[2]==0) ){*t++='e'; *t++='n'; s+=2;}else  //for unfinished ien, only for daiqi
		if( *s=='b' && s[1]=='h') { *t++='v'; s+=2; } else
		if( *s=='g' && s[1]=='h') { *t++='q'; s+=2; } else
		if( *s=='y' ){
									switch(s[1]){
									case 'i':
														{s++; break;}
														//{s++; *t++=*s++;break;}
									default:
														{*t++='i';s++;break;}
									}  }else
		if( *s=='w' ){
									switch(s[1]){
									case 'u':
														{s++; break;}
														//{s++; *t++=*s++;break;}
									default:
														{*t++='u';s++;break;}
									}  }else
			*t++=*s++;
	}
	*t=0;
	return cnt;
}


int del4wis_::hp(char *kiin, char *zuanki)
{ //assume kiin is shorter
	if(!(zuanki&&zuanki[0])) return 0;
	if(!(kiin&&kiin[0])) return 0;
	char *s, *t; s=zuanki; t=kiin; //int cnt=0;
	while(*s && *t){
		if(*s=='-'){s++; if(*t=='-') t++; continue;}
		if(*t=='-'){if(!isdigit(*s)) return 0; t++; s++; continue;}
		if(isdigit(*t)){if(!t[1]){if(*t!=*s)return 0;else{t++;s++;}continue;} if(!isdigit(*s))return 0;else{s++;t++;}continue;}
		if(isdigit(*s)){if(isdigit(*t)){s++;t++;}else{s++;}continue;}
		if(*s=='a'&&s[1]=='o'){if(*t=='a'&&(t[1]=='o'||t[1]=='u')) {s+=2;t+=2;continue;} }
		if(*s=='o'&&s[1]=='u'){if(*t=='o'){s+=2;t++;if(*t=='u'){t++;}continue;} }
		if(*s=='j'&&*t=='j'){s++;t++;if(!*t)continue;if(*t=='h'){if(*s!='h')return 0; s++;t++;}else if(*s=='h'){s++;}continue;}
		if(*s=='j'&&*t=='z'){s++;t++;if(!*t)continue;if(*t=='h'){if(*s!='h')return 0; s++;t++;}else if(*s=='h'){s++;}continue;}
		if(*s=='z'&&*t=='j'){s++;t++;if(!*t)continue;if(*t=='h'){if(*s!='h')return 0; s++;t++;}else if(*s=='h'){s++;}continue;}
		if(*s=='z'&&*t=='z'){s++;t++;if(!*t)continue;if(*t=='h'){if(*s!='h')return 0; s++;t++;}else if(*s=='h'){s++;}continue;}
		if(*s=='s'&&*t=='s'){s++;t++;if(!*t)continue;if(*t=='h'){if(*s!='h')return 0; s++;t++;}else if(*s=='h'){s++;}continue;}
		if(*s=='c'&&*t=='c'){s++;t++;if(!*t)continue;if(*t=='h'){if(*s!='h')return 0; s++;t++;}else if(*s=='h'){s++;}continue;}
		if(*s=='r'&&*t=='r'){s++;t++;if(!*t)continue;if(*t=='h'){if(*s!='h')t++;}else if(*s=='h'){s++;}continue;}
		if(*t==chku){if(*s==chku){t++;s++;}else if(!(*s=='i'&&s[1]=='h'))return 0;else{t++;s+=2;}continue;}
		//the case of s being iang should done after t being y???
		if(*s=='i'&&s[1]=='a'&&s[2]=='n'&&s[3]!='g'){if(*t=='i'){s++;t++;}else return 0;if(!*t)continue; if(*t=='a'||*t=='e'){s++;t++;}else return 0;if(!*t)continue; if(*t=='n'){s++;t++;}else return 0;if(!*t)continue; continue;}
		//the case 'y'
		if(*s=='y'&&s[1]=='o'){if(*t=='y'||*t=='i'){s++;t++;}else return 0;  if(!*t)continue; if(*t=='o'){s++; t++;}else return 0; continue; }
		if(*t=='y'&&t[1]=='i'){if(*s=='i'){s++;t+=2;}else return 0; continue;}
		if(*t=='y'&&t[1]=='u'){if(*s=='y'&&s[1]=='u'){s+=2;t+=2;}else return 0; continue;}
		if(*t=='y'&&t[1]!= 0 ){if(*s=='i'){s++;t++ ;}else return 0; continue;}
		if(*t=='y'&&t[1]== 0 ){if(*s=='y'||*s=='i'){s++;t++;}else return 0; continue;}
		if(*s=='i'&&s[1]=='o'&&s[2]=='u'){if(*t=='i'){s++;t++;}else return 0;if(!*t)continue; if(*t=='u'){s+=2;t++;}else {if(*t=='o'){s++;t++;}else return 0; if(!*t)continue; if(*t=='u'){s++;t++;}else return 0;} continue;}
		if(*s=='i'&&s[1]=='a'&&s[2]=='n'&&s[3]=='g'){if(*t=='i'){s++;t++;}else return 0;if(!*t)continue; if(*t=='a'         ){s++;t++;}else return 0;if(!*t)continue; if(*t=='n'){s++;t++;}else return 0;if(!*t)continue; if(*t=='g'){s++;t++;}else return 0; continue;}
		//now the case 'w'
		if(*s=='u'&&s[1]=='e'&&s[2]=='i'){if(*t=='u'||*t=='w'){s++;t++;}else return 0;if(!*t)continue; if(*t=='u'){t++;if(!*t)continue;} if(*t=='i'){s+=2;t++;}else {if(*t=='e'){s++;t++;}else return 0; if(!*t)continue; if(*t=='i'){s++;t++;}else return 0;} continue;}
		if(*t=='w'&&t[1]=='u'){if(*s=='u'){s++;t+=2;}else return 0; continue;}
		if(*t=='w'&&t[1]!= 0 ){if(*s=='u'){s++;t++ ;}else return 0; continue;}
		if(*t=='w'&&t[1]== 0 ){if(*s=='u'){s++;t++ ;}else return 0; continue;}
		//now finally the usual most common case
		if(*s==*t){s++;t++;continue;}
		else return 0;
	}
	if(!*s && *t) return 0;
	if(*t && isdigit(*t)){if(*t==*s){s++;t++;}else return 0;}
	if(*s=='-'){s++;}
	return s-zuanki;
}


int del4wis_::h(char *src)
{
	if(!(src&&src[0])) return 0; int cnt=0;
	char*s=src;
	char*t=s; if(!t) return 0;  int res;
	while(*s) {
		res=is012(s);
		if(res==2) break;
		if( isdigit(*s) || (*s =='-') ) { s++;t++;}  else break;//skipping the leading digits
	}
	char* ttt=s;
	while(*s) {
		res=is012(s);
		if(res==2) { *t++=*s++;*t++=*s++; continue; }
		if( isdigit(*s) || (*s =='-') ) {	s++; }else
		//if( isdigit(*s) ) {	s++; }else
			*t++=*s++;
	}
	*t=0;
	s=ttt; t=ttt;
	while(*s) {
		res=is012(s);
		if(res==2) { *t++=*s++;*t++=*s++; continue; }
		if( *s=='j' ){*s='z'; continue;}//simply change j to z, chech zh again
		//if( *s=='u' && s[1]=='o') {s++; *t++=*s++;} else
		if( *s=='a' && s[1]=='o') {*t++=*s++; *t++='u'; s++;} else
		if( *s=='o' && s[1]=='u') {*t++=*s++; s++;} else
		if((*s=='z'||*s=='c'||*s=='s'||*s=='r'||*s=='j') ){ *t++=*s++; if(*s=='h') {s++;} if(*s=='i'&&s[1]=='h'){*t++=chku;s+=2;} }else
		//if( *s=='i' && s[1]=='a' && s[2]=='n' && s[3]!='g'){*t++=*s++; *t++='e';s++; *t++=*s++;}else
		if( *s=='i' && s[1]=='e' && s[2]=='n'){*t++=*s++; *t++='a';s++; *t++=*s++;}else
		if( *s=='i' && s[1]=='o' && s[2]=='u'){*t++=*s++; s++; *t++=*s++;}else
		if( *s=='u' && s[1]=='e' && s[2]=='i'){*t++=*s++; s++; *t++=*s++;}else
		if( *s=='y' ){
									switch(s[1]){
									case 'i':
														{s++; break;}
														//{s++; *t++=*s++;break;}
									//case 'u'://case 'o':
														//{*t++='i';s++;*t++=*s++;break;}
														//{*t++=*s++;*t++=*s++;break;}
									case 'o':
														{*t++='i';s++;*t++=*s++;break;}
									default:
														{*t++='i';s++;break;}
									}  }else
		if( *s=='w' ){
									switch(s[1]){
									case 'u':
														{s++; break;}
														//{s++; *t++=*s++;break;}
									default:
														{*t++='u';s++;break;}
									}  }else
			*t++=*s++;
	}
	*t=0;
	return cnt;
}

int del4wis_::gp(char*partki, char*zuanki)
{
	return pfit1py(partki,zuanki,0);
}


int di5wis_:: nrK(const void*l, const void*r, dilaivesNxtr* lvx)
{
	ll=(char*)l;
	rr=lvx->lv->ki0( (dilaive*)r, lvx->K);
	return strcmp(ll.s,rr.s);
}

int di5wis_:: nrK_d(const void*l, const void*r, dilaivesNxtr* lvx)
{
	ll=(char*)l;
	rr=lvx->lv->ki_d( (dilaive*)r, lvx->K);
	return strcmp(ll.s,rr.s);
}

int di5wis_:: nrK_h(const void*l, const void*r, dilaivesNxtr* lvx)
{
	ll=(char*)l;
	rr=lvx->lv->ki_h( (dilaive*)r, lvx->K);
	return strcmp(ll.s,rr.s);
}

int di5wis_:: nit(const void*l, const void*r, di53rd_* rd)
{
	ll=(char*)l;
	rr=rd->it( *((ushort*)r) );
	//rr=rd->lvx.lv->it( (dilaive*)r, rd->lvx.K);
	return strcmp(ll.s,rr.s);
}

int wstrlenatmost4IME(char *s, int& useall, int ATMOST)
{
	if(ATMOST<0) ATMOST=80; // it seems that winxp can not take more than 80 byte at a time
	useall=1;
	if(!(s&&s[0])){return 0;}
	char *t=s; int len, LEN=0; 
	while(*t){
		len=CharNext(t)-t;
		if(len+LEN<ATMOST){LEN+=len; t+=len;}
		else{break;}
	}
	if(*t) useall=0;
	return LEN;
}



int pfit1vun  (const char* kiin, const char* rr)
{
	char* lll=(char*)kiin;
	while(*lll) { if(*lll != *rr) return 0; lll++; rr++;}
	return lll-kiin;
}

int pfit1py(const char* kiin, const char* rr, int mustfit_diau)
	//pfit1:partial fit, assuem ll is kiin, and shorter
	// r: #bytes in ll that is partially used by rr
{ // ignore digit and -
	char* l=(char*)kiin; char* r=(char*)rr;
	while( (*l) && (*r) ) {
		if(*r == '-') { r++; if(*l == '-')  { l++;} continue; }
		if(*l=='-') { if(!isdigit(*r)) return 0;  l++; r++;  continue; }
		if(isdigit(*l)) {
			if(l[1]==0)  // so that last diauhor will work
				{ if(*l != *r) return 0;  l++; r++;  continue;} // next loop will exit
			if(mustfit_diau) { if(*l != *r)    return 0;l++;r++;if(*l=='-')l++;continue; }
			else             { if(!isdigit(*r))return 0;l++;r++;if(*l=='-')l++;continue; }
		}
		//if(isdigit(*r)) { r++; if(isdigit(*l)) l++;if(*l=='-'){l++;}continue; }// ll is kiin
		if(isdigit(*r)) {
			if(r[1]==0)
			{ r++; continue; }// next loop will exit
			if(mustfit_diau) { if(*l != *r ) return 0; l++; r++; if(*l=='-')l++;continue;}
			else             { r++; if(isdigit(*l)) l++;if(*l=='-')l++;continue; }// ll is kiin
		}
		//if(isdigit(*r)) { r++; if(isdigit(*l)) l++;continue; }// ll is kiin
		if( (*l) == (*r) ) { l++; r++; continue; } else break;
		//return (*l)-(*r);
	}
	if(*l) return 0; // some ki is not equal
	return (r-rr);
}


int di53rd_::
dirdid_kind()
{
	char* t=hd_->idfier();
	if(t[0]=='n'&&t[1]=='i'&&t[2]=='t') return DIRDID_NIT;
	if(t[0]=='h'&&t[1]=='h'&&t[2]=='1') return DIRDID_HH1;
	if(t[0]=='h'&&t[1]=='h'&&t[2]=='2') return DIRDID_HH2;
	if(t[0]=='z'&&t[1]=='i'&&t[2]=='k') return DIRDID_ZIK;
	return DIRDID_NONE;
}

/*
int di53rd_::
isnit()
{
	char* t=hd_->idfier();
	return(t[0]=='n'&&t[1]=='i'&&t[2]=='t')?1:0;
}

int di53rd_::
ishh2()
{
	char* t=hd_->idfier();
	return(t[0]=='h'&&t[1]=='h'&&t[2]=='2')?1:0;
}
*/




char* di53rd_::
ki (USHORT n)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n;
		return (lvx.lv)->ki(rkn, K);
	case DIRD_NIT:
		return base4nit->it(((ushort*)dt_)[n]);
	case DIRD_DZB:
	case DIRD_DZB3:
		return (keyi())?d0(n):d1(n);
	}
	return s4null;
}

char* di53rd_::
im (USHORT n)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n;
		return (lvx.lv)->ki(rkn, K);
	case DIRD_NIT:
		return base4nit->ki(((ushort*)dt_)[n]);
	case DIRD_DZB:
		return (keyi())?d0(n):d1(n);
	case DIRD_DZB3:
		return d2(n);
	}
	return s4null;
}

char* di53rd_::
ri (USHORT n)
{
	dilaive *rkn; rikive rk;// static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n;
		return (lvx.lv)->ri(rkn, K);
	case DIRD_NIT:
		return base4nit->ri(((ushort*)dt_)[n]);
		//rkn=( (dilaive*)(base4nit->dt_) )+ K*((ushort*)dt_)[n];
		//return (lvx.lv)->ri(rkn, K);
	case DIRD_DZB:
	case DIRD_DZB3:
		return (keyi())?d1(n):d1(n);
	}
	return s4null;
}

char* di53rd_::
it (ushort n) // only nrK will return imtau, nit should use ki
{
	if(luibet()!=DIRD_NRK) return s4null;
	dilaive *rkn; rikive rk;
	rkn=((dilaive*)dt_)+K*n;
	return (lvx.lv)->it(rkn, K);
}

char* 	 di53rd_::
ki (USHORT n, int nthpart) // depends on luibet
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+nthpart;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}

char*    di53rd_::
ri (USHORT n, int nthpart) // depends on luibet
{
	dilaive *rkn; rikive rk;// static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+nthpart;
		return (lvx.lv)->ri(rkn, 1);
	}
	return s4null;
}

char*		 di53rd_::
im (ushort n, int nthpart)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+nthpart;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}


char*    di53rd_::
eki (USHORT n) // depends on luibet
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+K-1;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}

char*    di53rd_::
eri (USHORT n) // depends on luibet
{
	dilaive *rkn; rikive rk;// static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+K-1;
		return (lvx.lv)->ri(rkn, 1);
	}
	return s4null;
}

char*		 di53rd_::
eim (ushort n)
{
	dilaive *rkn; rikive rk; //char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((dilaive*)dt_)+K*n+K-1;
		return (lvx.lv)->ki(rkn, 1);
	}
	return s4null;
}



int di53rd_::
bfind(char*s)
{
	int l=lower(s); int u=upper(s);
	if(l==u) return -1;
	return l;
}

int di53rd_::
lu  (char*s, int*l, int*u)
{
	*l=lower(s); *u=upper(s);
	return 0; // 0 is nonsense
}

int di53rd_::
lmu  (char*s, int*l, int*m, int*u)
{
	char c=char(255); static chars ss; ss=s;
	*l=lower(s);
	*m=upper(s); ss+=c;
	*u=upper(ss.s);
	return 0; // 0 is nonsense
}

char* di53rd_::smd(char* s)
{ 
	static chars ss; //
	switch(hd_->key){
	case 'r':case 'v': return s;
	case 'i': ss=s; str_del4wis(ss.s); return ss.s;
	case 'd': ss=s; del4wis.d(ss.s); return ss.s;
	case 'h': ss=s; del4wis.h(ss.s); return ss.s;
	default : return s;
	}
	/*
	if(hd_->key!='i') return s;
	ss=s;
	str_del4wis(ss.s);
	return ss.s;
	*/
}

int di53rd_::
lower(char*s)
{
	uint sz=size();
	switch (luibet()) {
	case DIRD_NRK:
		return wislower1(smd(s), dt_, sz, lvx.usz, wisx, &lvx);
	case DIRD_NIT:
		return wislower1(smd(s), dt_, sz, sizeof(ushort), wisx, base4nit);
	case DIRD_DZB:
	case DIRD_DZB3:
		return wislower (smd(s),dst_, sz,sizeof(char**),wis);
	}
	return -1;
	//return (wisx)?
	//wislower1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
	//wislower (smd(s),dst_,size(),sizeof(char**),wis);
}

int di53rd_::
upper(char*s)
{
	uint sz=size();
	switch (luibet()) {
	case DIRD_NRK:
		return wisupper1(smd(s), dt_, sz, lvx.usz, wisx, &lvx);
	case DIRD_NIT:
		return wisupper1(smd(s), dt_, sz, sizeof(ushort), wisx, base4nit);
	case DIRD_DZB:
	case DIRD_DZB3:
		return wisupper (smd(s),dst_, sz,sizeof(char**),wis);
	}
	return -1;
	//return (wisx)?
	//wisupper1(smd(s),dst_,size(),sizeof(char**),wisx,lvK):
	//wisupper (smd(s),dst_,size(),sizeof(char**),wis);
}


//	int 	read(tyio& r ){int rs;del();rs=mm.read(r);if(rs)afterread();return rs;}
//	int 	read(char* fn){if(!io.open(fn))return 0;int rs=read(io);io.close();return rs;}


int di53rd_::
afterread()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(void*)(mm.s)();
	switch (luibet()) {
	case DIRD_NRK: //return 1;
		if(hd_->key=='d'){
			wisx=(int(*) (const void *, const void *, const void*))di5wis.nrK_d;
			pfit=(int(*) (char *, char*))del4wis.dp;
		}else
		if(hd_->key=='h'){
			wisx=(int(*) (const void *, const void *, const void*))di5wis.nrK_h;
			pfit=(int(*) (char *, char*))del4wis.hp;
		}else{
			wisx=(int(*) (const void *, const void *, const void*))di5wis.nrK;
			pfit=(int(*) (char *, char*))del4wis.gp;
		}
		K=(hd_->usz)/sizeof(ushort); lvx.K= K;
		return 1;
	case DIRD_NIT: // need 2 set base
		wisx=(int(*) (const void *, const void *, const void*))di5wis.nit;
		pfit=(int(*) (char *, char*))del4wis.gp;
		K=1;
		dirdid_knd=dirdid_kind();
		return 1;
	case DIRD_DZB:
		//setinnr(); return 1;
	case DIRD_DZB3:
		setinnr(); 
		if(hd_->key=='d'){
			wisx=(int(*) (const void *, const void *, const void*))di5wis.nrK_d;
			pfit=(int(*) (char *, char*))del4wis.dp;
		}else
		if(hd_->key=='h'){
			wisx=(int(*) (const void *, const void *, const void*))di5wis.nrK_h;
			pfit=(int(*) (char *, char*))del4wis.hp;
		}else{
			wisx=(int(*) (const void *, const void *, const void*))di5wis.nrK;
			pfit=(int(*) (char *, char*))del4wis.gp;
		}
		dirdid_knd=dirdid_kind();
		return 1;
	}
	return 0;
}

typedef char* p2char;
static int setinnrjunk=0;

void di53rd_::
setinnr()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	//if(hd_->frq) jumpbyte=1+sizeof(float); else jumpbyte=0;
	if(hd_->frq) jumpbyte=1+(hd_->frq)*sizeof(int); else jumpbyte=0;
	if(hd_->key=='r')
		wis = (jumpbyte)?(int(*) (const void *, const void *))di5wis.bykif  : (int(*) (const void *, const void *))di5wis.byki;
//		wis = (jumpbyte)?di5wis.bykif  : di5wis.byki;
	else
		wis = (jumpbyte)?(int(*) (const void *, const void *))di5wis.byki0f : (int(*) (const void *, const void *))di5wis.byki0;
//		wis = (jumpbyte)?di5wis.byki0f : di5wis.byki0;
	//int hasfreq=jumpbyte?1:0;
	hsd2= cols_is()>=2;
	hsd3= cols_is()>=3;
	hsd4= cols_is()>=4;
	hsd5= cols_is()>=5;
	int i, items=hd_->asz;
	dst_=new p2char[items+1];
	//dst_=new (char*)[items+1];
	dst_[items]=0;
	//int ll;
	setinnrjunk=0;
	char* p=(char*)dt_; uchar llc;
	if(!jumpbyte) {
		llc= *p++;
		for(i=0; i<items; i++) {
			dst_[i]=p;
			if(setinnrjunk%20==19)
				 setinnrjunk++;
			else
				setinnrjunk++;
			p += llc;				    llc = (*p);		*p++ =0;
			if(hsd2) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd3) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd4) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd5) {p += llc; llc = (*p);		*p++ =0;}
		}
	}else{
		for(i=0; i<items; i++) {
			llc=(uchar)(*p);
			*p=0;  dst_[i]=p;
			p+=llc;
			if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
			//*p=0; 		p+=jumpbyte;
		}
		*p=0;
	}
}
/*
void di53rd_::
setinnr()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	//if(hd_->frq) jumpbyte=1+sizeof(float); else jumpbyte=0;
	if(hd_->frq) jumpbyte=1+(hd_->frq)*sizeof(int); else jumpbyte=0;
	if(hd_->key=='r')
		wis = (jumpbyte)?di5wis.bykif  : di5wis.byki;
	else
		wis = (jumpbyte)?di5wis.byki0f : di5wis.byki0;
	//int hasfreq=jumpbyte?1:0;
	hsd2= cols_is()>=2;
	hsd3= cols_is()>=3;
	hsd4= cols_is()>=4;
	hsd5= cols_is()>=5;
	int i, items=hd_->asz;
	dst_=new char*[items+1];
	dst_[items]=0;
	//int ll;
	char* p=(char*)dt_; uchar llc;
	if(!jumpbyte) {
		llc= *p++;
		for(i=0; i<items; i++) {
			dst_[i]=p;
			p += llc;				    llc = (*p);		*p++ =0;
			if(hsd2) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd3) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd4) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd5) {p += llc; llc = (*p);		*p++ =0;}
		}
	}else{
		llc= *p; // do not skip size-uchar and freq
		for(i=0; i<items; i++) {
			*p=0; 		p+=jumpbyte;
			llc=(uchar)(*p); *p++=0;  dst_[i]=p;	p+=llc;
			if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		}
		//for(i=0; i<items; i++) {
			//dst_[i]=p;		p+=(jumpbyte-1);
			//llc = (uchar)(*p);         *p++=0; p+=llc;
			//if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			//if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			//if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			//if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		//}
	}
	jumpbyte=0;
}
*/

int		ustmio::
read (tyio& io)
{
	h.read(io);
	if(!h.isOK()) return 0;
	ph=(hust*)h();
	v.read(io);
	if(!v.isOK()) return 0;
	pv=(char*)v();
	return (h.sz+v.sz);
}

int ustmio::
new2(long asize)
{
	int bsize=asize;
	h.new2(sizeof(hust));
	ph=(hust*)h();
	v.new2(bsize);
	pv=(char*)v();
	if(!( (ph)&&(pv) )) return 0;
	ph->setidfv(); ph->setabu(asize,bsize,0);
	int b;char*t=pv;for(b=0;b<bsize;b++)*t++=0;
	return 1;
}

int ustmio::
status(USHORT n)
{if(!isOK(n))return 0;return (pv[n]);}

void ustmio::
suaned(USHORT n, USHORT n0, USHORT n9) //[n0,n9):range
{
  if(!isOK(n))return; USHORT nn; 
	for(nn=n0;nn<n9;nn++) if(pv[nn]>0) pv[nn]=0;
	//if(n>=0)
	pv[n]++; 
	if(pv[n]>1) pv[n]=1;
}

void ustmio::
unsuaned(USHORT n0, USHORT n9) //[n0,n9):range
{
	USHORT nn;
	for(nn=n0;nn<n9;nn++) if(pv[nn]>=0) pv[nn]--;
}

//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
// class mf-etc

int  ftime3:: get(char*   fn)
{
	HANDLE h=CreateFile(
		fn,GENERIC_READ,0,NULL,OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,NULL);
	if(h==INVALID_HANDLE_VALUE) return 0;
	good=GetFileTime(h,&ct,&at,&wt);
	CloseHandle(h);
	return good;
}

int  ftime3:: set(char*   fn)
{
	HANDLE h=CreateFile(
		fn,GENERIC_WRITE,0,NULL,OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,NULL);
	if(h==INVALID_HANDLE_VALUE) return 0;
	good=SetFileTime(h,&ct,&at,&wt);
	CloseHandle(h);
	return good;
}

//////////////////////////////////////
// class mfreader : map file reader

void* mfreader::mfopen(tyio& io, char* fn)
{
	mffn.getsetfname(fn);
	if(io.isERR()){p=0;}else{
		io.rewind();
		fsz=io.filesize();
		mfh=CreateFileMapping(HANDLE(io()),NULL,PAGE_READONLY,0,0,mffn.s);
		if(!mfh){p=0;}else{
			p=MapViewOfFile(mfh,FILE_MAP_READ,0,0,0);
		}
	}
	return p;
}

void* mfreader::open(char* fn, char* pn)
{
	io.open(fn,pn);
	return mfopen(io, fn);
}


int		mfreader::close()
{
	if(p  )UnmapViewOfFile(p);p=0;
	if(mfh)CloseHandle(mfh);mfh=0;
	io.close();
	return 0;
}

// class mfreader : map file reader
//////////////////////////////////////

//////////////////////////////////////
// class mfbuffer_

int	 mfbuffer::		open(char* fn, char* pn)
{
	int LEN=0;
	mfr.close();
	if(mfr.io.open(fn,pn)){
		LEN+=mfh.read(mfr.io);
		LEN+=dzb.read(mfr.io);
		mfr.mfopen(mfr.io,fn);
		return LEN;
	}
	return LEN;
}
// class mfbuffer_
//////////////////////////////////////

//////////////////////////////////////
// class mfheader


int mfheader::init()
{
	fsize=0;strctsz=sizeof(*this); idflen=32; idf[0]=0; // 1,2,3,4
	opt[0]=1; opt[1]=opt[2]=opt[3]=0;     // 5,6,7,8
	nSUBF=0;  seqlen=0; // 9,10
	mflen=256; extlen=32;	mfname[0]=extname[0]=0;// 11,12,13,14
	return 0;
}

int mfheader::isOK()
{
	if( (idflen!=32)||(mflen!=256)||(extlen!=32) ) return 0;
	if(strctsz!=sizeof(*this))return 0;
	int len;
	len=strlen(idf); 			if(len>=32 ) return 0;
	len=strlen(extname); 	if(len>=32 ) return 0;
	len=strlen(mfname); 	if(len>=256) return 0;
	return 1;
}
// class mfheader
//////////////////////////////////////

// class mf-etc
//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////
//////////////////////////////////////













#ifdef OLDOLDOLDOLDOLD

//////////////////////////////////////
// class riki, nriki, laivetos

char* laivetos ::
tos_ki	( rikin n )
{
	chars* ps=getcharsbuf();
	ps->set2( kis+ (ns[n.n].k)*WKI );
	return ps->s;
}


char* laivetos ::
tos_ki0	( rikin n )
{
	char* t=tos_ki(n);
	str_del4wis(t);
	return t;
}

char* laivetos ::
tos_ri	( rikin n )
{
	chars* ps=getcharsbuf();
	if(ns[n.n].ishanri()){ps->app((char*)(ns+n.n),2);return ps->s;}
	return tos_ki0(n);
}

char* laivetos ::
tos_line	( rikin n )
{
	chars* ps=getcharsbuf();
	ps->apptab(tos_ri(n));
	ps->app(tos_ki(n));
	return ps->s;
}


char* laivetos ::
tos_imtau	( rikin *a, int K)
{
	chars* ps=getcharsbuf(); char t;
	for(int k=0; k<K; k++) {
		t= kis[ (ns[a[k].n].k)*WKI ];
		ps->app(t);
	}
	return ps->s;
}


char* laivetos ::
tos_ri	( rikin *a, int K, char sep )
{
	chars* ps=getcharsbuf();
	int k;
	for(k=0; k<K; k++) {
		ps->app( tos_ri (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* laivetos ::
tos_ki	( rikin *a, int K, char sep )
{
	chars* ps=getcharsbuf();
	if(!a[0].n) return ps->s;
	int k;
	for(k=0; k<K; k++) {
		ps->app( tos_ki (a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}

char* laivetos ::
tos_ki0	( rikin *a, int K, char sep ) // remove digits except leading ones and no sep
{
	chars* ps=getcharsbuf();
	int k;
	for(k=0; k<K; k++) {
		ps->app( tos_ki0(a[k].n) );
		if( sep && (k<K-1) ) ps->app(sep);
	}
	return ps->s;
}


char* laivetos ::
tos_line( rikin *a, int K, char sep ) //use full info with sep='-'
{
	chars* ps=getcharsbuf();
	ps->app(tos_ki(a,K,'-'));
	if(sep)ps->app(sep);
	ps->app(tos_ri(a,K));
	return ps->s;
}

//static int __cdecl wisc1su(const void* l, const void* r)
//{ return strcmp( (cchar*)l, (cchar*)r ); }

riki laivetos ::
toriki (const char* ri, const char* ki)
{
	riki rk; static chars s; s.set2(ki); //s.dellastdigit();
	//int n=kis.ndx(ki);
	int n=bfind(ki, kis, kislen, WKI, wisc1su);
	if(n<=0)
		return rk;
	rk.k=n;  s.dellastbyte();
	if( (strcmp(ri,s.s)==0)||(ri[0]=='*') ) {	rk.r[0]='*';rk.r[1]=0; }
	else  {	rk.r[0]=ri[0]; rk.r[1]=ri[1]; }
	return rk;
}


int di53rd_::
lmu  (char*s, int*l, int*m, int*u)
{
	char c=char('0x\255'); static chars ss; ss=s;
	*l=lower(s); *m=upper(s); ss+=c; *u=upper(ss.s);
	return 0; // 0 is nonsense
}

char* di53rd_::
ki (USHORT n)
{
	rikin *rkn; riki rk; char* ki1;
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((rikin*)dt_)+n;
		return (lvK->lv)->tos_ki(rkn, lvK->K);
	case DIRD_NIT:
		rkn=( (rikin*)(base4nit->dt_) )+ ((ushort*)dt_)[n];
		return (lvK->lv)->tos_it(rkn, lvK->K);
	case DIRD_DZB:
		return (keyi())?d1(n):d2(n);
	case DIRD_LAIVE:
		rk=((riki*)dt_)[n];
		return (lvK->lv)->tos_ki(rk.k);
	case DIRD_C1SU:
		//ki1=( (char*)dt_+(hd_->usz)*n );//w/ fixed length char array
		ki1=( dst_[n] ); // w/ c1dzb
		return ki1;
	}
	return s4null;
}

char* di53rd_::
ri (USHORT n)
{
	rikin *rkn; riki rk; static char s[3];
	switch (luibet()) {
	case DIRD_NRK:
		rkn=((rikin*)dt_)+n;
		return (lvK->lv)->tos_ri(rkn, lvK->K);
	case DIRD_NIT:
		rkn=( (rikin*)(base4nit->dt_) )+ ((ushort*)dt_)[n];
		return (lvK->lv)->tos_ri(rkn, lvK->K);
	case DIRD_DZB:
		return (keyi())?d2(n):d2(n);
	case DIRD_LAIVE:
		rk=((riki*)dt_)[n];	s[0]=rk.r[0]; s[1]=rk.r[1]; s[2]=0;
		return s;
	case DIRD_C1SU:
		return s4null;
	}
	return s4null;
}

int di53rd_::
afterread()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(void*)(mm.s)();
	switch (luibet()) {
	case DIRD_NRK: return 1;
	case DIRD_NIT: return 1; // need 2 set base
	case DIRD_DZB:
		setinnr(); return 1;
	case DIRD_LAIVE: return 1;
	case DIRD_C1SU: // array of fixed size(usz)
		//usz=hd_->usz;
		setinnr();
		return 1;
	}
	return 0;
}

void di53rd_::
setinnr()
{
  hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	if(hd_->frq) jumpbyte=1+sizeof(float); else jumpbyte=0;
	if(hd_->key=='r') wis = (jumpbyte)?di5wis.r2if : di5wis.r2i; 
	else wis = (jumpbyte)?di5wis.i2rf : di5wis.i2r;
	int hasfreq=jumpbyte?1:0;
	hsd2= (cols_is()-hasfreq)>=2;
	hsd3= (cols_is()-hasfreq)>=3;
	hsd4= (cols_is()-hasfreq)>=4;
	hsd5= (cols_is()-hasfreq)>=5;
	int i, items=hd_->asz;
  dst_=new (char*)[items+1];
	dst_[items]=0;
	//int ll;
  char* p=(char*)dt_; uchar llc;
  if(!jumpbyte) {
		llc= *p++;
	  for(i=0; i<items; i++) {
			dst_[i]=p;
			p += llc;				    llc = (*p);		*p++ =0;
			if(hsd2) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd3) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd4) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd5) {p += llc; llc = (*p);		*p++ =0;}
		}
	}else{
		for(i=0; i<items; i++) {
			dst_[i]=p; p+=(jumpbyte-1); 
			llc = (uchar)(*p);         *p++=0; p+=llc;
			if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		}
  }
}


// class riki, nriki, laivetos
//////////////////////////////////////

void dzb53_::
setinnr()
{
	hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	if(hd_->frq) jumpbyte=1+sizeof(float); else jumpbyte=0;
	if(hd_->key=='r') wis = (jumpbyte)?di5wis.r2if : di5wis.r2i;
	else wis = (jumpbyte)?di5wis.i2rf : di5wis.i2r;
	int hasfreq=jumpbyte?1:0;
	hsd2= (cols_is()-hasfreq)>=2;
	hsd3= (cols_is()-hasfreq)>=3;
	hsd4= (cols_is()-hasfreq)>=4;
	hsd5= (cols_is()-hasfreq)>=5;
	int i, items=hd_->asz;
	dst_=new (char*)[items+1];
	dst_[items]=0;
	//int ll;
	char* p=dt_; uchar llc;
	if(!jumpbyte) {
		llc= *p++;
		for(i=0; i<items; i++) {
			dst_[i]=p;
			p += llc;				    llc = (*p);		*p++ =0;
			if(hsd2) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd3) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd4) {p += llc; llc = (*p);		*p++ =0;}
			if(hsd5) {p += llc; llc = (*p);		*p++ =0;}
		}
	}else{
		for(i=0; i<items; i++) {
			dst_[i]=p; p+=(jumpbyte-1);
			llc = (uchar)(*p);         *p++=0; p+=llc;
			if(hsd2) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd3) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd4) {llc=(uchar)(*p); *p++=0; p+=llc;}
			if(hsd5) {llc=(uchar)(*p); *p++=0; p+=llc;}
		}
	}
}

int dzb53_::
lmu  (char*s, int*l, int*m, int*u)
{
	char c=char('0x\255'); static chars ss; ss=s;
	*l=lower(s); *m=upper(s); ss+=c; *u=upper(ss.s);
	return 0; // 0 is nonsense
}

#endif //#ifdef OLDOLDOLDOLDOLD





//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// for pinimexpander
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

class vbnum { public: voids<short> N,n;
	int  app(short Ni) { short i=0; N.app(Ni); n.app(i); return 1;}
	int  operator= (int i);
	int  operator++(int  );
	int  isinbound();
	int  size() { return N.size(); }
	void clear(){ N.clear(); n.clear(); }
	void reset(){ clear(); }
};

int vbnum::operator=(int i)
{// note that this is kind of reversed
	int pos; int j;
	for(pos=0; pos<N.size(); pos++) {
		j=i%N[pos]; i=i/N[pos]; n[pos]=j; 
	}
	if(i) return 0; return 1;
}

int vbnum::operator++(int)
{// note that this is kind of reversed
	int pos;
	for(pos=0; pos<N.size(); pos++) {
		n[pos]++; 
		if(n[pos]<N[pos]) break; 
		else {if(pos<N.size()-1) n[pos]=0; }
	}
	return 1;
}

int vbnum::isinbound()
{// note that this is kind of reversed
	int pos;
	for(pos=0; pos<N.size(); pos++) {
		if(n[pos]>=N[pos]) return 0;
	}
	return 1;
}

class charspps : public voids<charspp> { public:
	void		hun();
	void    setvbnum(vbnum* vbn);
	chars*operator[](vbnum* vbn);
};

void charspps::setvbnum(vbnum* vbn)
{
	int pos; vbn->clear();
	for(pos=0;pos<size();pos++) {
		vbn->app(a[pos].size());
	}
}

void charspps::hun()
{
	int pos;
	for(pos=0;pos<size();pos++) a[pos].hunorset();
}

chars*charspps::operator[](vbnum* vbn)
{
	int pos; chars* ps=getcharsbuf();
	for(pos=0;pos<size();pos++){
		ps->app(a[pos][(vbn->n[pos])]);
		if(pos<size()-1) ps->app("-");
	}
	return ps;
}


int pinimexpander::set2Nexpand(char*s)
{
	//clear();
	output.clear();
	static charspp pinims; int N,n;
	N=pinims.set2Nhunpinim(s); if(N<1) return 0;
	static charspps spps; static charspp sppbuf; static vbnum vbn;
	static chars sbuf;
	spps.clear();
	for(n=0;n<pinims.size();n++)	{
		sppbuf.set2(pinims[n]);
		spps.app(sppbuf);
	}
	spps.hun();
	spps.setvbnum(&vbn);
	for(vbn=0; vbn.isinbound(); vbn++) {
		sbuf.set2((*(spps[&vbn])).s);
		output.s0.apptab(sbuf.s);
	}
	output.hun();
	return output.size();
}

int tcpmlexpander::set2Nexpand(char*x)
{
	static xmltagrw tg; static pinimexpander xpd;
	tg.set2Nhun(x); char* im;
	char imtagi[]="i", imtagy[]="y";
	char* imtag=imtagy;
	im=tg["y"];
	if(!(im&&im[0])){im=tg["i"];imtag=imtagi;}
	if(!str_hasorset(im))
		{ output.s0.set2(x);output.pp0.set20();output.pp0.app(output.s0.s);return 1;}
	xpd.set2Nexpand(im); output.s0.clear();
	for(int n=0; n<xpd.size(); n++){
		tg.set2(imtag, xpd[n]);
		output.s0.app(tg.tos()); if(n<xpd.size()-1) output.s0.app(ch01);
	}
	output.cut(ch01);
	return output.size();
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

int		segtr_::check4skip(char*s)
{
	static char pt []="�C�A�H�I�F";
	static char pt1[]=".,?!;";
	int n012=str_rbytes(s);
	if(n012==2)	for(int n=0; n<10; n+=2){
		if( (s[0]==pt[n])&&(s[1]==pt[n+1]) ) return pt1[n/2];
	}
	if(n012==1) if(ispunct(*s)) return 1;
	if(str_alldigits(s)) return 1;
	int sz, SZ=strlen(s); char* t=s;
	for(sz=0; sz<SZ; sz++){
		n012=str_rbytes(t);
		if(n012!=1) return 0;
		if(!isalnum(*t)) return 0;
	}
	if(SZ>0) if(isdigit(t[SZ-1])) return 1;
	return 0;
}

int		segtr_::
smmseg		(chars& ocs, charspp& in, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs; int CNT=0;
	int n, b,e,B=0,E=in.size();
	ocs.clear();
	b=B;
	while(b<E){
		e=b+maxsu; csbe(e, b, E);
		while(b<e){
			cs=in.tos("",b,e);
			if(e-b<=1) { ocs+=cs.s; ocs+=sep; b=e; CNT++; break; }
			lu.clear();
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) break;
			}
			if(lu.l<lu.u){
				ocs+=cs.s; ocs+=sep; b=e; CNT++;
			}else e--;
		}
	}
	if(CNT>0) ocs.dele(1);
	return ocs.size();
}
int		segtr_::
mmseg		(chars& ocs, charspp& in, char sep)
{
	if(nwrds<=0) return 0;
	int B=0,E=in.size();
	int nmsu=maxsu; if(nmsu>E-B) nmsu=E-B;
	ocs.clear();
	int CNT=mmseg(ocs, in, B, E, nmsu, sep);
	if(CNT>0) ocs.dele(1);
	return CNT;
}

int		segtr_::
mmseg		(chars& ocs, charspp& in, int B, int E, int nmsu, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs;
	int n, b,e, nsu; if(nmsu>E-B) nmsu=E-B;
	int found=0;	lu.clear();
	if(E-B>1) for(nsu=nmsu; nsu>1; nsu--){
		for(b=B; b<E-1; b++){
			e=b+nsu; if(e>E) break;
			cs=in.tos("",b,e);
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) {found=1; break;}
			}
			if(found) break;
		}
		if(found)break;
	}
	int CNT=0;
	if(found){
		if(B<b) CNT+=mmseg(ocs, in, B, b, nsu-1, sep);
		ocs+=cs.s; ocs+=sep; CNT++;
		if(e<E) CNT+=mmseg(ocs, in, e, E, nsu,   sep);
	}else{
		for(b=B; b<E; b++){
			ocs+=in[b]; ocs+=sep;
		}
		CNT=E-B;
	}
	return CNT;
}

char* segtr_::
seg(char* s, int domm, char sep){ //charspp spp, ispp;
	static chars ocs;
	chars ocs1;
	ocs.clear();//      chars tmp;
	ispp.set2Nhungu(s,1);
	int IK=ispp.size();
	for(int n=0; n<IK; n++){
		tspp.set2Nhunhanlor(ispp[n]); //!!!!!!!!!
		if(domm)		mmseg(ocs1, tspp, '=');
		else			 smmseg(ocs1, tspp, '=');
		ocs+=ocs1; if(n<IK-1) ocs+="\r\n";
	}
	return ocs.s;
}

char* segtr_::
tr(char* s, int domm, char sep){ //charspp spp, ispp;
	static chars ocs;
	chars ocs0, ocs1;
	ocs.clear();//      chars tmp;
	ispp.set2Nhungu(s,1);
	int IK=ispp.size();
	for(int n=0; n<IK; n++){
		tspp.set2Nhunhanlor(ispp[n]); //!!!!!!!!!
		if(domm)		mmtr(ocs0, ocs1, tspp, sep);
		else			 smmtr(ocs0, ocs1, tspp, sep);
		ocs+=ocs0;  if(n<IK-1) ocs+="\r\n";
		ocs+="\t";
		ocs+=ocs1;  if(n<IK-1) ocs+="\r\n";
	}
	return ocs.s;
}

char* segtr_::
tr1(char* s, int domm, char sep)
{//tr with partly hun-su-ed
	static chars ocs;
	chars ocs0, ocs1; chars ocs0a, ocs1a;
	ocs.clear();//      chars tmp;
	ispp.set2Nhungu(s,1);
	int ik, IK=ispp.size();
	for(ik=0; ik<IK; ik++){
		pspp.set2Nhun(ispp[ik]);
		int ip,IP=pspp.size(); ocs0a.clear(); ocs1a.clear();
		for(ip=0; ip<IP; ip++){
			char* tt=pspp[ip];
			//if(tt[0]=='?'&&tt[1]) {tt++;ocs0a+='?';ocs1a+='?';}
			tspp.set2Nhunhanlor(tt); //!!!!!!!!!
			if(domm)		mmtr(ocs0, ocs1, tspp, sep);
			else			 smmtr(ocs0, ocs1, tspp, sep);
			ocs0a+=ocs0.s; if(ip<IP-1) ocs0a+=sep;
			ocs1a+=ocs1.s; if(ip<IP-1) ocs1a+=sep;
		}
		ocs+=ocs0a;  if(ik<IK-1) ocs+="\r\n";
		ocs+="\t";
		ocs+=ocs1a;  if(ik<IK-1) ocs+="\r\n";
	}
	return ocs.s;
}

char* segtr_::
tr4ask(char* s, int domm, char sep)
{//tr with partly hun-su-ed, and for ask: exist one su bw '?'
	static chars ocs;
	chars ocs0, ocs1; chars ocs0a, ocs1a;
	ocs.clear();//      chars tmp;
//ispp.set2Nhungu(s,1);
	ispp.set2Nhun(s);
	int ik, IK=ispp.size();
	for(ik=0; ik<IK; ik++){
		//pspp.set2Nhun(ispp[ik]);
		//int ip,IP=pspp.size(); ocs0a.clear(); ocs1a.clear();
		//for(ip=0; ip<IP; ip++){
			char* tt=ispp[ik];
			if(tt[0]=='?'&&tt[1]) {tt++;ocs0a+='?';ocs1a+='?';}
			tspp.set2Nhunhanlor(tt); //!!!!!!!!!
			if(domm)		mmtr(ocs0, ocs1, tspp, sep);
			else			 smmtr(ocs0, ocs1, tspp, sep);
			ocs0a+=ocs0.s; if(ik<IK-1) ocs0a+=sep;
			ocs1a+=ocs1.s; if(ik<IK-1) ocs1a+=sep;
		//}
	}
		ocs+=ocs0a; // if(ip<IP-1) ocs+=sep;
		ocs+="\r\n";
		ocs+=ocs1a; // if(ip<IP-1) ocs+=sep;
	return ocs.s;
}


int		segtr_::
smmtr		(chars& ocs0,chars& ocs1, charspp& in, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs; int CNT=0;
	int n, b,e,B=0,E=in.size();
	ocs0.clear(); ocs1.clear();
	b=B;
	while(b<E){
		e=b+maxsu; csbe(e, b, E);
		while(b<e){
			cs=in.tos("",b,e);
			//if(e-b<=1) { ocs+=cs.s; ocs+=sep; b=e; break; }
			lu.clear();
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) break;
			}
			if(lu.l<lu.u){
				ocs0+=cs.s; ocs0+=sep;
				ocs1+=wrds[n]->d1(lu.l); ocs1+=sep;
				b=e; CNT++;
			}else {
				e--;
				if(e<=b) { // this single entry can not be found in wrds
					ocs0+=cs.s; ocs0+=sep;
					int ck=check4skip(cs.s);
					if(ck){if(ck>1)ocs1+=(char)ck;else ocs1+=cs.s;}else ocs1+="???";
					ocs1+=sep;
					b++; CNT++;
				}
			}
		}
	}
	if(CNT>0) { ocs0.dele(1);ocs1.dele(1);}
	return CNT;
}

int		segtr_::
mmtr		(chars& ocs0,chars& ocs1, charspp& in, char sep)
{
	if(nwrds<=0) return 0;
	int B=0,E=in.size();
	int nmsu=maxsu; if(nmsu>E-B) nmsu=E-B;
	ocs0.clear();	ocs1.clear();
	int CNT=mmtr(ocs0,ocs1, in, B, E, nmsu, sep);
	if(CNT>0) { ocs0.dele(1); ocs1.dele(1);}
	return CNT;
}

int		segtr_::
mmtr		(chars& ocs0,chars& ocs1, charspp& in, int B, int E, int nmsu, char sep)
{
	if(nwrds<=0) return 0;	LU lu; chars cs;
	int n, b,e, nsu; if(nmsu>E-B) nmsu=E-B;
	int found=0;	lu.clear();
	//if(E-B>1)
	for(nsu=nmsu; nsu>0; nsu--){ //0: not 1, since need check downto 1 entry
		for(b=B; b<E; b++){ // E: not E-1, since need check downto 1 entry
			e=b+nsu; if(e>E) break;
			cs=in.tos("",b,e);
			for(n=0; n<nwrds; n++){
				lu=wrds[n]->lu(cs.s);
				if(lu.l<lu.u) {found=1; break;}
			}
			if(found) break;
		}
		if(found)break;
	}
	int CNT=0;
	if(found){
		if(B<b) CNT+=mmtr(ocs0,ocs1, in, B, b, nsu-1, sep);
		ocs0+=cs.s; ocs0+=sep; ocs1+=wrds[n]->d1(lu.l); ocs1+=sep; CNT++;
		if(e<E) CNT+=mmtr(ocs0,ocs1, in, e, E, nsu,   sep);
	}else{
		for(b=B; b<E; b++){
			ocs0+=in[b]; ocs0+=sep;
			int ck=check4skip(in[b]);
			if(ck){if(ck>1)ocs1+=(char)ck;else ocs1+=in[b];}else ocs1+="???";
			//if(check4skip(in[b])){ocs1+=in[b];}else ocs1+="???";
			ocs1+=sep;
		}
		CNT=E-B;
	}
	return CNT;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

int	 	csfname4play1daiqi(chars& cs, char* ext, float& emph)
{
	emph=-1;
	if(cs.hasnone()) return 0;
	if(cs.ew(".sp")) cs.dele(3);
	char c,cd=cs.lastbyte();
	if(isdigit(cd)){
		cs.dele(1);
		c=cs.lastbyte();
		if(!(c=='p'||c=='t'||c=='k'||c=='h')){
			switch (cd) {
			case '6': cd='1';break;
			case '7': cd='2';break;
			case '8': cd='3';break;
			}
		}else
		if((c=='p'||c=='t'||c=='k')){
			switch (cd) {
			case '1': cd='6';break;
			case '2': cd='7';break;
			case '3': cd='8';break;
			}
		}else
		if(c=='h'){
			switch (cd) {
			case '3': cs.dele(1);break;
			case '4': cs.dele(1);break;
			case '8': cs.dele(1);cd='3';break;
			}
		}
		if(cs.is("m")||cs.is("hm"))
				emph=3;
		else if(cs[1]=='n'&&cs[2]=='g'&&str_isin(cs[0],"bpmvdtnlgkqzcsrh"))
				emph=2;
		else if(cs[0]=='n'&&cs[1]=='g')
				emph=3;

		if(cd=='3'||cd=='8') {
			if(cs.is("m")||cs.is("hm"))
				emph=8;
			else if(str_isin(cs[0],"mnvqaeiou"))
				emph=2;
			else if(cs[1]=='n'&&cs[2]=='g'&&str_isin(cs[0],"bpmvdtnlgkqzcsrh"))
				emph=4.5;
			else if(cs[0]=='n'&&cs[1]=='g')
				emph=6;
			else if(emph<0)
				emph=2;
		}else
		if(cd=='5')
			emph=2;
		cs+=cd;
	}
	if(!cs.ewdigit())cs+="1";
	cs+=".sp";
	return 1;
}

int	 	csfname4play1daiqi(chars& cs) 												// check/set
{
	char ext[]="sp"; float emph;
	return	csfname4play1daiqi(cs,ext,emph);
}
int	 	csfname4play1daiqi(chars& cs, char* ext) 							// check/set
{
	float emph;
	return	csfname4play1daiqi(cs,ext,emph);
}
int	 	csfname4play1daiqi(chars& cs, float& emph) 						// check/set
{
	char ext[]="sp";
	return	csfname4play1daiqi(cs,ext,emph);
}
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////


#endif //#ifndef DIBASE_CPP



#ifdef OLDOLDOLDOLDOLD

struct rdhdr51 { // riden header, note: sizeof(di51rdhdr) is 28, different from previous version 32
  char idf[8];
  long asz;		// size of data in unit of usize (array size)
  long bsz;		// size of data in unit of byte  (array size in bytes)
  long usz;		// size of each unit, 0 if not const
  long K;			// under anybody's interpretation
	USHORT vM; USHORT vm;
  rdhdr51() {  setidfv(); setabuK(0,0,0,0); idf[0]=0; }
	void setidfier (char*s,int n=8){ if(n>8)n=8;strncpy(idf,s,n); }
  void getidfier (char*s        ){ strncpy(s,idf,8);s[8]=0; }
  void peekidfier(tyio& r, char* s){int i; r.read(&i,4); read(r);r.rmoveto(-(long)(sizeof(int)+sizeof(*this))); getidfier(s);}
	char*idfier		 ( ){return idf;}
  void setidfv	 ( ){setidfier("dif");vM=5;vm=1;}
  void setabuK	 (long asiz,long bsiz,long usiz,long k=0)
										{asz=asiz; bsz=bsiz; usz=usiz; K=k; }
	long  read		 (tyio& r){return r.read (this, sizeof(*this));}
  long  write		 (tyio& w){return w.write(this, sizeof(*this));}
};

struct rdhdr52 { // riden header, note: sizeof(di51rdhdr) is 28, different from previous version 32
	long asz;		// size of data in unit of usize (array size)
  long bsz;		// size of data in unit of byte  (array size in bytes)
  long usz;		// size of each unit, 0 if not const
  char idf[8];
  char qqn,key,col,knd;//qiqen(d/k/h),key(dikey),col(1/2/3),kind(dirdkind)
  USHORT vM; USHORT vm;
  rdhdr52() {  setidfv(); setabu(0,0,0); idf[0]=0; }
  void setidfier (char*s,int n=8){ if(n>8)n=8;strncpy(idf,s,n); }
  void getidfier (char*s        ){ strncpy(s,idf,8);s[8]=0; }
	void peekidfier(tyio& r, char* s){int i; r.read(&i,4); read(r);r.rmoveto(-(long)(sizeof(int)+sizeof(*this))); getidfier(s);}
  char*idfier		 ( ){return idf;}
  void setidfv	 ( ){setidfier("dif");vM=5;vm=2;}
  void setabu		 (long asiz,long bsiz,long usiz)
										{asz=asiz; bsz=bsiz; usz=usiz; }
	void setqkck	 (char qiqen, char key1, char c2c3, char kind)
										{qqn=qiqen; key=key1; col=c2c3; knd=kind; }
  long  read		 (tyio& r){return r.read (this, sizeof(*this));}
  long  write		 (tyio& w){return w.write(this, sizeof(*this));}
};

class dzb52_ { // 2 or 3 column
protected:
	tyio    io;   szmiohs mm;
  rdhdr* hd_;  char*   dt_;  char**  dst_;
  short id;
  void  setinnr();
	//int	isc2c3() {char s[10], c3[]="c3"; hd_->getidfier(s); 
	//							return ( (str_find(s, c3, 2)>=0)? 3 : 2 ); }
	int	isc2c3() { return ( ('3'==hd_->col)? 3 : 2 ); }
	int (__cdecl *wis ) (const void *, const void *);//the wis function
public:
	int lower(char*s) { return wislower(s,dst_,size(),sizeof(char**),wis);}
	int upper(char*s) { return wisupper(s,dst_,size(),sizeof(char**),wis);}
public:
	dzb52_()				:	wis(di5wis.i2r) { }
	dzb52_(char* fn): wis(di5wis.i2r) { read(fn); }
public:
  int read(tyio& r ){ mm.read(r ); setinnr(); return 1; }
	int read(char* fn){ tyio io; if(!io.open(fn))return 0; mm.read(io); setinnr(); io.close(); return 1; }
public:
	uint size  () { return (uint)(hd_->asz);			}
	int  isc3  ()	{ return ('3'==hd_->col)? 1: 0; }
	char key   () { return hd_->key; }
	char qiqien() { return hd_->qqn; }
	char luibet() { return hd_->knd; }
public:
  char* d1(USHORT n) { return dst_[n]; }
  char* d2(USHORT n) { return dst_[n] + strlen(d1(n)) +1; }
	char* d3(USHORT n) { return dst_[n] + strlen(d1(n)) +1+ strlen(d2(n)) +isc3(); }
	//char* d3(USHORT n) { return dst_[n] + strlen(d1(n)) +1+ strlen(d2(n)) +1; }
};


inline void dzb52_::
setinnr()
{
  hd_=(rdhdr*)(mm.h)();  dt_=(char*)(mm.s)();
	if(hd_->key=='r') wis = di5wis.r2i; else wis = di5wis.i2r;
	int c3=isc3();
  int i, items=hd_->asz;
  dst_=new (char*)[items+1];
  dst_[items]=0;
  int ll;
  char* p=dt_;
  ll= *p++;
  for(i=0; i<items; i++) {
		dst_[i]=p;
		p += ll;				ll = (unsigned short)(*p);		*p++ =0;
		p += ll;				ll = (unsigned short)(*p);		*p++ =0;
		if(c3) {p += ll;ll = (unsigned short)(*p);		*p++ =0;}
  }
}

//typedef dzb_ i2rdzb_;
//
//class r2idzb_ :public dzb_ {public:
//	r2idzb_()					{wis=(di5wis.r2i); }
//	r2idzb_(char* fn) {wis=(di5wis.r2i); read(fn); }
//};


#endif //#ifdef OLDOLDOLDOLDOLD
