
#include <di5cpconst.h>
#include <di5base.h>

class 	di5cpdll_ {
public:	di5cpdll_(char* pfn=0):hinst(0),di5proc(0){init(pfn);}
			 ~di5cpdll_(){}//del();}
public:
	int operator()(int m, void*w, void*l){ return getset(m,w,l);}
public:
	int	strset			(char*s, int  l	){ll=l;res=getset(DIDM_strsetw,s,&ll);return res;}
	int	strget			(char*s, int& l	){ll=l;res=getset(DIDM_strgetw,s,&ll);return res;}
	int	str10set		(char*s, int  l	){ll=l;res=getset(DIDM_str10setw,s,&ll);return res;}
	int	str10get		(char*s, int& l	){ll=l;res=getset(DIDM_str10getw,s,&ll);return res;}
public:
	int	hndleditset	 	(uint  h				){uww=h;return getset(DIDM_hndleditsetw,&uww,&ull);}
	int	hndleditget 	(uint &h				){res=getset(DIDM_hndleditgetw,&uww,&ull);
																			h=uww;
																			return res;}
	int	hndleditclear (								){return getset(DIDM_hndleditclear,&uww,&ull);}
public:
	int	hndlprntset	 	(uint  h				){uww=h;return getset(DIDM_hndlprntsetw,&uww,&ull);}
	int	hndlprntget 	(uint &h				){res=getset(DIDM_hndlprntgetw,&uww,&ull);
																			h=uww;
																			return res;}
	int	hndlprntclear (								){return getset(DIDM_hndlprntclear,&uww,&ull);}
public:
	int	wlset				(int w, int l		){ww=w;ll=l;return getset(DIDM_wlset,&ww,&ll);}
	int	wlget				(int&w, int&l		){res=getset(DIDM_wlget,&ww,&ll);w=ww;l=ll;return res;}
	int	wlchanged		(								){return getset(DIDM_wlchanged,&ww,&ll);}
public:
	void del ();
private:
	int  getset(int m, void*w, void*l);
	void init(char* pfn);
		/*
	{
		res=0;
		char *pfndef="C:\\c2k\\di\\di5cpdll\\Debug\\di5cpdll.dll";
		if(!(pfn&&pfn[0])) pfn=pfndef;
		hinst=LoadLibrary(pfn);
		if(hinst)di5proc = (DI5PROC) GetProcAddress(hinst, (const char*)1);
	}
	int getset(int m, void*w, void*l)
	{
		if(!di5proc)return 0;
		int res=0;
		try{res=di5proc(m,w,l);}catch(...){}
		return res;
	}
		*/
	typedef int (*DI5PROC)(int m, void*w, void*l);
	HINSTANCE	hinst;
	DI5PROC 	di5proc; int ww,ll, uww, ull, res;
};
