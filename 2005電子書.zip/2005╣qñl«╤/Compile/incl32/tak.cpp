//---------------------------------------------------------------------------
//file "tak.cpp"
//---------------------------------------------------------------------------
#include "chars.cpp"
#include "htype.cpp"
#include "tyio8.cpp"
#include "tos.cpp"
// tak is an extern object defined in tyio8.cpp


