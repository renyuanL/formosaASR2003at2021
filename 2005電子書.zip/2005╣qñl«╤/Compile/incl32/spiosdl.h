//*
//*	spiosdl.h
//*
#ifndef SPIOSDL_H
#define SPIOSDL_H

#include <speechio.h>
#include <vcl.h>
#include "plot3d.hpp"
#include "rchart.hpp"
#include <di5vp.h>
//#include <vecproc.h>
#ifndef TPC(X)
// first a macro for a shorter name,
// remember spaces after TPC(X)
#define TPC(X)			template<class X>
#define TPC1(X)			template<class X>
#define TPC2(X,Y)		template<class X, class Y>
#define TPC3(X,Y,Z)		template<class X, class Y, class Z>
#define TPCI(X)			template<class X> inline
#define TPCI1(X)		template<class X> inline
#define TPCI2(X,Y)		template<class X, class Y> inline
#define TPCI3(X,Y,Z)	template<class X, class Y, class Z> inline
//vitr means iterator of vector/valarray/array, or random acess iterator
#endif //#ifndef TPC(X)

//* In SDL, setting ClassDeault to certain value,
//* subsequqent drawing will have this value until it is set2 other value.
//* ccsccw_: a handy class to control how rchart is drawn,
//* epecially the "cno", which allows group manipulation, simulate mulitple series plot
//* the cno allows the deleting/manipulating of the graph with same cno
//* without the knowledge of other parts.  This is an very good design.
class 	ccsccw_ {public:
		ccsccw_(					  ){setdef();}//def2 no-cleargf, no-scale, but clearcnum, change as little as possible
		ccsccw_(TColor clr1, uchar cno1, uchar scx1, uchar scy1){setdef();setccss(clr1,cno1,scx1,scy1);}
	TColor 	clr; //* DataColor
	uchar 	cno; //* class number =0:254 for group operation such as visible or remove
	uchar	scx; //* rescale x: 0 4no-rescale, 1 4scale
	uchar	scy; //* rescale y: 0 4no-rescale, 1 4scale
	bool  	cgf; //* clear graph or not before drawing
	bool	ccn; //* clear class num below
	int		wid; //* line width
	//*		cleargf,clearcnum, wid
	void	setccw	(bool   cgf1, bool  ccn1, int wid1=-1			){cgf=cgf1; ccn=ccn1;if(wid1>0)wid=wid1;}
	//*		color, 	cnum, scalex, scaley
	void	setccss	(TColor clr1, uchar cno1, uchar scx1, uchar scy1){clr=clr1; cno=cno1; scx=scx1;scy=scy1;validate();}
	//*				cnum, scalex, scaley
	void	setcss	(			  uchar cno1, uchar scx1, uchar scy1){			cno=cno1; scx=scx1;scy=scy1;validate();}
	//*		color,	cnum
	void	setcc 	(TColor clr1, uchar cno1			 			){clr=clr1; cno=cno1;					validate();}
	//*		scalex, scaley
	void	setss 	(uchar  scx1, uchar scy1 			 			){scx=scx1; scy=scy1;}
	//*		cleargf, scalex, scaley
	void	set4new	(){setdef();cgf=true;setss(1,1);}
	bool	scalex	(){return scx>0;}
	bool	scaley	(){return scy>0;}
	void	setdef	(){setccss(clBlack, 0, 0, 0);  setccw(false,false,1);}
//	void	setdef	(){setccss(clBlack, 0, 0, 0);  setccw(false,true,1);}
	void	validate(){ if(cno>254)cno=254;}
	void	set2	(TColor clr1, uchar cno1, uchar scx1, uchar scy1, bool   cgf1, bool  ccn1,  int wid1 ){cgf=cgf1;ccn=ccn1; clr=clr1;cno=cno1; scx=scx1; scy=scy1; wid=wid1; validate();}
};


//* SDL plotting routines.
//* These is actually standalone function (kind of namespace)
//* Collect them together has advantages that CodeCompletion can help
//*   with the more meaningful function names ( and parameter list)
//* 1. qiimbuf_ and its hili (high light)
//* 2. line, stick, mark(scatter plot), in 1d/2d
//* 3. spec, (since it is more involved (using color and quantile),
//*          so implement not in template to save the header file complexity
//*
class rchartf_ {ccsccw_  cswd;
public:
public:
	TRChart& wave	(TRChart& rct, qiimbuf_&  qb){cswd.set4new();return wave(rct,qb, cswd, -1,-1);}
	TRChart& wave	(TRChart& rct, qiimbuf_*p2qb);
	TRChart& wave	(TRChart& rct, qiimbuf_&  qb, ccsccw_& csw, int beg, int end, int begtickas0=1);//* -1 4 autoscale
	TRChart& wave	(TRChart& rct, qiimbuf_*p2qb, ccsccw_& csw, int beg, int end, int begtickas0=1);
	TRChart& hili	(TRChart& rct, qiimbuf_&  qb, ccsccw_& csw, int beg, int end);
	TRChart& hili	(TRChart& rct, qiimbuf_*p2qb, ccsccw_& csw, int beg, int end);
	TRChart& hilims	(TRChart& rct, qiimbuf_&  qb, ccsccw_& csw, int beg, int end);
	TRChart& hilims	(TRChart& rct, qiimbuf_*p2qb, ccsccw_& csw, int beg, int end);
	TRChart& hili	(TRChart& rct, qiimbuf_&  qb, ccsccw_& csw, int*bnds,uint noseg);
public:
//	TRChart& wavebar(TRChart& rct, vector<int>& u, int mM){cswd.setdef();cswd.setcc(clLime,3);return wavebar(rct,u, mM, cswd, -1,-1);}
//	TRChart& wavebar(TRChart& rct, vector<int>& u, int mM, ccsccw_& csw, int beg, int end, int begtickas0=1);//* -1 4 autoscale
//	TRChart& wavebar(TRChart& rct, vector<int>& u, int ndxbeg, int mM){cswd.setdef();cswd.setcc(clLime,3);return wavebar(rct,u, ndxbeg, mM, cswd, -1,-1);}
//	TRChart& wavebar(TRChart& rct, vector<int>& u, int ndxbeg, int mM, ccsccw_& csw, int beg, int end, int begtickas0=1);//* -1 4 autoscale
//	TRChart& wavebar(TRChart& rct, vector<int>& u, vector<int>& v, int ndxbeg, int mM){cswd.setdef();cswd.setcc(clLime,3);return wavebar(rct,u, v, ndxbeg, mM, cswd, -1,-1);}
//	TRChart& wavebar(TRChart& rct, vector<int>& u, vector<int>& v, int ndxbeg, int mM, ccsccw_& csw, int beg, int end, int begtickas0=1);//* -1 4 autoscale
public:
	TRChart& spec	(TRChart& rct, vecvec<float >&vv,int qbsz, int frmsz,int sftsz);
	TRChart& spec	(TRChart& rct, vecvec<double>&vv,int qbsz, int frmsz,int sftsz);
public:
public:
	TPC(R) TRChart& line (TRChart& rct, vector  <R>& v,  ccsccw_& csw, int beg=-1, int end=-1);
	TPC(R) TRChart& stem (TRChart& rct, vector  <R>& v,  ccsccw_& csw, int beg=-1, int end=-1);
	TPC(R) TRChart& mark (TRChart& rct, vector  <R>& v,  ccsccw_& csw, int markatkind=17, int beg=-1, int end=-1);
	TPC(R) TRChart& line (TRChart& rct, valarray<R>& v,  ccsccw_& csw, int beg=-1, int end=-1);
	TPC(R) TRChart& stem (TRChart& rct, valarray<R>& v,  ccsccw_& csw, int beg=-1, int end=-1);
	TPC(R) TRChart& mark (TRChart& rct, valarray<R>& v,  ccsccw_& csw, int markatkind=17, int beg=-1, int end=-1);
public:
public://use mark for scatter plot
	TPC2(R1,R2)	TRChart& line(TRChart& rct, vector<R1>& vx, vector<R2>& vy, ccsccw_& csw, int  beg=-1, int  end=-1);//ret 1 if success, 0 if fail
	TPC2(R1,R2)	TRChart& stem(TRChart& rct, vector<R1>& vx, vector<R2>& vy, ccsccw_& csw, int  beg=-1, int  end=-1);//ret 1 if success, 0 if fail
	TPC2(R1,R2)	TRChart& mark(TRChart& rct, vector<R1>& vx, vector<R2>& vy, ccsccw_& csw, int markatkind=17, int beg=-1, int end=-1);
public:
public:
	TPC(R) TRChart& line (TRChart& rct, vector  <R>& v, int beg=-1, int end=-1)						{ccsccw_ csw;return line(rct,v,csw,beg,end);}
	TPC(R) TRChart& stem (TRChart& rct, vector  <R>& v, int beg=-1, int end=-1)						{ccsccw_ csw;return stem(rct,v,csw,beg,end);}
	TPC(R) TRChart& mark (TRChart& rct, vector  <R>& v, int markatkind=17, int beg=-1, int end=-1)	{ccsccw_ csw;return mark(rct,v,csw,markatkind,beg,end);}
	TPC(R) TRChart& line (TRChart& rct, valarray<R>& v, int beg=-1, int end=-1)						{ccsccw_ csw;return line(rct,v,csw,beg,end);}
	TPC(R) TRChart& stem (TRChart& rct, valarray<R>& v, int beg=-1, int end=-1)						{ccsccw_ csw;return stem(rct,v,csw,beg,end);}
	TPC(R) TRChart& mark (TRChart& rct, valarray<R>& v, int markatkind=17, int beg=-1, int end=-1)	{ccsccw_ csw;return mark(rct,v,csw,markatkind,beg,end);}
public:
public://use mark for scatter plot
//	TPC2(R1,R2)	TRChart& line(TRChart& rct, vector<R1>& vx, vector<R2>& vy, int  beg=-1, int  end=-1)					{ccsccw_ csw;return line(rct,vx,vy,csw,beg,end);}
//	TPC2(R1,R2)	TRChart& stem(TRChart& rct, vector<R1>& vx, vector<R2>& vy, int  beg=-1, int  end=-1)					{ccsccw_ csw;return stem(rct,vx,vy,csw,beg,end);}
//	TPC2(R1,R2)	TRChart& mark(TRChart& rct, vector<R1>& vx, vector<R2>& vy, int markatkind=17, int beg=-1, int end=-1)	{ccsccw_ csw;return mark(rct,vx,vy,csw,markatkind,beg,end);}
public:
	TPC2(V1,V2)	TRChart& line(TRChart& rct, V1& vx, V2& vy, int  beg=-1, int  end=-1);//					{ccsccw_ csw;return line(rct,vx,vy,csw,beg,end);}
	TPC2(V1,V2)	TRChart& stem(TRChart& rct, V1& vx, V2& vy, int  beg=-1, int  end=-1);//					{ccsccw_ csw;return stem(rct,vx,vy,csw,beg,end);}
	TPC2(V1,V2)	TRChart& mark(TRChart& rct, V1& vx, V2& vy, int markkind=17, int beg=-1, int end=-1);//	{ccsccw_ csw;return mark(rct,vx,vy,csw,markatkind,beg,end);}
public:
public://2 supporting func to set beg/end and clear/auto-range plot as specified in ccsccw_
	TPC(R) TRChart& csbeNcr(TRChart& rct, valarray<R>& v,  ccsccw_& csw, int&beg,    int&end);//ret 1 if success, 0 if fail
	TPC(R) TRChart& csbeNcr(TRChart& rct, vector  <R>& v,  ccsccw_& csw, int&beg,    int&end);//ret 1 if success, 0 if fail
TPC2(R1,R2)TRChart& csbeNcr(TRChart& rct, vector <R1>&vx,  vector<R2>& vy, ccsccw_& csw, int &beg, int &end);//ret 1 if success, 0 if fail
		   TRChart& csbeNcr(TRChart& rct, qiimbuf_  & qb,  ccsccw_& csw, int &beg, int &end);//ret 1 if success, 0 if fail
public:
	void csbe(int& b, int &e, int N);//* check/set 0<=b<=e<=N
public:
		TRChart& hist(TRChart& rct, ucCounter&     cnt, int scale=1);
TPC(R)	TRChart& hist(TRChart& rct, frqCounter<R>& frq, int scale=1);

};
extern rchartf_ rchartf;


//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
class qbmouse_ {public:
		qbmouse_(TColor clr=clGreen, uchar clssnum=12):downed(0){csw.setcc(clr,clssnum);csw.ccn=1;}
public:
	int	ondown(TRChart&rct, qiimbuf_& qb, int capturemouse=1);
	int onmove(TRChart&rct, qiimbuf_& qb);
	int onupup(TRChart&rct, qiimbuf_& qb);
	uint	len(){return endx-begx;}
public:
	int 	downed; int hasbeenmoved;
	int 	begx, endx;
	ccsccw_ csw;
};
/*
class 	wbarmouse_ {public:
		wbarmouse_(TColor clr=clLime, uchar clssnum=13):downed(0){csw.setdef();csw.setcc(clr,clssnum);csw.ccn=1;}
public:
	int	ondown(TRChart&rct, vector<int>&v, int X, int Y, int indexbeg, int maxamp1, int capturemouse=1);
	int onmove(TRChart&rct, vector<int>&v);
	int onupup(TRChart&rct, vector<int>&v);
	uint	len		(){return endx-begx;}
	int	closestndx	(TRChart&rct, vector<int>& v, int X, int Y, int delta=3);
	int	wasmoved(){return hasbeenmoved;}
public:
	int 	downed; int hasbeenmoved;
	int 	nth, begx, endx;
	int		maxamp; int ndxbeg;
	ccsccw_ csw;
};
*/
template<class OWTPLAY>
class owplaybar_{ public:
		owplaybar_(OWTPLAY&owtp1):owtp(&owtp1),clsnum(120),playpos(-1){}
public:
	__int64	playpos; uchar clsnum; OWTPLAY* owtp;
public:
	void	start	(qiimbuf_ &qb,TTimer& tmr){owtp->tplay(&qb);playpos=-1;Sleep(1);tmr.Enabled=true;}
	void	start	(TTimer& tmr){playpos=-1;tmr.Enabled=true;}
	int	update(TRChart& rct,TTimer& tmr, int playbeg=0, TColor clr=clRed);
	void	clearbar(TRChart& rct);
};
//example:
// qiimbuf_ qb; /*qb is global*/
// owtplayer owt(qb);
// owplaybar_<owtplayer> playbar(owt);

template<class OWTPLAY>
void	owplaybar_<OWTPLAY>::clearbar(TRChart& rct)
{
	playpos=-1;
	rct.RemoveItemsByClass(clsnum);
	rct.ShowGraf();
}

template<class OWTPLAY>
int		owplaybar_<OWTPLAY>::update(TRChart& rct,TTimer& tmr,int playbeg, TColor clr)
{
	//uchar
	clsnum=120;//	TColor clr=clRed;
	rct.RemoveItemsByClass(clsnum);
	__int64 newpos=owtp->position();
	if(newpos==0&&playpos<=0&&!owtp->isplaying()){
//	if(playpos<0&&!owtp->isplaying()){
		return -1;//tmr.Enabled=false;
	}
	uchar clsnumold=rct.ClassDefault;	rct.ClassDefault=clsnum;
 	TColor   clrold=rct.DataColor;		rct.DataColor=clr;
	playpos=newpos;
	if(playpos>0){
		rct.Line(playpos+playbeg,-32300,playpos+playbeg,32300);
		//mout<<"update "<<int(playpos+playbeg)<<memo;
	}
	rct.ShowGraf();
	rct.ClassDefault=clsnumold;
	rct.DataColor=clrold;
	return 1;
}

/*
typedef owthread1_ owthread_;
class 	playbar_ { public:
	__int64	playpos; uchar clsnum; owthread_* owt;
//	void	start	(qiimbuf_ &qb,TTimer& tmr){owt=owthread_::newNplay(&qb);playpos=-1;tmr.Enabled=true;}
	void	start	(owthread_* owt1,qiimbuf_ &qb,TTimer& tmr){owt=owt1;owt->play(&qb);playpos=-1;tmr.Enabled=true;}
	void	start	(owthread_* owt1,TTimer& tmr){owt=owt1;playpos=-1;tmr.Enabled=true;}
	void	update	(TRChart& rct,TTimer& tmr, int playbeg=0, TColor clr=clRed);
	void	clearbar(TRChart& rct);
};
*/

class 	owdefplaybar_ { public:
	__int64	playpos; uchar clsnum;
	void	start	(TTimer& tmr){playpos=-1;tmr.Enabled=true;}
	void	update	(TRChart& rct,TTimer& tmr, int playbeg=0, TColor clr=clRed);
	void	clearbar(TRChart& rct);
};



//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
namespace di5{

template<class T>
struct rctmanip {TRChart&(*fn )(T,TRChart&);  T t;
	rctmanip	(TRChart&(*fn1)(T,TRChart&),  T t1){fn=fn1;t=t1;}
	rctmanip	(){}
	TRChart& operator()(TRChart& rct){ fn(t,rct); return rct;}
};
template<class T1, class T2>
struct rctmanip2 {TRChart&(*fn )(T1,T2,TRChart&);  T1 t1; T2 t2;
	rctmanip2	 (TRChart&(*fn1)(T1,T2,TRChart&),  T1 t1_,T2 t2_){fn=fn1;t1=t1_;t2=t2_;}
	rctmanip2	(){}
	TRChart& operator()(TRChart& rct){ fn(t1,t2,rct); return rct;}
};
template<class T1, class T2, class T3>
struct rctmanip3 {TRChart&(*fn )(T1,T2,T3,TRChart&);  T1 t1; T2 t2; T3 t3;
	rctmanip3	 (TRChart&(*fn1)(T1,T2,T3,TRChart&),  T1 t1_,T2 t2_,T3 t3_){fn=fn1;t1=t1_;t2=t2_;t3=t3_;}
	rctmanip3	(){}
	TRChart& operator()(TRChart& rct){ fn(t1,t2,t3,rct); return rct;}
};

typedef TRChart& (*RChartAR)(TRChart&);
inline		 TRChart& operator<< (TRChart& rct, RChartAR fn   ){fn (rct);return rct;}
TPCI(T) 	 TRChart& operator<< (TRChart& rct, rctmanip<T>man){man(rct);return rct;}
TPCI2(T1,T2) TRChart& operator<< (TRChart& rct, rctmanip2<T1,T2>man){man(rct);return rct;}
TPCI3(T1,T2,T3) TRChart& operator<< (TRChart& rct, rctmanip3<T1,T2,T3>man){man(rct);return rct;}
//TPCI(R) TRChart& operator<<	(TRChart& rct, spec_manip<R>v){rchartf.spec(rct,*(v.vv),v.qbsz,v.frmsz,v.sftsz); return rct;}

#define RCTMANIP_EQ(name, dtype, func)		\
inline TRChart& rchart_##name(dtype d,TRChart& rct){rct.func=d; return rct;}	\
inline rctmanip<dtype>   name(dtype d){rctmanip<dtype> s(rchart_##name,d);return s;}

#define RCTMANIP_FC(name, dtype, func)		\
inline TRChart& rchart_##name(dtype d,TRChart& rct){rct.func(d); return rct;}	\
inline rctmanip<dtype>   name(dtype d){rctmanip<dtype> s(rchart_##name,d);return s;}

//*example: rct<<clr; rct<<clear; rct<<update; rct<<autorange;
inline  TRChart& clr		(TRChart& rct){rct.ClearGraf();		 return rct;}
inline  TRChart& clear		(TRChart& rct){rct.ClearGraf();		 return rct;}
inline  TRChart& update		(TRChart& rct){rct.ShowGrafNewOnly();return rct;}
inline  TRChart& autorange	(TRChart& rct){rct.AutoRange(5);	 return rct;}




//*example: rct<<autorange(5);
inline TRChart&  rchart_autorange(double percent,TRChart& rct){rct.AutoRange(percent); return rct;}
inline rctmanip<double> autorange(double percent){rctmanip<double> s(rchart_autorange, percent);return s;}

//*example: rct<<autoRU(5); //* RU Range Update //* RS Range Shownew
inline TRChart&  rchart_autoRU(double percent,TRChart& rct){rct.AutoRange(percent); rct.ShowGrafNewOnly();return rct;}
inline rctmanip<double> autoRU(double percent=5){rctmanip<double> s(rchart_autoRU, percent);return s;}
inline rctmanip<double> autoRS(double percent=5){rctmanip<double> s(rchart_autoRU, percent);return s;}

//*example: rct<<autorange(5);
inline TRChart& rchart_title(char* c,TRChart& rct){rct.Caption=c; return rct;}
inline rctmanip<char*> title(char* c){rctmanip<char*> s(rchart_title, c);return s;}
//* The above is the same as
//	RCTMANIP_EQ(title, char*, Caption); //* example rct<<title("title");

RCTMANIP_EQ(legx, char*,  IdAbscissa); //* example: rct<<legx("x lable");
RCTMANIP_EQ(legy, char*,  IdOrdinate); //* example: rct<<legy("y lable");
RCTMANIP_EQ(color,TColor, DataColor ); //* example: rct<<color(clRed);

//*example: vv4spec vv(qbuf, frmms, sftms); rct<<spec(vv);
inline TRChart&    rchart_spec(vv4spec*vv ,TRChart& rct){rchartf.spec(rct,*vv, vv->qbsz, vv->frmsz,vv->sftsz); return rct;}
inline rctmanip<vv4spec*> spec(vv4spec&vv){rctmanip<vv4spec*>r(rchart_spec,&vv) ; return r;}

//*example: rct<<line(v);
TPCI(R) TRChart&     rchart_linevec(vector<R>*v,TRChart& rct){rchartf.line(rct,*v); return rct;}
TPCI(R) rctmanip<vector<R>*>line   (vector<R>&v){rctmanip<vector<R>* >r(rchart_linevec,&v); return r;}


//*example: rct<<stem(v);
TPCI(R) TRChart&     rchart_stemvec(vector<R>*v,TRChart& rct){rchartf.stem(rct,*v); return rct;}
TPCI(R) rctmanip<vector<R>*>stem   (vector<R>&v){rctmanip<vector<R>* >r(rchart_stemvec,&v); return r;}


//*example: rct<<mark(v);
TPCI(R) TRChart&     rchart_markvec(vector<R>*v,TRChart& rct){rchartf.mark(rct,*v); return rct;}
TPCI(R) rctmanip<vector<R>*>mark   (vector<R>&v){rctmanip<vector<R>* >r(rchart_markvec,&v); return r;}

//*example: ucCounter<int> cntr; cntr.set(vec); rct<<hist(cntr);
inline  TRChart&   rchartcnt_hist(ucCounter*c,TRChart& rct){rchartf.hist(rct,*c,c->scale); return rct;}
inline  rctmanip<ucCounter*> hist(ucCounter&c, int scale=1){c.scale=scale;rctmanip<ucCounter*>r(rchartcnt_hist, &c); return r;}

//*example: frqCounter<int> cntr; cntr.set(vec); rct<<hist(cntr);
TPCI(R) TRChart&       rchartfrq_hist(frqCounter<R>*c,TRChart& rct){rchartf.hist(rct,*c,c->scale); return rct;}
TPCI(R) rctmanip<frqCounter<R>*> hist(frqCounter<R>&c, int scale=1){c.scale=scale;rctmanip<frqCounter<R>*>r(rchartfrq_hist, &c); return r;}








//*example: rct<<line(vx,vy);
TPCI2(V1,V2) TRChart&   rchart_linevec2(V1*vx,V2*vy,TRChart& rct){rchartf.line(rct,*vx,*vy); return rct;}
TPCI2(V1,V2) rctmanip2<V1*,V2*>line2   (V1&vx,V2&vy){rctmanip2<V1*,V2*>r(rchart_linevec2,&vx,&vy);return r;}


//*example: rct<<stem(vx,vy);
TPCI2(V1,V2) TRChart&   rchart_stemvec2(V1*vx,V2*vy,TRChart& rct){rchartf.stem(rct,*vx,*vy); return rct;}
TPCI2(V1,V2) rctmanip2<V1*,V2*>stem2   (V1&vx,V2&vy){rctmanip2<V1*,V2*>r(rchart_stemvec2,&vx,&vy);return r;}


//*example: rct<<mark(vx,vy);
TPCI2(V1,V2) TRChart&   rchart_markvec2(V1*vx,V2*vy,TRChart& rct){rchartf.mark(rct,*vx,*vy); return rct;}
TPCI2(V1,V2) rctmanip2<V1*,V2*>mark2   (V1&vx,V2&vy){rctmanip2<V1*,V2*>r(rchart_markvec2,&vx,&vy);return r;}

//*example: rct<<mark(vx,vy,1);//1 is the markkind
TPCI2(V1,V2) TRChart&       rchart_markvec3(V1*vx,V2*vy,int mark,TRChart& rct){rchartf.mark(rct,*vx,*vy,mark); return rct;}
TPCI2(V1,V2) rctmanip3<V1*,V2*,int>mark2   (V1&vx,V2&vy,int mark){rctmanip3<V1*,V2*,int>r(rchart_markvec3,&vx,&vy,mark);return r;}







struct bound4 {double x0,y0, x1,y1;
  void set2(double xa,double ya, double xb,double yb){x0=xa;y0=ya; x1=xb;y1=yb;}
};

//*example: rct<<line1(1,1, 10,20);
inline TRChart&  rchart_line1(bound4 r,TRChart& rct){rct.Line(r.x0,r.y0,r.x1,r.y1); return rct;}
inline rctmanip<bound4> line1(double x0,double y0, double x1,double y1)
{rctmanip<bound4>r;r.fn=rchart_line1; r.t.set2(x0,y0,x1,y1); return r;}

//*example: rct<<range(0,0, 10,20);
inline TRChart&  rchart_range(bound4 r,TRChart& rct){rct.SetRange(r.x0,r.y0,r.x1,r.y1); return rct;}
inline rctmanip<bound4> range(double x0,double y0, double x1,double y1)
{rctmanip<bound4>r;r.fn=rchart_range; r.t.set2(x0,y0,x1,y1); return r;}

//*example: rct<<ellipse(0,0, 10,20);//(0,0) is the center
inline TRChart&  rchart_ellipse(bound4 r,TRChart& rct){rct.Ellipse(r.x0,r.y0,r.x1,r.y1); return rct;}
inline rctmanip<bound4> ellipse(double x0,double y0, double x1,double y1)
{rctmanip<bound4>r;r.fn=rchart_ellipse; r.t.set2(x0,y0,x1,y1); return r;}

//*example: rct<<ellipse(0,0, 10,20);//(0,0) is the center
inline TRChart&  rchart_rect(bound4 r,TRChart& rct){rct.Rectangle(r.x0,r.y0,r.x1,r.y1); return rct;}
inline rctmanip<bound4> rect(double x0,double y0, double x1,double y1)
{rctmanip<bound4>r;r.fn=rchart_rect; r.t.set2(x0,y0,x1,y1); return r;}

};//namespace di5{

class  rctpanel { public:
	int			setrc	(size_t ROW, size_t COL);
	int			setrange();
	TRChart&	rct		(size_t row, size_t col);
	TRChart&	rct		(size_t row){return rct(row,0);}
	TRChart&	operator()(size_t row, size_t col){return rct(row,col);}
	TRChart&	operator()(size_t row){return rct(row,0);}
public:
	void	rim	(char dir, int n);//* dir ='t' 'b' 'l' 'r'
	void	rim	(char dir, int n, size_t row, size_t col);
public:
	void	ndecx(int d);
	void	ndecy(int d);
	void	ndecx(int d, size_t row, size_t col);
	void	ndecy(int d, size_t row, size_t col);
public:
	rctpanel():pnl(NULL),ROW(0),COL(0),menu(NULL),menucnt(0){createmenu();}
	void	setmenu();
//	   ~rctpanel();
	vector<TRChart*> 	v;
	size_t 				ROW, 	COL;
	TPanel* 			pnl;
	TPopupMenu*			menu;	int menucnt;
	bool	dele();
	void	panel(TPanel* pnl1){pnl=pnl1;setmenu();}
//	void	menu (TPopupMenu*menu1){men=menu1;setmenu();}
//	void	menuclick(TObject*Sender);
	void __fastcall PopupMenuItemsClick(TObject *Sender);
	void	createmenu();
//	void	panel(TApplication* appl1, TPanel* pnl1){appl=appl1;pnl=pnl1;}
};


#include <spiosdl.cc>
/*
#undef TPC(X)
#undef TPC1(X)
#undef TPC2(X)
#undef TPC3(X)
#undef TPCI(X)
#undef TPCI1(X)
#undef TPCI2(X)
#undef TPCI3(X)
*/
#endif //#ifndef SPIOSDL_H

