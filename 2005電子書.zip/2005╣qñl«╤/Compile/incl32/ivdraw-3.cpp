//
// file ivdraw.cpp
//

#ifndef IVDRAW_CPP
#define IVDRAW_CPP

#include <ivdraw.h>
#include <vwin.h>
#include <math.h>

static int fontsizeU[]={ 6, 6, 8, 8, 8,10,12,13,14,16,18,20,24,40,48, 60 };
static int fontsizeS[]={ 8, 8,10,10,12,14,16,18,20,24,28,32,40,60,72, 96 };
static int fontsizeL[]={ 8,10,11,12,14,16,18,20,24,28,32,36,48,72,96,128 };

char*	ivdrawetc_::fontinfo()
{
	chars* s=getcharsbuf();
  s->app( tos(fontsizeL[ithfontsize]*72/120) ); s->app("//");
	s->app( tos(fontsizeS[ithfontsize]*72/120) );
}

void	ivdrawetc_::setfont(int ithsize1)
{
	int M=sizeof(fontsizeU)/sizeof(int);
	int newsize=ithsize1; if(ithsize1==-1) newsize=0; if(ithsize1<-1) newsize=12;
	if( (ithfontsize>=0)&&(newsize==ithfontsize) ) return;
	if(newsize>=M) newsize=M-1;
	ithfontsize=newsize;
	uf.create(fontsizeU[ithfontsize]);
	sf.create(fontsizeS[ithfontsize]);
	lf.create(fontsizeL[ithfontsize]);
	sfheight=sf.height();
	lfheight=lf.height();
	setgap(fontsizeL[ithfontsize]);
}






static char SSmark=0x01; // SuperScript mark
static char DHmark=0x02; // DiauHing mark

void  nrhtransform( char* t ) // transform t when \n\r\h;
{
  int n012;
  while(*t) {
  	n012=is012(t);
  	if( (n012==1)&&(*t=='\\') ){
    	if((t[1]=='r')||(t[1]=='h')) *t=DHmark;
      else *t=SSmark;
    }
    t+=n012;
  }
}




struct imzet1_ {
  imzet1_(){clear();}
	int  s, g, q, p, r, d, hasd;//siann, gaiim, qianim, pinn,rip,diau, hsadiau
  char im[20]; int imsz; // remember the im1 to im
  void clear(){s=g=q=p=r=d=hasd=0;im[0]=0;}
  int  len()  {return s+g+q+p+r+d; }
  int  cumu() { hasd=d; int ns=s; g+=s; q+=g; p+=q; r+=p; d+=r; s-=ns;g-=ns;q-=ns;p-=ns;r-=ns;d-=ns;return 1;}
	int  imzet1to6parts(char* im1);
  int  checkset4unvor_m (char* imsub);
  int  checkset4unvor_ng(char* imsub);
  int  isgood () { hasd=d; return (imsz==len()); }
 	int  isin(char c, char* in){while(*in)if(c==*in++)return 1;return 0;}
  int  is_aeiou(char c){static char s[]="aeiou";return isin(c,s);}
  char*to4ivdraw( int nn_ben, int d_move, char qiqen);
  char*_5gaidiau( char d, char qiqen);
};

char* imzet1_ :: _5gaidiau( char d, char qiqen)
{
	static chars ss; ss.clear();
	switch (qiqen) {
  case 'h':
  	switch(d){
    case '1': ss.app(" 5 5");break;
    case '2': ss.app(" 1 5");break;
    case '3': ss.app(" 2 1 5");break;
    case '4': ss.app(" 5 1");break;
    case '5': ss.app(" 3 0");break;
    }break;
  case 'k':
  	switch(d){
    case '1': ss.app(" 5 1");break;
    case '2': ss.app(" 2 4");break;
    case '3': ss.app(" 1 1");break;
    case '4': ss.app(" 5 5");break;
    case '5': ss.app(" 5 5");break;
    case '7': ss.app(" 3 3");break;
    case '8': ss.app(" 2 1");break;
    }break;
  case 'm':
  	switch(d){
    case '1': ss.app(" 2 4");break;
    case '2': ss.app(" 3 1");break;
    case '3': ss.app(" 5 5");break;
    case '4': ss.app(" 3 1");break;
    case '5': ss.app(" 1 1");break;
    case '8': ss.app(" 5 5");break;
    }break;
  case 'd':  default:
  	switch(d){
    case '1': ss.app(" 5 5");break;
    case '2': ss.app(" 3 3");break;
    case '3': ss.app(" 2 1");break;
    case '4': ss.app(" 5 1");break;
    case '5': ss.app(" 2 1 5");break;
    case '6': ss.app(" 5 4");break;
    case '7': ss.app(" 4 3");break;
    case '8': ss.app(" 2 1");break;
    case '9': ss.app(" 2 5");break;
    }
  }
  str_replace(ss.s, ' ', SSmark);
  return ss.s;
}

char* imzet1_ :: to4ivdraw( int nn_ben, int diauhing, char qiqen)
{
	static	chars ss; ss.clear();
  ss.app(im, s);
	int n;//=q;
  //ss.app(im+s+g, 1);
  if( (diauhing==1)&&(hasd==1) ){
  	if(qiqen=='d'){ n=g+q;
    	ss.app(im+s,1);
      ss.app(DHmark); ss.app(im+s+g+q+p+r, d);
      ss.app(im+s+1, n-1);
    }else{ n=q;
    	ss.app(im+s, g+1);
      ss.app(DHmark); ss.app(im+s+g+q+p+r, d);
	    ss.app(im+s+g+1, n-1);
    }
  }else
  	ss.app(im+s, g+q);
//	if( (diauhing==1)&&(hasd==1) ){ss.app(DHmark); ss.app(im+s+g+q+p+r, d);}
//	ss.app(im+s+1, n-1);
  n=s+g+q;
  if( (nn_ben)&&(im[n]=='n')&&(im[n+1]=='n') )
  	{ ss.app(SSmark); ss.app("n"); }
  else { ss.app(im+n,p); }
  n+= p;
  ss.app(im+n,r);
  n+= r;
  if( (diauhing==2)&&(hasd) ){ss.app(SSmark); ss.app(im+n,  1);	}
  if( (diauhing==3)&&(hasd) ){ss.app(_5gaidiau(*(im+n), qiqen));}
  nrhtransform(ss.s);
  strcpy(im, ss.s);
  return im;
}



int imzet1_ :: imzet1to6parts(char* im1)
{
  imsz=strlen(im1);
  if(imsz>12) return 0; // too long to be imzet1
  clear();
  strcpy(im, im1);
	static char siann[]="bpmvfdtlgkqzcsrh";
  char* t=im;
  if(*t=='m') { if(checkset4unvor_m (im)) return isgood(); }
  if(*t=='n') { if(checkset4unvor_ng(im)) return isgood(); }
	if(*t=='n') { if((t[1])&&(t[1]=='q')) { s=2; t+=2; } else {s=1;t+=1;} }
  if( isin(*t, siann) ) { s++; t++; }
  if( *t=='h' ) { s++; t++; }
  //for gaiyim and huaqi y/w
  switch(*t){
  case 'w': g=1; t++; break;
  case 'i':	if( (t[1]!='i')&&is_aeiou(t[1]) ) { g=1; t++; } break;
  case 'u':	if(is_aeiou(t[1])) { g=1; t++; } break;
  case 'y': if(t[1]=='u')
  						if(is_aeiou(t[2])){g=2; t+=2;}
              else { g=1; t++; } // yu must be quanyim
  					else { g=1; t++; }
            break;
  }
  //if( (*t=='y')||(*t=='w') ) { g=1; t++; }
  // now for unvor except the yu- case
  if(*t=='m') { if(checkset4unvor_m (t)) return isgood(); }
  if(*t=='n') { if(checkset4unvor_ng(t)) return isgood(); }
	int ll=0;
	//int ll=q;
  while(is_aeiou(t[ll])) ll++;
  if(t[ll]=='r') ll++;
  if(t[ll]=='r') ll++;
  else if(t[ll]=='\\') ll+=2; // for \h \r hat
  q=ll;
  t+=ll;
  // now for pinnvue
  if(*t=='m') p=1;  else
  if(*t=='n') {
  	if((t[1])&&t[1]=='n') { p=2; } else
  	if((t[1])&&t[1]=='g') { p=2; } else
    p=1;
  }
  t+=p;
  // now for rip-vue
  if( (r<=0)&&( (*t=='p')||(*t=='t')||(*t=='k')||(*t=='h') ) ){ r=1; t++; }
  // now for sianndiau
  if(isdigit(*t)) d=1;
  if((t[1])&& (isdigit(t[0])) )d++;
  hasd=d;
  return isgood();
}

int ivdraw_::idqtransform(char* im) // transform im to iwork;
{
	imzet1_ iz1; int para=0;
	iwork.clear(); static charspp temp; static chars ss;
  if(im[0]=='(') { // considering cases like (a1)
  	ss.set2(im+1);
    if(ss.lastbyte()==')') { para=1; ss.dellastbyte(); }
  }else ss.set2(im);
  temp.set2Nhunhanlor(ss.s); char* t;
  if(para){ iwork.app('('); }
  for(int n=0, NN=temp.size(); n<NN; n++) {
  	t=temp[n];
  	if( str_hashanri(t)||(*t=='-')||ispunct(*t) )
    	{ iwork.app(*t); continue; }
		if( (etc.qiqen=='d')&&(etc.get_diauhing()==1) )
			str_del4kauqidiau(t);
    if(!iz1.imzet1to6parts(t))
    	iwork.app(t); //something wrong in im
		iwork.app(iz1.to4ivdraw(etc.get_sn(),etc.get_diauhing(), etc.qiqen));
    if(n<NN-1) { iwork.app(SSmark); iwork.app(SSmark);}//4 gapim
  }
  if(para){iwork.app(')');}
	return 1;
}

int imzet1_ :: checkset4unvor_m(char* imsub)
{
  char* t=imsub;
  if(*t=='m') {
  	t++;
  	if(t[0]&&(t[0]=='h')) { q=1; r=1; t++; }
    if( (t[0]) && (isdigit(t[0])) )
      	{ q=1; d=1; if((t[1])&& (isdigit(t[0])) )d++; return 1; }
    if(q>0) return 1;
  }
  return 0;
}

int imzet1_ :: checkset4unvor_ng(char* imsub)
{
  char* t=imsub;
  if( (*t=='n')&&(t[1])&&(t[1]=='g') ){
  	t++; t++;
  	if(t[0]&&(t[0]=='h')) { q=2; r=1; t++; }
    if( (t[0])&&(isdigit(t[0])) )
      	{ q=2; d=1; if((t[1])&& (isdigit(t[0])) )d++; return 1; }
    if(q>0) return 1;
  }
  return 0;
}
char* ivdraw_::SStext		(char* t)
{
	static chars s; s.clear();
  int n012;
  while(*t) {
  	n012=is012(t);
    if( (n012==1) ) {
    	if( *t==SSmark ) {
      	if(t[1]==SSmark){s.app(" ");}else{ s.app(t+1,1);}
        t+=2; continue;
      }else if( *t==DHmark ) { t+=2; continue; }
    }
    t+=n012;
  }
  return s.s;
}

char* ivdraw_::NONSStext(char* t)
{
	static chars s; s.clear();
  int n012;
  while(*t) {
  	n012=is012(t);
    if( (n012==1) && ( (*t==SSmark)||(*t==DHmark) ) ) {
    	t+=2; continue;
    }
    s.app(t,n012);
    t+=n012;
  }
  return s.s;
}

int ivdraw_::textout(HDC hdc1,int selected, RECT rect, char* vun, char* im)
{
	hdc=hdc1;
	etc.selectfont(hdc);
	si=im;
	str_replace(si.s, '=', ' ');
	si1=si.s; sv=vun;
	str_replace(sv.s, '=', ' ');
  sppi.set2Nhun(si1.s); sppv.set2Nhun(sv.s);
  static char nullstr[]=""; char* ti, *tv; int width;
  int left=rect.left;
  rect.left+=20;
  int N=sppv.size(); if(sppi.size()>N) N=sppi.size();
  for(int n=0; n<N; n++) {
  	ti=(n>sppi.size()-1)?nullstr:sppi[n];
  	if(!str_hashanri(ti)) {
  		if( (ti[0])&&(ti[0]=='(')&&(ti[1])&&(ti[1]==')') ) ti=nullstr;
    	idqtransform(ti); ti=iwork.s;
    }
    tv=(n>sppv.size()-1)?nullstr:sppv[n];
    if( (tv[0]=='-')&&(tv[1]==0) ) tv=nullstr;
    if( (tv[0]=='(')&&(tv[1]==')')&&(tv[2]==0) ) tv=nullstr;
    nrhtransform(tv);
    width=textoutsu(selected, rect, tv, ti);
    rect.left+=(width+etc.gapsu);
  }
	etc.restorefont();
  return rect.left-left;
}

SIZE ivdraw_::gettext_su(char* vun, char* im)
{
	si=im;	sv=vun;
  char* ti, *tv; ti=si.s; tv=sv.s;
 	idqtransform(ti);si=iwork;
  ti=si.s;
  nrhtransform(tv);
  return gettext_su0(tv,ti);
}

SIZE ivdraw_::gettext_su0(char* vun, char* im)
{
  char* ti, *tv; ti=im; tv=vun;
	SIZE sz;
	szi.cx=0; szv.cx=0; char* t; int nSS;
  SaveDC(hdc);
  if(etc.getyim()){
  	t=SStext(ti);
    SelectObject(hdc, etc.uf() );
	  GetTextExtentPoint32(hdc, t, strlen(t), &szi); nSS=szi.cx;
  	t=NONSStext(ti);
    SelectObject(hdc, etc.sf() );
	  GetTextExtentPoint32(hdc, t, strlen(t), &szi); szi.cx+=nSS;
  }
  if(etc.getvun()){
  	t=SStext(tv);
    SelectObject(hdc, etc.uf() );
	  GetTextExtentPoint32(hdc, t, strlen(t), &szv); nSS=szv.cx;
  	t=NONSStext(tv);
    SelectObject(hdc, etc.lf() );
	  GetTextExtentPoint32(hdc, t, strlen(t), &szv); szv.cx+=nSS;
  }
  RestoreDC(hdc,-1);
	sz.cx=(szi.cx>szv.cx)?szi.cx:szv.cx;
	sz.cy=(szi.cy>szv.cy)?szi.cy:szv.cy;
  return sz;//(szi.cx>szv.cx)?szi.cx:szv.cx;
}

int 	ivdraw_::getwidth_su		(char* vun, char* im)
{ SIZE sz=gettext_su(vun, im); return sz.cx; }

int 	ivdraw_::getwidth_su0		(char* vun, char* im)
{ SIZE sz=gettext_su0(vun, im); return sz.cx; }

SIZE	ivdraw_::gettext_su		(char* vunim)
{
	static charspp spp; spp.set2Nhunplus(vunim);
	return gettext_su(spp[0],spp[1]);
}

int ivdraw_::textoutsu(         int selected, RECT rect, char* vun1, char* im1)
{
	char* vun, *im;
 	si=im1;	sv=vun1;
  im=si.s; vun=sv.s;
 	idqtransform(im);si=iwork;
  im=si.s;
  nrhtransform(vun);

	int width=getwidth_su0(vun, im);
  int xi,xv;
  int is_e5=0; //static char e52[]="ec2", e5[]="ec5", ze[]="��";
  static char ze[]="��";
  if( (vun[0]==ze[0])&&(vun[1]==ze[1])&&(vun[2]==0) ){
  	if( (im[0]=='e')&&(im[1]==DHmark) ) is_e5=1;
  }
  if(is_e5||ispunct(*im)||(etc.justify== 0))
  		{ xi=rect.left+(width-szi.cx)/2;xv=rect.left+(width-szv.cx)/2;}
  else if	(etc.justify== 1)
  		{ xi=rect.left+width-szi.cx;  xv=rect.left+width-szv.cx; }
  else
  		{ xi=rect.left;  xv=rect.left; }

  int ttt=etc.sfheight; if(!etc.getyim()) ttt=0;
  int base =int(rect.top+ttt*etc.heighttimes);
  int y    =int(base-etc.sfheight*(1+(etc.heighttimes-1)/2));
  int SSoff=     etc.sfheight/8;
  char* t;
	SIZE sz; int dx=0, dx0=0; int xi0=xi;
  SaveDC(hdc);
  if(etc.getyim()&&(*im!=SSmark)){
  	if(!(*vun)) {
    	base +=int(etc.sfheight*((etc.heighttimes-1)*2/3));
      y    +=int(etc.sfheight*((etc.heighttimes-1)*2/3));
      SSoff+=int(etc.sfheight*((etc.heighttimes-1)/8));
    }
    t=im; int n012;
  	while(*t){
    	sz.cx=0;
    	n012=is012(t);
      if( (n012==1)&&( (*t==SSmark)||(*t==DHmark) ) ) {
	    	if((*t==SSmark)) {	t++;
 		    	if(isdigit(*t)||(*t=='n')){
   		 	    SelectObject(hdc, etc.uf() );
     		  	GetTextExtentPoint32(hdc, t, 1, &sz);
       			TextOut(hdc, xi, y-SSoff, t, 1);
	        } else {
  	       	if(*t==SSmark)
 	  	    		if(etc.get_diauhing()<=1) sz.cx=etc.gapim;
   	  	  }
	     	} else {
  	     	if(*t==DHmark){ t++;
    	 			if(isdigit(*t)||(*t=='h')||(*t=='r'))
      	  		drawdiau(hdc, xi0, dx0, base, t[-2], t[0],selected, etc.qiqen);
  	    	}
	      }
      }else{
  		  SelectObject(hdc, etc.sf() );
      	GetTextExtentPoint32(hdc, t, n012, &sz);
       	TextOut(hdc, xi, y, t, n012);
      }
  	  dx=sz.cx; dx0=dx; xi0=xi; xi+=dx;
    	t+=n012;
    }
  }
  if(!etc.getyim()) base+=int(etc.sfheight*((etc.heighttimes-1)*2/3));
  SelectObject(hdc, etc.lf() );
  int n1;
  dx=0; dx0=0;
  int xv0=xv;
	if(etc.getvun()) {
  	t=vun;
    while(*t) {
    	n1=is012(t);
      if( (n1==1) && ( (*t==SSmark)||(*t==DHmark)||(*t=='\\') ) ) {
      	if( ((t[1]=='r')||(t[1]=='h')) ) {
	        drawdiau(hdc, xv0, dx0, int(base+etc.lfheight*1.2), t[-1], t[1],selected, etc.qiqen);
  	      t+=2; continue;
    	  }else if(t[1]=='n'){
     		  SelectObject(hdc, etc.uf() );
        	GetTextExtentPoint32(hdc, t, 1, &sz);
        	TextOut(hdc, xv, base-SSoff, t+1, 1);
          t++;
        }
      }else{
   	    SelectObject(hdc, etc.lf() );
		   	GetTextExtentPoint32(hdc, t, n1, &sz);
  		  TextOut(hdc, xv, base, t, n1);
      }
      dx=sz.cx; dx0=dx; xv0=xv; xv+=dx;
      t+=n1;
    }
  }
  RestoreDC(hdc,-1);
	return width;
}




enum diaugi_ {vorbiau=0,gorbenn,diongbenn,gegang,gorgang,gorgau,gorsing,gordiam,gebenn,divor};
static int daiqi	[]={	vorbiau,gorbenn,vorbiau	 ,gegang ,gorgang, gorgau ,
//static int daiqi	[]={	divor	 ,gorbenn,vorbiau	 ,gegang ,gorgang,
                        gorgang,vorbiau	 ,gegang ,gorsing};
static int kehqi	[]={	vorbiau,gorgang,gorsing	 ,gebenn ,gorbenn, gorbenn,
                        vorbiau,vorbiau	 ,gegang ,vorbiau};
static int miaulik[]={	vorbiau,gorsing,gegang	 ,gorbenn,gegang,  gebenn ,
                        vorbiau,vorbiau	 ,gorbenn,vorbiau};
static int huaqi	[]={	gordiam,gorbenn,gorsing	 ,gorgau ,gorgang, gordiam,
                        vorbiau,vorbiau	 ,vorbiau,vorbiau, divor};

void ivdrawetc_::set1D(int ubiau)
{
	if(ubiau){
		daiqi[1]=gorbenn;		daiqi[2]=vorbiau;
		kehqi[4]=gorgang;		kehqi[5]=gorbenn;
		miaulik[3]=gorbenn;	miaulik[8]=gorgang;
		huaqi[1]=gorbenn;
							
	} else {
		daiqi[1]=vorbiau;		daiqi[2]=gorbenn;
		kehqi[4]=vorbiau;		kehqi[5]=vorbiau;
		miaulik[3]=vorbiau;	miaulik[8]=vorbiau;
		huaqi[1]=vorbiau;
	} 
}

void ivdraw_::
setdiaupoints(point_* pts,int *npt,int diau,int xb,int yb,int xe,int ye,int lw)
{
	*npt=0; int dx, dy; double dxx, dy1; int P,P_1,PP, i;
  double sinx;
	switch (diau) {
	case vorbiau:  return;
	case gorbenn:
	case gebenn:		ye=yb;
	case gorgang:
	case gorsing:
		pts[0].set2(xb, yb);    pts[1].set2(xe, ye);
		pts[3].set2(xb, yb+lw);	pts[2].set2(xe, ye+lw);
		pts[4].set2(xb, yb);
		*npt=5; return;
	case gegang: P=10; // lenght of points must have at least 2*P+3
		dxx=(xe-xb)/3.0; dy1=ye-yb; PP=P*2+2; P_1=P-1;
		for(i=0; i<P; i++) {
    	sinx=sin(i*3.1415926/4/P);
      sinx=sqrt(sinx)+0.2;
			pts[i		  ].set2(int(xb+dxx*i/(P_1)), int(yb+dy1*sinx)   );
			pts[PP-i-1].set2(int(xb+dxx*i/(P_1)), int(yb+dy1*sinx)+lw);
		}
		pts[P  ].set2(xe, ye);
		pts[P+1].set2(xe, ye+lw);
		pts[PP ].set2(xb,yb);		
		*npt=PP+1; return;
	case gorgau: dx=xe-xb; dy=ye-yb; if(dy<2) dy=2;
		pts[0].set2(xb, yb+dy*2/5   ); pts[1].set2(xb+dx*2/5,ye);    pts[2].set2(xe, yb);
		pts[5].set2(xb, yb+dy*2/5+lw); pts[4].set2(xb+dx*2/5,ye+lw); pts[3].set2(xe, yb+lw);
		pts[6].set2(xb, yb+dy*2/5		); 
		*npt=7; return;
	case divor:	dx=xe-xb; dy=ye-yb; if(dy<2) dy=2;
		pts[0].set2(xb, ye   ); pts[1].set2(xb+dx/2,yb);    pts[2].set2(xe, ye);
		pts[5].set2(xb, ye+lw); pts[4].set2(xb+dx/2,yb+lw); pts[3].set2(xe, ye+lw);
		pts[6].set2(xb, ye); 
		*npt=7; return;
	}
}


void ivdraw_::
drawdiau(	HDC hdc, int x,int dx,int base, char c, char diau,
					int selected, char qiqen)
{
	if(!( isdigit(diau)||(diau=='h')||(diau=='r')) ) return;
  int xbeg, xend;
  static POINT pnt[4];
  if(c=='i'){ xbeg=x+dx/12;dx=dx*10/12;	 	xend=xbeg+dx+1;}
  else 			{ xbeg=x+dx/6; dx=dx*4/6;  		xend=xbeg+dx+1;}
	int y=int(base-etc.sfheight*1.2);
  int dy;
  int dg;
  if((diau=='h')||(diau=='r')) dg=divor; else
  switch(qiqen) {
		case 'd': dg=daiqi	[diau-'0'];break;
  	case 'k': dg=kehqi	[diau-'0'];break;
  	case 'm': dg=miaulik[diau-'0'];break;
		case 'h': dg=huaqi	[diau-'0'];break;
    default : dg=daiqi	[diau-'0'];break;
  }
	HRGN hrgn; point_ pts[23]; int npts;  HBRUSH hbrush; int lw=etc.lw;
  if( (c=='i') ) {
  if( (dg==gorbenn)||(dg==gorgang)||(dg==gorgau)||(dg==gorgau)||(dg==divor) ) {
  	int ty=int( y - etc.sfheight*0.03);
		SaveDC(hdc);
    if(selected){SetROP2(hdc,R2_COPYPEN);}
    else				{SetROP2(hdc,R2_NOTMASKPEN);}
		pts[0].set2(xbeg, ty); pts[1].set2(xend,ty);
		pts[2].set2(xend,int(ty+lw*1.5)); pts[3].set2(xbeg,int(ty+lw*1.5));
		pts[4].set2(xbeg,ty);
		hrgn=CreatePolygonRgn((POINT*)pts, 5, ALTERNATE);
		hbrush=(HBRUSH)GetStockObject(BLACK_BRUSH);
		FillRgn(hdc, hrgn, hbrush);
		//Polygon(hdc,(POINT*)pts, npts);
		DeleteObject(hrgn);
    RestoreDC(hdc,-1);
  }
  }
 	//if(selected) {SaveDC(hdc);SetROP2(hdc, R2_NOTCOPYPEN);}
  SaveDC(hdc);
 	if(selected) {SetROP2(hdc, R2_NOTCOPYPEN);}
  //else         {SetROP2(hdc, R2_XORPEN);}
  int xc, yc, b;  npts=0;
  switch (dg) {
  case vorbiau:
  	break;
  case gorbenn:
    y -= int(etc.sfheight*0.015); y--;
		setdiaupoints(pts,&npts, gorbenn, xbeg,y, xend,y, etc.lw);
    break;
  case gegang:
  	y =int(base-etc.sfheight*0.6);
  	dy=int(etc.sfheight*0.08); if(dy<2) dy=2;
		setdiaupoints(pts,&npts, gegang, xbeg,y, xend,y+dy, etc.lw);
    break;
  case gebenn:
  	y =int(base-etc.sfheight*0.5);
  	//dy=int(etc.sfheight*0.08); if(dy<2) dy=2;
		setdiaupoints(pts,&npts,gebenn, xbeg,y, xend,y, etc.lw);
    break;
  case gorgang:
  	dy=int(etc.sfheight*0.125); if(dy<2) dy=2;
    y-=dy/3;y-=2;
		setdiaupoints(pts,&npts, gorgang, xbeg,y, xend,y+dy, etc.lw);
    break;
  case gorsing:
  	dy =int(etc.sfheight*0.12); if(dy<2) dy=2;
    y -=dy*7/10;
		setdiaupoints(pts,&npts, gorsing, xbeg,y+dy, xend,y, etc.lw);
    break;
  case gorgau:
  	dy=int(etc.sfheight*0.11); if(dy<2) dy=2;
		y-=dy/2;
		setdiaupoints(pts,&npts, gorgau, xbeg,y, xend,y+dy, etc.lw);
    break;
  case divor:  //case 'h':  //case 'r':
  	dy=int(etc.sfheight*0.12); if(dy<2) dy=2;
		y-=dy/2;
		setdiaupoints(pts,&npts, divor, xbeg,y, xend,y+dy, etc.lw);
    break;
  case gordiam:
    y -= int(etc.sfheight*0.015); //if(dy<2) dy=2;
    xc=(xbeg+xend)/2;
    yc=y;
    b=etc.lw*2/3;
    if(!selected) { /*SaveDC(hdc);*/ SetROP2(hdc, R2_BLACK);}
    Pie(hdc, xc-b, yc-b, xc+b, yc+b, 0,0,0,0);
    //if(!selected) { RestoreDC(hdc,-1);}
    break;
  }
	if(npts>0) {
		hrgn=CreatePolygonRgn((POINT*)pts, npts, ALTERNATE);
		hbrush=(HBRUSH)GetStockObject(BLACK_BRUSH);
		//FillRgn(hdc, hrgn, hbrush);
		//Polyline(hdc,pts, npts);
		SelectObject(hdc,hbrush);
		Polygon(hdc,pts, npts);
		DeleteObject(hrgn);
	}
	//if(selected) {RestoreDC(hdc,-1);}
 	RestoreDC(hdc,-1);
}



#endif //#ifndef IVDRAW_CPP


#ifdef OLDOLDOLDOLDOLD


void ivdraw_::setvorim(char* im)
{
	char* t=im;
  int possible=-1;
  while(*t) {
  	if((possible<=0)&&is_aeiou(*t)){
    	possible=t-im; t++;
      while(*t){
        if(isspace(*t)) { possible=-1; break; }
      	if(isdigit(*t)) { vipos[t-im]=possible;t++;possible=-1;break;}
        t++;
      }
    }else{
    	switch (*t) {
      case 'm':
        t++; if(!t[0]) break;
      	possible=t-1-im;
        if(isdigit(t[0])){vipos[t-im]=possible;t++;possible=-1;break;}
        if( (t[0]=='h')&&t[1]&&isdigit(t[1]) )
        	{vipos[t-im]=possible;t++;possible=-1;break;}
        possible=-1; break;
      case 'n':
        t++; if( (!t[0])||(t[0]!='g') ) break;
        t++; if( !t[0] ) break;
      	possible=t-2-im;
        if(isdigit(t[0])){vipos[t-im]=possible;t++;possible=-1;break;}
        if( (t[0]=='h')&&t[1]&&isdigit(t[1]) )
        	{vipos[t-im]=possible;t++;possible=-1;break;}
        possible=-1; break;
      default: t++;
      }
    }
  }
}


int ivdraw_::textoutsu(         int selected, RECT rect, char* vun, char* im)
{
	int width=getwidth_su(vun, im);
  setvorim(im);
  int xi,xv;
  if(ispunct(*im)||(etc.justify== 0))
  		{ xi=rect.left+(width-szi.cx)/2;xv=rect.left+(width-szv.cx)/2;}
  else if	(etc.justify== 1)
  		{ xi=rect.left+width-szi.cx;  xv=rect.left+width-szv.cx; }
  else
  		{ xi=rect.left;  xv=rect.left; }

  int ttt=etc.sfheight; if(!etc.pinim) ttt=0;
  int base=rect.top+ttt*etc.heighttimes;
  int y=base-etc.sfheight*(1+(etc.heighttimes-1)/2);
  if(etc.pinim){
  	if(!(*vun)) {
    	base+=etc.sfheight*((etc.heighttimes-1)*2/3);
      y   +=etc.sfheight*((etc.heighttimes-1)*2/3);
    }
	  int len=strlen(im);
	  for(int n=0; n<len; n++) {
    	if(etc.diauhing&&isdigit(im[n])) {
      	int dx=ncumwidth[vipos[n]]-ncumwidth[vipos[n]-1];
      	drawdiau(	hdc, xi+ncumwidth[vipos[n]-1],dx, base,im[vipos[n]],im[n],
        					selected, etc.qiqen);
      } else
		  	TextOut (hdc, xi+ncumwidth[n-1], y, im+n, 1);
  	}
  }
  if(!etc.pinim) base+=etc.sfheight*((etc.heighttimes-1)*2/3);
  TextOut(hdc, xv, base, vun, strlen(vun));
	return width;
}


int ivdraw_::textout(HDC hdc1,int selected, RECT rect, char* vun, char* im)
{
	hdc=hdc1;  si=im; si1=im; sv=vun;
  sppi.set2Nhun(si1.s); sppv.set2Nhun(sv.s);
  static char nullstr[]=""; char* ti, *tv; int width;
  int left=rect.left;
  rect.left+=20;
  int N=sppv.size(); if(sppi.size()>N) N=sppi.size();
  for(int n=0; n<N; n++) {
  	ti=(n>sppi.size()-1)?nullstr:sppi[n];
  	if( (ti[0])&&(ti[0]=='(')&&(ti[1])&&(ti[1]==')') ) ti=nullstr;
    tv=(n>sppv.size()-1)?nullstr:sppv[n];
    width=textoutsu(selected, rect, tv, ti);
    rect.left+=(width+etc.gapsu);
  }
  return rect.left-left;
}




int ivdraw_::getwidth_su(char* vun, char* im)
{
	szi.cx=0;
  if(etc.pinim){
		int len=strlen(im); if(len>nSLEN+2) len=nSLEN;
	  ncumwidth0[0]=0; ncumwidth=ncumwidth0+1;
		GetTextExtentExPoint(hdc, im, len, 10000, &nFIT, ncumwidth, &szi);
    if(etc.diauhing) { int n,nn, delta;
    	for( n=0; n<nFIT; n++) {
      	if(isdigit(im[n])) {
        	delta=ncumwidth[n]-ncumwidth[n-1]-etc.gapim;
        	for( nn=n; nn<nFIT; nn++)	ncumwidth[nn] -= delta;
        }
      }
      szi.cx=ncumwidth[nFIT-1];
    }
  }
  GetTextExtentPoint32(hdc, vun, strlen(vun), &szv);
  return (szi.cx>szv.cx)?szi.cx:szv.cx;
}


int ivdraw_::getwidth_gu(char* vun, char* im)
{
	int width, WIDTH=0;
	si=im; si1=im; sv=vun;
  setvorim(si.s);
  sppi.set2Nhun(si1.s); sppv.set2Nhun(sv.s);
  static char nullstr[]=""; char* ti;
  for(int n=0; n<sppv.size(); n++) {
  	ti=(n>sppi.size()-1)?nullstr:sppi[n];
    width=getwidth_su(sppv[n], ti);
    WIDTH+=(width+etc.gapsu);
  }
  return WIDTH;
}




#endif //OLDOLDOLDOLDOLD



