
//
// file alldngsu.h
//

#ifndef ALLDNGSU_H
#define ALLDNGSU_H

#include <chars.h>
#include <voids.h>
#include <c3dzb.h>
#include <msgbox.h>

class alldngsu_ { public: r2ic3d_* riden; int MAX;
			alldngsu_(r2ic3d_* riden1, int MAX1=5){riden=riden1;MAX=MAX1;}
		 ~alldngsu_() { }
public:
	charspp spp;
	charspp dngsus;
	int set2(char*s);
	int checkAll1suGood();
	int alldngsu();
	int set2Nalldngsu(char*s) { set2(s); dngsus.clear(); return alldngsu(); }
	int find(char* substr){ return riden->find(substr);}
	char* substr(int beg, int end);
	int emit (short* a, int size);
public:
	int   size() { return dngsus.size(); }
	char* ithdngsu(int i) { return dngsus[i]; }
};

#endif //#ifndef ALLDNGSU_H



