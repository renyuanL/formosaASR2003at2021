//
// di5base_i.h
// inline definition for di5base
#ifndef DI5BASE_I_H
#define DI5BASE_I_H

template<size_t BSZ, size_t PSZ>
void
mpool<BSZ,PSZ>::
dllc_pnodes()
{
	pnode* pn;
	while(phead){
		pn=phead;
		phead=phead->next;
		free(pn);
	}
	pn_destroyed=1;
}


template<size_t BSZ, size_t PSZ>
inline int
mpool<BSZ,PSZ>::
allc_pnodes()
{
	pnode* pn=(pnode*)malloc(bsz*psz);
	if(!pn){ uhead=0; return 0; }
	if(pn_destroyed){ return 0; }
	pn->next=phead;phead=pn;
	unode* un; char* cs=(char*)pn; size_t i;
	for(i=0; i<psz;i++){
		un=(unode*)&(cs[i*bsz]);
		un->next=uhead; uhead=un;
	}
	return psz;
}

template<size_t BSZ, size_t PSZ>
inline void*
mpool<BSZ,PSZ>::
allc(size_t bsz1)
{
	if(bsz!=bsz1) return malloc(bsz1);
	if(!uhead){if(!allc_pnodes())return NULL;}
	unode* un=uhead;
	uhead=uhead->next;
	return (void*)un;
}

template<size_t BSZ, size_t PSZ>
inline void
mpool<BSZ,PSZ>::
dllc(void*un1, size_t bsz1)
{
	if(!un1) return;
	if(bsz!=bsz1) { free(un1); return; }
	if(pn_destroyed) return;
	unode* un=(unode*)un1;
	un->next=uhead;
	uhead=un;
}




#endif //#ifndef DI5BASE_I_H


 
