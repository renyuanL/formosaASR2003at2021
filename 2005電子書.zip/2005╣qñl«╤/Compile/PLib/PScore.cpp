#include "PScore.h"
////////////////////////////////////////////////////////////////////
void PScore::Wav2Fea(PWave& wav,PFeature& fea)
{
	m_wav=&wav;
	m_fea=&fea;
        if (m_EngBou.size()!=0)
                m_EngBou.clear();
        if (m_SpecCenBou.size()!=0)
                m_SpecCenBou.clear();
        if (m_VolumnBou.size()!=0)
                m_VolumnBou.clear();
        if (m_VolumnfraTsam.size()!=0)
                m_VolumnfraTsam.clear();

	m_fea->WaveToEnergy(*m_wav,320,160);
        m_fea->WaveToVolumn(*m_wav,320,160);
        m_fea->WaveToZCR(*m_wav,320,160);
        m_fea->WaveToSpecRolloff(*m_wav,320,160,512);
	m_fea->WaveToSpecCentroid(*m_wav,320,160,512);
        m_fea->WaveToEntropy(*m_wav,320,160,512);
        m_fea->WaveToSpectrumFlux(*m_wav,320,512);
}
////////////////////////////////////////////////////////////////////
void PScore::CalBoundary()
{
        float sampleindex;
        float time;
        //ofstream fout;
        //fout.open("energy.txt");
//�p��Energy������

        if (m_EngBou.size()!=0)
                m_EngBou.clear();
        vector<double> Etemp;
        for (int i=0;i<m_fea->m_engBuf.size();i++)
                Etemp.push_back(m_fea->m_engBuf[i]);
        sort(Etemp.begin(),Etemp.end());
        float ethreshold=Etemp.at(int(Etemp.size()*0.3)); //�ۤv�]�w

        for (int i=0;i<m_fea->m_engBuf.size();i++)
        {
            if (m_fea->m_engBuf[i]<=ethreshold)
               m_EngBou.push_back(i);
            else
               m_EngBou.push_back(-1);
        }
        Etemp.clear();
//Boundary
        if (m_EnergyfraTsam.size()!=0)
                m_EnergyfraTsam.clear();
        for (unsigned int j=1;j<m_EngBou.size()-1;j++)
        {
                if ((m_EngBou.at(j)==-1 && m_EngBou.at(j-1)>=0) || (m_EngBou.at(j)>=0 && m_EngBou.at(j-1)==-1))
                {
                        sampleindex=j*(320-160)+320/2;
                        time=sampleindex/16000.0;
                        m_EnergyfraTsam.push_back(time);

                }
        }


        //fout<<"energy"<<endl;
        //fout<<m_EnergyfraTsam.size()<<endl;
       // for (unsigned int i=0;i<m_EnergyfraTsam.size();i++)
                //fout<<m_EnergyfraTsam.at(i)<<endl;

//�NEnergy�ഫ��Boundary�h�e
//Old Energy
//�T�I����k,���L�n���S�����I�N�q?
/*
        if (m_EngBou.size()!=0)
                m_EngBou.clear();
        vector<double> Etemp;
        for (int i=0;i<m_fea->m_engBuf.size();i++)
                Etemp.push_back(m_fea->m_engBuf[i]);
        sort(Etemp.begin(),Etemp.end());

        float ethreshold=Etemp.at(int(Etemp.size()*0.4)); //�ۤv�]�w

        for (int i=2;i<m_fea->m_engBuf.size()-2;i++)
        {
                if ((m_fea->m_engBuf[i]<m_fea->m_engBuf[i-1]) && (m_fea->m_engBuf[i]<m_fea->m_engBuf[i-2]) && m_fea->m_engBuf[i-1]<m_fea->m_engBuf[i-2])
                        if ((m_fea->m_engBuf[i]<m_fea->m_engBuf[i+1]) && (m_fea->m_engBuf[i]<m_fea->m_engBuf[i+2]) && m_fea->m_engBuf[i+1]<m_fea->m_engBuf[i+2])
                                if (m_fea->m_engBuf[i]<=ethreshold)
                                        m_EngBou.push_back(i);
        }
//Boundar
        if (m_EnergyfraTsam.size()!=0)
                m_EnergyfraTsam.clear();
        for (unsigned int j=0;j<m_EngBou.size();j++)
        {
                sampleindex=m_EngBou.at(j)*(320-160)+320/2;
                time=sampleindex/16000.0;
                m_EnergyfraTsam.push_back(time);
        }
        for (unsigned int i=0;i<m_EnergyfraTsam.size();i++)
                fout<<m_EnergyfraTsam.at(i)<<endl;
  */
//�PZero Crossing Rate���X�𭵪�����,��
//�A�ݬ�Spectrum Flux and Entropy�p��w�q�P�p��
//�A�W�[��LFeature!!
//�p��SpecCentroid
/*
        for (int i=2;i<m_fea->m_SpecCentroid.size()-2;i++)
        {
                if ((m_fea->m_SpecCentroid[i]>m_fea->m_SpecCentroid[i-1]) && (m_fea->m_SpecCentroid[i]>m_fea->m_SpecCentroid[i-2]))
                        if ((m_fea->m_SpecCentroid[i]>m_fea->m_SpecCentroid[i+1]) && (m_fea->m_SpecCentroid[i]>m_fea->m_SpecCentroid[i+2]))
                                m_SpecCenBou.push_back(i);

                if ((m_fea->m_SpecCentroid[i]<m_fea->m_SpecCentroid[i-1]) && (m_fea->m_SpecCentroid[i]<m_fea->m_SpecCentroid[i-2]))
                        if ((m_fea->m_SpecCentroid[i]<m_fea->m_SpecCentroid[i+1]) && (m_fea->m_SpecCentroid[i]<m_fea->m_SpecCentroid[i+2]))
                                m_SpecCenBou.push_back(i);
        }

        fout.open("SecCenbou.txt");
        for (unsigned int i=0;i<m_SpecCenBou.size();i++)
                fout<<m_SpecCenBou.at(i)<<endl;
        fout.close();
*/
//�p��Voluman������
        if (m_VolumnBou.size()!=0)
                m_VolumnBou.clear();
        float volumeTh;
        float volumeRatio=0.1;
        float maxvol=0.0;
        for (int i=0;i<m_fea->m_volumnBuf.size();i++)
        {
                if (m_fea->m_volumnBuf[i]>maxvol)
                        maxvol=m_fea->m_volumnBuf[i];
        }
        volumeTh=maxvol*volumeRatio;
        for (int i=0;i<m_fea->m_volumnBuf.size();i++)
        {
                if (m_fea->m_volumnBuf[i]<volumeTh)
                        m_VolumnBou.push_back(i);
                else
                        m_VolumnBou.push_back(-1);
        }

//�NVolumn�ഫ��Boundary�h�e
        if(m_VolumnfraTsam.size()!=0)
                m_VolumnfraTsam.clear();
        for (unsigned int j=1;j<m_VolumnBou.size()-1;j++)
        {
                if ((m_VolumnBou.at(j)==-1 && m_VolumnBou.at(j-1)>=0) || (m_VolumnBou.at(j)>=0 && m_VolumnBou.at(j-1)==-1))
                {
                        sampleindex=j*(320-160)+320/2;
                        time=sampleindex/16000.0;
                        m_VolumnfraTsam.push_back(time);

                }

        }
        //fout<<"Volumn"<<endl;
        //fout<<m_VolumnfraTsam.size()<<endl;
        //for (unsigned int i=0;i<m_VolumnfraTsam.size();i++)
                //fout<<m_VolumnfraTsam.at(i)<<endl;
//�NPitch�ഫ��Boundary�h�e
        if (m_PitchfraTsam.size()!=0)
                m_PitchfraTsam.clear();
        //fout<<"Pitch Value"<<endl;
        //for(int f =0; f<m_fea->m_PitchBuf.size(); f++)
        //{
        // fout<<m_fea->m_PitchBuf[f]<<endl;
        //}
//������MPitch��3�I**************************start
        for(int f =2; f<m_fea->m_PitchBuf.size()-2; f++)
        {
            if(m_fea->m_PitchBuf[f]!=0)
            {
               if((m_fea->m_PitchBuf[f+2]-m_fea->m_PitchBuf[f-2])==0)
               {
                  m_fea->m_PitchBuf[f]=0.0;
                  m_fea->m_PitchBuf[f+1]=0.0;
                  m_fea->m_PitchBuf[f-1]=0.0;
               }
               if (m_fea->m_PitchBuf[f-1]==0 && m_fea->m_PitchBuf[f+1]!=0)
                  if (m_fea->m_PitchBuf[f+2]!=0 && m_fea->m_PitchBuf[f+3]!=0 && m_fea->m_PitchBuf[f+4]==0)
                     {
                        m_fea->m_PitchBuf[f]=0.0;
                        m_fea->m_PitchBuf[f+1]=0.0;
                        m_fea->m_PitchBuf[f+2]=0.0;
                        m_fea->m_PitchBuf[f+3]=0.0;
                     }
            }
            if (m_fea->m_PitchBuf[f]>=500 || m_fea->m_PitchBuf[f]<90)
               m_fea->m_PitchBuf[f]=0.0;
        }

//������MPitch��4�I**************************start        
//������MPitch��3�I**************************end
//Check Pitch���L������M�֤@�Ӫ�
//�o�ج�M�ֱ�,�M��e�᪺pitch frequency���t�Z�h,�n�R���٬O�d�U��,/
//�A�ݰQ��
        for(int f =0; f<m_fea->m_PitchBuf.size(); f++)
        {
            if(m_fea->m_PitchBuf[f]!=0)
            {
               if(m_fea->m_PitchBuf[f+1]==0)
                  if (m_fea->m_PitchBuf[f+2]!=0)
                  {
                     m_fea->m_PitchBuf[f+1]= (m_fea->m_PitchBuf[f]+m_fea->m_PitchBuf[f+2])/2;
                  }
            }
        }

//
        for (int j=1;j<m_fea->m_PitchBuf.size();j++)
        {
                if ((m_fea->m_PitchBuf[j]==0.0 && m_fea->m_PitchBuf[j-1]>0.0) || (m_fea->m_PitchBuf[j]>0.0 && m_fea->m_PitchBuf[j-1]==0.0))
                {
                        //sampleindex=j*(640-160)+640/2;
                        time=m_fea->m_PitchIntvalTime*j;//sampleindex/16000.0;
                        m_PitchfraTsam.push_back(time);
                }
        }
        //fout<<"Pitch"<<endl;
        //fout<<m_PitchfraTsam.size()<<endl;
        //for (unsigned int i=0;i<m_PitchfraTsam.size();i++)
                //fout<<m_PitchfraTsam.at(i)<<endl;
//�NZCR�ഫ��Boundary�h�e
        float ZcrThres=185;
        if (m_ZcrBou.size()!=0)
                m_ZcrBou.clear();
        for (int i=0;i<m_fea->m_ZcrBuf.size();i++)
        {
                if (m_fea->m_ZcrBuf[i]>=ZcrThres)
                  m_ZcrBou.push_back(i);
                else
                  m_ZcrBou.push_back(-1);
        }
//�o�䪺����n�ק�
        //fout<<"Zcr distribution"<<endl;
        for (unsigned int z=2;z<m_ZcrBou.size()-2;z++)
        {
           if (m_ZcrBou.at(z)==-1)
            if(m_ZcrBou.at(z-2)>=0 && m_ZcrBou.at(z+2)>=0)
               m_ZcrBou.at(z)=(m_ZcrBou.at(z-2)+m_ZcrBou.at(z+2))/2;
            //fout<<m_ZcrBou.at(z)<<endl;
        }


        if(m_ZcrfraTsam.size()!=0)
                m_ZcrfraTsam.clear();
        vector<float> temptime;
        for (unsigned int j=1;j<m_ZcrBou.size()-1;j++)
        {
                if ((m_ZcrBou.at(j)==-1 && m_ZcrBou.at(j-1)>=0) || (m_ZcrBou.at(j)>=0 && m_ZcrBou.at(j-1)==-1))
                {
                        sampleindex=j*(320-160)+320/2;
                        time=sampleindex/16000.0;
                        temptime.push_back(time);

                }
        }
        for (unsigned int j=0;j<temptime.size()/2;j++)
        {
                if ((temptime.at(2*j+1)-temptime.at(2*j))>0.01)
                {
                        m_ZcrfraTsam.push_back(temptime.at(2*j));
                        m_ZcrfraTsam.push_back(temptime.at(2*j+1));
                }
        }
        temptime.clear();
        //fout<<"Zcr"<<endl;
        //fout<<m_ZcrfraTsam.size()<<endl;
        //for (unsigned int i=0;i<m_ZcrfraTsam.size();i++)
                //fout<<m_ZcrfraTsam.at(i)<<endl;

//�NSpectrum Centroid�ഫ��Boundary�h�e
        float SpecCenThres=165;
        if (m_SpecCenBou.size()!=0)
                m_SpecCenBou.clear();
        for (int i=0;i<m_fea->m_SpecCentroid.size();i++)
        {
                if (m_fea->m_SpecCentroid[i]>=SpecCenThres)
                  m_SpecCenBou.push_back(i);
                else
                  m_SpecCenBou.push_back(-1);
        }

//�o�䪺����n�ק�
        for (unsigned int z=0;z<m_SpecCenBou.size()-4;z++)
        {
           if (m_SpecCenBou.at(z)!=-1)
            if(m_SpecCenBou.at(z+1)<0 && m_SpecCenBou.at(z+2)<0 && m_SpecCenBou.at(z+3)<0 && m_SpecCenBou.at(z+4)!=-1)
            {
               m_SpecCenBou.at(z+1)=(m_SpecCenBou.at(z)+m_SpecCenBou.at(z+4))/2;
               m_SpecCenBou.at(z+2)=(m_SpecCenBou.at(z)+m_SpecCenBou.at(z+4))/2;
               m_SpecCenBou.at(z+3)=(m_SpecCenBou.at(z)+m_SpecCenBou.at(z+4))/2;
            }
        }

        if(m_SpecCenfraTsam.size()!=0)
                m_SpecCenfraTsam.clear();
        for (unsigned int j=1;j<m_SpecCenBou.size()-1;j++)
        {
                if ((m_SpecCenBou.at(j)==-1 && m_SpecCenBou.at(j-1)>=0) || (m_SpecCenBou.at(j)>=0 && m_SpecCenBou.at(j-1)==-1))
                {
                        sampleindex=j*(320-160)+320/2;
                        time=sampleindex/16000.0;
                        temptime.push_back(time);
                        //m_SpecCenfraTsam.push_back(time);

                }
        }

//�g�L�W���٥�������Check����,�A���U�@�Ӵ��վ���...
//��֬�M�_�X����i..�@���,�n�ް���..�H�ɶ��h����
        for (unsigned int j=0;j<temptime.size()/2;j++)
        {
                if ((temptime.at(2*j+1)-temptime.at(2*j))>0.01)
                {
                        m_SpecCenfraTsam.push_back(temptime.at(2*j));
                        m_SpecCenfraTsam.push_back(temptime.at(2*j+1));
                }
        }
        temptime.clear();
        //fout<<"SpecCentroid"<<endl;
        //fout<<m_SpecCenfraTsam.size()<<endl;
        //for (unsigned int i=0;i<m_SpecCenfraTsam.size();i++)
               // fout<<m_SpecCenfraTsam.at(i)<<endl;

//�NSpectrum Roll�ഫ��Boundary�h�e

//������MSpectrum Roll��3�I**************************start
        for(int f =2; f<m_fea->m_SpecRoll.size()-2; f++)
        {
            if(m_fea->m_SpecRoll[f]!=0)
            {
               if((m_fea->m_SpecRoll[f+2]-m_fea->m_SpecRoll[f-2])==0)
               {
                  m_fea->m_SpecRoll[f]=0.0;
                  m_fea->m_SpecRoll[f+1]=0.0;
                  m_fea->m_SpecRoll[f-1]=0.0;
               }
            }
        }
//������MSpectrum Roll��3�I**************************end
        float SpecRollThres=0;
        if (m_SpecRollBou.size()!=0)
                m_SpecRollBou.clear();
        for (int i=0;i<m_fea->m_SpecRoll.size();i++)
        {
                if (m_fea->m_SpecRoll[i]>SpecRollThres)
                  m_SpecRollBou.push_back(i);
                else
                  m_SpecRollBou.push_back(-1);
        }

        if(m_SpecRollfraTsam.size()!=0)
                m_SpecRollfraTsam.clear();
        for (unsigned int j=1;j<m_SpecRollBou.size()-1;j++)
        {
                if ((m_SpecRollBou.at(j)==-1 && m_SpecRollBou.at(j-1)>=0) || (m_SpecRollBou.at(j)>=0 && m_SpecRollBou.at(j-1)==-1))
                {
                        sampleindex=j*(320-160)+320/2;
                        time=sampleindex/16000.0;
                        m_SpecRollfraTsam.push_back(time);

                }

        }
        //fout<<"SpecRoll"<<endl;
        //fout<<m_SpecRollfraTsam.size()<<endl;
        //for (unsigned int i=0;i<m_SpecRollfraTsam.size();i++)
                //fout<<m_SpecRollfraTsam.at(i)<<endl;
        //fout.close();


}
////////////////////////////////////////////////////////////////////
int PScore::Combine()
{
//�ثeCombine������,�ߤ@���I�O�J���ӳs�����(�Υ����l��,���e�D�O�n��Pitch�����p�U)
//�o�˥ثe�L�k�ѨM
   //ofstream fout;
   //fout.open("Result.txt",ios::out);
   float difftime; //���o�̪�Syllable,��t�諸��,�ç��Syllable��Boundary
   float stime,etime;//��Syllabe���ɶ�
   float astime,aetime;//��𭵪��ɶ�
   float pstime,petime;//Pitch���ɶ�
   float mintime;
   int idx;  //�s��Syllable�� INDEX
//�p��Syllable������start
   if (m_SylBou.size()!=0)
      m_SylBou.clear();
   Syl temp;
   for (unsigned int x=0;x<m_VolumnfraTsam.size()/2;x++)
   {
      temp.stime=m_VolumnfraTsam.at(2*x);
      temp.etime=m_VolumnfraTsam.at(2*x+1);
      if (temp.etime-temp.stime>0.08)
         m_SylBou.push_back(temp);
   }
   if (m_SylBou.size()==0)
      return 1;
//Syllable...End,�ثe�HVolumn���D,����Henergy or intensity (��20 log.....��)��Spectrum Roll ����)
//���p�G�HVolumn�N���D����,���ȹJ�����T�j�����ҴN���@�w����,�]�O�n�Q�ר�Robustness
//���U�ӴN�O�p��Pitch�H��Intensity�����D, praat�p�⪺frame���רS���T�w,�H��J�y�������ץh��
//�L�O�p��h����?

//�p��Unvoiced������ �𭵦]��threshold����],���ɷ|�X�{�G�Ӥs�p�@�Ӥs��1,��������,���ӭn�A�[
//��Combine����
//

   if (m_UnvoiceBou.size()!=0)
      m_UnvoiceBou.clear();
   Unvoiced atemp1,atemp2;
   //if (m_ZcrfraTsam.size()!=m_SpecCenfraTsam.size() )
      //return 2;
   for (unsigned int x=0;x<m_ZcrfraTsam.size()/2;x++)
   {
      atemp1.stime=m_ZcrfraTsam.at(2*x);
      atemp1.etime=m_ZcrfraTsam.at(2*x+1);
      for (unsigned int y=0;y<m_SpecCenfraTsam.size()/2;y++)
      {
        atemp2.stime=m_SpecCenfraTsam.at(2*y);
        atemp2.etime=m_SpecCenfraTsam.at(2*y+1);
                if (((atemp1.stime-0.02) <atemp2.stime)&& (atemp2.stime<(atemp1.stime+0.02)))
                        if (((atemp1.etime-0.02) <atemp2.etime)&& (atemp2.etime<(atemp1.etime+0.02)))
                        {
                                atemp1.stime=(atemp1.stime+atemp2.stime)/2;
                                atemp1.etime=(atemp1.etime+atemp2.etime)/2;
                                m_UnvoiceBou.push_back(atemp1);

                        }

      }
   }

   int count=0;//���X�ئP�˱��p,unvoice��ӦbSyllable�ح�����,��X��
   for (unsigned int i=0;i<m_UnvoiceBou.size();i++)
   {
      astime=m_UnvoiceBou.at(i).stime;
      aetime=m_UnvoiceBou.at(i).etime;
      idx=-1;
      mintime=100;
      for (unsigned int j=0;j<m_SylBou.size();j++)
      {
         stime=m_SylBou.at(j).stime;
         etime=m_SylBou.at(j).etime;
         if (astime>stime && aetime<etime)
         {
            idx=j;
            count++;
            break;
         }
         difftime=stime-aetime;
         if (difftime<0)
            difftime=-difftime;
         if (difftime<mintime)
         {
            mintime=difftime;
            idx=j;
         }
      }
      if (idx>=0)
      {
          m_SylBou.at(idx).airvoice.stime=m_UnvoiceBou.at(i).stime;
          m_SylBou.at(idx).airvoice.etime=m_UnvoiceBou.at(i).etime;
      }
   }
   //fout<<count<<endl;
   Syl *psyl;
   psyl=new Syl[count];
   count=0;
   for (unsigned int j=0;j<m_SylBou.size();j++)
   {
         if (m_SylBou.at(j).airvoice.stime>m_SylBou.at(j).stime)
            if (m_SylBou.at(j).airvoice.etime<m_SylBou.at(j).etime)
            {
               psyl[count].etime=m_SylBou.at(j).etime;
               m_SylBou.at(j).etime=m_SylBou.at(j).airvoice.stime-0.01;
               psyl[count].stime=m_SylBou.at(j).airvoice.stime;
               psyl[count].airvoice.stime=m_SylBou.at(j).airvoice.stime;
               psyl[count].airvoice.etime=m_SylBou.at(j).airvoice.etime;
               etime=m_SylBou.at(j).etime;
               stime=m_SylBou.at(j).stime;
               idx=-1;
               mintime=100;
               for (unsigned int i=0;i<m_UnvoiceBou.size();i++)
               {
                  astime=m_UnvoiceBou.at(i).stime;
                  aetime=m_UnvoiceBou.at(i).etime;
                  if (astime>=stime && aetime>=etime)
                  {
                     break;
                  }
                  difftime=stime-aetime;
                  if (difftime<0)
                     difftime=-difftime;
                  if (difftime<mintime)
                  {
                     mintime=difftime;
                     idx=i;
                  }
               }
               if (idx>=0)
               {
                  m_SylBou.at(j).airvoice.stime=m_UnvoiceBou.at(idx).stime;
                  m_SylBou.at(j).airvoice.etime=m_UnvoiceBou.at(idx).etime;
               }
               else
               {
                  m_SylBou.at(j).airvoice.stime=0.0;
                  m_SylBou.at(j).airvoice.etime=0.0;
               }
               count++;
            }
   }

   //��s�����i�h
   for (int h=0;h<count;h++)
   {
      m_SylBou.push_back(psyl[h]);
   }

   //�e���ŧi�LSyl temp;
   //Syl temp;
   //Bible sort...��w�ƧǪk
   for (int i=0;i<=(m_SylBou.size()-1);i++)
      for (int j=(m_SylBou.size()-1);j>i;j--)
      {
         if (m_SylBou.at(j-1).stime>m_SylBou.at(j).stime)
         {
            temp=m_SylBou.at(j-1);
            m_SylBou.at(j-1)=m_SylBou.at(j);
            m_SylBou.at(j)=temp;
         }
      }

      //Unvoiced End,(spectrum Centroid and ZCR)
   if (m_VoicedBou.size()!=0)
      m_VoicedBou.clear();
//�p��Voice....Pitch������
//�����J��s�����L�k���},�d���n�ή𭵤��},�i�Opitch�o�O�s�b�@�_��
//�n���M�s��J���Ӧ�pitch���l������,�p�G�s�ۤ]�����}
//�̫�,�٦������T�q,�o�O���,������M����80.xxxxx,�ݭn�B�z��?

   Voiced vtemp;
   for (unsigned int x=0;x<m_PitchfraTsam.size()/2;x++)
   {
      vtemp.stime=m_PitchfraTsam.at(2*x);
      vtemp.etime=m_PitchfraTsam.at(2*x+1);
      if (vtemp.etime-vtemp.stime>0.1)
            m_VoicedBou.push_back(vtemp);
   }

   count=0;
   for (unsigned int i=0;i<m_VoicedBou.size();i++)
   {
      pstime=m_VoicedBou.at(i).stime;
      petime=m_VoicedBou.at(i).etime;
      for (unsigned int j=0;j<m_SylBou.size();j++)
      {
         stime=m_SylBou.at(j).stime;
         etime=m_SylBou.at(j).etime;
         if (pstime>=(stime-0.06))
            if (petime<=(etime+0.06))
            {
               if (m_SylBou.at(j).pitchvoice.stime!=0.0)
                  count++;
               m_SylBou.at(j).pitchvoice.stime=m_VoicedBou.at(i).stime;
               m_SylBou.at(j).pitchvoice.etime=m_VoicedBou.at(i).etime;
               break;
            }
      }
   }
   //fout<<count<<endl;
   delete [] psyl;
   psyl=new Syl[count];
   count=0;
   for (unsigned int i=0;i<m_VoicedBou.size();i++)
   {
      pstime=m_VoicedBou.at(i).stime;
      petime=m_VoicedBou.at(i).etime;
      for (unsigned int j=0;j<m_SylBou.size();j++)
      {
         stime=m_SylBou.at(j).stime;
         etime=m_SylBou.at(j).etime;
         if (pstime>=(stime-0.06))
            if (petime<=(etime+0.06))
            {
               if (m_SylBou.at(j).pitchvoice.stime!=pstime)
               {
                  psyl[count].stime=m_SylBou.at(j).stime;
                  psyl[count].etime=m_VoicedBou.at(i).etime;
                  psyl[count].airvoice.stime=m_SylBou.at(j).airvoice.stime;
                  psyl[count].airvoice.etime=m_SylBou.at(j).airvoice.etime;
                  psyl[count].pitchvoice.stime=m_VoicedBou.at(i).stime;
                  psyl[count].pitchvoice.etime=m_VoicedBou.at(i).etime;
                  count++;
                  m_SylBou.at(j).stime=m_VoicedBou.at(i).etime+0.01;
                  m_SylBou.at(j).airvoice.stime=0.0;
                  m_SylBou.at(j).airvoice.etime=0.0;
               }
               break;
            }
      }
   }

   //��s�����i�h
   for (int h=0;h<count;h++)
   {
      m_SylBou.push_back(psyl[h]);
   }
   delete [] psyl;

   //�e���ŧi�LSyl temp;
   //Syl temp;
   //Bible sort...��w�ƧǪk
   for (int i=0;i<=(m_SylBou.size()-1);i++)
      for (int j=(m_SylBou.size()-1);j>i;j--)
      {
         if (m_SylBou.at(j-1).stime>m_SylBou.at(j).stime)
         {
            temp=m_SylBou.at(j-1);
            m_SylBou.at(j-1)=m_SylBou.at(j);
            m_SylBou.at(j)=temp;
         }
      }

//End Pitch...

   for (unsigned int i=0;i<m_SylBou.size();i++)
   {
      if (m_SylBou.at(i).airvoice.stime!=0.0)
         if (m_SylBou.at(i).stime>m_SylBou.at(i).airvoice.stime)
             m_SylBou.at(i).stime=m_SylBou.at(i).airvoice.stime;
      if (m_SylBou.at(i).pitchvoice.etime!=0.0)
         if (m_SylBou.at(i).etime<m_SylBou.at(i).pitchvoice.etime)
             m_SylBou.at(i).etime=m_SylBou.at(i).pitchvoice.etime;
      if (m_SylBou.at(i).pitchvoice.stime!=0.0)
         if (m_SylBou.at(i).stime>m_SylBou.at(i).pitchvoice.stime)
             m_SylBou.at(i).stime=m_SylBou.at(i).pitchvoice.stime;
   }
 
   m_fea->WaveToSpecFlux(*m_wav,m_SylBou,m_UnvoiceBou);

   //Bible sort...��w�ƧǪk
   for (int i=0;i<=(m_SylBou.size()-1);i++)
      for (int j=(m_SylBou.size()-1);j>i;j--)
      {
         if (m_SylBou.at(j-1).stime>m_SylBou.at(j).stime)
         {
            temp=m_SylBou.at(j-1);
            m_SylBou.at(j-1)=m_SylBou.at(j);
            m_SylBou.at(j)=temp;
         }
      }
/**/
/*
   count=0;
   for (unsigned int i=1;i<m_SylBou.size();i++)
   {
      if ((m_SylBou.at(i).stime-m_SylBou.at(i-1).etime)>0.04)
         count++;
   }
   psyl=new Syl[count];
*/
//�L�X��
   /*
   fout<<"Syllabe����u"<<endl;
   for (unsigned int i=0;i<m_SylBou.size();i++)
   {
      fout<<"��"<<i+1<<"�ӭ��`"<<endl;
      fout<<"�_�l:"<<m_SylBou.at(i).stime<<endl;
      fout<<"����:"<<m_SylBou.at(i).etime<<endl;
      fout<<"�𭵪���u"<<endl;
      fout<<"�𭵰_�l:"<<m_SylBou.at(i).airvoice.stime<<endl;
      fout<<"�𭵵���:"<<m_SylBou.at(i).airvoice.etime<<endl;
      fout<<"Pitch����u"<<endl;
      fout<<"Pitch�_�l:"<<m_SylBou.at(i).pitchvoice.stime<<endl;
      fout<<"Pitch����:"<<m_SylBou.at(i).pitchvoice.etime<<endl;
   }

   fout.close();
   */
   return 3;

}
////////////////////////////////////////////////////////////////////
void PScore::GetAnswer()
{
        //ofstream fout;
        //fout.open("Answer.txt",ios::out);
        if (m_Result.size()!=0)
                m_Result.clear();
        m_Result.push_back(m_SylBou.at(0));
        Syl temp;
        float before,after;
        for (unsigned int i=1;i<m_SylBou.size();i++)
        {
                before=m_SylBou.at(i-1).etime;
                after=m_SylBou.at(i).stime;
                if (after-before>0)
                {
                        temp.stime=before;
                        temp.etime=before+(after-before);
                        m_Result.push_back(temp);
                }
                m_Result.push_back(m_SylBou.at(i));
        }
        /*
        fout<<"Syllabe����u"<<endl;
        for (unsigned int i=0;i<m_Result.size();i++)
        {
                fout<<"��"<<i+1<<"�ӭ��`"<<endl;
                fout<<"�_�l:"<<m_Result.at(i).stime<<endl;
                fout<<"����:"<<m_Result.at(i).etime<<endl;
                fout<<"�𭵪���u"<<endl;
                fout<<"�𭵰_�l:"<<m_Result.at(i).airvoice.stime<<endl;
                fout<<"�𭵵���:"<<m_Result.at(i).airvoice.etime<<endl;
                fout<<"Pitch����u"<<endl;
                fout<<"Pitch�_�l:"<<m_Result.at(i).pitchvoice.stime<<endl;
                fout<<"Pitch����:"<<m_Result.at(i).pitchvoice.etime<<endl;
        }

        fout.close();
       */
}
////////////////////////////////////////////////////////////////////
