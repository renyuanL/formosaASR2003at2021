#ifndef __PWavOutPlay_H
#define __PWavOutPlay_H
#include <windows.h>
#include <mmsystem.h>
#include <process.h>
#include <winbase.h>

/*
void CALLBACK waveInProc(
  HWAVEIN hwi,
  UINT uMsg,
  DWORD dwInstance,
  DWORD dwParam1,
  DWORD dwParam2
);
*/
typedef unsigned long ULONG;

typedef ULONG WINAPI (*THREADFUNC)(void*pv);

class thinthread{
public:
        HANDLE h;
        ULONG id;
	thinthread():h(NULL),id(0){}
        ~thinthread(){dele();}
public:
	void begin(THREADFUNC f, void* obj){
        dele();
        h=CreateThread(NULL,0,f,obj,0,&id);}
        //h=(HANDLE)_beginthreadex(NULL,0,f,obj,0,&id);
	void dele (){if(h) CloseHandle(h);	h=0;}
};

//typedef void WINAPI (IWPROC)(HWAVEOUT hwo,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);

typedef void WINAPI (*OWPROC)(HWAVEOUT hwo,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);

struct eventhandle{ HANDLE h;
	eventhandle	(){create();}
	~eventhandle	(){close ();}
	HANDLE	create	(){ h=CreateEvent(NULL,FALSE,FALSE,NULL);return h;}
	void	reset	(){ ResetEvent(h);	}
	/*
	This method sets the state of the event to 
	nonsignaled until explicitly set to signaled 
	by the SetEvent method
	*/
	void	set		(){ SetEvent(h);	}
	/*
	This method sets the state of the event to signaled, 
	releasing any waiting threads. If the event is manual, 
	the event remains signaled until ResetEvent is called. 
	If the event is automatic, 
	the event remains signaled until a single thread is released.

	*/
	void	close	(){CloseHandle(h);	}
};

class PWavOutPlay
{
public:
	volatile int bOpened;
	volatile int bEnded;
	bool bPlayDiong;
	HWAVEOUT hwo;
	WAVEHDR hdr;
	MMRESULT result;
	WAVEFORMATEX wfex;
	eventhandle evtplayend;
        static void CALLBACK OWPdef(HWAVEOUT hwo,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);
	PWavOutPlay(){};
	~PWavOutPlay(){};

	MMRESULT open(DWORD dwInst,OWPROC p,WAVEFORMATEX *wf=NULL){
		result=waveOutOpen(&hwo,WAVE_MAPPER,wf,(DWORD)p,dwInst,CALLBACK_FUNCTION);
		return result;
	}
	MMRESULT open(WAVEFORMATEX *wf=NULL){return open((DWORD)this,OWPdef,wf);}

	MMRESULT prepare(WAVEHDR* hdr1=NULL){
		return result=waveOutPrepareHeader(hwo,(hdr1)?hdr1:&hdr,sizeof(WAVEHDR));
	}


	MMRESULT write(WAVEHDR* hdr1=NULL){
		return result=waveOutWrite(hwo,(hdr1)?hdr1:&hdr,sizeof(WAVEHDR));
		
	}
	MMRESULT unprepare(WAVEHDR* hdr1=NULL){
		return result=waveOutUnprepareHeader(hwo,(hdr1)?hdr1:&hdr,sizeof(WAVEHDR));
	}

	MMRESULT close(){
		return result=waveOutClose(hwo);
	}
	DWORD getposition();

	void wait2end(){WaitForSingleObject(evtplayend.h,INFINITE);}
	void reset4wait(){evtplayend.reset();}
	int reset(int mswait=0);
        int pause(int mswait=0);
        int restart();

	void sethdr(short*data,int shsize);
	void sleep2end(int ms){if (bPlayDiong) sleep2end0(ms);}
	void sleep2end0(int ms);

};
inline void CALLBACK PWavOutPlay::OWPdef(HWAVEOUT hwo,UINT uMsg, DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
        PWavOutPlay* iwb=(PWavOutPlay*)dwInst;
	switch (uMsg) {
	case WOM_DONE:
		iwb->bPlayDiong=0;
                iwb->evtplayend.set();
		break;
	default:
		break;
	}
}
/*
inline void CALLBACK PWavOutPlay::waveOutProc(HWAVEOUT hwo,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	switch (uMsg) {
	case WOM_DONE:
		//bPlayDiong=0;
		//SetEvent((HANDLE)dwInst);//hEvent_PlayEnd is placed at arg:dwCallbackInst
		break;
	default:
		break;
	}
}
*/
#endif