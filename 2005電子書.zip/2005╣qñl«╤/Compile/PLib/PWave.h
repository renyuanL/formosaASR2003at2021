#ifndef __PWAVE_H
#define __PWAVE_H
#include <windows.h>
#include <fstream.h>
#include <mmsystem.h>
#include "PFft.h"
#include "PMatrix.h"
#include "PBuffer.h"
#include "PPraat.h"
#include "PImage.h"
#include "wavseg.h"
using namespace std;
class PWave
{
private:
        int m_framesize;
        int m_shift;
        WAVEFORMATEX m_pcmWaveFormat;
	int m_length;
	PBuffer m_qbuf;

        short* m_segwav;

        //�s������
        ImageHeader m_heder;
        ImageInfoHeader m_infoheder;
        int m_PixelWidth;
        int m_PixelHeight;
        PMatrix m_Bcolor;
        PMatrix m_Gcolor;
        PMatrix m_Rcolor;
public:
	PWave();
	~PWave();
        int GetSamplesPerSec();
	void load(const char* fn);

        //�B�zTTS�걵����
        void SaveWave(const char* fn);
        void savesegwave(int sw,int ew,const char* file);
        PWave& operator+ (PWave& obj2);
        PWave& operator+=(PWave& obj2);
        //����

        short operator[](long idx)
        {
                return m_qbuf[idx];
        }
        void makewave(PBuffer& buf,int len);
        //short operator[](long idx);
	PBuffer& GetBuf();

	int GetBufLength();

        void plotSpec(HDC hdc,PVector& pit,int hpitch,PVector& eng,int heng);
        void plotWave(HDC hdc);

        void plotDifWave(HDC hdc,int tsize,wseginfo& teacher,int tlen,wseginfo& student,int slen);
        COLORREF getRGB(int mag,int& blue,int& green,int& red);
        void frame2spec(int curOffset,PVector &vec);
        void Spec2Image(const char* fn);
        int getsamplerate(){return m_pcmWaveFormat.nSamplesPerSec;}

};
#endif