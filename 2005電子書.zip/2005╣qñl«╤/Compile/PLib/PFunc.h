#ifndef __PFUNC_H
#define __PFUNC_H
#include <iostream.h>
#include <fstream.h>
#include <STRSTREAM>
class CStrScan:public istrstream
{
private:
   char strbuff[1024];
public:
   CStrScan(): istrstream(strbuff,sizeof(strbuff)){}
   void r2b(char *buff,int size){seekg(0,ios::beg);strcpy(strbuff,buff);}
};
#endif