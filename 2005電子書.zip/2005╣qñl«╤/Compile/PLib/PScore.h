#ifndef __PSCORE_H
#define __PSCORE_H
#include <vector.h>
#include <fstream.h>
#include <algorithm>
#include "PFeature.h"


class PScore
{
private:
        PWave* m_wav;
        PFeature* m_fea;
public:
        PScore(){}
        ~PScore(){}
        vector<int> m_EngBou;
        vector<int> m_VolumnBou;
        vector<int> m_ZcrBou;
        vector<int> m_SpecCenBou;
        vector<int> m_SpecRollBou;
        void Wav2Fea(PWave& wav,PFeature& fea);
        void CalBoundary();

        //�̫ᵲ�G�PCombine
        vector<float> m_VolumnfraTsam;
        vector<float> m_PitchfraTsam;
        vector<float> m_EnergyfraTsam;
        vector<float> m_ZcrfraTsam;
        vector<float> m_SpecCenfraTsam;
        vector<float> m_SpecRollfraTsam;
        //Combined ����
        int Combine();
        vector<Syl> m_SylBou;
        vector<Unvoiced> m_UnvoiceBou;
        vector<Voiced> m_VoicedBou;
        //Last Result
        void GetAnswer();
        vector<Syl> m_Result;
};
#endif
