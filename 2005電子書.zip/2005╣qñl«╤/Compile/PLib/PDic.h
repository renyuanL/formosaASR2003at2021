#ifndef __PDic_H
#define __PDic_H
#include <fstream.h>
#include <windows.h>
#include "PFunc.h"
#include <vector>
struct Mapping
{
        string Li;
        string PingIng;
        Mapping():Li(""),PingIng(""){}
};
class PDic
{
private:
        vector<Mapping> m_Dictable;
        int m_count;
public:
	string addgong(char strLine[]);
	void loadtable(const char* fn);
        vector<string> m_chinese;

	vector<string> m_answer;

        vector<string> m_noexistchinese;
	void searchpinging(const char instring[]);
        int geterrorcount(){return m_count;}

        void getChineseWord(const char strLine[]);
        vector<string> m_ChineseWord;
        
	PDic();
	~PDic();
};
#endif