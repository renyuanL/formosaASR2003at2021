#include "PWavInLokim.h"
//�i��inline�W�[�t��
//inline void PWavInLokim::CALLBACK IWPdef(HWAVEIN,UINT,DWORD dwInst,DWORD,DWORD)

void PWavInLokim::sethdr(short*data,int shsize)
{
	memset(&hdr,0,sizeof(hdr));//�u�O�Nsizeof(hdr)�o�������Ƴ���0
	hdr.lpData=(LPSTR)(data);//�ǧڭ�buffer����m����
	hdr.dwBufferLength=shsize*sizeof(short);//�ڭ̳]�wbuffer������
	/*
	typedef struct {
  	LPSTR lpData;
  	DWORD dwBufferLength;
  	DWORD dwBytesRecorded;
  	DWORD dwUser;
  	DWORD dwFlags;
  	DWORD dwLoops;
  	struct wavehdr_tag* lpNext;
  	DWORD reserved;}
	WAVEHDR;
	*/
	//��L�����γ]�w,�Ϋ�˪�??	
	
}
int PWavInLokim::reset(int mswait)
{
   MMTIME mmt;
	mmt.wType = TIME_SAMPLES;
   waveInGetPosition(hwi, &mmt, sizeof(MMTIME));
	result=waveInReset(hwi);

	/*
	This function stops input on a specified waveform input device
	and resets the current position to 0.
	All pending buffers are marked as done and returned to the application.

	*/
   Sleep(10);
   sleep2end(mswait);
        /*
        if ( waveInGetPosition(hwi, &mmt, sizeof(MMTIME)) ) {
                return -1;
        }
        else {
                return mmt.u.sample;
        }
        */
        return mmt.u.sample;
	//return result;
	//�����򤣬Oreturn MMRESULT ??
}
void PWavInLokim::sleep2end0(int ms)
{
        while (ms>0){if (!bLokImDiong) break;ms-=10;Sleep(10);}
}
