#ifndef __PPlay_H
#define __PPlay_H
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <mmsystem.h>
#include "PBuffer.h"
#include "PWavOutPlay.h"
#include <stdio.h>

class PPlay
{
private:
        int m_qstartpos;
        int m_qendpos;
public:
	PWavOutPlay iw;
	MMRESULT res;

        void load(const char* fn);

        WAVEFORMATEX m_pcmWaveFormat;
        PBuffer qbuf;
        int m_length;

	//int resztplay(){return iw.restart();}
	//�٥�check������
	thinthread thd;
        PBuffer* p2qbuf;
        int shsize;
	int tplay(PBuffer& qbuf);
        int tplay(PBuffer& qbuf,int qstart,int qend);

        bool m_restop;
        int replay(PBuffer& qbuf);
        int resztplay();

	int sztplay();

        int play();
        int waveplay(PBuffer& buf);
        int waveplay(PBuffer& qbufin,int qstart,int qend);
        bool m_bpause;
        int playpause(){iw.pause(10);m_bpause=true;return 1;}
        int playrestart(){
        if (m_bpause)
                return iw.restart();
                m_bpause=false;
        }
        DWORD getPosition();

   	PPlay();
        ~PPlay();

        int playstop(){m_restop=true;iw.reset(10);m_qstartpos=0;m_qendpos=0;return 1;}

        bool isplaying(){return iw.bPlayDiong;}
        void setReset();
   	//static UINT WINAPI thdf(void*p){PPlay&o=(*(PPlay*)p);o.sztplay();o.thd.dele();return 1;}
        static unsigned long WINAPI thdf(void*p){PPlay&o=(*(PPlay*)p);o.sztplay();o.thd.dele();return 1;}

        static unsigned long WINAPI rethdf(void*p){PPlay&o=(*(PPlay*)p);o.resztplay();o.thd.dele();return 1;}
};
#endif