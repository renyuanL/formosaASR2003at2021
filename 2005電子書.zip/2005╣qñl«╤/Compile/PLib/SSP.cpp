#include "SSP.h"
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::fft(float *s,int size , int invert)
{
   int ii,jj,n,nn,limit,m,j,inc,i;
   double wx,wr,wpr,wpi,wi,theta;
   double xre,xri,x;
   
   n=size;
   nn=n / 2; j = 1;
   for (ii=1;ii<=nn;ii++) {
      i = 2 * ii - 1;
      if (j>i) {
         xre = s[j]; xri = s[j + 1];
         s[j] = s[i];  s[j + 1] = s[i + 1];
         s[i] = xre; s[i + 1] = xri;
      }
      m = n / 2;
      while (m >= 2  && j > m) {
         j -= m; m /= 2;
      }
      j += m;
   };
   limit = 2;
   while (limit < n) {
      inc = 2 * limit; theta = TPI / limit;
      if (invert) theta = -theta;
      x = sin(0.5 * theta);
      wpr = -2.0 * x * x; wpi = sin(theta); 
      wr = 1.0; wi = 0.0;
      for (ii=1; ii<=limit/2; ii++) {
         m = 2 * ii - 1;
         for (jj = 0; jj<=(n - m) / inc;jj++) {
            i = m + jj * inc;
            j = i + limit;
            xre = wr * s[j] - wi * s[j + 1];
            xri = wr * s[j + 1] + wi * s[j];
            s[j] = s[i] - xre; s[j + 1] = s[i + 1] - xri;
            s[i] = s[i] + xre; s[i + 1] = s[i + 1] + xri;
         }
         wx = wr;
         wr = wr * wpr - wi * wpi + wr;
         wi = wi * wpr + wx * wpi + wi;
      }
      limit = inc;
   }
   if (invert)
      for (i = 1;i<=n;i++) 
         s[i] = s[i] / nn;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::realfft(float *s , int size)
{
   int n, n2, i, i1, i2, i3, i4;
   double xr1, xi1, xr2, xi2, wrs, wis;
   double yr, yi, yr2, yi2, yr0, theta, x;

   n= size / 2; n2 = n/2;
   theta = PI / n;
   fft(s,size,false);
   x = sin(0.5 * theta);
   yr2 = -2.0 * x * x;
   yi2 = sin(theta); yr = 1.0 + yr2; yi = yi2;
   for (i=2; i<=n2; i++) {
      i1 = i + i - 1;      i2 = i1 + 1;
      i3 = n + n + 3 - i2; i4 = i3 + 1;
      wrs = yr; wis = yi;
      xr1 = (s[i1] + s[i3])/2.0; xi1 = (s[i2] - s[i4])/2.0;
      xr2 = (s[i2] + s[i4])/2.0; xi2 = (s[i3] - s[i1])/2.0;
      s[i1] = xr1 + wrs * xr2 - wis * xi2;
      s[i2] = xi1 + wrs * xi2 + wis * xr2;
      s[i3] = xr1 - wrs * xr2 + wis * xi2;
      s[i4] = -xi1 + wrs * xi2 + wis * xr2;
      yr0 = yr;
      yr = yr * yr2 - yi  * yi2 + yr;
      yi = yi * yr2 + yr0 * yi2 + yi;
   }
   xr1 = s[1];
   s[1] = xr1 + s[2];
   s[2] = 0.0;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
int SSP::ulaw2linear(float *s , int size , int offset)
{
  static int exp_lut[8] = { 0, 132, 396, 924, 1980, 4092, 8316, 16764 };
  int sign, exponent, mantissa, sample , i;
  unsigned char ulawbyte;
	
  if(offset==0) size--;
  	
  for(i = offset ; i <= size ; i++)
  { 
  	ulawbyte = (unsigned char) s[i];
  	ulawbyte = ~ulawbyte;
  	sign = (ulawbyte & 0x80);
  	exponent = (ulawbyte >> 4) & 0x07;
  	mantissa = ulawbyte & 0x0F;
  	sample = exp_lut[exponent] + (mantissa << (exponent + 3));
  	if(sign != 0) sample = -sample;
  	
  	s[i] = sample;
  }	
  return i;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::LowPassFilter(PVector &x,PVector &y,int N)
{
        float b[10]={0.0109,0.0312,0.0876,0.1598,0.2105,0.2105,0.1598,0.0876,0.0312,0.0109};
        //PVector y;
        y.SetLength(x.size());
        float result;
        for (int idy=1;idy<y.size();idy++)
        {
                result=0.0;
                for (int idb=0,idx=idy;idb<10;idb++,idx--)
                {
                        if (idx<=0)
                                break;
                        else
                        {
                                result += (x[idx]*b[idb]);
                        }
                }
                y[idy]=result;
        }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::AutoCorrelation(PVector &y,PVector &ay,int N)
{
        ay.SetLength(N);  //320�I,�q0�}�l
        float sum;
        for (int i=0;i<N;i++)
        {
                sum=0.0;
                for (int j=1;j<=(N-i);j++)
                {
                        sum=sum+y[j]*y[j+i];
                }
                ay[i]=sum/N;
        }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::MaxValue(PVector &x,int start,int end)
{
        float Max=0.0;
        for (;start<end;start++)
        {
                if (x[start]>Max)
                        Max=x[start];
        }
        return Max;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
int SSP::SignalSign(float value)
{
        if (value>0)
                return 1;
        else
                return -1;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
int SSP::CalZeroCrossRate(PVector &x)
{
	int zcr=0;

	for (int n=1;n<(x.size()-1);n++)
	{
		if ((x[n]*x[n+1])<0)
                {
			zcr++;
                }
	}
	return zcr;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::LPF(PVector &x,PVector &y)
{
        float b[10]={0.0109,0.0312,0.0876,0.1598,0.2105,0.2105,0.1598,0.0876,0.0312,0.0109};
        //PVector y;
        y.SetLength(x.size());
        float result;
        for (int idy=0;idy<y.size();idy++)
        {
                result=0.0;
                for (int idb=0,idx=idy;idb<10;idb++,idx--)
                {
                        if (idx<=0)
                                break;
                        else
                        {
                                result += (x[idx]*b[idb]);
                        }
                }
                y[idy]=result;
        }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::CalPitch(PVector &x)
{
        //Male=>50~250Hz
        //FeMale=>120~500Hz
        //��70��280hz������pitch
        //��L�h�L
        int N=x.size()-1;
        PVector lpfx;
        LowPassFilter(x,lpfx,N); //�p�G�����󪺸�,���ӻݭnoperator =�ŧi�bPVector�ض�??

        float ct(0.0),ct1(0.0),ct2(0.0);
        int thirdofframe=N/3;

        ct1=MaxValue(lpfx,1,thirdofframe);
        ct2=MaxValue(lpfx,2*thirdofframe,N);
        //R=0.64�嫬�]��0.64
        ct=0.64*min(ct1,ct2);
        for (int i=1;i<=N;i++)
        {
                if (lpfx[i]>ct){
                        lpfx[i]=lpfx[i]-ct;
                }
                else if (lpfx[i]<ct){
                        lpfx[i]=lpfx[i]+ct;
                }
                else
                {
                        lpfx[i]=0;
                }
        }
        PVector acfy;
        float SecMax=0.0;
        int SecMaxIndex=0;
        AutoCorrelation(lpfx,acfy,N);
        for (int k=1;k<acfy.size()-1;k++)
        {
                if (acfy[k]>SecMax && acfy[k]>acfy[k-1] && acfy[k]>acfy[k+1]) //acfy[k]>SecMax�ݭn���n�令���n������,�M��search��index����W�[?how to do it?
                {
                        SecMax=acfy[k];
                        SecMaxIndex=k;
                }
        }
        float pitch=0.0;
        if (SecMaxIndex!=0) pitch=16000.0/SecMaxIndex;

        return pitch;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::totaleng(PVector &x)
{
	float te=0;
	for(int n=1;n<x.size();n++)
                te += x[n]*x[n];
        return te;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::calVolumn(PVector &x)
{
	float te=0;
        //����Ȫ��`�M�G�o�ؤ�k���p���²��A�u�ݭn��ƹB��A�A�X�Ω�C�����x�]�p�L�q�����^�C
	for(int n=1;n<x.size();n++)
                te += abs(x[n]);
        return te;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::PreEmphasise (PVector &s, float k)
{
   int i;
   float preE;
   
   preE = k;
   for (i= s.size()-1 ; i>= 2 ; i--)
      s[i] -= s[i-1]*preE;
   s[1] *= 1.0f-preE;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::ZeroMeanFrame(PVector &s)
{
   int size,i;
   float sum = 0.0,off;

   size = s.size()-1;
   for (i=1; i<=size; i++) sum += s[i];
   off = sum / size;
   for (i=1; i<=size; i++) s[i] -= off;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void  SSP::doHam(PVector &s)
{
	int i,size;
	float a;
	PVector hamWin;
	hamWin.SetLength(s.size());
   	size=s.size()-1;
	a = TPI / size;
	for (i=1 ;i <= size ; i++)
      		hamWin[i] = 0.54 - 0.46 * cos(a*(i-1));
	
	for ( i=1 ; i <= size ; i++)
		s[i] *= hamWin[i];
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::frame2spec(PVector &vec)
{
  int size=vec.size()-1;

  for(int n=1;n<vec.size();n++)
  	vec[n] = (float)vec[n];///((1 << (16 - 1)) - 1);

  realfft(vec.GetBuffer(),size);

  float real,img;
  for(int i=1;i<=size/2;i++)
  {
      real = vec[2*i-1]  ;  img = vec[2*i];
      //double te =  sqrt(real*real + img*img);
      double te =  real*real + img*img;
      vec[i] = te;
  }
  for (int j=size/2+1,k=size/2;j<=size;j++,k--)
  {
        vec[j]= vec[k];
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::CalEntropy(PVector& vec)
{
        frame2spec(vec);
        int size=vec.size()-1;
        float sumsfk=0.0;
        for (int i=1;i<=size/2;i++)
        {
                sumsfk=sumsfk+vec[i];
        }
        PVector pi;
        pi.SetLength(size+1);
        float fi=8000/size;
        for (int i=1;i<=size/2;i++)
        {
                pi[i]=vec[i]/sumsfk;
                if (((i-1)*(fi))<250 || ((i-1)*(fi))>6000)
                      pi[i]=0.0;
        }
        float H=0.0;
        for (int i=1;i<=size/2;i++)
        {
                if (pi[i]!=0.0)
                {
                        H=H+pi[i]*log(pi[i]);
                }
                else
                {
                        H=H+0.0;
                }
        }
        H=-H;
        return H;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::CalSpecCentroid(PVector &vec)
{
        float Ct=0.0;
        double nMt=0.0;
        double Mt=0.0;
        frame2spec(vec);
        int size=vec.size()-1;
        for (int i=1;i<=size/2;i++)
        {
                //nMt=nMt+(((size/2)-i)*vec[i]);
                nMt=nMt+(i*vec[i]);
                Mt=Mt+vec[i];
        }
        Ct=nMt/Mt;
        return Ct;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::CalSpecDiversity(PVector &vec,float Ct)
{
        double Dt=0.0;
        double nMt=0.0;
        double Mt=0.0;
        frame2spec(vec);
        int size=vec.size()-1;
        for (int i=1;i<=size/2;i++)
        {
                //nMt=nMt+(((size/2)-i)*vec[i]);
                nMt=nMt+(i*i*vec[i]);
                Mt=Mt+vec[i];
        }
        Dt=(nMt/Mt)-pow(Ct,2);
        return Dt;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::CalSpecRolloff(PVector &vec)
{
        float Rt=0.0;
        double Mt=0.0;
        double RMt=0.0;
        frame2spec(vec);
        int size=vec.size()-1;
        for (int i=1;i<=size/2;i++)
        {
                Mt=Mt+vec[i];
        }
        Mt=Mt*0.8;
        for (int i=1;i<=size/2;i++)
        {
                RMt=RMt+vec[i];
                if (abs(RMt-Mt)<100)
                {
                        Rt=(i*8000)/(size/2);
                        break;
                }
        }
        return Rt;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::SpecCentrRatio(PVector &seg)
{
        float Scratio=0.0;
        for (int i=0;i<seg.size();i++)
        {
                Scratio=Scratio+seg[i];
        }
        return (Scratio/seg.size());
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::SpecRollRatio(PVector &seg)
{
        float Srratio=0.0;
        for (int i=0;i<seg.size();i++)
        {
                Srratio=Srratio+seg[i];
        }
        return (Srratio/seg.size());
}
float SSP::PitchRatio(PVector &seg)
{
        float Numofpitch=0.0;
        for (int i=0;i<seg.size();i++)
        {
                if (seg[i]>=70 && seg[i]<=280)
                {
                        Numofpitch++;
                }
        }
        return (Numofpitch/seg.size());
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::HightZcrRatio(PVector &seg)
{
        float avZCR(0.0),Hzcrr(0.0);

        for (int i=0;i<seg.size();i++)
        {
                        avZCR=avZCR+seg[i];
        }
        avZCR=(avZCR*1.5)/seg.size();

        for (int i=0;i<seg.size();i++)
        {
                        Hzcrr=Hzcrr+SignalSign(seg[i]-avZCR)+1;
        }
        Hzcrr=Hzcrr/(2*seg.size());
        return Hzcrr;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::LowstEngRatio(PVector &seg)
{
       float avSTE(0.0),Lster(0.0);
       for (int i=0;i<seg.size();i++)
       {
                avSTE=avSTE+seg[i];
       }
       avSTE=(avSTE*0.5)/seg.size();

       for (int i=0;i<seg.size();i++)
       {
                Lster=Lster+SignalSign(avSTE-seg[i])+1;
       }
       Lster=Lster/(2*seg.size());
       return Lster;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
float SSP::SpectrumFlux(PMatrix& mat)
{
        float spectrumflux=0.0;
        double temp(0.0),sum(0.0);
        
        float deltavalue=0.000001;  //�n�h�֭�?
        
        int size=mat.GetCol()-1;
        for (int i=1;i<mat.GetRow();i++)
        {
                //for (int j=1;j<=(m_specframesize);j++)
                for (int j=1;j<=size;j++)
                {
                        temp=log10(mat[i][j]+deltavalue)-log10(mat[i-1][j]+deltavalue);
                        temp=pow(temp,2);
                        sum=sum+temp;
                }
        }
        spectrumflux=sum/((mat.GetRow()-1)*size);
        return spectrumflux;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
void SSP::CalLpcValue(PVector& in,PVector& out,int orderp)
{
        out.SetLength(orderp);
        
        int size=in.size()-1;
        PVector sp;
        sp.SetLength(size);
        int i,n;
	for(i=0,n=1; n < in.size(); i++,n++)
	{
		sp[i] = in[n];
	}
        //int frameNum=(m_size-m_framesize)/m_shift+1;
        //m_totalframeNum=frameNum;
        //int offset=0;
	PMatrix a;
	PVector autocorrelation;
	PVector Error;
	PVector Reck;
        
        double sum;
        double delta;


        //m_a�H��m_Reck���Ȥ���!��L�����n,�B0����
        //Initial
        autocorrelation.SetLength(orderp+1);
	Reck.SetLength(orderp+1);
	Error.SetLength(orderp+1);
	a.setRC(orderp+1,orderp+1);
	
	for (int k=0;k<=orderp;k++)
	{
        	sum=0.0f;
                for (int i=0;i<size-k;i++)
                {
                	sum = sum+sp[i]*sp[i+k];
                }
                autocorrelation[k]=sum;//(sum/m_framesize);
         }
         Error[0]=autocorrelation[0];
         Reck[1]=autocorrelation[1]/Error[0];
         a[1][1]=Reck[1];
         Error[1]=(1-Reck[1]*Reck[1])*Error[0];
                
         for (int ordi=2;ordi<=orderp;ordi++)
         {
         	Reck[ordi]=autocorrelation[ordi];
                for (int j=1;j<=ordi-1;j++)
                {
                	Reck[ordi]=Reck[ordi]-a[ordi-1][j]*autocorrelation[ordi-j];
                }
                Reck[ordi]=Reck[ordi]/Error[ordi-1];
                a[ordi][ordi]=Reck[ordi];
                for (int j=1;j<=(ordi-1);j++)
                {
                	a[ordi][j]=a[ordi-1][j]-(Reck[ordi]*a[ordi-1][ordi-j]);
                }
                Error[ordi]=(1.0-Reck[ordi]*Reck[ordi])*Error[ordi-1];
                //m_Error[ordi]=(1-pow(m_Reck[ordi-1],2))*m_Error[ordi-1];
         }
         
         for (int z=1,idx=0;z<=(orderp);idx++,z++)
         {
         	out[idx]=a[orderp][z];
         }		
}
