#ifndef __PIMAGE_H
#define __PIMAGE_H
#include <fstream.h>
#include "PMatrix.h"
typedef unsigned char BYTE;
struct ImageHeader{
   short type;                 /* Magic identifier            */
   int size;                       /* File size in bytes          */
   unsigned short reserved1;
   unsigned short reserved2;
   unsigned int offset;                     /* Offset to image data, bytes */
};
struct ImageInfoHeader{
   unsigned int size;               /* Header size in bytes      */
   int width;
   int height;                /* Width and height of image */
   unsigned short int planes;       /* Number of colour planes   */
   unsigned short int bits;         /* Bits per pixel            */
   unsigned int compression;        /* Compression type          */
   unsigned int imagesize;          /* Image size in bytes       */
   int xresolution,yresolution;     /* Pixels per meter          */
   unsigned int ncolours;           /* Number of colours         */
   unsigned int importantcolours;   /* Important colours         */
};
class PImage
{
private:
   ImageHeader m_heder;
   ImageInfoHeader m_infoheder;
   int m_PixelWidth;
   int m_PixelHeight;
   int Filter(PMatrix& mat,int i,int j);
   int HighPassFilter(PMatrix& mat,int i,int j);
   int ExpendFilter(PMatrix& mat,int i,int j);
   int ErosionFilter(PMatrix& mat,int i,int j);
   //��Ӫ��}�C
   PMatrix m_Rmat;
   PMatrix m_Gmat;
   PMatrix m_Bmat;
   //�B�z�L�᪺�}�C
   PMatrix m_ProcRmat;
   PMatrix m_ProcGmat;
   PMatrix m_ProcBmat;
public:
   void ReadImage(const char* fn);
   //��YCbCr
   void RGB2YCbCr();
   //�Ƕ�
   void RGB2Gray();
   //�G���
   void RGB2TMB(int threshold);
   void ImageTLPF();
   
   void ImageTHPF();
   //�U�٩���
   void Image2Negative();
   //�G�׳���
   void Image2Bright(int threshold);
   
   bool doSobel();
   bool doPrewitt();
   void WriteImage(const char* fn);



};


#endif