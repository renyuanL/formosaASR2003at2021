#include "PWave.h"
void PWave::load(const char* fn)
{
	ifstream fin(fn,ios::binary);
	
	char szTmp[10];
	WAVEFORMATEX pcmWaveFormat;
	ZeroMemory(szTmp, 10 * sizeof(char));
	fin.read(szTmp,4 * sizeof(char));
	
	DWORD dwFileSize/* = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign + 36*/ ;
	fin.read((char *)&dwFileSize,sizeof(dwFileSize));
	ZeroMemory(szTmp, 10 * sizeof(char));
	fin.read(szTmp,8 * sizeof(char));

	DWORD dwFmtSize /*= 16L*/;
	fin.read((char *)&dwFmtSize,sizeof(dwFmtSize));
	fin.read((char *)&pcmWaveFormat.wFormatTag,sizeof(pcmWaveFormat.wFormatTag));
	fin.read((char *)&pcmWaveFormat.nChannels,sizeof(pcmWaveFormat.nChannels));
	fin.read((char *)&pcmWaveFormat.nSamplesPerSec,sizeof(pcmWaveFormat.nSamplesPerSec));	
	fin.read((char *)&pcmWaveFormat.nAvgBytesPerSec,sizeof(pcmWaveFormat.nAvgBytesPerSec));
	fin.read((char *)&pcmWaveFormat.nBlockAlign,sizeof(pcmWaveFormat.nBlockAlign));	
	fin.read((char *)&pcmWaveFormat.wBitsPerSample,sizeof(pcmWaveFormat.wBitsPerSample));		
	
	ZeroMemory(szTmp, 10 * sizeof(char));
	fin.read(szTmp,4 * sizeof(char));
	m_pcmWaveFormat=pcmWaveFormat;
	m_qbuf.m_pcmWaveFormat=pcmWaveFormat;
        //m_pcmWaveFormat=pcmWaveFormat;
	DWORD dwNum;
	fin.read((char *)&dwNum,sizeof(dwNum));
        m_length=dwNum/2;

        m_qbuf.reserve(m_length);

        fin.read((char*)m_qbuf.GetBufPoint(),dwNum);
	fin.close();			
}
int PWave::GetSamplesPerSec()
{
        return m_pcmWaveFormat.nSamplesPerSec;
}
void PWave::makewave(PBuffer& buf,int len)
{
        //m_wav.makewave(m_buffer,m_lokim.szlength);
        m_qbuf.reserve(len);
        for (int i=0;i<len;i++)
                m_qbuf[i]=buf[i];
        m_qbuf.m_pcmWaveFormat=buf.m_pcmWaveFormat;
        m_pcmWaveFormat=buf.m_pcmWaveFormat;
        m_length=len;
        buf.m_nsh=len;

}
//////////////////////////////////////////////////////////////////////////////
void PWave::SaveWave(const char* fn)
{
        ofstream fout(fn,ios::binary);
	fout.write("RIFF",4);

	DWORD dwFileSize = m_length*m_pcmWaveFormat.nBlockAlign + 36 ;
	fout.write((char *)&dwFileSize,sizeof(dwFileSize));
	fout.write("WAVEfmt ",8);

	DWORD dwFmtSize = 16L + (m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM ? sizeof(m_pcmWaveFormat.cbSize) : 0 ) ;

	fout.write((char *)&dwFmtSize,sizeof(dwFmtSize));
	fout.write((char *)&m_pcmWaveFormat.wFormatTag,sizeof(m_pcmWaveFormat.wFormatTag));
	fout.write((char *)&m_pcmWaveFormat.nChannels,sizeof(m_pcmWaveFormat.nChannels));
	fout.write((char *)&(m_pcmWaveFormat.nSamplesPerSec),sizeof(m_pcmWaveFormat.nSamplesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nAvgBytesPerSec,sizeof(m_pcmWaveFormat.nAvgBytesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nBlockAlign,sizeof(m_pcmWaveFormat.nBlockAlign));
	fout.write((char *)&m_pcmWaveFormat.wBitsPerSample,sizeof(m_pcmWaveFormat.wBitsPerSample));

	if(m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM)
		fout.write((char *)&m_pcmWaveFormat.cbSize ,sizeof(m_pcmWaveFormat.cbSize));

	fout.write("data",4);
	DWORD dwNum = m_length * m_pcmWaveFormat.nBlockAlign;
	fout.write((char *)&dwNum,sizeof(dwNum));
	fout.write((char *)m_qbuf.GetBufPoint(),dwNum);
        fout.close();
}
///////////////////////////////////////////////////////////////////////////////
PWave& PWave::operator+(PWave& obj2)
{

        long obj1_size = GetBufLength();
        long obj2_size = obj2.GetBufLength();

        m_length = obj1_size + obj2_size ; // total size

        //����obj1��wave buffer �����@��
        short *wavbuftmp=new short[obj1_size];
        for (int i=0;i<obj1_size;i++)
       	{
       		wavbuftmp[i]= m_qbuf[i];	
       	}
	m_qbuf.reserve(m_length);
        int i,j;
        for (i=0;i<obj1_size;i++)
       	{
       		m_qbuf[i]=wavbuftmp[i];
       	}
       	
       	for (j=obj1_size,i=0;j<m_length;j++,i++)
       	{
       		m_qbuf[j]=obj2[i];
       	}
       	
        delete [] wavbuftmp;

        return *this;
}
///////////////////////////////////////////////////////////////////////////////
PWave& PWave::operator+=(PWave& obj2)
{
       return operator+(obj2);
}
///////////////////////////////////////////////////////////////////////////////
void PWave::savesegwave(int sw,int ew,const char* file)
{
        if (m_segwav!=NULL)
                delete [] m_segwav;
        if (ew>m_length)
                ew=m_length;
        
        int len=ew-sw+1;
        m_segwav=new short[len];
        int i,j=0;
        for (i=sw;i<=ew;i++,j++)
        {
                m_segwav[j]=m_qbuf[i];
        }

        ofstream fout(file,ios::binary);
	fout.write("RIFF",4);

	DWORD dwFileSize = len*m_pcmWaveFormat.nBlockAlign + 36 ;
	fout.write((char *)&dwFileSize,sizeof(dwFileSize));
	fout.write("WAVEfmt ",8);

	DWORD dwFmtSize = 16L + (m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM ? sizeof(m_pcmWaveFormat.cbSize) : 0 ) ;

	fout.write((char *)&dwFmtSize,sizeof(dwFmtSize));
	fout.write((char *)&m_pcmWaveFormat.wFormatTag,sizeof(m_pcmWaveFormat.wFormatTag));
	fout.write((char *)&m_pcmWaveFormat.nChannels,sizeof(m_pcmWaveFormat.nChannels));
	fout.write((char *)&(m_pcmWaveFormat.nSamplesPerSec),sizeof(m_pcmWaveFormat.nSamplesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nAvgBytesPerSec,sizeof(m_pcmWaveFormat.nAvgBytesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nBlockAlign,sizeof(m_pcmWaveFormat.nBlockAlign));
	fout.write((char *)&m_pcmWaveFormat.wBitsPerSample,sizeof(m_pcmWaveFormat.wBitsPerSample));

	if(m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM)
		fout.write((char *)&m_pcmWaveFormat.cbSize ,sizeof(m_pcmWaveFormat.cbSize));

	fout.write("data",4);
	DWORD dwNum = len * m_pcmWaveFormat.nBlockAlign;
	fout.write((char *)&dwNum,sizeof(dwNum));
	fout.write((char *)m_segwav,dwNum);
        fout.close();
}
///////////////////////////////////////////////////////////////////////////////
//�����b.h�ɽsĶ���L
/*
short PWave::operator[](long idx)
{
        return m_qbuf[idx];
}
*/
PWave::PWave()
{
        m_framesize=1024;
        m_shift=256;
        m_segwav=NULL;
}
PWave::~PWave()
{
}
PBuffer& PWave::GetBuf()
{
	return m_qbuf;
}
int PWave::GetBufLength()
{
	return m_length;	
}
//////////////////////////////////////////////////////////////////////

void PWave::plotSpec(HDC hdc,PVector& pit,int hpitch,PVector&  eng,int heng)
{
    int frameNum = (m_length - m_framesize) / m_shift + 1;
    PMatrix specBuf;//,engBuf;
    specBuf.setRC(frameNum,m_framesize+1);
    for(int n = 0; n < frameNum; n++)
       	frame2spec(n* m_shift , specBuf[n]);

    //plot
     RECT rect;
     HDC hMemDC;
     HDC hSrc;     //screen DC
     HBITMAP hBitmap,hOldBitmap;

     HPEN hPen,hOldPen;
     HBRUSH hbrush, hbrushOld;

     GetClipBox(hdc,&rect);   // ���o�ӷ���Client���j�p

     
     hSrc = GetDC(0);      //���oThe GetDC function retrieves a handle to a display device context (DC)
                                // for the client area of a specified window or for the entire screen.

     hMemDC  = CreateCompatibleDC(hSrc);       //�гy�@��MemoryDC�ۮe�P�Ӹ˸m,(�ǤJ���Ѽ�)

     //�гy�@�ӹϻP���w��rect�����b��specified windows(deivice)�U
     hBitmap = CreateCompatibleBitmap(hSrc ,rect.right,rect.bottom);

    //���Hbitmap�o��object���hMemDC�h
     hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);

     //creates a logical brush that has the specified solid color
     //hbrush = CreateSolidBrush(RGB(255, 255,255));
     hbrush = CreateSolidBrush(RGB(0, 0,0));
     hbrushOld = SelectObject(hMemDC, hbrush);

     //��hBrush���W��
     FillRect(hMemDC,&rect , hbrush);

     //�ۤv�h�w�q���Q��SetWindowExtEx and SetViewportExtEx functions 
     SetMapMode(hMemDC  ,MM_ANISOTROPIC );

     //sets the horizontal and vertical extents of the window for a device context

     SetWindowExtEx(hMemDC , frameNum , m_framesize/2 ,NULL);
     //sets the horizontal and vertical extents of the viewport for a device context
     //�w�q�i�H������x�Ȩ쪺,�H��y��
     //�]�wx�My���e��
     SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);

     //�w�qView�����I,�q�Ϫ����U��
     SetViewportOrgEx(hMemDC,0,rect.bottom,NULL);   //�̫�@�ӰѼƬO�^�Ǥ��e�����I

     m_PixelWidth=frameNum;
     m_PixelHeight=m_framesize/2;
     m_Bcolor.setRC(m_PixelHeight,m_PixelWidth);
     m_Gcolor.setRC(m_PixelHeight,m_PixelWidth);
     m_Rcolor.setRC(m_PixelHeight,m_PixelWidth);
     int r,g,b;
     for(int i=0; i < frameNum ; i++)
     {
        for(int j=1 ; j <= m_framesize/2 ; j++)
        {
            int color = specBuf[i][j]*100;      //���Ӱ��F2��16����,�{�b���H100��
            if(color < 10)
            {
               r=g=b=0;
               m_Bcolor[j-1][i]=b;
               m_Gcolor[j-1][i]=g;
               m_Rcolor[j-1][i]=r;
               continue;            //���p�C��p��10,�M�ᤣ��(�]�N�O���¦�)
            }
            hPen = CreatePen(PS_SOLID,1,getRGB(color,b,g,r)); //��ߪ��e�׬�1,�M����o���C��
            m_Bcolor[j-1][i]=b;
            m_Gcolor[j-1][i]=g;
            m_Rcolor[j-1][i]=r;
            hOldPen = SelectObject(hMemDC,hPen);
            Rectangle(hMemDC,i,j,i+2,j+1);   //�e�@�ӥ��諬 ,x���׬�2,y���׬�1,�M�ᦳ�\�L�h
                                                //�W�X�u�]�S���Y,��n�W�X1
            SelectObject(hMemDC,hOldPen);
            DeleteObject(hPen);
        }
   }

     if (pit.size()>0 && hpitch)
     {
        float maxPitch = 0.0f;

        for(int i = 0; i < pit.size(); i++)
        {
                if(pit[i] > maxPitch) maxPitch = pit[i];
        }
        maxPitch=600;
        //SetMapMode(hMemDC  ,MM_ANISOTROPIC );
        SetWindowExtEx(hMemDC , pit.size() , maxPitch ,NULL);
        SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);
        SetViewportOrgEx(hMemDC,0,rect.bottom,NULL);
        MoveToEx(hMemDC,0,0,NULL);
        hPen = CreatePen(PS_SOLID,3,RGB(0,255,255));
        hPen = SelectObject(hMemDC,hPen);
        for(int i=0; i < pit.size() ; i++)
        {
               if (i>=1 && i<=pit.size()-1)
                  if ((pit[i]==0 && pit[i-1]>0) || (pit[i]>0 && pit[i-1]==0))
                     MoveToEx(hMemDC,i,pit[i],NULL);
                  else
                     LineTo(hMemDC,i,pit[i]);
               else
                     LineTo(hMemDC,i,pit[i]);
        }
     }

     if (eng.size()>0 && heng)
     {
        double maxEnergy = 0.0f;
        PVector temp;
        temp.SetLength(eng.size());
        for(int i = 0; i < eng.size(); i++)
        {
                temp[i]=sqrt(eng[i]);

                if(temp[i] > maxEnergy) maxEnergy = temp[i];
        }
        SetWindowExtEx(hMemDC , eng.size() , maxEnergy ,NULL);
        SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);
        SetViewportOrgEx(hMemDC,0,rect.bottom,NULL);
        MoveToEx(hMemDC,0,0,NULL);
        hPen = CreatePen(PS_SOLID,0,RGB(0,255,0));
        hPen = SelectObject(hMemDC,hPen);
        for(int i=0; i < temp.size() ; i++)
        {
                LineTo(hMemDC,i,temp[i]);
        }

     }

      //Each logical unit is mapped to one device pixel.
      //Positive x is to the right;
      //positive y is down.
     SetMapMode(hMemDC  ,MM_TEXT);         //�]�w�^�h
     SetViewportOrgEx(hMemDC ,0,0,NULL);    //�]�w���I�^�h
     /*
     performs a bit-block transfer of the color data corresponding to
     a rectangle of pixels from the specified source device context
     into a destination device context
     */

     BitBlt(hdc,0,0,                // destination (x,y)   //�NMemoryDC���϶K���Ӫ��ϤW,�n���_�@
            rect.right,rect.bottom, // width, height
            hMemDC,0,0,             // source (x,y)
            SRCCOPY);



     SelectObject(hMemDC, hOldPen);
     DeleteObject(hPen);

     SelectObject(hMemDC, hbrushOld);
     DeleteObject(hbrush);

     SelectObject(hMemDC, hOldBitmap);
     DeleteObject(hBitmap);

     //The ReleaseDC function releases a device context (DC),
     //freeing it for use by other applications
     ReleaseDC(NULL,hSrc);

     //The DeleteDC function deletes the specified device context (DC).
     DeleteDC(hMemDC);

}
//////////////////////////////////////////////////////////////////////
void PWave::Spec2Image(const char* fn)
{
   ofstream fout;
   fout.open(fn,ios::binary);
   /*
   m_heder.type=
   m_heder.size=
   m_heder.reserved1=
   m_heder.reserved2=
   m_heder.offset=
   */
   fout.write((char*)&m_heder.type,sizeof(short));
   fout.write((char*)&m_heder.size,sizeof(int));

   fout.write((char*)&m_heder.reserved1,sizeof(short));
   fout.write((char*)&m_heder.reserved2,sizeof(short));
   //�e���`�@14 byes add 40 infomation header=>54 Bytes
   fout.write((char*)&m_heder.offset,sizeof(int));
   /*
   m_infoheder.size=
   m_infoheder.width=
   m_infoheder.height=
   m_infoheder.planes=
   m_infoheder.bits=
   m_infoheder.compression=
   m_infoheder.imagesize=
   m_infoheder.xresolution=
   m_infoheder.yresolution=
   m_infoheder.ncolours=
   m_infoheder.importantcolours
   */
   fout.write((char*)&m_infoheder.size,sizeof(int));
   //Read Image���e�P����
   fout.write((char*)&m_infoheder.width,sizeof(m_infoheder.width));
   fout.write((char*)&m_infoheder.height,sizeof(m_infoheder.height));

   fout.write((char*)&m_infoheder.planes,sizeof(m_infoheder.planes));
   fout.write((char*)&m_infoheder.bits,sizeof(m_infoheder.bits));
   fout.write((char*)&m_infoheder.compression,sizeof(m_infoheder.compression));
   fout.write((char*)&m_infoheder.imagesize,sizeof(m_infoheder.imagesize));
   fout.write((char*)&m_infoheder.xresolution,sizeof(m_infoheder.xresolution));
   fout.write((char*)&m_infoheder.yresolution,sizeof(m_infoheder.yresolution));
   fout.write((char*)&m_infoheder.ncolours,sizeof(m_infoheder.ncolours));
   fout.write((char*)&m_infoheder.importantcolours,sizeof(m_infoheder.importantcolours));
   BYTE rdata;
   //rdata=new Byte[infoheder.imagesize];
/*
   for (int i=(m_infoheder.height-1);i>=0;i--)
   {
      for (int j=0;j<m_infoheder.width;j++)
      {
         rdata=(int)m_Bmat[i][j];
         fout.write((char*)&rdata,sizeof(BYTE));
         rdata=(int)m_Gmat[i][j];
         fout.write((char*)&rdata,sizeof(BYTE));
         rdata=(int)m_Rmat[i][j];
         fout.write((char*)&rdata,sizeof(BYTE));
      }
   }
*/
   fout.close();

}
//////////////////////////////////////////////////////////////////////
COLORREF PWave::getRGB(int mag,int& blue,int& green,int& red)
{
/*
    int R=0,G=0,B=0;
    if (mag>=10 && mag<25)
    {
        R=60;G=60;B=60;
    }
    if (mag>=25 && mag<50)
    {
        R=0;G=70;B=70;
    }
    if (mag>=50 && mag<100)
    {
        R=80;G=80;B=80;
    }
    if (mag>=100 && mag<150)
    {
        R=90;G=90;B=90;
    }
    if (mag>=150 && mag<200)
    {
        R=100;G=100;B=100;
    }
    if (mag>=200 && mag<250)
    {
        R=110;G=110;B=110;
    }
    if (mag>=250 && mag<300)
    {
        R=120;G=120;B=120;
    }
    if (mag>=300 && mag<350)
    {
        R=130;G=130;B=130;
    }
    if (mag>=350 && mag<400)
    {
        R=140;G=140;B=140;
    }
    if (mag>=400)
    {
        R=150;G=150;B=150;
    }
    return RGB(R,G,B);
*/
    int R=0,G=0,B=0;
    if(mag>25)
    {
           B=50;
           if(mag>50+125)
           {
                 R=255;
                 if(mag>50+125+250)
                 {
                     G=255;
                     if(mag>50+125+250+500)
                     {
                         B=255;
                     }
                     else
                         B=(mag-50-125-250)/4;
                 }
                 else
                     G=(mag-125-25)/2;
           }
           else
                R=mag-25;
    }
    else
         B=mag*2;
    blue=B;
    green=G;
    red=R;
    return RGB(R,G,B);

}

//////////////////////////////////////////////////////////////////////
void PWave::frame2spec(int curOffset ,PVector &vec)
{
  for(int i=curOffset , n=1; i < m_framesize + curOffset ; i++ , n++)
  	vec[n] = (float)m_qbuf[i]/((1 << (16 - 1)) - 1);

  PFft::realfft(vec.GetBuffer(),m_framesize);

  float real,img;
  for(int i=1;i<=m_framesize/2;i++)
  {
      real = vec[2*i-1]  ;  img = vec[2*i];
      double te =  sqrt(real*real + img*img);
      vec[i] = te;
  }

}

//////////////////////////////////////////////////////////////////////
void PWave::plotWave(HDC hdc)
{
     //GDI����O�޿�y�� ,�i�M�g��h�ؤ覡�h
     //�ӭ�Ӫ��O�˸m�y��
     RECT rect;
     HDC hMemDC;
     HDC hSrc;     //screen DC
     HBITMAP hBitmap,hOldBitmap;

     HPEN hGreenPen,hOldGreenPen;
     HPEN hRedPen,hOldRedPen;
     HBRUSH hbrush, hbrushOld;

     GetClipBox(hdc,&rect);

     hSrc = GetDC(0);
     hMemDC  = CreateCompatibleDC(hSrc);
     hBitmap = CreateCompatibleBitmap(hSrc ,rect.right,rect.bottom);
     hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);

     hbrush = CreateSolidBrush(RGB(0, 255, 0));
     hbrushOld = SelectObject(hMemDC, hbrush);

        short wavAmp = 0;
        for(int i = 0; i < m_length; i++)
        {
                if (abs(m_qbuf[i])>wavAmp)
                        wavAmp=abs(m_qbuf[i]);
        }

     FillRect(hMemDC,&rect , hbrush);

     SetMapMode(hMemDC  ,MM_ANISOTROPIC );

     //SetWindowExtEx(hMemDC ,m_length,65535,NULL);  //���@�˪��a��
     SetWindowExtEx(hMemDC ,m_length,2*wavAmp,NULL);  //���@�˪��a��

     //�ĤG�ӭt�O�N��ܪ��y�Э˹L��,���ӥ������k�U,�{�b�ܥ��`
     SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);  //���@�˪��a��

     SetViewportOrgEx(hMemDC ,0,rect.bottom/2,NULL);   //���@�˪��a��

     //�e��������u
     hRedPen = CreatePen(PS_SOLID,1,RGB(255,0,0));  //���@�˪��a��
     hOldRedPen = SelectObject(hMemDC,hRedPen);  //���@�˪��a��

     MoveToEx(hMemDC,0,0,NULL);               //���ʲ{�b���I��..(0,0)���I

     LineTo(hMemDC,m_length,0);   //���@�˪��a��

     //plot waveform
     hGreenPen = CreatePen(PS_SOLID,1,RGB(0,0,0));      //���@�˪��a��
     hOldGreenPen = SelectObject(hMemDC,hGreenPen);       //���@�˪��a��
     MoveToEx(hMemDC,0,0,NULL);

     for(int i=0;i<m_length;i++)       //���@�˪��a��
        LineTo(hMemDC,i,m_qbuf[i]);                    //���@�˪��a��

     SetMapMode(hMemDC  ,MM_TEXT);

     BitBlt(hdc,0,0,                // destination (x,y)            //���@�˪��a��
            rect.right,rect.bottom, // width, height
            hMemDC,0,-rect.bottom/2,             // source (x,y)
            SRCCOPY);


     SelectObject(hMemDC, hOldGreenPen);
     DeleteObject(hGreenPen);

     SelectObject(hMemDC, hOldRedPen);
     DeleteObject(hRedPen);

     SelectObject(hMemDC, hbrushOld);
     DeleteObject(hbrush);

     SelectObject(hMemDC, hOldBitmap);
     DeleteObject(hBitmap);

     ReleaseDC(NULL,hSrc);
     DeleteDC(hMemDC);
}
void PWave::plotDifWave(HDC hdc,int tsize,wseginfo& teacher,int tlen,wseginfo& student,int slen)
{
     //GDI����O�޿�y�� ,�i�M�g��h�ؤ覡�h
     //�ӭ�Ӫ��O�˸m�y��
     RECT rect;
     HDC hMemDC;
     HDC hSrc;     //screen DC
     HBITMAP hBitmap,hOldBitmap;

     HPEN hGreenPen,hOldGreenPen;
     HPEN hRedPen,hOldRedPen;
     HBRUSH hbrush, hbrushOld;

     GetClipBox(hdc,&rect);

     hSrc = GetDC(0);
     hMemDC  = CreateCompatibleDC(hSrc);
     hBitmap = CreateCompatibleBitmap(hSrc ,rect.right,rect.bottom);
     hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);

     hbrush = CreateSolidBrush(RGB(0, 255, 0));
     hbrushOld = SelectObject(hMemDC, hbrush);

        short wavAmp = 0;
        for(int i = 0; i < m_length; i++)
        {
                if (abs(m_qbuf[i])>wavAmp)
                        wavAmp=abs(m_qbuf[i]);
        }

     FillRect(hMemDC,&rect , hbrush);

     SetMapMode(hMemDC  ,MM_ANISOTROPIC );

     //SetWindowExtEx(hMemDC ,m_length,65535,NULL);  //���@�˪��a��
     //SetWindowExtEx(hMemDC ,m_length,2*wavAmp,NULL);  //���@�˪��a��
     SetWindowExtEx(hMemDC ,tsize,2*wavAmp,NULL);  //���@�˪��a��

     //�ĤG�ӭt�O�N��ܪ��y�Э˹L��,���ӥ������k�U,�{�b�ܥ��`
     SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);  //���@�˪��a��

     SetViewportOrgEx(hMemDC ,0,rect.bottom/2,NULL);   //���@�˪��a��

     //�e��������u
     hRedPen = CreatePen(PS_SOLID,1,RGB(255,0,0));  //���@�˪��a��
     hOldRedPen = SelectObject(hMemDC,hRedPen);  //���@�˪��a��

     MoveToEx(hMemDC,0,0,NULL);               //���ʲ{�b���I��..(0,0)���I

     LineTo(hMemDC,tsize,0);   //���@�˪��a��

     //plot waveform
     hGreenPen = CreatePen(PS_SOLID,1,RGB(0,0,0));      //���@�˪��a��
     hOldGreenPen = SelectObject(hMemDC,hGreenPen);       //���@�˪��a��
     MoveToEx(hMemDC,0,0,NULL);

     if (teacher.size()==student.size())
     {
         float start,end,tmps,tmpe;
         int z=0;
         int oldi=0;
         for (int k=0;k<student.size()-1;k++)
         {
            start=student[k].sn;
            end=student[k+1].sn;
            tmps = teacher[k].sn;
            tmpe = teacher[k+1].sn;
            float deltaJ=(end-start)/(tmpe-tmps);
            int i;
            for (float j=start;j<end;j=j+deltaJ)
            {
               i=(int)(j);
               if (i>=1 && i<m_length)
               {
                  //LineTo(hMemDC,i,m_qbuf[i]);
                  LineTo(hMemDC,z,m_qbuf[i]);
               }
               oldi=i;
               z++;
            }
         }

     }

     //for(int i=0;i<m_length;i++)       //���@�˪��a��
     //    LineTo(hMemDC,i,m_qbuf[i]);                    //���@�˪��a��

     SetMapMode(hMemDC  ,MM_TEXT);

     BitBlt(hdc,0,0,                // destination (x,y)            //���@�˪��a��
            rect.right,rect.bottom, // width, height
            hMemDC,0,-rect.bottom/2,             // source (x,y)
            SRCCOPY);


     SelectObject(hMemDC, hOldGreenPen);
     DeleteObject(hGreenPen);

     SelectObject(hMemDC, hOldRedPen);
     DeleteObject(hRedPen);

     SelectObject(hMemDC, hbrushOld);
     DeleteObject(hbrush);

     SelectObject(hMemDC, hOldBitmap);
     DeleteObject(hBitmap);

     ReleaseDC(NULL,hSrc);
     DeleteDC(hMemDC);

}

