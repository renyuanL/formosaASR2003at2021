#include "PFeature.h"
void PFeature::WaveToEnergy(PWave& wav,int fs,int ol)
{
	int framesize=fs;
        int overlap=ol;
	int frameNum = ( wav.GetBufLength()- framesize) / overlap + 1;

        PVector tempBuf;
        tempBuf.SetLength(frameNum);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {
	        PVector sp;
        	int i,n;
	        //copy�@�q speech frame
	        sp.SetLength(framesize+1);
	        for(i=z*overlap,n=1; i < (framesize+z*overlap); i++,n++)
	        {
		        sp[n] = wav[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                tempBuf[z]=FSSP.totaleng(sp);
        }
        FSSP.LPF(tempBuf,m_engBuf);
}
/////////////////////////////////////////////////////////////////////////////////////////////
void PFeature::WaveToVolumn(PWave& wav,int fs,int ol)
{
	int framesize=fs;
        int overlap=ol;
	int frameNum = ( wav.GetBufLength()- framesize) / overlap + 1;

        m_volumnBuf.SetLength(frameNum);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {
	        PVector sp;
        	int i,n;
	        //copy�@�q speech frame
	        sp.SetLength(framesize+1);
	        for(i=z*overlap,n=1; i < (framesize+z*overlap); i++,n++)
	        {
		        sp[n] = wav[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                m_volumnBuf[z]=FSSP.calVolumn(sp);
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////
void PFeature::WaveToZCR(PWave& wav,int fs,int ol)
{
	int framesize=fs;
        int overlap=ol;
	int frameNum = ( wav.GetBufLength()- framesize) / overlap + 1;

        m_ZcrBuf.SetLength(frameNum);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {
	        PVector sp;
        	int i,n;
	        //copy�@�q speech frame
	        sp.SetLength(framesize+1);
	        for(i=z*overlap,n=1; i < (framesize+z*overlap); i++,n++)
	        {
		        sp[n] = wav[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                m_ZcrBuf[z]=FSSP.CalZeroCrossRate(sp);
        }
}
/////////////////////////////////////////////////////////////////////////////////////////////
void PFeature::WaveToSpectrumFlux(PWave& wav,int fs,int fftsize)
{
	int framesize=fs;
        int specfftsize=fftsize;
	int frameNum =  wav.GetBufLength() / framesize;

        PVector sp;
        m_SpectrumBuf.setRC(frameNum,specfftsize+1);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {

                //�@�}�l�N�]�w��fft��size
                sp.SetLength(framesize+1);
                //sp.SetLength(specfftsize+1);
        	int i,n;
	        //copy�@�q speech frame
	        for(i=z*framesize,n=1; i < (1+z)*framesize; i++,n++)
	        {
		        sp[n] = wav[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                //��fft�Ϊ�
                //PVector fsp;

                for (i=1;i<=framesize;i++)
                        m_SpectrumBuf[z][i]=sp[i];
                if (framesize<specfftsize)
                {
                         //�᭱�ɹs
                         for (int k=framesize+1; k<=specfftsize; k++) //�᭱�[0
                                m_SpectrumBuf[z][k] = 0.0;
                }
                FSSP.frame2spec(m_SpectrumBuf[z]);
        }
        //Cal Spec Flux
        float spectrumflux=0.0;
        double temp(0.0),sum(0.0);
        double deltavalue=0.0001;  //�n�h�֭�?
        m_SpecFluxBuf.SetLength(frameNum-1);
        for(int z = 1; z < frameNum; z++)
        {
                sum=0.0;
                for (int h=1;h<=specfftsize/2;h++)
                {
                        temp=log10(m_SpectrumBuf[z][h]+deltavalue)-log10(m_SpectrumBuf[z-1][h]+deltavalue);
                        //temp=m_SpectrumBuf[z][h]-m_SpectrumBuf[z-1][h];
                        temp=pow(temp,2);
                        if (h>=2 && h<128) //72.5 Hz~4K HZ
                                temp=2*temp;
                        sum=sum+temp;
                }
                sum=sum/(specfftsize/2);
                m_SpecFluxBuf[z-1]=sum;
        }
        m_SpecMean;
        m_SpecVariance;

        //Cal Mean And Variance
        //m_SpectrumBuf.setRC(frameNum,specfftsize+1);
        m_SpecMean.SetLength(frameNum);
        m_SpecVariance.SetLength(frameNum);
        for (int i=0;i<m_SpectrumBuf.GetRow();i++)
        {
                sum=0.0;
                for (int j=1;j<m_SpectrumBuf.GetCol();j++)
                {
                        sum=sum+m_SpectrumBuf[i][j];
                }
                sum=sum/(m_SpectrumBuf.GetCol()-1);
                m_SpecMean[i]=sum;
        }

        for (int i=0;i<m_SpectrumBuf.GetRow();i++)
        {
                sum=0.0;
                for (int j=1;j<m_SpectrumBuf.GetCol();j++)
                {
                        sum=sum+pow((m_SpecMean[i]-m_SpectrumBuf[i][j]),2);

                }
                sum=sum/(m_SpectrumBuf.GetCol()-1);
                m_SpecVariance[i]=sum;
        }
/*
//��Spectrum Flux
        float spectrumflux=0.0;
        double temp(0.0),sum(0.0);
        double deltavalue=0.000001;  //�n�h�֭�?
        m_SpecFluxBuf.SetLength(frameNum-1);
        for(int z = 1; z < frameNum; z++)
        {
                sum=0.0;
                for (int h=1;h<=specfftsize/2;h++)
                {
                        //temp=log10(m_SpectrumBuf[z][h]+deltavalue)-log10(m_SpectrumBuf[z-1][h]+deltavalue);
                        temp=m_SpectrumBuf[z][h]-m_SpectrumBuf[z-1][h];
                        temp=pow(temp,2);
                        sum=sum+temp;
                }
                sum=sum/(specfftsize/2);
                m_SpecFluxBuf[z-1]=sum;
        }
*/
}
/////////////////////////////////////////////////////////////////////////////////////////////
void PFeature::WaveToSpecRolloff(PWave& wav,int fs,int ol,int fftsize)
{
	int framesize=fs;
        int overlap=ol;
        int specfftsize=fftsize;
	int frameNum = ( wav.GetBufLength()- framesize) / overlap + 1;
        PVector sp,fsp;
        m_SpecRoll.SetLength(frameNum);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {

                //�@�}�l�N�]�w��fft��size
                sp.SetLength(framesize+1);
                //sp.SetLength(specfftsize+1);
        	int i,n;
	        //copy�@�q speech frame
	        for(i=z*overlap,n=1; i < (framesize+z*overlap); i++,n++)
	        {
		        sp[n] = wav[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                //��fft�Ϊ�
                //PVector fsp;
                fsp.SetLength(specfftsize+1);
                for (i=1;i<=framesize;i++)
                        fsp[i]=sp[i];
                if (framesize<specfftsize)
                {
                         //�᭱�ɹs
                         for (int k=framesize+1; k<=specfftsize; k++) //�᭱�[0
                                fsp[k] = 0.0;
                }
                m_SpecRoll[z]=FSSP.CalSpecRolloff(fsp);
        }
}
void PFeature::WaveToSpecCentroid(PWave& wav,int fs,int ol,int fftsize)
{
	int framesize=fs;
        int overlap=ol;
        int specfftsize=fftsize;
	int frameNum = ( wav.GetBufLength()- framesize) / overlap + 1;
        PVector sp,fsp,dsp;
        m_SpecCentroid.SetLength(frameNum);
        m_SpecDiversity.SetLength(frameNum);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {

        	int i,n;
	        //copy�@�q speech frame
	        sp.SetLength(framesize+1);
	        for(i=z*overlap,n=1; i < (framesize+z*overlap); i++,n++)
	        {
		        sp[n] = wav[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                //��fft�Ϊ�
                fsp.SetLength(specfftsize+1);
                dsp.SetLength(specfftsize+1);
                for (i=1;i<=framesize;i++)
                {
                        fsp[i]=sp[i];
                        dsp[i]=sp[i];
                }
                if (framesize<specfftsize)
                {
                         //�᭱�ɹs
                         for (int k=framesize+1; k<=specfftsize; k++) //�᭱�[0
                         {
                                fsp[k] = 0.0;
                                dsp[k] = 0.0;
                         }
                }
                m_SpecCentroid[z]=FSSP.CalSpecCentroid(fsp);
                //m_SpecDiversity[z]=FSSP.CalSpecDiversity(dsp, m_SpecCentroid[z]);
        }
}
void PFeature::WaveToEntropy(PWave& wav,int fs,int ol,int fftsize)
{
	int framesize=fs;
        int overlap=ol;
        int specfftsize=fftsize;
	int frameNum = ( wav.GetBufLength()- framesize) / overlap + 1;
        PVector sp,fsp;
        m_EntroypyBuf.SetLength(frameNum);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {

        	int i,n;
	        //copy�@�q speech frame
	        sp.SetLength(framesize+1);
	        for(i=z*overlap,n=1; i < (framesize+z*overlap); i++,n++)
	        {
		        sp[n] = wav[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                //��fft�Ϊ�
                fsp.SetLength(specfftsize+1);
                for (i=1;i<=framesize;i++)
                        fsp[i]=sp[i];
                if (framesize<specfftsize)
                {
                         //�᭱�ɹs
                         for (int k=framesize+1; k<=specfftsize; k++) //�᭱�[0
                                fsp[k] = 0.0;
                }
                m_EntroypyBuf[z]=FSSP.CalEntropy(fsp);
        }
}
void PFeature::FromPrat(PVector& vec,float intval)
{
        m_PitchBuf.SetLength(vec.size());
        for (int i=0;i<vec.size();i++)
                m_PitchBuf[i]=vec[i];
        m_PitchIntvalTime=intval;
}
void PFeature::IntesityFromPrat(PVector& vec,float intval)
{
        m_IntensityBuf.SetLength(vec.size());
        for (int i=0;i<vec.size();i++)
                m_IntensityBuf[i]=vec[i];
        m_IntenIntvalTime=intval;
}
bool PFeature::WaveToSpecFlux(PWave& wav,vector<Syl>& vec,vector<Unvoiced> unvoicebou)
{
        ///ofstream fout;
        //fout.open("error.txt",ios::out);
        if (vec.size()<=0)
                return false;
        float stime(0.0),etime(0.0);
        float threashold;
        vector<Syl> Syltemp;
        vector<float> Bou;
        if (Syltemp.size()>0)
                Syltemp.clear();
        Syl stemp;
        double mvar;
        Syl source;
        for (unsigned int i=0;i<vec.size();i++)
        {
               source=vec.at(i);
               etime=vec.at(i).pitchvoice.etime;
               stime=vec.at(i).pitchvoice.stime;
               if ((etime-stime)>=0.2)
               {
                        if ((etime-stime)>0.9)
                        {
                                threashold=0.5;
                        }else if ((etime-stime)>0.6)
                        {
                                threashold=0.45;
                        }else
                        {
                                threashold=0.4;
                        }
                       /* */
                       // threashold=0.4;
                        int start=stime*16000;
                        int end=etime*16000;
                        //fout<<stime<<" "<<etime<<endl;
                        //fout<<start<<" "<<end<<endl;
                        //fout<<"Threadhold:"<<threashold<<endl;
                        PVector wavspeech;
                        wavspeech.SetLength(end-start+1);
                        for (int w=0;w<wavspeech.size();w++)
                                wavspeech[w]=wav[w+start];

	                int framesize=320;
                        int specfftsize=512;//fftsize;
	                int frameNum =  wavspeech.size() / framesize;

                        PVector sp;
                        PVector specsum;
                        
                        m_partSpectrumBuf.setRC(frameNum,specfftsize+1);
                        specsum.SetLength(frameNum);
                        //SSP FSSP;
	                for(int z = 0; z < frameNum; z++)
                        {

                                //�@�}�l�N�]�w��fft��size
                                sp.SetLength(framesize+1);
                                //sp.SetLength(specfftsize+1);
        	                int i,n;
	                        //copy�@�q speech frame
	                        for(i=z*framesize,n=1; i < (1+z)*framesize; i++,n++)
	                        {
		                        sp[n] = wavspeech[i];
	                        }
                                FSSP.ZeroMeanFrame(sp);
                                //��fft�Ϊ�
                                //PVector fsp;

                                for (i=1;i<=framesize;i++)
                                        m_partSpectrumBuf[z][i]=sp[i];
                                if (framesize<specfftsize)
                                {
                                        //�᭱�ɹs
                                        for (int k=framesize+1; k<=specfftsize; k++) //�᭱�[0
                                                m_partSpectrumBuf[z][k] = 0.0;
                                }
                                FSSP.frame2spec(m_partSpectrumBuf[z]);
                        }
                        //Cal Spec Flux
                        float spectrumflux=0.0;
                        double temp(0.0),sum(0.0);
                        double deltavalue=0.0001;  //�n�h�֭�?
                        double spectrumsum=0.0;
                        double RMt=0.0;
                        float Rt=0.0;
                        m_partSpecFluxBuf.SetLength(frameNum-1);
                        for(int z = 1; z < frameNum; z++)
                        {
                                sum=0.0;
                                for (int h=1;h<=specfftsize/2;h++)
                                {
                                        temp=log10(m_partSpectrumBuf[z][h]+deltavalue)-log10(m_partSpectrumBuf[z-1][h]+deltavalue);
                                        //temp=m_SpectrumBuf[z][h]-m_SpectrumBuf[z-1][h];
                                        temp=pow(temp,2);
                                        if (h>=2 && h<128) //72.5 Hz~4K HZ
                                                temp=2*temp;

                                        sum=sum+temp;
                                }
                                sum=sum/(specfftsize/2);
                                m_partSpecFluxBuf[z-1]=sum;
                        }
                        //Cal Mean And Variance
                        //m_SpectrumBuf.setRC(frameNum,specfftsize+1);
                        m_partSpecMean.SetLength(frameNum);
                        m_partSpecVariance.SetLength(frameNum);
                        for (int i=0;i<m_partSpectrumBuf.GetRow();i++)
                        {
                                sum=0.0;
                                for (int j=1;j<m_partSpectrumBuf.GetCol();j++)
                                {
                                        sum=sum+m_partSpectrumBuf[i][j];
                                }
                                sum=sum/(m_partSpectrumBuf.GetCol()-1);
                                m_partSpecMean[i]=sum;
                        }
                        vector<float> meantime;
                        if (meantime.size()>0)
                                meantime.clear();
                        for (int i=2;i<m_partSpecMean.size()-2;i++)
                        {
                                if (m_partSpecMean[i]>m_partSpecMean[i-1] && m_partSpecMean[i]>m_partSpecMean[i-2])
                                        if (m_partSpecMean[i]>m_partSpecMean[i+1] && m_partSpecMean[i]>m_partSpecMean[i+2])
                                                meantime.push_back((0.02*i)+stime);
                        }

                        //fout<<"Mean Value"<<endl;
                        //for (int i=0;i<m_SpecMean.size();i++)
                        //{
                               //fout<<m_SpecMean[i]<<endl;
                        //}
                        //fout<<"Over"<<endl;


                        for (int i=0;i<m_partSpectrumBuf.GetRow();i++)
                        {
                                sum=0.0;
                                for (int j=1;j<m_partSpectrumBuf.GetCol();j++)
                                {
                                        sum=sum+pow((m_partSpecMean[i]-m_partSpectrumBuf[i][j]),2);

                                }
                                sum=sum/(m_partSpectrumBuf.GetCol()-1);
                                m_partSpecVariance[i]=sum;
                        }
                        mvar=0.0;
                        for (int i=0;i<m_partSpecVariance.size();i++)
                        {
                                mvar=mvar+m_partSpecVariance[i];
                        }
                        mvar=mvar/m_partSpecVariance.size();
                        vector<float> vartime;
                        if (vartime.size()>0)
                                vartime.clear();
                        for (int i=2;i<m_partSpecVariance.size()-2;i++)
                        {
                                if (m_partSpecVariance[i]>m_partSpecVariance[i-1] && m_partSpecVariance[i]>m_partSpecVariance[i-2])
                                        if (m_partSpecVariance[i]>m_partSpecVariance[i+1] && m_partSpecVariance[i]>m_partSpecVariance[i+2])
                                                      vartime.push_back((0.02*i)+stime);
                                // if (m_SpecVariance[i]>mvar)

                        }

                        //fout<<"Variance Value"<<endl;
                        //for (unsigned int i=0;i<vartime.size();i++)
                        //{
                               //fout<<vartime.at(i)<<endl;
                        //}
                        //fout<<"Over"<<endl;
                        int eidx=etime/m_IntenIntvalTime-2;
                        int sidx=stime/m_IntenIntvalTime+2;
                        vector<float> Intentime;
                        if (Intentime.size()>0)
                                Intentime.clear();
                        for (;sidx<=eidx;sidx++)
                        {
                                if (m_IntensityBuf[sidx]<m_IntensityBuf[sidx+1] && m_IntensityBuf[sidx]<m_IntensityBuf[sidx-1])
                                        if (m_IntensityBuf[sidx]<m_IntensityBuf[sidx+2] && m_IntensityBuf[sidx]<m_IntensityBuf[sidx-2])
                                                Intentime.push_back((sidx+5)*m_IntenIntvalTime);
                        }

                        //fout<<"Intensity"<<endl;
                        //for (unsigned int z=0;z<Intentime.size();z++)
                        //{
                                //fout<<Intentime.at(z)<<endl;
                        //}
                        //fout<<"Over"<<endl;
                        /**/
                         /*
                        fout<<"�y��Buffer"<<endl;
                        for (int w=2;w<wavspeech.size()-2;w++)
                        {
                                if (wavspeech[w]<wavspeech[w+1] && wavspeech[w]<wavspeech[w-1])
                                        if (wavspeech[w]<wavspeech[w+2] && wavspeech[w]<wavspeech[w-2])
                                                fout<<(stime+(float)w*(1/16000))<<endl;

                        }



                        fout<<"Spectrum Flux"<<endl;
                        for (int i=0;i<m_SpecFluxBuf.size();i++)
                        {
                               fout<<m_SpecFluxBuf[i]<<endl;
                        }
                        fout<<"Over"<<endl;
                         */
                        for(int z = 0; z < frameNum; z++)
                        {
                                Rt=0.0;
                                spectrumsum=0.0;
                                RMt=0.0;
                                for (int h=1;h<=specfftsize/2;h++)
                                {
                                        spectrumsum=spectrumsum+m_partSpectrumBuf[z][h];
                                }
                                spectrumsum=spectrumsum*0.8;
                                for (int h=1;h<=specfftsize/2;h++)
                                {
                                        RMt=RMt+m_partSpectrumBuf[z][h];
                                        if (abs(spectrumsum-RMt)<100000)
                                        {
                                                Rt=(h*8000)/(specfftsize/2);
                                                break;
                                        }
                                }
                                specsum[z]=Rt;
                        }
                        /*
                        fout<<"Spectrum Value"<<endl;
                        for (int i=0;i<specsum.size();i++)
                        {
                               fout<<specsum[i]<<endl;
                        }
                        */
                        double msumsf=0.0;
                        for (int i=0;i<m_partSpecFluxBuf.size();i++)
                        {
                                msumsf=msumsf+m_partSpecFluxBuf[i];
                                //fout<<m_SpecFluxBuf[i]<<endl;
                        }
                        msumsf=msumsf/m_partSpecFluxBuf.size();
                        //fout<<"Spectrum Flux+Spectrum Value"<<endl;
                        vector<float> sftime;
                        if (sftime.size()>0)
                                sftime.clear();
                        //fout<<"Spectrum Flux"<<endl;
                        for (int i=0;i<m_partSpecFluxBuf.size();i++)
                        {
                                if (m_partSpecFluxBuf[i]>msumsf)
                                {
                                        sftime.push_back(stime+0.02*(i+1)+0.01);
                                        //fout<<stime+0.02*(i+1)+0.01<<endl;
                                }
                                //fout<<m_SpecFluxBuf[i]<<endl;
                        }
                        //fout<<"Over"<<endl;
                        vector<float> srtime;
                        if (srtime.size()>0)
                                srtime.clear();
                        //fout<<"Spectrum Roll"<<endl;
                        for (int i=1;i<specsum.size()-1;i++)
                        {
                               if (specsum[i]>specsum[i-1] && specsum[i]>specsum[i+1])
                               {
                                        srtime.push_back(stime+0.02*(i+1));
                        //                fout<<stime+0.02*(i+1)<<endl;
                               }
                                //fout<<specsum[i]<<endl;
                        }

                        if (Bou.size()>0)
                                Bou.clear();
                        float intensitytime;
                        for (unsigned int i=0;i<Intentime.size();i++)
                        {
                                intensitytime=Intentime.at(i);
                                for (unsigned int j=0;j<vartime.size();j++)
                                {
                                        if ((intensitytime-0.025)<=vartime.at(j) && (intensitytime+0.025)>=vartime.at(j))
                                        {
                                                for (unsigned int k=0;k<sftime.size();k++)
                                                {
                                                        if ((intensitytime-0.025)<=sftime.at(k) && (intensitytime+0.025)>=sftime.at(k))
                                                        {
                                                               // for (unsigned int l=0;l<srtime.size();l++)
                                                                //{
                                                                        //if ((intensitytime-0.02)<=srtime.at(l) && (intensitytime+0.02)>=srtime.at(l))
                                                                        //{

                                                //for (unsigned int k=0;k<unvoicebou.size();k++)
                                                //{
                                                        //if {
                                                        //fout<<"hihi"<<endl;
                                                        //fout<<intensitytime<<endl;
                                                Bou.push_back(intensitytime);
                                                                            }
                                                                //}
                                                        //}
                                                }
                                        }
                                }
                        }
                        
                        float tc;
                        for (unsigned int g=0;g<Bou.size();g++)
                        {
                                tc=Bou.at(g);
                                if ((tc-0.02)<vec.at(i).airvoice.etime && (tc+0.02)>vec.at(i).airvoice.etime)
                                {
                                        continue;
                                }
                                else
                                {
                                        if (g==0)
                                        {

                                                stemp.stime=tc;
                                                stemp.etime=source.etime;
                                                stemp.airvoice.stime=0.0;
                                                stemp.airvoice.etime=0.0;
                                                stemp.pitchvoice.stime=tc;
                                                stemp.pitchvoice.etime=source.pitchvoice.etime;
                                                vec.at(i).etime=tc;
                                                vec.at(i).pitchvoice.etime=tc;
                                                Syltemp.push_back(stemp);
                                        }
                                        else
                                        {
                                                //etime=vec.at(i).pitchvoice.etime;
                                                //stime=vec.at(i).pitchvoice.stime;
                                                if ((tc-Bou.at(g-1))<0.07)
                                                        continue;
                                                else
                                                {
                                                        stemp.stime=tc;
                                                        stemp.etime=source.etime;
                                                        stemp.airvoice.stime=0.0;
                                                        stemp.airvoice.etime=0.0;
                                                        stemp.pitchvoice.stime=tc;
                                                        stemp.pitchvoice.etime=source.pitchvoice.etime;
                                                        Syltemp.at(Syltemp.size()-1).etime=tc;
                                                        Syltemp.at(Syltemp.size()-1).pitchvoice.etime=tc;
                                                        Syltemp.push_back(stemp);
                                                }
                                        }
                                }

                        }


                        /*
                        float ti,tc;
                        for (int i=4;i<(m_SpecFluxBuf.size()-4);i++)
                        {
                                if (m_SpecFluxBuf[i]>threashold && specsum[i]>=1500)
                                {

                                        ti=stime+0.02*(i+1)+0.01;
                                        if (Bou.size()>0)
                                        {
                                                for (unsigned int g=0;g<Bou.size();g++)
                                                {
                                                        tc=Bou.at(g);
                                                        if ((tc+0.1)>ti)
                                                        {
                                                                tc=(tc+ti)/2;
                                                                Bou.at(g)=tc;
                                                        }
                                                        else
                                                                Bou.push_back(tc);

                                                }
                                        }
                                        else
                                        {
                                                Bou.push_back(ti);
                                        }
                                        //fout<<stime+0.02*(i+1)+0.01<<endl;
                                }

                        }
                        */
                        /*for (unsigned int g=0;g<Bou.size();g++)
                        {
                                fout<<Bou.at(g)<<endl;
                        }
                        
                        for (unsigned int z=0;z<Intentime.size();z++)
                        {
                                fout<<Intentime.at(z)<<endl;
                        }
                        
                        for (unsigned int g=0;g<Bou.size();g++)
                        {
                                tc=Bou.at(g);
                                //etime=vec.at(i).pitchvoice.etime;
                                //stime=vec.at(i).pitchvoice.stime;
                                stemp.stime=stime;
                                stemp.etime=etime;
                                stemp.pitchvoice.stime=tc;
                                stemp.pitchvoice.etime=0.0;
                                Syltemp.push_back(stemp);
                        } */
               }
        }
                        /*
                        fout<<"Check"<<endl;
                        for (unsigned int g=0;g<Syltemp.size();g++)
                        {
                                //tc=Bou.at(g);
                                fout<<Syltemp.at(g).stime<<endl;
                                fout<<Syltemp.at(g).etime<<endl;
                                fout<<Syltemp.at(g).airvoice.stime<<endl;
                                fout<<Syltemp.at(g).airvoice.etime<<endl;
                                fout<<Syltemp.at(g).pitchvoice.stime<<endl;
                                fout<<Syltemp.at(g).pitchvoice.etime<<endl;
                                //Syltemp.push_back(stemp);
                        }
                        fout<<"Check over"<<endl;
                        */
        if (Syltemp.size()>0)
        {
                //fout<<"in1"<<endl;
                for (unsigned zz=0;zz<Syltemp.size();zz++)
                {
                        stemp=Syltemp.at(zz);
                        vec.push_back(stemp);
                /*
                        fout<<"in2"<<endl;

                        for (unsigned int i=0;i<vec.size();i++)
                        {
                                if ((stemp.stime==vec.at(i).pitchvoice.stime) && (stemp.etime==vec.at(i).pitchvoice.etime))
                                {
                                        fout<<"in3"<<endl;
                                        stemp.etime=vec.at(i).etime;
                                        stemp.pitchvoice.etime=vec.at(i).etime;
                                        vec.at(i).etime=stemp.pitchvoice.stime;
                                        vec.at(i).pitchvoice.etime=stemp.pitchvoice.stime;
                                        stemp.stime=stemp.pitchvoice.stime;
                                        vec.push_back(stemp);
                                        break;
                                 }
                        } */
                }

        }
/* */
        //fout.close();
/*
        if ((etime-stime)<0.4)
                return false;
        fout<<stime<<" "<<etime<<endl;
        int start=stime*16000;
        //int start=0.1*16000;
        int end=etime*16000;
        //int end=2.1*16000;
        fout<<start<<" "<<end<<endl;
        PVector wavspeech;
        wavspeech.SetLength(end-start+1);
        for (int w=0;w<wavspeech.size();w++)
                wavspeech[w]=wav[w+start];

	int framesize=320;
        int specfftsize=512;//fftsize;
	int frameNum =  wavspeech.size() / framesize;
        //int frameNum =  wav.GetBufLength() / framesize;

        PVector sp;
        m_SpectrumBuf.setRC(frameNum,specfftsize+1);
        //SSP FSSP;
	for(int z = 0; z < frameNum; z++)
        {

                //�@�}�l�N�]�w��fft��size
                sp.SetLength(framesize+1);
                //sp.SetLength(specfftsize+1);
        	int i,n;
	        //copy�@�q speech frame
	        for(i=z*framesize,n=1; i < (1+z)*framesize; i++,n++)
	        {
		        sp[n] = wavspeech[i];
	        }
                FSSP.ZeroMeanFrame(sp);
                //��fft�Ϊ�
                //PVector fsp;

                for (i=1;i<=framesize;i++)
                        m_SpectrumBuf[z][i]=sp[i];
                if (framesize<specfftsize)
                {
                         //�᭱�ɹs
                         for (int k=framesize+1; k<=specfftsize; k++) //�᭱�[0
                                m_SpectrumBuf[z][k] = 0.0;
                }
                FSSP.frame2spec(m_SpectrumBuf[z]);
        }
        //Cal Spec Flux
        float spectrumflux=0.0;
        double temp(0.0),sum(0.0);
        double deltavalue=0.000001;  //�n�h�֭�?
        m_SpecFluxBuf.SetLength(frameNum-1);
        for(int z = 1; z < frameNum; z++)
        {
                sum=0.0;
                for (int h=1;h<=specfftsize/2;h++)
                {
                        temp=log10(m_SpectrumBuf[z][h]+deltavalue)-log10(m_SpectrumBuf[z-1][h]+deltavalue);
                        //temp=m_SpectrumBuf[z][h]-m_SpectrumBuf[z-1][h];
                        temp=pow(temp,2);
                        sum=sum+temp;
                }
                sum=sum/(specfftsize/2);
                m_SpecFluxBuf[z-1]=sum;
        }
        for (int i=0;i<m_SpecFluxBuf.size();i++)
        {
                fout<<m_SpecFluxBuf[i]<<endl;
        }
        fout.close();
*/
        return true;
}
void PFeature::plotVolumn(HDC hdc)
{
     //GDI����O�޿�y�� ,�i�M�g��h�ؤ覡�h
     //�ӭ�Ӫ��O�˸m�y��
     RECT rect;
     HDC hMemDC;
     HDC hSrc;     //screen DC
     HBITMAP hBitmap,hOldBitmap;

     HPEN hPen,hOldPen;
     
     HBRUSH hbrush, hbrushOld;

     GetClipBox(hdc,&rect);

     hSrc = GetDC(0);
     hMemDC  = CreateCompatibleDC(hSrc);
     hBitmap = CreateCompatibleBitmap(hSrc ,rect.right,rect.bottom);
     hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);

     hbrush = CreateSolidBrush(RGB(0, 0, 0));
     hbrushOld = SelectObject(hMemDC, hbrush);

     FillRect(hMemDC,&rect , hbrush);

     SetMapMode(hMemDC  ,MM_ANISOTROPIC );

     if (m_volumnBuf.size()>0)
     {
        float maxVolumn = 0.0f;

        for(int i = 0; i < m_volumnBuf.size(); i++)
        {
                if(m_volumnBuf[i] > maxVolumn) maxVolumn = m_volumnBuf[i];
        }
        //maxPitch=600;
        //SetMapMode(hMemDC  ,MM_ANISOTROPIC );
        SetWindowExtEx(hMemDC , m_volumnBuf.size() , maxVolumn ,NULL);
        SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);
        SetViewportOrgEx(hMemDC,0,rect.bottom,NULL);
        MoveToEx(hMemDC,0,0,NULL);
        hPen = CreatePen(PS_SOLID,0,RGB(0,255,255));
        hPen = SelectObject(hMemDC,hPen);
        for(int i=0; i < m_volumnBuf.size() ; i++)
        {
                LineTo(hMemDC,i,m_volumnBuf[i]);
        }
     }


     SetMapMode(hMemDC  ,MM_TEXT);
     SetViewportOrgEx(hMemDC ,0,0,NULL);    //�]�w���I�^�h
     BitBlt(hdc,0,0,                // destination (x,y)   //�NMemoryDC���϶K���Ӫ��ϤW,�n���_�@
            rect.right,rect.bottom, // width, height
            hMemDC,0,0,             // source (x,y)
            SRCCOPY);


     SelectObject(hMemDC, hOldPen);
     DeleteObject(hPen);

     SelectObject(hMemDC, hbrushOld);
     DeleteObject(hbrush);

     SelectObject(hMemDC, hOldBitmap);
     DeleteObject(hBitmap);

     ReleaseDC(NULL,hSrc);
     DeleteDC(hMemDC);
	
}
void PFeature::plotDifVolumn(HDC hdc,int tsize,wseginfo& teacher,int tlen,wseginfo& student,int slen)
{
     //GDI����O�޿�y�� ,�i�M�g��h�ؤ覡�h
     //�ӭ�Ӫ��O�˸m�y��
     int framesize=160;
     RECT rect;
     HDC hMemDC;
     HDC hSrc;     //screen DC
     HBITMAP hBitmap,hOldBitmap;

     HPEN hPen,hOldPen;
     
     HBRUSH hbrush, hbrushOld;

     GetClipBox(hdc,&rect);

     hSrc = GetDC(0);
     hMemDC  = CreateCompatibleDC(hSrc);
     hBitmap = CreateCompatibleBitmap(hSrc ,rect.right,rect.bottom);
     hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);

     hbrush = CreateSolidBrush(RGB(0, 0, 0));
     hbrushOld = SelectObject(hMemDC, hbrush);

     FillRect(hMemDC,&rect , hbrush);

     SetMapMode(hMemDC  ,MM_ANISOTROPIC );

     if (m_volumnBuf.size()>0)
     {
        float maxVolumn = 0.0f;

        for(int i = 0; i < m_volumnBuf.size(); i++)
        {
                if(m_volumnBuf[i] > maxVolumn) maxVolumn = m_volumnBuf[i];
        }
        //maxPitch=600;
        //SetMapMode(hMemDC  ,MM_ANISOTROPIC );
        SetWindowExtEx(hMemDC , tsize , maxVolumn ,NULL);
        SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);
        SetViewportOrgEx(hMemDC,0,rect.bottom,NULL);
        MoveToEx(hMemDC,0,0,NULL);
        hPen = CreatePen(PS_SOLID,0,RGB(0,255,255));
        hPen = SelectObject(hMemDC,hPen);
        if (teacher.size()==student.size())
        {
            float start,end,tmps,tmpe;
            int z=0;
            int oldi=0;
            for (int k=0;k<student.size()-1;k++)
            {
               start=student[k].sn/framesize;
               end=student[k+1].sn/framesize;
               tmps = teacher[k].sn/framesize;
               tmpe = teacher[k+1].sn/framesize;
               float deltaJ=(end-start)/(tmpe-tmps);
               int i;
               for (float j=start;j<end;j=j+deltaJ)
               {
                  i=(int)(j);
                  if (i>=1 && i<m_volumnBuf.size())
                  {
                     //LineTo(hMemDC,z,m_qbuf[i]);
                     LineTo(hMemDC,z,m_volumnBuf[i]);
                  }
                  oldi=i;
                  z++;
               }
            }

         }
        /*
        for(int i=0; i < m_volumnBuf.size() ; i++)
        {
                LineTo(hMemDC,i,m_volumnBuf[i]);
        }
        */
     }


     SetMapMode(hMemDC  ,MM_TEXT);
     SetViewportOrgEx(hMemDC ,0,0,NULL);    //�]�w���I�^�h
     BitBlt(hdc,0,0,                // destination (x,y)   //�NMemoryDC���϶K���Ӫ��ϤW,�n���_�@
            rect.right,rect.bottom, // width, height
            hMemDC,0,0,             // source (x,y)
            SRCCOPY);


     SelectObject(hMemDC, hOldPen);
     DeleteObject(hPen);

     SelectObject(hMemDC, hbrushOld);
     DeleteObject(hbrush);

     SelectObject(hMemDC, hOldBitmap);
     DeleteObject(hBitmap);

     ReleaseDC(NULL,hSrc);
     DeleteDC(hMemDC);
}
