#ifndef __PMATRIX_H
#define __PMATRIX_H
//#include <vector>
//using namespace std;
class PVector
{
private:
	float* m_value;
	int m_vec_size;
public:
        PVector():m_value(0),m_vec_size(0){}

	float* GetBuffer(){return m_value;}
	void SetLength(long length)     //COL
	{
		if (m_value) delete [] m_value;
		m_value=new float[length];
		m_vec_size=length;
	}
	int size()  {return m_vec_size;}

	float& operator[](long idx)
	{
		return m_value[idx];
	}
        ~PVector(){ if (m_value) delete [] m_value; }
};

/*

class classMatrix
{
   public:
      // Constructor
      classMatrix() {}
      
      classMatrix(int row, int col) : array(row)
      {
         for(int i = 0; i < row; i++)
            array[i].resize(col);
      }
      
      classMatrix(int row, int col, const int val) : array(row)
      {
         for(int i = 0; i < row; i++)
            array[i].resize(col, val);
      }
      
      // Destructor
      
      // Accessors
      const vector<int>& operator[](int row) const;
      int NumRows() const;
      int NumCols() const;
      void Display() const;
            
      // Mutators
      void push_back(const vector<int>& r); //add a new row
      void push_front(const vector<int>& r);
      void add_col(int pos, const vector<int>& r);//add a new col
      void erase(int pos); //remove a row at the posotion pos
      
   private:
      vector<vector<int> > array; //mind extra space between > >
};
*/

class PMatrix
{
private:
	PVector *m_pvec;
	long     m_matrix_size;   //row
	long     m_vector_size;   //col

	void   createMatrix(long row,long col)
	{
        if(m_pvec) delete [] m_pvec;
		m_pvec = new PVector[row];

		for(int i = 0 ; i < row ; i++)
			(m_pvec+i)->SetLength(col);
	}

public:
	PMatrix():m_matrix_size(0),m_vector_size(0),m_pvec(0){};
	long GetCol() { return m_vector_size ; }
	long GetRow() { return m_matrix_size ; }
	void setRC(long RowDim,long ColDim)
	{
		m_matrix_size = RowDim;
		m_vector_size = ColDim;
		createMatrix(RowDim,ColDim);
	}

	PVector& operator[](long ridx)
	{
		return m_pvec[ridx];
	}
	
	~PMatrix() {if(m_pvec) delete [] m_pvec ; }
};

#endif