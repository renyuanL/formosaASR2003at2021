#ifndef __PBuffer_H
#define __PBuffer_H
#include<windows.h>
#include<mmsystem.h>
#include <fstream.h>


class PBuffer
{
private:
        short* m_sh;
public:

        WAVEFORMATEX m_pcmWaveFormat;
	int m_nsh;
	int nshused;

        short& operator[](long idx)
        {
                return m_sh[idx];
        }

        PBuffer& operator =(PBuffer& obj);

	PBuffer();
	~PBuffer() ;
        short* GetBufPoint();

	void reserve(int nsh);
        void setformat();
	int ms2nsh(int ms);
        void save();
        void save(int len);
};
#endif