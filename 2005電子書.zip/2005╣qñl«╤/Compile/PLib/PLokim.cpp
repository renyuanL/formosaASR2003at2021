#include "PLokim.h"
//Constuctor
PLokim::PLokim()
{
	
}
int PLokim::lokim(PBuffer& qbuf,int nsh)
{
        qbuf.reserve(nsh);
	//if (!iw.open(&(qbuf.pcm)))
	//{
	  //	return 0;
	//}
        res=iw.open(&(qbuf.m_pcmWaveFormat));
	iw.sethdr(qbuf.GetBufPoint(),nsh);
        if (res==MMSYSERR_NOERROR)
        {
	res=iw.prepare();
       
	res=iw.add();

	iw.reset4wait();
	iw.bLokImDiong=1;
	res=iw.start();
	iw.wait2end();
	//qbuf.nshused=iw.hdr.dwBytesRecorded/sizeof(short);
   iw.bLokImDiong=0;
        res=iw.unprepare();
	res=iw.reset();
   iw.close();

        szlength=nsh;
        return 1;
	}
        else
                return 0;


}
int PLokim::tlokim(PBuffer& qbuf,int nsh)
{
	p2qbuf=&qbuf;
	shsize=nsh;
        res=iw.open(&(qbuf.m_pcmWaveFormat));
        if (res==MMSYSERR_NOERROR)
        {
	        thd.begin(thdf,this);
	        return 1;
        }
        else
                return 0;
}

int PLokim::sztlokim()
{
        //crtsection cs;

	PBuffer &qbuf=*p2qbuf;
	int nsh=shsize;

	qbuf.reserve(nsh);
        //�s�}�⦸�����D
	//res=iw.open(&(qbuf.m_pcmWaveFormat));
	iw.sethdr(qbuf.GetBufPoint(),nsh);
        if (res==MMSYSERR_NOERROR)
        {

	        res=iw.prepare();
           res=iw.add();
           iw.reset4wait();
		     iw.bLokImDiong=1;
		     res=iw.start();
		     iw.wait2end();
		     //qbuf.nshused=iw.hdr.dwBytesRecorded/sizeof(short);
           iw.bLokImDiong=0;
           res=iw.unprepare();
		     res=iw.reset();
           res=iw.close();
           szlength=nsh;
           //qbuf.save();

        	return 1;
	}
        else
               	return 0;

        
}