#ifndef __PDynamic_H
#define __PDynamic_H
#include <iostream.h>
#include <limits.h>
#include "PWave.h"
#include "Compile/inc/CRec.h"
#include "Compile/inc/CMel.h"
#include "Compile/inc/CWaveIn.h"
#include "Compile/inc/CWaveOut.h"
#include "PDic.h"
#include "SSP.h"
#include <stdio.h>
#include <io.h>
#include <dir.h>

struct xandy
{
        int x;
        int y;
};
class PDynamic
{
private:
	float getvecdis(CVector& ref,CVector& com);
	PDic m_dic;
        CWave m_comwb;
        CMel m_mel;
        CFeaBuf m_comfb;
        CWave m_refwb;
        CFeaBuf m_reffb;
        CMatrix m_distance;
        CMatrix m_dpmatrix;
        vector<xandy> m_mapvec;

        SSP m_ssp;
public:
        //TTS
	vector<float> m_wavlength;
        int file_exists(char *filename);
	vector<float> m_dtwsegbou;
        vector<double> m_disgrade;
	void init(char* table, char* parameter);
	bool connectwave(const char* instr);
	void doDynamicProgramming(const char* rfn,const char* cfn);

   double doOnedimDP(PVector& in,int ins,int ine,PVector& com,int coms,int come);

        void SaveToTextGrid(const char* tfn);
        //������J������?
        vector<string> m_pingin;
        char m_dir[MAXPATH];

        vector<string> m_nonexist;
        bool pinginwave(const char* instr);
        PDynamic();
        ~PDynamic();
        char m_start_dir[MAXPATH];
        //USE LPC TO SEGMENT
        void doLPCDTW(const char* rfn,const char* cfn,int lpcorder);
};
#endif