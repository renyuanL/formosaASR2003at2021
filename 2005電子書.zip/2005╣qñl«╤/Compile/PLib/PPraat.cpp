
#include "PPraat.h"
///////////////////////////////////////////////////////
//Constuctor
PPraat::PPraat()
{
	m_TotalFrameNum=0;
        m_PitchInterVal=0.0;
        m_point=NULL;
}
//Destructor
///////////////////////////////////////////////////////
PPraat::~PPraat()
{

}
///////////////////////////////////////////////////////
void PPraat::readPraatFormantFile(const char* fn)
{
        ifstream fin;
        fin.open(fn,ios::in);
        char LineBuf[500];
        for (int i=0;i<3;i++)
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
        //�_�l�M�����ɶ�
        float smin,emax;
        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>smin;
        //cout<<smin<<endl;
        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>emax;
        //cout<<emax<<endl;
        m_pointsize=0;
        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>LineBuf>>m_pointsize;
        //cout<<pointsize<<endl;
        //IPoint* m_point;
        if (m_point!=NULL)
                delete [] m_point;
        m_point=new IPoint[m_pointsize];

        float time;
        float freq;
        float bandwidth;
        int numofformants;
        for (int i=0;i<m_pointsize;i++)
        {
                //points [1]:
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                //    time = 0.02675736961451247
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                m_strScan.r2b(LineBuf,sizeof(LineBuf));
                m_strScan>>LineBuf>>LineBuf>>time;
                m_point[i].time=time;
                //    numberOfFormants = 5
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                m_strScan.r2b(LineBuf,sizeof(LineBuf));
                m_strScan>>LineBuf>>LineBuf>>numofformants;
                m_point[i].NumOfFormants=numofformants;
                m_point[i].formant=new float [numofformants];
                m_point[i].bandwidth=new float [numofformants];
                //    formant []:
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                for (int j=0;j<numofformants;j++)
                {
                        fin.getline(LineBuf,sizeof(LineBuf),'\n');
                        m_strScan.r2b(LineBuf,sizeof(LineBuf));
                        m_strScan>>LineBuf>>LineBuf>>LineBuf>>freq;
                        m_point[i].formant[j]=freq;
                }
                //        bandwidth []: 
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                for (int j=0;j<numofformants;j++)
                {
                        fin.getline(LineBuf,sizeof(LineBuf),'\n');
                        m_strScan.r2b(LineBuf,sizeof(LineBuf));
                        m_strScan>>LineBuf>>LineBuf>>LineBuf>>bandwidth;
                        m_point[i].bandwidth[j]=bandwidth;
                }

        }
}
///////////////////////////////////////////////////////
void PPraat::readPraatIntensityFile(const char* fn)
{
   ifstream fin;
   fin.open(fn);
   char LineBuf[1024];
   for (int i=0;i<3;i++)
        fin.getline(LineBuf,sizeof(LineBuf),'\n');

   float xmin=0.0;
   float xmax=0.0;

   fin.getline(LineBuf,sizeof(LineBuf),'\n');
   m_strScan.r2b(LineBuf,sizeof(LineBuf));
   m_strScan>>LineBuf>>LineBuf>>xmin;
   //cout<<xmin<<endl;
   fin.getline(LineBuf,sizeof(LineBuf),'\n');
   m_strScan.r2b(LineBuf,sizeof(LineBuf));
   m_strScan>>LineBuf>>LineBuf>>xmax;
   //cout<<xmax<<endl;

   float nx;
   fin.getline(LineBuf,sizeof(LineBuf),'\n');
   m_strScan.r2b(LineBuf,sizeof(LineBuf));
   m_strScan>>LineBuf>>LineBuf>>nx;
   //cout<<nx<<endl;
   fin.getline(LineBuf,sizeof(LineBuf),'\n');
   m_strScan.r2b(LineBuf,sizeof(LineBuf));
   m_strScan>>LineBuf>>LineBuf>>m_IntenInterVal;
   //cout<<dx<<endl;

   for (int i=0;i<8;i++)
        fin.getline(LineBuf,sizeof(LineBuf),'\n');


   m_intensity.SetLength(nx);
      
   for (int i=0;i<nx;i++)
   {
        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>LineBuf>>LineBuf>>m_intensity[i];
        //cout<<m_intensity[i]<<endl;
   }
   fin.close();

}
///////////////////////////////////////////////////////
void PPraat::readPraatPitchFile(const char* fn)
{
        ifstream fin;
	fin.open(fn);
	char LineBuf[1024];
	for (int i=0;i<5;i++)
		fin.getline(LineBuf,sizeof(LineBuf),'\n');
	fin.getline(LineBuf,sizeof(LineBuf),'\n');
   	if(strstr(LineBuf ,"nx = "))
   	{
     		m_strScan.r2b(LineBuf,sizeof(LineBuf));
      		m_strScan>>LineBuf>>LineBuf>>m_TotalFrameNum;
   	}
   	//else
   		//cout<<"Error about Read File Sequence"<<endl;
	fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
      	m_strScan>>LineBuf>>LineBuf>>m_PitchInterVal;

        m_PitchVal.SetLength(m_TotalFrameNum);
        m_intVal.SetLength(m_TotalFrameNum);

	int cfn=0;//�p��FrameNum
	while (!fin.eof())
	{
		strcpy(LineBuf,"");
      		fin.getline(LineBuf,sizeof(LineBuf),'\n');
      		if (strlen(LineBuf)==0)
        		continue;

		if(strstr(LineBuf ,"intensity = "))
		{
         		m_strScan.r2b(LineBuf,sizeof(LineBuf));
         		m_strScan>>LineBuf>>LineBuf>>m_intVal[cfn];
      		}

      		if(strstr(LineBuf ,"candidate [1]"))
      		{
         		fin.getline(LineBuf,sizeof(LineBuf),'\n');
         		m_strScan.r2b(LineBuf,sizeof(LineBuf));
         		m_strScan>>LineBuf>>LineBuf>>m_PitchVal[cfn];
         		cfn++;
      		}
     		//�b�Y���L�{��,����M���T�I�ΨS����M���T�I
   	}
	fin.close();
}
///////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void PPraat::plotPitch(HDC hdc)
{
    float maxPitch = 0.0f;
    float minPitch = 600.0f;

    for(int i = 0; i < m_PitchVal.size(); i++)
    {
        if(m_PitchVal[i] > maxPitch) maxPitch = m_PitchVal[i];
        if (m_PitchVal[i]>0.0f && m_PitchVal[i] < minPitch) minPitch = m_PitchVal[i];
    }
    //maxPitch=600;
      maxPitch=maxPitch-minPitch+20;
     //plot
     RECT rect;
     HDC hMemDC;
     HDC hSrc;     //screen DC
     HBITMAP hBitmap,hOldBitmap;

     HPEN hPen,hOldPen,hRedPen,hOldRedPen;
     HBRUSH hbrush, hbrushOld;

     GetClipBox(hdc,&rect);

     hSrc = GetDC(0);
     hMemDC  = CreateCompatibleDC(hSrc);
     hBitmap = CreateCompatibleBitmap(hSrc ,rect.right,rect.bottom);
     hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);

     hbrush = CreateSolidBrush(RGB(0, 0, 0));
     hbrushOld = SelectObject(hMemDC, hbrush);

     FillRect(hMemDC,&rect , hbrush);

     SetMapMode(hMemDC  ,MM_ANISOTROPIC );
     SetWindowExtEx(hMemDC , m_PitchVal.size() , maxPitch ,NULL);
     SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);
     SetViewportOrgEx(hMemDC,0,rect.bottom,NULL);

     hRedPen = CreatePen(PS_SOLID,1,RGB(100,100,100));
     hOldRedPen = SelectObject(hMemDC,hRedPen);
     MoveToEx(hMemDC,0,10,NULL);
     LineTo(hMemDC,m_PitchVal.size(),10);
     MoveToEx(hMemDC,0,(maxPitch-20)/4+10,NULL);
     LineTo(hMemDC,m_PitchVal.size(),(maxPitch-20)/4+10);
     MoveToEx(hMemDC,0,(maxPitch-20)/2+10,NULL);
     LineTo(hMemDC,m_PitchVal.size(),(maxPitch-20)/2+10);
     MoveToEx(hMemDC,0,(maxPitch-20)*3/4+10,NULL);
     LineTo(hMemDC,m_PitchVal.size(),(maxPitch-20)*3/4+10);
     MoveToEx(hMemDC,0,maxPitch-10,NULL);
     LineTo(hMemDC,m_PitchVal.size(),maxPitch-10);
/*
     MoveToEx(hMemDC,0,10,NULL);
     LineTo(hMemDC,m_PitchVal.size(),10);
     MoveToEx(hMemDC,0,maxPitch/4,NULL);
     LineTo(hMemDC,m_PitchVal.size(),maxPitch/4);
     MoveToEx(hMemDC,0,maxPitch/2,NULL);
     LineTo(hMemDC,m_PitchVal.size(),maxPitch/2);
     MoveToEx(hMemDC,0,maxPitch*3/4,NULL);
     LineTo(hMemDC,m_PitchVal.size(),maxPitch*3/4);
     MoveToEx(hMemDC,0,maxPitch-10,NULL);
     LineTo(hMemDC,m_PitchVal.size(),maxPitch-10);
*/
     MoveToEx(hMemDC,0,0,NULL);
     
     hPen = CreatePen(PS_SOLID,2,RGB(0,255,0));
     hPen = SelectObject(hMemDC,hPen);

     // float deltaJ=2; //downsample
     //for(int j=0; j < m_PitchVal.size()*deltaJ ; j=j+1)
     for(int i=0; i < m_PitchVal.size() ; i++)
     {
       // i=(int)(j/deltaJ);
        if (i>=1 && i<=m_PitchVal.size()-1)
                if ((m_PitchVal[i]==0 && m_PitchVal[i-1]>0) || (m_PitchVal[i]>0 && m_PitchVal[i-1]==0))
                        MoveToEx(hMemDC,i,m_PitchVal[i]-minPitch+10,NULL);
                else
                        LineTo(hMemDC,i,m_PitchVal[i]-minPitch+10);
        else
                LineTo(hMemDC,i,m_PitchVal[i]-minPitch+10);
       //LineTo(hMemDC,i,m_PitchVal[i]);
     }

     SetMapMode(hMemDC,MM_TEXT);
     SetViewportOrgEx(hMemDC ,0,0,NULL);
     BitBlt(hdc,0,0,                // destination (x,y)
            rect.right,rect.bottom, // width, height
            hMemDC,0,0,             // source (x,y)
            SRCCOPY);



     SelectObject(hMemDC, hOldPen);
     DeleteObject(hPen);

     SelectObject(hMemDC, hOldRedPen);
     DeleteObject(hRedPen);

     SelectObject(hMemDC, hbrushOld);
     DeleteObject(hbrush);

     SelectObject(hMemDC, hOldBitmap);
     DeleteObject(hBitmap);

     ReleaseDC(NULL,hSrc);
     DeleteDC(hMemDC);


}
//////////////////////////////////////////////////////////////////////
void PPraat::readPraatTextGridFile(const char* fn)
{

        ifstream fin;
        fin.open(fn,ios::in);
        char LineBuf[500];
        for (int i=0;i<6;i++)
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
        //Size�j�p
        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        int itemNum=0;
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>itemNum;

        //cout<<itemNum<<endl;
        
        for (int i=0;i<4;i++)
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
        //�_�l�M�����ɶ�
        float smin,emax;
        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>smin;
        //cout<<smin<<endl;
        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>emax;
        //cout<<emax<<endl;
        //�X��Intervals
        int intervals;

        fin.getline(LineBuf,sizeof(LineBuf),'\n');
        m_strScan.r2b(LineBuf,sizeof(LineBuf));
        m_strScan>>LineBuf>>LineBuf>>LineBuf>>intervals;
        //cout<<intervals<<endl;
        syl temp;

        m_labbou.Bouder.clear();

        while (fin)
        {
                strcpy(LineBuf,"");
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                if (strlen(LineBuf)==0)
                        continue;
                if(strstr(LineBuf,"        intervals ["))
                {
                        float xmin,xmax;
                        fin.getline(LineBuf,sizeof(LineBuf),'\n');
                        m_strScan.r2b(LineBuf,sizeof(LineBuf));
                        m_strScan>>LineBuf>>LineBuf>>xmin;
                        temp.stime=xmin;
                        fin.getline(LineBuf,sizeof(LineBuf),'\n');
                        m_strScan.r2b(LineBuf,sizeof(LineBuf));
                        m_strScan>>LineBuf>>LineBuf>>xmax;
                        temp.etime=xmax;
                        fin.getline(LineBuf,sizeof(LineBuf),'\n');
                        m_strScan.r2b(LineBuf,sizeof(LineBuf));
                        m_strScan>>LineBuf>>LineBuf>>LineBuf;
                        strcpy(temp.sylname,LineBuf);
                        m_labbou.Bouder.push_back(temp);
                }
        }
/*
        for (int kk=0;kk<m_labbou.Bouder.size();kk++)
        {
                cout<<m_labbou.Bouder.at(kk).stime<<endl;
                cout<<m_labbou.Bouder.at(kk).etime<<endl;
                cout<<m_labbou.Bouder.at(kk).sylname<<endl;
        }
*/
        fin.close();

}
//////////////////////////////////////////////////////////////////////
void PPraat::plotDifPitch(HDC hdc,int tsize,wseginfo& teacher,int tlen,wseginfo& student,int slen)
{
    float maxPitch = 0.0f;
    float minPitch = 600.0f;
     int framesize=m_PitchInterVal*16000;

     vector<int> tempi;
     if (teacher.size()==student.size())
     {
      float start,end,tmps,tmpe;
      int z=0;
      int oldi=0;
      for (int k=0;k<student.size()-1;k++)
      {
         start=student[k].sn/framesize;
         end=student[k+1].sn/framesize;
         tmps = teacher[k].sn/framesize;
         tmpe = teacher[k+1].sn/framesize;
         float deltaJ=(end-start)/(tmpe-tmps);
         int i;
         for (float j=start;j<end;j=j+deltaJ)
         {
            i=(int)(j);
            if (i>=1 && i<=m_PitchVal.size()-1)
            {
                if ((m_PitchVal[i]==0 && m_PitchVal[oldi]>0) || (m_PitchVal[i]>0 && m_PitchVal[oldi]==0)){
                        tempi.push_back(i);
                        //MoveToEx(hMemDC,z,m_PitchVal[i]-minPitch+10,NULL);
                }
                else{
                        tempi.push_back(i);
                        //LineTo(hMemDC,z,m_PitchVal[i]-minPitch+10);
                        //fout<<i<<"\t"<<m_PitchVal[i]<<endl;
                }
            }
            else{
                //LineTo(hMemDC,z,m_PitchVal[i]-minPitch+10);
            }

            oldi=i;
         }

      }
     }

    for (unsigned int j=0;j<tempi.size();j++)
    {
      //for(int i = 0; i < m_PitchVal.size(); i++)
      //{
         int i=tempi.at(j);
        if(m_PitchVal[i] > maxPitch) maxPitch = m_PitchVal[i];
        if (m_PitchVal[i]>0.0f && m_PitchVal[i] < minPitch) minPitch = m_PitchVal[i];
    }
    //maxPitch=600;
      maxPitch=maxPitch-minPitch+20;
     //plot
     RECT rect;
     HDC hMemDC;
     HDC hSrc;     //screen DC
     HBITMAP hBitmap,hOldBitmap;

     HPEN hPen,hOldPen,hRedPen,hOldRedPen;
     HBRUSH hbrush, hbrushOld;

     GetClipBox(hdc,&rect);

     hSrc = GetDC(0);
     hMemDC  = CreateCompatibleDC(hSrc);
     hBitmap = CreateCompatibleBitmap(hSrc ,rect.right,rect.bottom);
     hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);

     hbrush = CreateSolidBrush(RGB(0, 0, 0));
     hbrushOld = SelectObject(hMemDC, hbrush);

     FillRect(hMemDC,&rect , hbrush);

     SetMapMode(hMemDC  ,MM_ANISOTROPIC );
     //SetWindowExtEx(hMemDC , m_PitchVal.size() , maxPitch ,NULL);
     SetWindowExtEx(hMemDC , tsize , maxPitch ,NULL);
     SetViewportExtEx(hMemDC ,rect.right,-rect.bottom,NULL);
     SetViewportOrgEx(hMemDC,0,rect.bottom,NULL);

     hRedPen = CreatePen(PS_SOLID,1,RGB(100,100,100));
     hOldRedPen = SelectObject(hMemDC,hRedPen);
     MoveToEx(hMemDC,0,10,NULL);
     LineTo(hMemDC,tsize,10);
     MoveToEx(hMemDC,0,(maxPitch-20)/4+10,NULL);
     LineTo(hMemDC,tsize,(maxPitch-20)/4+10);
     MoveToEx(hMemDC,0,(maxPitch-20)/2+10,NULL);
     LineTo(hMemDC,tsize,(maxPitch-20)/2+10);
     MoveToEx(hMemDC,0,(maxPitch-20)*3/4+10,NULL);
     LineTo(hMemDC,tsize,(maxPitch-20)*3/4+10);
     MoveToEx(hMemDC,0,maxPitch-10,NULL);
     LineTo(hMemDC,tsize,maxPitch-10);

     MoveToEx(hMemDC,0,0,NULL);
     
     hPen = CreatePen(PS_SOLID,2,RGB(0,255,0));
     hPen = SelectObject(hMemDC,hPen);


     ofstream fout;
     fout.open("pitch1.txt",ios::out);
     fout<<tsize<<endl;
     fout<<m_PitchVal.size()<<endl;
     if (teacher.size()==student.size())
     {
      float start,end,tmps,tmpe;
      int z=0;
      int oldi=0;
      for (int k=0;k<student.size()-1;k++)
      {
         start=student[k].sn/framesize;
         end=student[k+1].sn/framesize;

         //tmps = (teacher[k].sn/tlen)*slen/framesize;
         //tmpe = (teacher[k+1].sn/tlen)*slen/framesize;
         tmps = teacher[k].sn/framesize;
         tmpe = teacher[k+1].sn/framesize;


         fout<<(char)student[k].kd<<endl;
         fout<<start<<"\t"<<end<<endl;
         fout<<tmps<<"\t"<<tmpe<<endl;

         float deltaJ=(end-start)/(tmpe-tmps);
         //float deltaJ=(tmpe-tmps)/(end-start);

         //fout<<deltaJ<<endl;
         int i;

         //for (int j=start;j<(int)((end-start)*deltaJ+start);j=j+1)
         for (float j=start;j<end;j=j+deltaJ)
         {
            //i=(int)(j/deltaJ);

            i=(int)(j);

            //fout<<j<<"\t"<<i<<"\t"<<z<<endl;
            if (i>=1 && i<=m_PitchVal.size()-1)
            {
                if ((m_PitchVal[i]==0 && m_PitchVal[oldi]>0) || (m_PitchVal[i]>0 && m_PitchVal[oldi]==0)){
                        MoveToEx(hMemDC,z,m_PitchVal[i]-minPitch+10,NULL);
                }
                else{
                        LineTo(hMemDC,z,m_PitchVal[i]-minPitch+10);
                        fout<<i<<"\t"<<m_PitchVal[i]<<endl;
                }
            }
            else{
                LineTo(hMemDC,z,m_PitchVal[i]-minPitch+10);
            }
            oldi=i;

            z++;

         }

      }
     }

      /*
     // float deltaJ=2; //downsample
     //for(int j=0; j < m_PitchVal.size()*deltaJ ; j=j+1)
     for(int i=0; i < m_PitchVal.size() ; i++)
     {
       // i=(int)(j/deltaJ);
        if (i>=1 && i<=m_PitchVal.size()-1)
                if ((m_PitchVal[i]==0 && m_PitchVal[i-1]>0) || (m_PitchVal[i]>0 && m_PitchVal[i-1]==0))
                        MoveToEx(hMemDC,i,m_PitchVal[i]-minPitch+10,NULL);
                else
                        LineTo(hMemDC,i,m_PitchVal[i]-minPitch+10);
        else
                LineTo(hMemDC,i,m_PitchVal[i]-minPitch+10);
     }
    */
     SetMapMode(hMemDC,MM_TEXT);
     SetViewportOrgEx(hMemDC ,0,0,NULL);
     BitBlt(hdc,0,0,                // destination (x,y)
            rect.right,rect.bottom, // width, height
            hMemDC,0,0,             // source (x,y)
            SRCCOPY);



     SelectObject(hMemDC, hOldPen);
     DeleteObject(hPen);

     SelectObject(hMemDC, hOldRedPen);
     DeleteObject(hRedPen);

     SelectObject(hMemDC, hbrushOld);
     DeleteObject(hbrush);

     SelectObject(hMemDC, hOldBitmap);
     DeleteObject(hBitmap);

     ReleaseDC(NULL,hSrc);
     DeleteDC(hMemDC);


}
//////////////////////////////////////////////////////////////////////
