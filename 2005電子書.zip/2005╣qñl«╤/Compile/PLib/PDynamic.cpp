#include "PDynamic.h"
//Constuctor
///////////////////////////////////////////////////////////////////////////////////
PDynamic::PDynamic()
{

}
///////////////////////////////////////////////////////////////////////////////////
PDynamic::~PDynamic()
{
       
}
///////////////////////////////////////////////////////////////////////////////////
float PDynamic::getvecdis(CVector& ref,CVector& com)
{
        float sum=0.0;
        for (int i=0;i<ref.size();i++)
        {
                sum=sum+pow((ref[i]-com[i]),2);
                //sum=sum+fabs((ref[i]-com[i]));
        }
        float res=sqrt(sum);
        return res;	
}
///////////////////////////////////////////////////////////////////////////////////
void PDynamic::init(char* table, char* parameter)
{
	m_dic.loadtable(table);
	m_mel.settgtPK(parameter);
        m_mel.m_cfg.eNormalise = false;

}
///////////////////////////////////////////////////////////////////////////////////
bool PDynamic::connectwave(const char* instr)
{
	m_dic.searchpinging(instr);

        if (m_nonexist.size()>0)
		m_nonexist.clear();
        if (m_dic.m_noexistchinese.size()>0)
        {
                for (unsigned int i=0;i<m_dic.m_noexistchinese.size();i++)
                {
		        m_nonexist.push_back(m_dic.m_noexistchinese.at(i));
                }
                return false;
        }
        char LineBuf[1024];
        PWave wav1;
        int wavnum=0;

	if (m_wavlength.size()>0)
		m_wavlength.clear();

        float qiimlen;
        float qiimlensum=0.0;


        char szTmp[1024];
        for (int i=0;i<m_dic.m_answer.size();i++)
        {
                ifstream fin;
                strcpy(szTmp,"");
                strcpy(szTmp,"Run/wav/");
                strcat(szTmp,m_dic.m_answer.at(i).c_str());
                strcat(szTmp,".wav");

                if (file_exists(szTmp))
                        continue;
                else
                {
                        strcpy(szTmp,"");
                        strcpy(szTmp,"Run/newwav/");
                        strcat(szTmp,m_dic.m_answer.at(i).c_str());
                        strcat(szTmp,".wav");
                        if (file_exists(szTmp))
                                continue;
                        else
                        {
                                bool isfileexist=false;
                                for (int j=57;j>=48;j--)
                                {
                                        m_pingin.at(i)[m_dic.m_answer.at(i).length()-1]=j;
                                        strcpy(szTmp,"");
                                        strcpy(szTmp,"Run/wav/");
                                        strcat(szTmp,m_dic.m_answer.at(i).c_str());
                                        strcat(szTmp,".wav");
                                        if (file_exists(szTmp))
                                        {
                                                isfileexist=true;
                                                break;
                                        }
                                        strcpy(szTmp,"");
                                        strcpy(szTmp,"Run/newwav/");
                                        strcat(szTmp,m_dic.m_answer.at(i).c_str());
                                        strcat(szTmp,".wav");
                                        if (file_exists(szTmp))
                                        {
                                                isfileexist=true;
                                                break;
                                        }
                                }
                                if (isfileexist==false)
                                        m_nonexist.push_back(m_dic.m_answer.at(i));
                                else
                                        continue;
                        }
                }
                //fin.open(szTmp,ios::in);
                //if (!fin.is_open())
                //        m_nonexist.push_back(m_dic.m_answer.at(i));
                //fin.close();
        }

        if (m_nonexist.size()>0)
                return false;



        for (int i=0;i<m_dic.m_answer.size();i++)
        {

                strcpy(LineBuf,"");
                strcpy(LineBuf,"Run/wav/");
                strcat(LineBuf,m_dic.m_answer.at(i).c_str());
                strcat(LineBuf,".wav");

                if (!file_exists(LineBuf))
                {
                        strcpy(LineBuf,"");
                        strcpy(LineBuf,"Run/newwav/");
                        strcat(LineBuf,m_dic.m_answer.at(i).c_str());
                        strcat(LineBuf,".wav");
                }
                if (wavnum==0)
                {
                        wav1.load(LineBuf);
                        wavnum++;
                        qiimlen=(float)wav1.GetBufLength()/16000.0;
                        m_wavlength.push_back(qiimlen);
                        qiimlensum=qiimlensum+qiimlen;
                }
                else
                {
                        PWave wav2;
                        wav2.load(LineBuf);
                        wav1+=wav2;
                        wavnum++;
                        qiimlen=(float)wav2.GetBufLength()/16000.0;
                        if (i!=m_dic.m_answer.size()-1)
                        {
                                qiimlensum=qiimlensum+qiimlen;
                                m_wavlength.push_back(qiimlensum);

                        }
                }
                //cout<<dic.m_answer.at(i)<<endl;

        }
        //�i�H��Error Checking
        int e=m_dic.geterrorcount();
        
        
        //cout<<e<<endl;
        if(wavnum>0)
                wav1.SaveWave("Run/TTS.wav");

        //for (int b=0;b<wavlength.size();b++)
        //        cout<<wavlength.at(b)<<endl;
        return true;
}
///////////////////////////////////////////////////////////////////////////////////
bool PDynamic::pinginwave(const char* instr)
{

	char* substring;
	char seps[]="_=- /";
//ofstream fout;
//fout.open("D:\\�ڷs�}�o���{��\\MyCT\\xx.txt",ios::out);
        char LineBuf[1024];
        strcpy(LineBuf,instr);
         //fout<<instr<<endl;
	substring=strtok(LineBuf,seps);
	if (m_pingin.size()>0)
		m_pingin.clear();
	while(substring!=NULL)
	{
		string tmp=substring;
               // fout<<tmp<<endl;
		m_pingin.push_back(tmp);
		substring=strtok(NULL,seps);
	}
        /*
        for (int i=0;i<m_pingin.size();i++)
        {
                //��0��9���Ʀr
                if (m_pingin.at(i)[m_pingin.at(i).length()-1]>=48 && m_pingin.at(i)[m_pingin.at(i).length()-1]<=57)
                {
                         m_pingin.at(i)=m_pingin.at(i);
                }
                else
                {
                        m_pingin.at(i)=m_pingin.at(i)+"1";
                }
        }
        */
       // fout<<m_nonexist.size()<<endl;
//fout.close();
        if (m_nonexist.size()>0)
		m_nonexist.clear();
        char szTmp[1024];
        char szTmp2[1024];
        for (int i=0;i<m_pingin.size();i++)
        {
                ifstream fin;

                strcpy(szTmp,"");
                strcpy(szTmp,"Run/wav/");
                strcat(szTmp,m_pingin.at(i).c_str());
                strcat(szTmp,".wav");
                if (file_exists(szTmp))
                        continue;
                else
                {
                        strcpy(szTmp,"");
                        strcpy(szTmp,"Run/newwav/");
                        strcat(szTmp,m_pingin.at(i).c_str());
                        strcat(szTmp,".wav");
                        if (file_exists(szTmp))
                                continue;
                        else
                        {

                                bool isfileexist=false;
                                for (int j=57;j>=48;j--)
                                {
                                        m_pingin.at(i)[m_pingin.at(i).length()-1]=j;
                                        strcpy(szTmp,"");
                                        strcpy(szTmp,"Run/wav/");
                                        strcat(szTmp,m_pingin.at(i).c_str());
                                        strcat(szTmp,".wav");
                                        if (file_exists(szTmp))
                                        {
                                                isfileexist=true;
                                                break;
                                        }
                                        strcpy(szTmp,"");
                                        strcpy(szTmp,"Run/newwav/");
                                        strcat(szTmp,m_pingin.at(i).c_str());
                                        strcat(szTmp,".wav");
                                        if (file_exists(szTmp))
                                        {
                                                isfileexist=true;
                                                break;
                                        }
                                }
                                if (isfileexist==false)
                                        m_nonexist.push_back(m_pingin.at(i));
                                else
                                        continue;
                        }
                }
                


        }

        if (m_nonexist.size()>0)
                return false;


        PWave wav1;
        int wavnum=0;
	if (m_wavlength.size()>0)
		m_wavlength.clear();
        float qiimlen;
        float qiimlensum=0.0;
        for (int i=0;i<m_pingin.size();i++)
        {
                strcpy(LineBuf,"");
                strcpy(LineBuf,"Run/wav/");
                strcat(LineBuf,m_pingin.at(i).c_str());
                strcat(LineBuf,".wav");

                if (!file_exists(LineBuf))
                {
                        strcpy(LineBuf,"");
                        strcpy(LineBuf,"Run/newwav/");
                        strcat(LineBuf,m_pingin.at(i).c_str());
                        strcat(LineBuf,".wav");
                }

                if (wavnum==0)
                {
                        wav1.load(LineBuf);
                        wavnum++;
                        qiimlen=(float)wav1.GetBufLength()/16000.0;
                        m_wavlength.push_back(qiimlen);
                        qiimlensum=qiimlensum+qiimlen;
                }
                else
                {
                        PWave wav2;
                        wav2.load(LineBuf);
                        wav1+=wav2;
                        wavnum++;
                        qiimlen=(float)wav2.GetBufLength()/16000.0;
                        if (i!=m_pingin.size()-1)
                        {
                                qiimlensum=qiimlensum+qiimlen;
                                m_wavlength.push_back(qiimlensum);

                        }
                }

                //cout<<dic.m_answer.at(i)<<endl;

        }
        if(wavnum>0)
                wav1.SaveWave("Run/TTS.wav");


        return true;

}
///////////////////////////////////////////////////////////////////////////////////
int PDynamic::file_exists(char *filename)
{
           return (access(filename, 00) == 0); 
}
///////////////////////////////////////////////////////////////////////////////////
void PDynamic::SaveToTextGrid(const char* tfn)
{
      ofstream fout;
      fout.open(tfn,ios::out);
      //m_pingin
      //m_dynamic.m_dtwsegbou.size()
/*
      fout<<"File type = \"ooTextFile\""<<endl;
      fout<<"Object class = \"TextGrid\""<<endl;
      fout<<endl;
      fout<<"xmin = 0"<<endl;
      fout<<"xmax = "<<(float)m_comwb.getNumSamples()/16000.0<<endl;
      fout<<"tiers? <exists> "<<endl;
      fout<<"size = 1 "<<endl;
      fout<<"item []: "<<endl;
      fout<<"    item [1]:"<<endl;
      fout<<"        class = \"IntervalTier\" "<<endl;
      fout<<"        name = \"Syllable\" "<<endl;
      fout<<"        xmin = 0 "<<endl;
      fout<<"        xmax = "<<(float)m_comwb.getNumSamples()/16000.0<<endl;
      fout<<"        intervals: size = "<<m_dtwsegbou.size()-1<<endl;

      int intervals=0;
      for (unsigned int i=0;i<m_dtwsegbou.size()-1;i++)
      {
         intervals=intervals+1;
         fout<<"        intervals ["<<intervals<<"]:"<<endl;
         fout<<"            xmin = "<<m_dtwsegbou.at(i)<<endl;
         fout<<"            xmax = "<<m_dtwsegbou.at(i+1)<<endl;
         fout<<"            text = "<<"\""<<m_pingin.at(i)<<"\""<<endl;
      }
*/

      int size=m_dtwsegbou.size()-1;
      int intervals=0;
      intervals=intervals+1;
      fout<<"        intervals ["<<intervals<<"]:"<<endl;
      fout<<"            xmin = "<<0<<endl;
      fout<<"            xmax = "<<m_dtwsegbou.at(0)<<endl;
      fout<<"            text = "<<"\""<<m_dic.m_chinese.at(0)<<"\""<<endl;
      for (unsigned int i=0;i<m_dtwsegbou.size()-1;i++)
      {
         intervals=intervals+1;
         fout<<"        intervals ["<<intervals<<"]:"<<endl;
         fout<<"            xmin = "<<m_dtwsegbou.at(i)<<endl;
         fout<<"            xmax = "<<m_dtwsegbou.at(i+1)<<endl;
         fout<<"            text = "<<"\""<<m_dic.m_chinese.at(i+1)<<"\""<<endl;
      }
      intervals=intervals+1;
      fout<<"        intervals ["<<intervals<<"]:"<<endl;
      fout<<"            xmin = "<<m_dtwsegbou.at(size)<<endl;
      fout<<"            xmax = "<<(float)m_comwb.getNumSamples()/16000.0<<endl;
      fout<<"            text = "<<"\""<<m_dic.m_chinese.at(m_dic.m_chinese.size()-1)<<"\""<<endl;

      fout.close();

}
///////////////////////////////////////////////////////////////////////////////////
void PDynamic::doDynamicProgramming(const char* rfn,const char* cfn)
{
	m_comwb.load(cfn);
        m_mel.wav2fea(m_comwb,m_comfb);
        m_refwb.load(rfn);
        m_mel.wav2fea(m_refwb,m_reffb);
        
         //Col 0~4
         //Row 0~5
        m_distance.setRC(m_reffb.getRow()+1,m_comfb.getRow()+1);
        m_dpmatrix.setRC(m_reffb.getRow()+1,m_comfb.getRow()+1);
         
         //INitial  �s�Ȥ�
        for (int i=0;i<m_distance.getRow();i++)
                for (int j=0;j<m_distance.getCol();j++)
                {
                        m_distance[i][j]=0.0;
                        m_dpmatrix[i][j]=0.0;
                }
        for (int i=1;i<m_distance.getRow();i++)
        {
                for (int j=1;j<m_distance.getCol();j++)
                {
                        m_distance[i][j]=getvecdis(m_reffb[i-1],m_comfb[j-1]);
                }
        }

        m_dpmatrix[1][1]=m_distance[1][1];

        for (int i=2;i<m_dpmatrix.getRow();i++)
        {
                m_dpmatrix[i][1]=m_dpmatrix[i-1][1]+m_distance[i][1];
        }

        for (int j=2;j<m_dpmatrix.getCol();j++)
        {
                m_dpmatrix[1][j]=m_dpmatrix[1][j-1]+m_distance[1][j];
        }


        for (int i=0;i<m_dpmatrix.getRow();i++)
        {
                m_dpmatrix[i][0]=LONG_MAX;
        }
        for (int j=0;j<m_dpmatrix.getCol();j++)
        {
                m_dpmatrix[0][j]=LONG_MAX;
        }

	//�}�l�p��DP
        for (int idx=2;idx<m_dpmatrix.getRow();idx++)
        {
                for (int idy=2;idy<m_dpmatrix.getCol();idy++)
                {
                        float diff=m_distance[idx][idy];
                        if (m_dpmatrix[idx-1][idy]<=m_dpmatrix[idx-1][idy-1] && m_dpmatrix[idx-1][idy]<=m_dpmatrix[idx][idy-1])
                        {
                                m_dpmatrix[idx][idy]=diff+m_dpmatrix[idx-1][idy];
                        }
                        if (m_dpmatrix[idx-1][idy-1]<=m_dpmatrix[idx-1][idy] && m_dpmatrix[idx-1][idy-1]<=m_dpmatrix[idx][idy-1])
                        {
                                m_dpmatrix[idx][idy]=diff+m_dpmatrix[idx-1][idy-1];
                        }
                        if (m_dpmatrix[idx][idy-1]<=m_dpmatrix[idx-1][idy-1] && m_dpmatrix[idx][idy-1]<=m_dpmatrix[idx-1][idy])
                        {
                                m_dpmatrix[idx][idy]=diff+m_dpmatrix[idx][idy-1];
                        }
                }
        }
        
        if (m_mapvec.size()>0)
        	m_mapvec.clear();
	//�}�lBack Tracking
        xandy temp;
        int maxx=m_dpmatrix.getRow()-1;
        int maxy=m_dpmatrix.getCol()-1;
        do
        {
                temp.x=maxx;
                temp.y=maxy;
                m_mapvec.push_back(temp);
                float minvalue;
                int optx,opty;
                if (m_dpmatrix[maxx-1][maxy]>m_dpmatrix[maxx][maxy-1])
                {
                        minvalue=m_dpmatrix[maxx][maxy-1];
                        optx=maxx;
                        opty=maxy-1;
                }
                else
                {
                        minvalue=m_dpmatrix[maxx-1][maxy];
                        optx=maxx-1;
                        opty=maxy;
                }
                if (minvalue<m_dpmatrix[maxx-1][maxy-1])
                {
                        maxx=optx;
                        maxy=opty;
                }
                else
                {
                        maxx=maxx-1;
                        maxy=maxy-1;
                }
                if (maxx==1 && maxy==1)
                        break;
        }while (maxx>=1 && maxy>=1);
        temp.x=maxx;
        temp.y=maxy;
        m_mapvec.push_back(temp);
        
        //cout<<maxx<<endl;
        //cout<<maxy<<endl;

	if (m_dtwsegbou.size()>0)
		m_dtwsegbou.clear();


      vector<xandy> getdismap;

	//m_dtwsegbou.push_back(0.0);	
        int frameindex;
        for (int h=0;h<m_wavlength.size();h++)
        {
                frameindex=m_wavlength.at(h)/0.01;
                //cout<<frameindex<<endl;
                for (int w=0;w<m_mapvec.size();w++)
                {
                        if (m_mapvec.at(w).x==frameindex)
                        {
                                //���i��X�{�s��index,�ڥu��Ĥ@��^^
                                //cout<<(float)m_mapvec.at(w).y*0.01<<endl;
                                m_dtwsegbou.push_back((float)m_mapvec.at(w).y*0.01);
                                getdismap.push_back(m_mapvec.at(w));
                                break;
                        }
                }
        }
        //m_dtwsegbou.push_back((float)m_comwb.getNumSamples()/16000.0);
        if (m_disgrade.size()>0)
         m_disgrade.clear();
         double dtmp;
         double subtmp=0.0;
         for (unsigned int p=0;p<getdismap.size();p++)
         {
            dtmp=m_dpmatrix[getdismap.at(p).x][getdismap.at(p).y];
            if (p!=0)
               m_disgrade.push_back(dtmp-subtmp);
            subtmp=dtmp;

         }
       	
}
///////////////////////////////////////////////////////////////////////////////////
double PDynamic::doOnedimDP(PVector& in,int ins,int ine,PVector& com,int coms,int come)
{
        CMatrix distance;
        CMatrix dpmatrix;
        //Col 0~4
        //Row 0~5
//ofstream fout("onedp.txt",ios::out);

        int insize=ine-ins+1;
        int comsize=come-coms+1;
 //  fout<<ins<<"\t"<<ine<<endl;
  // fout<<coms<<"\t"<<come<<endl;
  // fout<<insize<<"\t"<<comsize<<endl;
        distance.setRC(insize+1,comsize+1);
        dpmatrix.setRC(insize+1,comsize+1);
         
         //INitial  �s�Ȥ�
        for (int i=0;i<distance.getRow();i++)
                for (int j=0;j<distance.getCol();j++)
                {
                        distance[i][j]=0.0;
                        dpmatrix[i][j]=0.0;
                }

        //fout<<distance.getRow()<<"\t"<<distance.getCol()<<endl;
        //fout<<in.size()<<"\t"<<com.size()<<endl;
        for (int i=1;i<distance.getRow();i++)
        {
                for (int j=1;j<distance.getCol();j++)
                {

                        distance[i][j]=fabs(in[ins+i-1]-com[coms+j-1]);
                }
        }

        dpmatrix[1][1]=distance[1][1];

        for (int i=2;i<dpmatrix.getRow();i++)
        {
                dpmatrix[i][1]=dpmatrix[i-1][1]+distance[i][1];
        }

        for (int j=2;j<dpmatrix.getCol();j++)
        {
                dpmatrix[1][j]=dpmatrix[1][j-1]+distance[1][j];
        }


        for (int i=0;i<dpmatrix.getRow();i++)
        {
                dpmatrix[i][0]=LONG_MAX;
        }
        for (int j=0;j<dpmatrix.getCol();j++)
        {
                dpmatrix[0][j]=LONG_MAX;
        }

	//�}�l�p��DP
        for (int idx=2;idx<dpmatrix.getRow();idx++)
        {
                for (int idy=2;idy<dpmatrix.getCol();idy++)
                {
                        float diff=distance[idx][idy];
                        if (dpmatrix[idx-1][idy]<=dpmatrix[idx-1][idy-1] && dpmatrix[idx-1][idy]<=dpmatrix[idx][idy-1])
                        {
                                dpmatrix[idx][idy]=diff+dpmatrix[idx-1][idy];
                        }
                        if (dpmatrix[idx-1][idy-1]<=dpmatrix[idx-1][idy] && dpmatrix[idx-1][idy-1]<=dpmatrix[idx][idy-1])
                        {
                                dpmatrix[idx][idy]=diff+dpmatrix[idx-1][idy-1];
                        }
                        if (dpmatrix[idx][idy-1]<=dpmatrix[idx-1][idy-1] && dpmatrix[idx][idy-1]<=dpmatrix[idx-1][idy])
                        {
                                dpmatrix[idx][idy]=diff+dpmatrix[idx][idy-1];
                        }
                }
        }
        return sqrt(dpmatrix[dpmatrix.getRow()-1][dpmatrix.getCol()-1]);
}
///////////////////////////////////////////////////////////////////////////////////
void PDynamic::doLPCDTW(const char* rfn,const char* cfn,int lpcorder)
{
/*
        m_refwb.load(rfn);
        int framesize=320;
        int overlap=160;

        int frameNum = (m_refwb.getNumSamples() - framesize) / overlap + 1;
        m_reffb.setdim(frameNum,lpcorder);
        for(int n = 0; n < frameNum; n++)
        {
		//frame2fea(wb , n* m_overlap, fb[n]);
        	PVector sp;
                int shirt=n*overlap;
	        int i,n;
	        //copy�@�q speech frame
	        sp.SetLength(framesize+1);
	        for(i=shirt,n=1; i < framesize+shirt; i++,n++)
	        {
		        sp[n] = m_refwb[i];
	        }

                m_ssp.ZeroMeanFrame(sp);
                m_ssp.PreEmphasise(sp,0.97f);
                m_ssp.doHam(sp);


        }
	m_comwb.load(cfn);
*/

}
///////////////////////////////////////////////////////////////////////////////////