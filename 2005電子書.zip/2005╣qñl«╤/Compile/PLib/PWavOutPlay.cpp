#include "PWavOutPlay.h"
//�i��inline�W�[�t��
//inline void CWave::CALLBACK OWPdef(HWAVEIN,UINT,DWORD dwInst,DWORD,DWORD)
void PWavOutPlay::sethdr(short*data,int shsize)
{
	hdr.lpData = (LPSTR)data;
	hdr.dwBufferLength = shsize*2; // length in bytes rather in short
	hdr.dwBytesRecorded= shsize*2; // length in bytes rather in short
	hdr.dwFlags = WHDR_BEGINLOOP|WHDR_ENDLOOP;
	hdr.dwLoops = 1L;
	
	/*
	typedef struct {
  	LPSTR lpData;
  	DWORD dwBufferLength;
  	DWORD dwBytesRecorded;
  	DWORD dwUser;
  	DWORD dwFlags;
  	DWORD dwLoops;
  	struct wavehdr_tag* lpNext;
  	DWORD reserved;}
	WAVEHDR;
	*/
	//��L�����γ]�w,�Ϋ�˪�??	
}

int PWavOutPlay::reset(int mswait)
{
	result=waveOutReset(hwo);
        Sleep(1);
        sleep2end(mswait);
	return result;
	//�����򤣬Oreturn MMRESULT ??
}
int PWavOutPlay::pause(int mswait)
{
	result=waveOutPause(hwo);
        Sleep(1);
        sleep2end(mswait);
	return result;
}
int PWavOutPlay::restart()
{
	result=waveOutRestart(hwo);
	return result;
}
void PWavOutPlay::sleep2end0(int ms)
{
        while (ms>0){if (!bPlayDiong) break;ms-=10;Sleep(10);}
}
DWORD PWavOutPlay::getposition()
{
                MMTIME mmt;
		mmt.wType = TIME_SAMPLES;
                result=waveOutGetPosition(hwo,&mmt,sizeof(MMTIME));
                if (result==MMSYSERR_NOERROR)
                        return mmt.u.sample;
                else
                        return -1;
}
/*
inline	__int64	owave0_::position ()
{
	MMTIME mmt1;mmt1.wType=TIME_SAMPLES;
	MMRESULT mmr=waveOutGetPosition(hwo,&mmt1,sizeof(mmt1));
	if(mmr==MMSYSERR_NOERROR){
		return mmt1.u.sample;
	}
	return 0;
}
*/