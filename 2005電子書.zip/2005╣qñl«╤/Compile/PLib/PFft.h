#ifndef __PFFT_H
#define __PFFT_H
#include <math.h>

#define PI					    3.14159265358979
#define TPI						6.28318530717959     /* PI*2 */
class PFft
{
public:
  static void fft(float *s, int size,int invert);  // just for realfft
  static void realfft(float *s , int size);
	
};



#endif