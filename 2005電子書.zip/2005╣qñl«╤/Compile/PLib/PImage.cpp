#include "PImage.h"
void PImage::ReadImage(const char* fn)
{
   ifstream fin;
   fin.open(fn,ios::binary);
   fin.read((char*)&m_heder.type,sizeof(short));
   fin.read((char*)&m_heder.size,sizeof(int));

   fin.read((char*)&m_heder.reserved1,sizeof(short));
   fin.read((char*)&m_heder.reserved2,sizeof(short));
   //�e���`�@14 byes add 40 infomation header=>54 BYTEs
   fin.read((char*)&m_heder.offset,sizeof(int));
/*
   cout<<heder.type<<endl;
   cout<<heder.size<<endl;
   cout<<heder.reserved1<<endl;
   cout<<heder.reserved2<<endl;
   cout<<heder.offset<<endl;
*/
//now read 4o byptes below
   fin.read((char*)&m_infoheder.size,sizeof(int));
   //Read Image���e�P����
   fin.read((char*)&m_infoheder.width,sizeof(m_infoheder.width));
   fin.read((char*)&m_infoheder.height,sizeof(m_infoheder.height));

   fin.read((char*)&m_infoheder.planes,sizeof(m_infoheder.planes));
   fin.read((char*)&m_infoheder.bits,sizeof(m_infoheder.bits));
   fin.read((char*)&m_infoheder.compression,sizeof(m_infoheder.compression));
   fin.read((char*)&m_infoheder.imagesize,sizeof(m_infoheder.imagesize));
   fin.read((char*)&m_infoheder.xresolution,sizeof(m_infoheder.xresolution));
   fin.read((char*)&m_infoheder.yresolution,sizeof(m_infoheder.yresolution));
   fin.read((char*)&m_infoheder.ncolours,sizeof(m_infoheder.ncolours));
   fin.read((char*)&m_infoheder.importantcolours,sizeof(m_infoheder.importantcolours));
/*
   cout<<infoheder.size<<endl;
   cout<<infoheder.width<<endl;
   cout<<infoheder.height<<endl;
   cout<<infoheder.planes<<endl;
   cout<<infoheder.bits<<endl;
   cout<<infoheder.compression<<endl;
   cout<<infoheder.imagesize<<endl;
   cout<<infoheder.xresolution<<endl;
   cout<<infoheder.yresolution<<endl;
   cout<<infoheder.ncolours<<endl;
   cout<<infoheder.importantcolours<<endl;
*/
   //cout<<infoheder.imagesize<<endl;
   //cout<<(float)infoheder.imagesize/3.0<<endl;
   //fin.close();
/*
   FILE *fpSrc;
   int Dim=infoheder.width*infoheder.height;
   BYTE SrcB[512][512];
   BYTE SrcG[512][512];
   BYTE SrcR[512][512];
   int pos;
   fpSrc=fopen("beagirl.bmp","rb");
   pos=54;
   int i;
   for (i=(infoheder.height-1);i>=0;i--)
   {
      fseek(fpSrc,pos,0);
      for (int j=0;j<infoheder.width;j++)
      {
         fread(&SrcB[i][j],sizeof(BYTE),1,fpSrc);
         fread(&SrcG[i][j],sizeof(BYTE),1,fpSrc);
         fread(&SrcR[i][j],sizeof(BYTE),1,fpSrc);
      }
      pos=pos+infoheder.width*3;
   }
   fclose(fpSrc);
   cout<<(int)SrcB[512-1][0]<<endl;
   cout<<(int)SrcG[512-1][0]<<endl;
   cout<<(int)SrcR[512-1][0]<<endl;
*/
   //int length=infoheder.imagesize/3.0;
   //Ū�����ǬO B ...G....R
   m_PixelWidth=m_infoheder.width;
   m_PixelHeight=m_infoheder.height;

   m_Bmat.setRC(m_infoheder.height,m_infoheder.width);
   m_Gmat.setRC(m_infoheder.height,m_infoheder.width);
   m_Rmat.setRC(m_infoheder.height,m_infoheder.width);

   BYTE rdata;
   //rdata=new BYTE[infoheder.imagesize];
   for (int i=(m_infoheder.height-1);i>=0;i--)
   {
      for (int j=0;j<m_infoheder.width;j++)
      {
         fin.read((char*)&rdata,sizeof(BYTE));
         m_Bmat[i][j]=(int)rdata;
         fin.read((char*)&rdata,sizeof(BYTE));
         m_Gmat[i][j]=(int)rdata;
         fin.read((char*)&rdata,sizeof(BYTE));
         m_Rmat[i][j]=(int)rdata;
      }
   }
   fin.close();
   
//if it is 24bit true colour images.it is easy to read
//The image data follows immediately after the information header
//That is ,there is no colour palette.
//It consists of three BYTEs per pixel in b,g,r order.
//Each BYTE gives the saturation for that colour component
//0 for black and 1 for white(fully saturated).
}
//�B�z�Ƕ�
void PImage::RGB2Gray()
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        int r,g,b;
        int gray;
        for (int i=0;i<m_PixelHeight;i++)
        {
                for (int j=0;j<m_PixelWidth;j++)
                {
                        r=m_Rmat[i][j];//R
                        g=m_Gmat[i][j];//G
                        b=m_Bmat[i][j];//B
                        gray=0.299*r +0.587*g+0.114*b;
                        m_ProcRmat[i][j]=gray;
                        m_ProcGmat[i][j]=gray;
                        m_ProcBmat[i][j]=gray;
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        m_Rmat[i][j] = m_ProcRmat[i][j];
                        m_Gmat[i][j] = m_ProcGmat[i][j];
                        m_Bmat[i][j] = m_ProcBmat[i][j];
                }

}
//HighpASSfILTER
//�ҥ�P.129����,�Ĥ@��
int PImage::HighPassFilter(PMatrix& mat,int i,int j)
{
        int HPF;
        int p[10];
        p[1]=0;
        p[2]=mat[i-1][j];
        p[3]=0;
        p[4]=mat[i][j-1];
        p[5]=mat[i][j]*-4;
        p[6]=mat[i][j+1];
        p[7]=0;
        p[8]=mat[i+1][j];
        p[9]=0;
        HPF=(p[1]+p[2]+p[3]+p[4]+p[5]+p[6]+p[7]+p[8]+p[9]);
        return (HPF);
}
int PImage::Filter(PMatrix& mat,int i,int j)
{
        int LPF;
        int p[10];
        p[1]=mat[i-1][j-1];
        p[2]=mat[i-1][j];
        p[3]=mat[i-1][j+1];
        p[4]=mat[i][j-1];
        p[5]=mat[i][j];
        p[6]=mat[i][j+1];
        p[7]=mat[i+1][j-1];
        p[8]=mat[i+1][j];
        p[9]=mat[i+1][j+1];
        LPF=(p[1]+p[2]+p[3]+p[4]+p[5]+p[6]+p[7]+p[8]+p[9])/9;
        return (LPF);
}
//�U����i,j Index�O�A�˪�
int PImage::ExpendFilter(PMatrix& mat,int i,int j)
{
        int Expend;
        int p[10];
        p[1]=mat[i-1][j-1];
        p[2]=mat[i][j-1];
        p[3]=mat[i+1][j-1];
        p[4]=mat[i-1][j];
        p[5]=mat[i][j];
        p[6]=mat[i+1][j];
        p[7]=mat[i-1][j+1];
        p[8]=mat[i][j+1];
        p[9]=mat[i+1][j+1];
        Expend=(p[1]+p[2]+p[3]+p[4]+p[6]+p[7]+p[8]+p[9]);
        if (Expend>=255)
                return (Expend);
        else
                return 0;
}
//---------------------------------------------------------------------------
int PImage::ErosionFilter(PMatrix& mat,int i,int j)
{
        int Erosion;
        int p[10];
        p[1]=mat[i-1][j-1];
        p[2]=mat[i][j-1];
        p[3]=mat[i+1][j-1];
        p[4]=mat[i-1][j];
        p[5]=mat[i][j];
        p[6]=mat[i+1][j];
        p[7]=mat[i-1][j+1];
        p[8]=mat[i][j+1];
        p[9]=mat[i+1][j+1];
        Erosion=(p[1]&p[2]&p[3]&p[4]&p[5]&p[6]&p[7]&p[8]&p[9]);
        return Erosion;
}
//�o�i���٭nCheck
void PImage::ImageTLPF()
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        int r,g,b;
        int gray;
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        m_ProcRmat[i][j]=Filter(m_Bmat,i,j);
                        m_ProcGmat[i][j]=Filter(m_Bmat,i,j);
                        m_ProcBmat[i][j]=Filter(m_Bmat,i,j);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                        {
                                m_Rmat[i][j] = 0;
                                m_Gmat[i][j] = 0;
                                m_Bmat[i][j] = 0;
                        }
                        else
                        {
                                m_Rmat[i][j] = m_ProcRmat[i][j];
                                m_Gmat[i][j] = m_ProcGmat[i][j];
                                m_Bmat[i][j] = m_ProcBmat[i][j];
                        }
                }
}
void PImage::ImageTHPF()
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        int r,g,b;
        int gray;
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        m_ProcRmat[i][j]=HighPassFilter(m_Bmat,i,j);
                        m_ProcGmat[i][j]=HighPassFilter(m_Bmat,i,j);
                        m_ProcBmat[i][j]=HighPassFilter(m_Bmat,i,j);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                        {
                                m_Rmat[i][j] = 0;
                                m_Gmat[i][j] = 0;
                                m_Bmat[i][j] = 0;
                        }
                        else
                        {
                                m_Rmat[i][j] = m_ProcRmat[i][j];
                                m_Gmat[i][j] = m_ProcGmat[i][j];
                                m_Bmat[i][j] = m_ProcBmat[i][j];
                        }
                }
}
//
//��������
void PImage::Image2Negative()
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        int r,g,b;
        for (int i=0;i<m_PixelHeight;i++)
        {
                for (int j=0;j<m_PixelWidth;j++)
                {
                        r=255-m_Rmat[i][j];
                        g=255-m_Gmat[i][j];
                        b=255-m_Bmat[i][j];
                        m_ProcRmat[i][j]=r;
                        m_ProcGmat[i][j]=g;
                        m_ProcBmat[i][j]=b;
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        m_Rmat[i][j] = m_ProcRmat[i][j];
                        m_Gmat[i][j] = m_ProcGmat[i][j];
                        m_Bmat[i][j] = m_ProcBmat[i][j];
                }
}
//�G�׳���
void PImage::Image2Bright(int threshold)
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        int r,g,b;
        int gray;
        for (int i=0;i<m_PixelHeight;i++)
        {
                for (int j=0;j<m_PixelWidth;j++)
                {
                        r=m_Rmat[i][j]+threshold;//R
                        g=m_Gmat[i][j]+threshold;//G
                        b=m_Bmat[i][j]+threshold;//B
                        if (r>255)
                                 m_ProcRmat[i][j]=255;
                        else if (r<0)
                                m_ProcRmat[i][j]=0;
                        else
                                m_ProcRmat[i][j]=r;

                        if (g>255)
                                 m_ProcGmat[i][j]=255;
                        else if (g<0)
                                m_ProcGmat[i][j]=0;
                        else
                                m_ProcGmat[i][j]=g;

                        if (b>255)
                                 m_ProcBmat[i][j]=255;
                        else if (b<0)
                                m_ProcBmat[i][j]=0;
                        else
                                m_ProcBmat[i][j]=b;
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        m_Rmat[i][j] = m_ProcRmat[i][j];
                        m_Gmat[i][j] = m_ProcGmat[i][j];
                        m_Bmat[i][j] = m_ProcBmat[i][j];
                }

}
//�G���
void PImage::RGB2TMB(int threshold)
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        int r,g,b;
        int gray;
        for (int i=0;i<m_PixelHeight;i++)
        {
                for (int j=0;j<m_PixelWidth;j++)
                {
                        r=m_Rmat[i][j];//R
                        g=m_Gmat[i][j];//G
                        b=m_Bmat[i][j];//B
                        gray=0.299*r +0.587*g+0.114*b;
                        if(gray>threshold)
                                gray=255;
                        else
                                gray=0;
                        m_ProcRmat[i][j]=gray;
                        m_ProcGmat[i][j]=gray;
                        m_ProcBmat[i][j]=gray;
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        m_Rmat[i][j] = m_ProcRmat[i][j];
                        m_Gmat[i][j] = m_ProcGmat[i][j];
                        m_Bmat[i][j] = m_ProcBmat[i][j];
                }

}
void PImage::RGB2YCbCr()
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        double R,G,B;
        for (int i=0;i<m_PixelHeight;i++)
        {
                for (int j=0;j<m_PixelWidth;j++)
                {
                        /*
            Y  = 0.299*R+0.587*G+0.114*B;
            Cr = 0.5*R-0.419*G-0.081*B+128;
            Cb = -0.169*R-0.332*G+0.5*B+128;
                        */
                        R=m_Rmat[i][j];//R
                        G=m_Gmat[i][j];//G
                        B=m_Bmat[i][j];//B
                        m_ProcRmat[i][j]=0.299*R+0.587*G+0.114*B;//Y
                        m_ProcGmat[i][j]=-0.169*R-0.332*G+0.5*B+128;//Cb
                        m_ProcBmat[i][j]=0.5*R-0.419*G-0.081*B+128;//Cr
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        m_Rmat[i][j] = m_ProcRmat[i][j];
                        m_Gmat[i][j] = m_ProcGmat[i][j];
                        m_Bmat[i][j] = m_ProcBmat[i][j];
                }

}
bool PImage::doPrewitt()
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        int z1,z2,z3,z4,z5,z6,z7,z8,z9,Gx,Gy;
                        //X��V
                        z1=m_Bmat[i-1][j-1]*(-1);
                        z2=m_Bmat[i-1][j]*(-1);
                        z3=m_Bmat[i-1][j+1]*(-1);
                        z4=0;
                        z5=0;
                        z6=0;
                        z7=m_Bmat[i+1][j-1]*(1);
                        z8=m_Bmat[i+1][j]*(1);
                        z9=m_Bmat[i+1][j+1]*(1);
                        Gx=z1+z2+z3+z7+z8+z9;

                        if (Gx<0)
                                Gx=-Gx;
                        //y��V
                        z1=m_Bmat[i-1][j-1]*(-1);
                        z2=0;
                        z3=m_Bmat[i-1][j+1]*(1);
                        z4=m_Bmat[i][j-1]*(-1);
                        z5=0;
                        z6=m_Bmat[i][j+1]*(1);
                        z7=m_Bmat[i+1][j-1]*(-1);
                        z8=0;
                        z9=m_Bmat[i+1][j+1]*(1);
                        Gy=z3+z6+z9+z1+z4+z7;
                        if (Gy<0)
                                Gy=-Gy;
                        if ((Gx+Gy)>255)
                                m_ProcBmat[i][j]=255;
                        else
                                m_ProcBmat[i][j]=(Gx+Gy);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                                m_Bmat[i][j] = 0;
                        else
                                m_Bmat[i][j] = m_ProcBmat[i][j];
                }

//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        int z1,z2,z3,z4,z5,z6,z7,z8,z9,Gx,Gy;
                        z1=m_Gmat[i-1][j-1]*(-1);
                        z2=m_Gmat[i-1][j]*(-1);
                        z3=m_Gmat[i-1][j+1]*(-1);
                        z4=0;
                        z5=0;
                        z6=0;
                        z7=m_Gmat[i+1][j-1]*(1);
                        z8=m_Gmat[i+1][j]*(1);
                        z9=m_Gmat[i+1][j+1]*(1);
                        Gx=z1+z2+z3+z7+z8+z9;

                        if (Gx<0)
                                Gx=-Gx;
                        z1=m_Gmat[i-1][j-1]*(-1);
                        z2=0;
                        z3=m_Gmat[i-1][j+1]*(1);
                        z4=m_Gmat[i][j-1]*(-1);
                        z5=0;
                        z6=m_Gmat[i][j+1]*(1);
                        z7=m_Gmat[i+1][j-1]*(-1);
                        z8=0;
                        z9=m_Gmat[i+1][j+1]*(1);
                        Gy=z3+z6+z9+z1+z4+z7;
                        if (Gy<0)
                                Gy=-Gy;
                        if ((Gx+Gy)>255)
                                m_ProcGmat[i][j]=255;
                        else
                                m_ProcGmat[i][j]=(Gx+Gy);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                                m_Gmat[i][j] = 0;
                        else
                                m_Gmat[i][j] = m_ProcGmat[i][j];
                }
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        int z1,z2,z3,z4,z5,z6,z7,z8,z9,Gx,Gy;
                        z1=m_Rmat[i-1][j-1]*(-1);
                        z2=m_Rmat[i-1][j]*(-1);
                        z3=m_Rmat[i-1][j+1]*(-1);
                        z4=0;
                        z5=0;
                        z6=0;
                        z7=m_Rmat[i+1][j-1]*(1);
                        z8=m_Rmat[i+1][j]*(1);
                        z9=m_Rmat[i+1][j+1]*(1);
                        Gx=z1+z2+z3+z7+z8+z9;

                        if (Gx<0)
                                Gx=-Gx;
                        z1=m_Rmat[i-1][j-1]*(-1);
                        z2=0;
                        z3=m_Rmat[i-1][j+1]*(1);
                        z4=m_Rmat[i][j-1]*(-1);
                        z5=0;
                        z6=m_Rmat[i][j+1]*(1);
                        z7=m_Rmat[i+1][j-1]*(-1);
                        z8=0;
                        z9=m_Rmat[i+1][j+1]*(1);
                        Gy=z3+z6+z9+z1+z4+z7;
                        if (Gy<0)
                                Gy=-Gy;
                        if ((Gx+Gy)>255)
                                m_ProcRmat[i][j]=255;
                        else
                                m_ProcRmat[i][j]=(Gx+Gy);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                                m_Rmat[i][j] = 0;
                        else
                                m_Rmat[i][j] = m_ProcRmat[i][j];
                }
        return true;

}
bool PImage::doSobel()
{
//Blue
        m_ProcBmat.setRC(m_PixelHeight,m_PixelWidth);
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        int z1,z2,z3,z4,z5,z6,z7,z8,z9,Gx,Gy;
                        z1=m_Bmat[i-1][j-1]*(-1);
                        z2=m_Bmat[i-1][j]*(-2);
                        z3=m_Bmat[i-1][j+1]*(-1);
                        z4=0;
                        z5=0;
                        z6=0;
                        z7=m_Bmat[i+1][j-1]*(1);
                        z8=m_Bmat[i+1][j]*(2);
                        z9=m_Bmat[i+1][j+1]*(1);
                        Gx=z1+z2+z3+z7+z8+z9;

                        if (Gx<0)
                                Gx=-Gx;
                        z1=m_Bmat[i-1][j-1]*(-1);
                        z2=0;
                        z3=m_Bmat[i-1][j+1]*(1);
                        z4=m_Bmat[i][j-1]*(-2);
                        z5=0;
                        z6=m_Bmat[i][j+1]*(2);
                        z7=m_Bmat[i+1][j-1]*(-1);
                        z8=0;
                        z9=m_Bmat[i+1][j+1]*(1);
                        Gy=z3+z6+z9+z1+z4+z7;
                        if (Gy<0)
                                Gy=-Gy;
                        if ((Gx+Gy)>255)
                                m_ProcBmat[i][j]=255;
                        else
                                m_ProcBmat[i][j]=(Gx+Gy);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                                m_Bmat[i][j] = 0;
                        else
                                m_Bmat[i][j] = m_ProcBmat[i][j];
                }

//Green
        m_ProcGmat.setRC(m_PixelHeight,m_PixelWidth);
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        int z1,z2,z3,z4,z5,z6,z7,z8,z9,Gx,Gy;
                        z1=m_Gmat[i-1][j-1]*(-1);
                        z2=m_Gmat[i-1][j]*(-2);
                        z3=m_Gmat[i-1][j+1]*(-1);
                        z4=0;
                        z5=0;
                        z6=0;
                        z7=m_Gmat[i+1][j-1]*(1);
                        z8=m_Gmat[i+1][j]*(2);
                        z9=m_Gmat[i+1][j+1]*(1);
                        Gx=z1+z2+z3+z7+z8+z9;

                        if (Gx<0)
                                Gx=-Gx;
                        z1=m_Gmat[i-1][j-1]*(-1);
                        z2=0;
                        z3=m_Gmat[i-1][j+1]*(1);
                        z4=m_Gmat[i][j-1]*(-2);
                        z5=0;
                        z6=m_Gmat[i][j+1]*(2);
                        z7=m_Gmat[i+1][j-1]*(-1);
                        z8=0;
                        z9=m_Gmat[i+1][j+1]*(1);
                        Gy=z3+z6+z9+z1+z4+z7;
                        if (Gy<0)
                                Gy=-Gy;
                        if ((Gx+Gy)>255)
                                m_ProcGmat[i][j]=255;
                        else
                                m_ProcGmat[i][j]=(Gx+Gy);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                                m_Gmat[i][j] = 0;
                        else
                                m_Gmat[i][j] = m_ProcGmat[i][j];
                }
//Red
        m_ProcRmat.setRC(m_PixelHeight,m_PixelWidth);
        for (int i=1;i<m_PixelHeight-1;i++)
        {
                for (int j=1;j<m_PixelWidth-1;j++)
                {
                        int z1,z2,z3,z4,z5,z6,z7,z8,z9,Gx,Gy;
                        z1=m_Rmat[i-1][j-1]*(-1);
                        z2=m_Rmat[i-1][j]*(-2);
                        z3=m_Rmat[i-1][j+1]*(-1);
                        z4=0;
                        z5=0;
                        z6=0;
                        z7=m_Rmat[i+1][j-1]*(1);
                        z8=m_Rmat[i+1][j]*(2);
                        z9=m_Rmat[i+1][j+1]*(1);
                        Gx=z1+z2+z3+z7+z8+z9;

                        if (Gx<0)
                                Gx=-Gx;
                        z1=m_Rmat[i-1][j-1]*(-1);
                        z2=0;
                        z3=m_Rmat[i-1][j+1]*(1);
                        z4=m_Rmat[i][j-1]*(-2);
                        z5=0;
                        z6=m_Rmat[i][j+1]*(2);
                        z7=m_Rmat[i+1][j-1]*(-1);
                        z8=0;
                        z9=m_Rmat[i+1][j+1]*(1);
                        Gy=z3+z6+z9+z1+z4+z7;
                        if (Gy<0)
                                Gy=-Gy;
                        if ((Gx+Gy)>255)
                                m_ProcRmat[i][j]=255;
                        else
                                m_ProcRmat[i][j]=(Gx+Gy);
                }
        }
        for(int i = 0; i < m_PixelHeight; i++)
	        for(int j = 0; j < m_PixelWidth; j++)
                {
                        if( (i==0)||(j==0)||(i==(m_PixelHeight-1))||(j==(m_PixelWidth-1)) )
                                m_Rmat[i][j] = 0;
                        else
                                m_Rmat[i][j] = m_ProcRmat[i][j];
                }
        return true;

}
void PImage::WriteImage(const char* fn)
{
   ofstream fout;
   fout.open(fn,ios::binary);
   fout.write((char*)&m_heder.type,sizeof(short));
   fout.write((char*)&m_heder.size,sizeof(int));

   fout.write((char*)&m_heder.reserved1,sizeof(short));
   fout.write((char*)&m_heder.reserved2,sizeof(short));
   //�e���`�@14 byes add 40 infomation header=>54 BYTEs
   fout.write((char*)&m_heder.offset,sizeof(int));

   fout.write((char*)&m_infoheder.size,sizeof(int));
   //Read Image���e�P����
   fout.write((char*)&m_infoheder.width,sizeof(m_infoheder.width));
   fout.write((char*)&m_infoheder.height,sizeof(m_infoheder.height));

   fout.write((char*)&m_infoheder.planes,sizeof(m_infoheder.planes));
   fout.write((char*)&m_infoheder.bits,sizeof(m_infoheder.bits));
   fout.write((char*)&m_infoheder.compression,sizeof(m_infoheder.compression));
   fout.write((char*)&m_infoheder.imagesize,sizeof(m_infoheder.imagesize));
   fout.write((char*)&m_infoheder.xresolution,sizeof(m_infoheder.xresolution));
   fout.write((char*)&m_infoheder.yresolution,sizeof(m_infoheder.yresolution));
   fout.write((char*)&m_infoheder.ncolours,sizeof(m_infoheder.ncolours));
   fout.write((char*)&m_infoheder.importantcolours,sizeof(m_infoheder.importantcolours));
   BYTE rdata;
   //rdata=new BYTE[infoheder.imagesize];
   for (int i=(m_infoheder.height-1);i>=0;i--)
   {
      for (int j=0;j<m_infoheder.width;j++)
      {
         rdata=(int)m_Bmat[i][j];
         fout.write((char*)&rdata,sizeof(BYTE));
         rdata=(int)m_Gmat[i][j];
         fout.write((char*)&rdata,sizeof(BYTE));
         rdata=(int)m_Rmat[i][j];
         fout.write((char*)&rdata,sizeof(BYTE));
      }
   }
   fout.close();

}
