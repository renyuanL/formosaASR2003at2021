#ifndef __PWavInLokim_H
#define __PWavInLokim_H
#include "PWavOutPlay.h"
//�Ȯɵ��ѱ�
/*
#include <windows.h>
#include <mmsystem.h>
#include <process.h>
#include <winbase.h>
*/

/*
void CALLBACK waveInProc(
  HWAVEIN hwi,
  UINT uMsg,
  DWORD dwInstance,
  DWORD dwParam1,
  DWORD dwParam2
);
*/
//typedef UINT WINAPI (*THREADFUNC)(void*pv);
typedef unsigned long WINAPI (*THREADFUNC)(void*pv);
//�Ȯɵ��ѱ�
/*
class	thinthread{
public:
        HANDLE h;
        unsigned long id;
        //UINT id;
	thinthread():h(NULL),id(0){}
        ~thinthread(){dele();}
public:
	void begin(THREADFUNC f, void* obj){dele();
	//h=(HANDLE)_beginthreadex(NULL,0,f,obj,0,&id);
        h=CreateThread(NULL,0,f,obj,0,&id);}
	void dele (			){if(h)CloseHandle(h);	h=0;}
};
*/
//typedef void WINAPI (IWPROC)(HWAVEOUT hwo,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);
 
typedef void WINAPI (*IWPROC)(HWAVEIN hwo,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);
//�Ȯɵ��ѱ�
/*
struct eventhandle{ HANDLE h;
	eventhandle	(){create();}
	~eventhandle	(){close ();}
	HANDLE	create	(){ h=CreateEvent(NULL,FALSE,FALSE,NULL);return h;}
	void	reset	(){ ResetEvent(h);	}
	
	This method sets the state of the event to 
	nonsignaled until explicitly set to signaled 
	by the SetEvent method
	
	void	set		(){ SetEvent(h);	}
	
	This method sets the state of the event to signaled, 
	releasing any waiting threads. If the event is manual, 
	the event remains signaled until ResetEvent is called. 
	If the event is automatic, 
	the event remains signaled until a single thread is released.

	
	void	close	(){CloseHandle(h);	}
};
*/



class PWavInLokim
{
public:
	volatile int bOpened;
	volatile int bClosed;
	bool bLokImDiong;
	HWAVEIN hwi;
	WAVEHDR hdr;
	MMRESULT result;
	WAVEFORMATEX wfex;
	eventhandle evtlokimend;
	static void CALLBACK IWPdef(HWAVEIN hwi,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2);
	PWavInLokim(){};
	~PWavInLokim(){};
	MMRESULT open(DWORD dwInst,IWPROC p,WAVEFORMATEX *wf=NULL){
		//if (!bOpened)
		//{
			result=waveInOpen(&hwi,WAVE_MAPPER,wf,(DWORD)p,dwInst,CALLBACK_FUNCTION);
		//}
		//return result;
		return result;
	}
	MMRESULT open(WAVEFORMATEX *wf=NULL){return open((DWORD)this,IWPdef,wf);		}
	/*
	�ǳƿ�����buffer
	This function prepares a buffer for waveform input.
	*/	
	MMRESULT prepare(WAVEHDR* hdr1=NULL){
		return result=waveInPrepareHeader(hwi,(hdr1)?hdr1:&hdr,sizeof(WAVEHDR));
	}
	/*
	��buffer�e�L�h����
	This function sends an input buffer to the specified waveform-audio input device.
	When the buffer is filled, the application is notified
	*/
	MMRESULT add(WAVEHDR* hdr1=NULL){
		return result=waveInAddBuffer(hwi,(hdr1)?hdr1:&hdr,sizeof(WAVEHDR));
	}
	/*
	This function starts input on the specified waveform input device.

	*/
	MMRESULT start(){
		return result=waveInStart(hwi);
	}
	MMRESULT unprepare(WAVEHDR* hdr1=NULL){
		return result=waveInUnprepareHeader(hwi,(hdr1)?hdr1:&hdr,sizeof(WAVEHDR));
	}

   MMRESULT close(){
      return result=waveInClose(hwi);
   }

	void wait2end(){WaitForSingleObject(evtlokimend.h,INFINITE);}
	void reset4wait(){evtlokimend.reset();}
	int reset(int mswait=0);
	/*
	This method sets the state of the event
	to nonsignaled until explicitly set to signaled
	by the SetEvent method
	*/
	
	void sethdr(short*data,int shsize);
	void sleep2end(int ms){if (bLokImDiong) sleep2end0(ms);}
	void sleep2end0(int ms);

};
inline void CALLBACK PWavInLokim::IWPdef(HWAVEIN hwi,UINT uMsg,DWORD dwInst,DWORD dwPrm1,DWORD dwPrm2)
{
	PWavInLokim* iwb=(PWavInLokim*)dwInst;
	switch(uMsg){
	case WIM_OPEN:
		iwb->bOpened=1;break;//Sent when the device is opened using the waveInOpen function.
	case WIM_CLOSE:
		iwb->bClosed=1;break;//Sent when the device is closed using the waveInClose function.
	case WIM_DATA:
		iwb->evtlokimend.set();
                break;
		//Sent when the device driver is finished with 
		//a data block sent using the waveInAddBuffer function.
		//�N�O�ɮ׿��n�F
	}
	
}
#endif