#ifndef __PTcp_H
#define __PTcp_H
#include "PFunc.h"
#include <string.h>
#include <vector.h>
#include <windows.h>
struct tcpcomponet
{
	string filename;
	string word;
	string pingin;	
};
class PTcp
{
private:
	CStrScan m_strscan;
public:
	PTcp();
	~PTcp();
	void readGangsTCP(const char* fn);
        void readGangsTCP2(const char* fn);
	vector<tcpcomponet> m_tcpvec;
	void plotGround(HDC hdc);
	
};

#endif