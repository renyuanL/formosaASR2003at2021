#include "PBuffer.h"
//Constuctor
PBuffer::PBuffer()
{
        m_sh=NULL;
}
void PBuffer::reserve(int nsh)
{

        if (m_sh!=NULL)
        {
                delete[] m_sh;
        }
	m_sh=new short[nsh];
	m_nsh=nsh;

}
PBuffer::~PBuffer()
{
        if (m_sh!=NULL)
        {
	        delete[] m_sh;
        }
        m_nsh=0;
        
}
void PBuffer::setformat()
{
        m_pcmWaveFormat.wFormatTag=WAVE_FORMAT_PCM;//�令1�ݬ�WAVE_FORMAT_PCM;
	m_pcmWaveFormat.nChannels=1;
	m_pcmWaveFormat.nSamplesPerSec =16000;
        m_pcmWaveFormat.nBlockAlign=2;//pcm.wBitsPerSample/8;
	m_pcmWaveFormat.nAvgBytesPerSec=(m_pcmWaveFormat.nSamplesPerSec*m_pcmWaveFormat.nBlockAlign);
	m_pcmWaveFormat.wBitsPerSample=16;
}
int PBuffer::ms2nsh(int ms)
{
        m_pcmWaveFormat.wFormatTag=WAVE_FORMAT_PCM;//�令1�ݬ�WAVE_FORMAT_PCM;
	m_pcmWaveFormat.nChannels=1;
	m_pcmWaveFormat.nSamplesPerSec =16000;
        m_pcmWaveFormat.nBlockAlign=2;//pcm.wBitsPerSample/8;
	m_pcmWaveFormat.nAvgBytesPerSec=(m_pcmWaveFormat.nSamplesPerSec*m_pcmWaveFormat.nBlockAlign);
	m_pcmWaveFormat.wBitsPerSample=16;
	m_nsh=ms*16000/1000;
	return m_nsh;	
}
short* PBuffer::GetBufPoint()
{
        return m_sh;
}

PBuffer& PBuffer::operator =(PBuffer& obj)
{
        m_nsh=obj.m_nsh;
        if (m_sh!=NULL)
                delete [] m_sh;
        m_sh=new short[m_nsh];
        //short* objbuf=obj.GetBufPoint();
        for (long i=0;i<m_nsh;i++)
                m_sh[i]=obj[i];
                //m_sh[i]=objbuf[i];
        return *this;

}
////////////////////////////////////////////////////
void PBuffer::save()
{
	ofstream fout("Run\\thread.wav",ios::binary);	
	fout.write("RIFF",4);
	
	DWORD dwFileSize = m_nsh*m_pcmWaveFormat.nBlockAlign + 36 ;
	fout.write((char *)&dwFileSize,sizeof(dwFileSize));
	fout.write("WAVEfmt ",8);
	
	DWORD dwFmtSize = 16L + (m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM ? sizeof(m_pcmWaveFormat.cbSize) : 0 ) ;
	fout.write((char *)&dwFmtSize,sizeof(dwFmtSize));
	fout.write((char *)&m_pcmWaveFormat.wFormatTag,sizeof(m_pcmWaveFormat.wFormatTag));//�o���Ӽg1��??
	fout.write((char *)&m_pcmWaveFormat.nChannels,sizeof(m_pcmWaveFormat.nChannels));
	fout.write((char *)&m_pcmWaveFormat.nSamplesPerSec,sizeof(m_pcmWaveFormat.nSamplesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nAvgBytesPerSec,sizeof(m_pcmWaveFormat.nAvgBytesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nBlockAlign,sizeof(m_pcmWaveFormat.nBlockAlign));
	fout.write((char *)&m_pcmWaveFormat.wBitsPerSample,sizeof(m_pcmWaveFormat.wBitsPerSample));
	//if(m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM)
		//fout.write((char *)&m_pcmWaveFormat.cbSize ,sizeof(m_pcmWaveFormat.cbSize));		

	fout.write("data",4);
	DWORD dwNum = 2*m_nsh;
	fout.write((char *)&dwNum,sizeof(dwNum));
	fout.write((char *)m_sh,dwNum);

}
////////////////////////////////////////////////////
void PBuffer::save(int len)
{
	ofstream fout("Run\\thread.wav",ios::binary);
	fout.write("RIFF",4);

        if (len>m_nsh)
                len=m_nsh;

	DWORD dwFileSize = len*m_pcmWaveFormat.nBlockAlign + 36 ;
	fout.write((char *)&dwFileSize,sizeof(dwFileSize));
	fout.write("WAVEfmt ",8);
	
	DWORD dwFmtSize = 16L + (m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM ? sizeof(m_pcmWaveFormat.cbSize) : 0 ) ;
	fout.write((char *)&dwFmtSize,sizeof(dwFmtSize));
	fout.write((char *)&m_pcmWaveFormat.wFormatTag,sizeof(m_pcmWaveFormat.wFormatTag));//�o���Ӽg1��??
	fout.write((char *)&m_pcmWaveFormat.nChannels,sizeof(m_pcmWaveFormat.nChannels));
	fout.write((char *)&m_pcmWaveFormat.nSamplesPerSec,sizeof(m_pcmWaveFormat.nSamplesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nAvgBytesPerSec,sizeof(m_pcmWaveFormat.nAvgBytesPerSec));
	fout.write((char *)&m_pcmWaveFormat.nBlockAlign,sizeof(m_pcmWaveFormat.nBlockAlign));
	fout.write((char *)&m_pcmWaveFormat.wBitsPerSample,sizeof(m_pcmWaveFormat.wBitsPerSample));
	//if(m_pcmWaveFormat.wFormatTag!=WAVE_FORMAT_PCM)
		//fout.write((char *)&m_pcmWaveFormat.cbSize ,sizeof(m_pcmWaveFormat.cbSize));		

	fout.write("data",4);
	DWORD dwNum = 2*len;
	fout.write((char *)&dwNum,sizeof(dwNum));
	fout.write((char *)m_sh,dwNum);



}
