#include "PDic.h"
//Constuctor
PDic::PDic()
{

}
PDic::~PDic()
{
       
}
void PDic::loadtable(const char* fn)
{
        CStrScan strscan;
        ifstream fin;
        char LineBuf[1024];
        char W[512];
        char PI[512];
        Mapping tmp;
        fin.open(fn,ios::in);
        if (m_Dictable.size()>0)
                m_Dictable.clear();
        while (!fin.eof())
        {
                strcpy(LineBuf,"");
                fin.getline(LineBuf,sizeof(LineBuf),'\n');
                if (strlen(LineBuf)==0)
                        continue;
                strscan.r2b(LineBuf,sizeof(LineBuf));
                strscan>>W>>PI;
                tmp.Li=W;
                tmp.PingIng=PI;
                m_Dictable.push_back(tmp);
        }
        fin.close();
        //cout<<m_Dictable.size()<<endl;
}
///////////////////////////////////////////////////////////////////
void PDic::searchpinging(const char instring[])
{
        /*
        string res=addgong(instring);
        //cout<<res<<endl;
	char* substring;
	char seps[]="_";
        char LineBuf[1024];
        strcpy(LineBuf,res.c_str());
	substring=strtok(LineBuf,seps);

	if (m_chinese.size()>0)
		m_chinese.clear();
	while(substring!=NULL)
	{
		string tmp=substring;
		m_chinese.push_back(tmp);
		substring=strtok(NULL,seps);
	}
        */
        getChineseWord(instring);
        if (m_chinese.size()>0)
		m_chinese.clear();
        m_chinese.push_back("sil1");
        for (unsigned int i=0;i<m_ChineseWord.size();i++)
                m_chinese.push_back(m_ChineseWord.at(i));
        m_chinese.push_back("sil1");

	if (m_noexistchinese.size()>0)
		m_noexistchinese.clear();
	if (m_answer.size()>0)
		m_answer.clear();
	m_count=0;
	for (unsigned int i=0;i<m_chinese.size();i++)
	{
		string find=m_chinese.at(i);
		string PI="";
		for (unsigned int j=0;j<m_Dictable.size();j++)
		{
			if (m_Dictable.at(j).Li==find)
			{
				PI=m_Dictable.at(j).PingIng;
				m_answer.push_back(PI);
				break;
			}			
		
		}	
		if (PI==""){
                        m_noexistchinese.push_back(find);
			m_count++;
                }
	}

}
////////////////////////////////////////////////////////////////////
string PDic::addgong(char strLine[])
{
        char *p,*s;
        char *t;
        //char strLine[1024];
        //strcpy(strLine,ustrgond.c_str());
        char A[3];
        A[2]='\0';
        char B[2];
        B[1]='\0';
        char Result[1024]="";

        s=strLine;
        while (1)
        {

                p=CharNext(s);
                t=CharNext(p);
                if (p-s==2)
                {
                        A[0]=*(p-2);
                        A[1]=*(p-1);
                        strcat(Result,A);
                        if (t-p==1)
                        {
                                strcat(Result,"_");
                        }
                        if (t-p==2)
                        {
                                strcat(Result,"_");
                        }
                }
                else if (p-s==1)
                {
                        B[0]=*(p-1);
                        strcat(Result,B);
                        if (t-p!=0)
                        {
                                strcat(Result,"_");
                         }
                }
                else if (p-s==0)
                {

                        break;
                }
                s=p;
        }
        cout<<Result<<endl;
        string answer=Result;
        return answer;
        //strcpy(Result,"");
}
////////////////////////////////////////////////////////////////////
void PDic::getChineseWord(const char strLine[])
{
        if (m_ChineseWord.size()>0)
                m_ChineseWord.clear();
        const char *p,*s;
        const char *t;
        //char strLine[1024];
        //strcpy(strLine,ustrgond.c_str());
        char A[3];
        A[2]='\0';
        char B[2];
        B[1]='\0';
        char Result[1024]="";
        char szTmp[200];
        strcpy(szTmp,"");

        s=strLine;
        while (1)
        {

                p=CharNext(s);
                t=CharNext(p);
                if (p-s==2)
                {
                        A[0]=*(p-2);
                        A[1]=*(p-1);
                        //cout<<A<<endl;
                        strcat(Result,A);

                        cout<<A<<endl;
                        if (strcmp(A,"�H")==0 || strcmp(A,"�^")==0 || strcmp(A,"�]")==0 || strcmp(A,"�I")==0 || strcmp(A,"�C")==0 ||strcmp(A,"�G")==0 || strcmp(A,"�A")==0)
                        {

                        }
                        else
                                m_ChineseWord.push_back(A);
                        if (t-p==1)
                        {
                                //strcat(szTmp,B);
                                if (strcmp(szTmp,"")!=0)
                                {
                                        cout<<szTmp<<endl;
                                        m_ChineseWord.push_back(szTmp);
                                        strcpy(szTmp,"");
                                }
                                //strcat(Result,"_");
                        }
                        if (t-p==2)
                        {

                                //strcat(Result,"==");

                        }

                }
                else if (p-s==1)
                {
                        B[0]=*(p-1);
                        strcat(Result,B);
                        if (strcmp(B,"-")==0 || strcmp(B,"=")==0 || strcmp(B,"_")==0)
                        {
                                strcpy(B,"");

                                if (strcmp(szTmp,"")!=0)
                                {

                                        cout<<szTmp<<endl;
                                        m_ChineseWord.push_back(szTmp);
                                        strcpy(szTmp,"");
                                }
                        }

                        strcat(szTmp,B);

                        //cout<<B<<endl;
                        if (t-p==2)
                        {
                                if (strcmp(szTmp,"�H")==0 || strcmp(szTmp,"�^")==0 || strcmp(szTmp,"�]")==0 || strcmp(szTmp,"�I")==0 || strcmp(szTmp,"�C")==0 ||strcmp(szTmp,"�G")==0 || strcmp(szTmp,"�A")==0)
                                {
                                        strcpy(szTmp,"");
                                        continue;
                                }
                                if (strcmp(szTmp,"")!=0)
                                {
                                        cout<<szTmp<<endl;
                                        m_ChineseWord.push_back(szTmp);
                                        strcpy(szTmp,"");
                                }
                                //strcat(Result,"_");
                        }
                }
                else if (p-s==0)
                {
                        if (strcmp(szTmp,"")!=0)
                        {
                                cout<<szTmp<<endl;
                                m_ChineseWord.push_back(szTmp);
                                strcpy(szTmp,"");
                        }
                        break;
                }
                s=p;
        }
        //cout<<Result<<endl;
        string answer=Result;
        //return answer;
        //strcpy(Result,"");

}
