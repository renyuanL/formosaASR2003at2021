#include "PPlay.h"
//Constuctor
PPlay::PPlay()
{
        m_bpause=false;
        m_qstartpos=0;
        m_qendpos=0;
        m_restop=false;
}
PPlay::~PPlay()
{
}
void PPlay::load(const char* fn)
{
	ifstream fin(fn,ios::binary);
	
	char szTmp[10];
	WAVEFORMATEX pcmWaveFormat;
	ZeroMemory(szTmp, 10 * sizeof(char));
	fin.read(szTmp,4 * sizeof(char));
	
	DWORD dwFileSize/* = m_buffer.GetNumSamples() * m_pcmWaveFormat.nBlockAlign + 36*/ ;
	fin.read((char *)&dwFileSize,sizeof(dwFileSize));
	ZeroMemory(szTmp, 10 * sizeof(char));
	fin.read(szTmp,8 * sizeof(char));

	DWORD dwFmtSize /*= 16L*/;
	fin.read((char *)&dwFmtSize,sizeof(dwFmtSize));
	fin.read((char *)&pcmWaveFormat.wFormatTag,sizeof(pcmWaveFormat.wFormatTag));
	fin.read((char *)&pcmWaveFormat.nChannels,sizeof(pcmWaveFormat.nChannels));
	fin.read((char *)&pcmWaveFormat.nSamplesPerSec,sizeof(pcmWaveFormat.nSamplesPerSec));	
	fin.read((char *)&pcmWaveFormat.nAvgBytesPerSec,sizeof(pcmWaveFormat.nAvgBytesPerSec));
	fin.read((char *)&pcmWaveFormat.nBlockAlign,sizeof(pcmWaveFormat.nBlockAlign));
	fin.read((char *)&pcmWaveFormat.wBitsPerSample,sizeof(pcmWaveFormat.wBitsPerSample));
	
	ZeroMemory(szTmp, 10 * sizeof(char));
	fin.read(szTmp,4 * sizeof(char));
	
	m_pcmWaveFormat=pcmWaveFormat;
	DWORD dwNum;
	fin.read((char *)&dwNum,sizeof(dwNum));
        m_length=dwNum/2;

        qbuf.reserve(m_length);

	fin.read((char*)qbuf.GetBufPoint(),dwNum);
	fin.close();
}
int PPlay::waveplay(PBuffer& buf)
{
        qbuf=buf;
         //�o�ئp�Gbuffer�S��operator=�|��memory�����D
         //���ӬO�S��new,�Ѻc�l�ɷ|�����D


        m_pcmWaveFormat=buf.m_pcmWaveFormat;
        m_length=buf.m_nsh;

        res=iw.open(&(m_pcmWaveFormat));
	iw.sethdr(qbuf.GetBufPoint(),m_length);
        if (res==MMSYSERR_NOERROR)
        {
		res=iw.prepare();

   		iw.reset4wait();
		iw.bPlayDiong=1;
		res=iw.write();
		iw.wait2end();

        	res=iw.unprepare();
		res=iw.reset();
		iw.bPlayDiong=0;
        	res=iw.close();

        	return 1;
	}
        else
	{
                return 0;
	}


}
int PPlay::waveplay(PBuffer& qbufin,int qstart,int qend)
{
        m_qstartpos = qstart;//* m_wave.getFormat().nBlockAlign;
        //if (m_qstartpos>=qbuf.m_nsh)
        //        m_qstartpos=qbuf.m_nsh;
	m_qendpos = (qend == -1) ? qbufin.m_nsh : min(qbufin.m_nsh,qend);// * m_wave.getFormat().nBlockAlign;


        p2qbuf=&qbufin;
        shsize=qbufin.m_nsh;
        res=iw.open(&(qbufin.m_pcmWaveFormat));
        //crtsection cs;

	PBuffer &qbuf=*p2qbuf;
	int nsh=shsize;

        //�o��ק�Fm_qendpos
        //�b2005/1/19
        if (m_qstartpos!=0 || m_qendpos!=0)
        {
                iw.sethdr(qbuf.GetBufPoint()+m_qstartpos,m_qendpos-m_qstartpos);
        }
        else
        {
                iw.sethdr(qbuf.GetBufPoint(),nsh);
        }

        if (res==MMSYSERR_NOERROR)
        {

	        res=iw.prepare();

                iw.reset4wait();
		iw.bPlayDiong=1;
		res=iw.write();
		iw.wait2end();

        	res=iw.unprepare();
                //�p�G�o��Wave����s��play
		res=iw.reset();
		iw.bPlayDiong=0;
                res=iw.close();

        	return 1;
	}
        else
               	return 0;

}
int PPlay::play()
{

        res=iw.open(&(m_pcmWaveFormat));
	iw.sethdr(qbuf.GetBufPoint(),m_length);

        if (res==MMSYSERR_NOERROR)
        {
		res=iw.prepare();

   		iw.reset4wait();
		iw.bPlayDiong=1;
		res=iw.write();
		iw.wait2end();

        	res=iw.unprepare();
		res=iw.reset();
		iw.bPlayDiong=0;
        	res=iw.close();
        	return 1;
	}
        else
	{
                return 0;
	}

}
DWORD PPlay::getPosition()
{
        return iw.getposition();
}
int PPlay::tplay(PBuffer& qbuf)
{
        //if (m_bpause==false)
        //{
	        p2qbuf=&qbuf;
                ofstream fout;
	        shsize=qbuf.m_nsh;
                res=iw.open(&(qbuf.m_pcmWaveFormat));
                if (res==MMSYSERR_NOERROR)
                {
	                thd.begin(thdf,this);
	                return 1;
                }
                else
                        return 0;
        //}
        //else
        //{
        //        m_bpause=false;
        //        return iw.restart();
        //}
}
int PPlay::tplay(PBuffer& qbuf,int qstart,int qend)
{
        m_qstartpos = qstart;//* m_wave.getFormat().nBlockAlign;
        //if (m_qstartpos>=qbuf.m_nsh)
        //        m_qstartpos=qbuf.m_nsh;
	m_qendpos = (qend == -1) ? qbuf.m_nsh : min(qbuf.m_nsh,qend);// * m_wave.getFormat().nBlockAlign;

        //if (m_bpause==false)
        //{
	        p2qbuf=&qbuf;
	        shsize=qbuf.m_nsh;
                res=iw.open(&(qbuf.m_pcmWaveFormat));
                if (res==MMSYSERR_NOERROR)
                {
	                thd.begin(thdf,this);
	                return 1;
                }
                else
                        return 0;
        //}
        //else
        //{
         //       m_bpause=false;
        //        return iw.restart();
        //}


}
void PPlay::setReset()
{
        m_qstartpos=0;
        m_qendpos=0;
}
int PPlay::sztplay()
{
        //crtsection cs;

	PBuffer &qbuf=*p2qbuf;
	int nsh=shsize;

        //�o��ק�Fm_qendpos
        //�b2005/1/19
        if (m_qstartpos!=0 || m_qendpos!=0)
        {
                iw.sethdr(qbuf.GetBufPoint()+m_qstartpos,m_qendpos-m_qstartpos);
        }
        else
        {
                iw.sethdr(qbuf.GetBufPoint(),nsh);
        }

        if (res==MMSYSERR_NOERROR)
        {

	        res=iw.prepare();

                iw.reset4wait();
		iw.bPlayDiong=1;
		res=iw.write();
		iw.wait2end();

        	res=iw.unprepare();
                //�p�G�o��Wave����s��play
		//res=iw.reset();
		iw.bPlayDiong=0;
                //res=iw.close();

        	return 1;
	}
        else
               	return 0;

        
}
int PPlay::replay(PBuffer& qbuf)
{
        p2qbuf=&qbuf;

        shsize=qbuf.m_nsh;
        res=iw.open(&(qbuf.m_pcmWaveFormat));
        if (res==MMSYSERR_NOERROR)
        {
                thd.begin(rethdf,this);
                return 1;
        }
        else
               return 0;
        //}
        //else
        //{
        //        m_bpause=false;
        //        return iw.restart();
        //}
}
int PPlay::resztplay()
{


        //crtsection cs;
        m_restop=false;
	PBuffer &qbuf=*p2qbuf;
	int nsh=shsize;
        //�o��ק�Fm_qendpos
        //�b2005/1/19
        if (m_qstartpos!=0 || m_qendpos!=0)
        {
                iw.sethdr(qbuf.GetBufPoint()+m_qstartpos,m_qendpos-m_qstartpos);
        }
        else
        {
                iw.sethdr(qbuf.GetBufPoint(),nsh);
        }

        if (res==MMSYSERR_NOERROR)
        {

	        res=iw.prepare();
                while (1)
                {
                        iw.reset4wait();
		        iw.bPlayDiong=1;
		        res=iw.write();
		        iw.wait2end();
                        if (m_restop==true)
                                break;
                                
                        iw.bPlayDiong=0;
                        res=iw.reset();
                }
                m_restop=false;
                res=iw.unprepare();
                //�p�G�o��Wave����s��play
                //

                //res=iw.close();

        	return 1;
	}
        else
               	return 0;

}
