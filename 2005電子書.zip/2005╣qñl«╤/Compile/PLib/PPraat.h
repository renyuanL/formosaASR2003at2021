#ifndef __PPraat_H
#define __PPraat_H
#include "PFunc.h"
#include "PMatrix.h"
#include <windows.h>
#include <vector>
#include "wavseg.h"
struct syl
{
        char sylname[500];
        float stime;
        float etime;
};
struct LabBou
{
        char filename[500];
        vector<syl> Bouder;
};
struct IPoint
{
public:
        float* formant;
        float* bandwidth;
        float time;
        int NumOfFormants;
        IPoint(){time=0.0,NumOfFormants=0,formant=NULL,bandwidth=NULL;}
        ~IPoint()
        {
                if (formant!=NULL)
                        delete [] formant;
                if (bandwidth!=NULL)
                        delete [] bandwidth;
        }
};
class PPraat
{
private:
	CStrScan m_strScan;
	int m_TotalFrameNum;
public:
        PPraat();
        ~PPraat();

        IPoint* m_point;
        int m_pointsize;
        float m_FormantInterVal;
        void readPraatFormantFile(const char* fn);

        PVector m_intensity;
        float m_IntenInterVal;
        void readPraatIntensityFile(const char* fn);

	void readPraatPitchFile(const char* fn);
        void plotPitch(HDC hdc);
	PVector m_PitchVal;
        float m_PitchInterVal;
	PVector m_intVal;
	
	void readPraatTextGridFile(const char* fn);
        LabBou m_labbou;
        void PPraat::plotDifPitch(HDC hdc,int tsize,wseginfo& teacher,int tlen,wseginfo& student,int slen);
};
#endif