#ifndef __PLokim_H
#define __PLokim_H
#include <windows.h>
#include "PBuffer.h"
#include "PWavInLokim.h"
#include <stdio.h>
#include <stdlib.h>
class PLokim
{
public:
	PWavInLokim iw;
	MMRESULT res;
	thinthread thd;
	int tlokim(PBuffer& qbuf,int nsh);
	int sztlokim();
	PBuffer *p2qbuf;
	int shsize;
	//PWaveInLokimBuffer;
	int lokim(PBuffer& qbuf,int nsh);
   	PLokim();
        int szlength;
        int lokimstop(){szlength=iw.reset(10);iw.bLokImDiong=0;return 1;}
        int isRecording(){
                return iw.bLokImDiong;
       }

   	static ULONG WINAPI thdf(void*p){PLokim&o=(*(PLokim*)p);o.sztlokim();o.thd.dele();return 1;}

};
#endif