#ifndef __PFEATURE_H
#define __PFEATURE_H
#include "SSP.h"
#include "PWave.h"
struct Unvoiced
{
   float stime;
   float etime;
   Unvoiced():stime(0.0),etime(0.0){}
};
struct Voiced
{
   float stime;
   float etime;
   Voiced():stime(0.0),etime(0.0){}
};
struct Syl
{
   float stime;
   float etime;
   Unvoiced airvoice;
   Voiced pitchvoice;
   Syl():stime(0.0),etime(0.0){}
};
using namespace std;
class PFeature
{
private:
        SSP FSSP;

public:
        PFeature(){}
        ~PFeature(){}        
	PVector m_engBuf;
	void WaveToEnergy(PWave& wav,int fs,int ol);

        PVector m_volumnBuf;
	void WaveToVolumn(PWave& wav,int fs,int ol);
	        void plotVolumn(HDC hdc);
           void plotDifVolumn(HDC hdc,int tsize,wseginfo& teacher,int tlen,wseginfo& student,int slen);

        PVector m_SpecRoll;
        void WaveToSpecRolloff(PWave& wav,int fs,int ol,int fftsize);

        PVector m_SpecCentroid;
        PVector m_SpecDiversity;
        void WaveToSpecCentroid(PWave& wav,int fs,int ol,int fftsize);

        PVector m_ZcrBuf;
        void WaveToZCR(PWave& wav,int fs,int ol);

        PVector m_EntroypyBuf;
        void WaveToEntropy(PWave& wav,int fs,int ol,int fftsize);

        PVector m_PitchBuf;
        float m_PitchIntvalTime;
        void FromPrat(PVector& vec,float intval);

        PVector m_IntensityBuf;
        float m_IntenIntvalTime;
        void IntesityFromPrat(PVector& vec,float intval);

        //SpectrumFlux
        PVector m_SpecMean;
        PVector m_SpecVariance;
        PMatrix m_SpectrumBuf;
        PVector m_SpecFluxBuf;
        void WaveToSpectrumFlux(PWave& wav,int fs,int fftsize);

        //Vowel Combined;
        PMatrix m_partSpectrumBuf;
        PVector m_partSpecFluxBuf;
        PVector m_partSpecMean;
        PVector m_partSpecVariance;
        bool WaveToSpecFlux(PWave& wav,vector<Syl>& vec,vector<Unvoiced> unvoicebou);
};
#endif
