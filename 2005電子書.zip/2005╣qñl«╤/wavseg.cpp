//�{�EHMM
#include "Compile/inc/CRec.h"
#include "Compile/inc/CMel.h"
#include "Compile/inc/CWaveIn.h"
#include "Compile/inc/CWaveOut.h"

//�E��
#include "Compile/PLib/PMatrix.h"
#include "Compile/PLib/PPlay.h"
#include "Compile/PLib/PPraat.h"
#include "Compile/PLib/SSP.h"
#include "Compile/PLib/PFeature.h"
#include "Compile/PLib/PScore.h"
#include "Compile/PLib/PLokim.h"
#include "Compile/PLib/PWavInLokim.h"
#include "Compile/PLib/PDynamic.h"
#include "Compile/PLib/PTcp.h"
//���Ѯv
#include "Compile/incl32/di5mout.h"

#include <io.h>
#include <dir.h>
#include <conio.h>
#include <dos.h>
#include <dir.h>
#include "wavseg.h"

wavseg0_ wavseg;

int wseginfo::allc(int size1)
{
	if (size1>0)
	{
                SZ=0;
		ALLCSZ=size1;
		bk=new wboundkind[ALLCSZ];
		return 1;
	}
	else
		return 0;
}
int wseginfo::dllc()
{
	if (ALLCSZ>0){
		if (bk!=NULL){
			delete [] bk;
			return 1;
		}		
		else
			return 0;
	}
	else
		return 0;
}
int wseginfo::push(int sn, short kd)
{
	if (SZ<ALLCSZ){
		bk[SZ].sn=sn;
		bk[SZ].kd=kd;
                ++SZ;
		return 1;
	}
	else
		return 0;	
	
}
/*
wavseg_::wavseg_()
{

}
wavseg_::~wavseg_()
{

}
*/
int wavseg0_::byDTW(wseginfo&wsi,vector<double>& grade, cchar* pinimstr, short*wav, int len, int framesize, int samplrate)
{
        PDynamic dynamic;
        PBuffer buf;
        PWave ttswav;
        PDic dic;

        dic.loadtable("Run\\INIT\\Tchr2Tsyl.v1.dic");
        dynamic.init("Run\\INIT\\Tchr2Tsyl.v1.dic","MFCC_0");

        buf.reserve(len);
        for (int z=0;z<len;z++)
                buf[z]=wav[z];
        buf.setformat();

        PWave pwav;
        pwav.makewave(buf,len);
        pwav.SaveWave("Run\\thread.wav");


        if (strcmp(pinimstr,"")==0)
                return 0;//�S����J�����r
	//�����ؿ�
        //chdir(m_start_dir);
        if (dynamic.pinginwave(pinimstr))
        {
                //cout<<dynamic.
                ttswav.load("Run\\TTS.wav");
                //cout<<"Hihi"<<endl;
                //m_ttslength=m_ttswav.GetBufLength();
                /*
                for (unsigned int z=0;z<dynamic.m_pingin.size();z++)
                {
                        cout<<dynamic.m_pingin.at(z)<<endl;

                }
                */
                //return 1;

        }
        else
        {
                //cout<<"ForPA�Э����~"<<endl;
                //char nonexistin[4096];
                //strcpy(nonexistin,"");
                //for (int j=0;j<dynamic.m_nonexist.size();j++)
                //{
                        //cout<<dynamic.m_nonexist.at(j)<<endl;
                        //strcat(nonexistin,dynamic.m_nonexist.at(j).c_str());
                        //strcat(nonexistin," ");
                //}
                //mout<<nonexistin<<memo;
                return 0;
        }
        /*
        if (dynamic.connectwave(pinimstr))
        {
                dic.searchpinging(pinimstr);
                ttswav.load("TTS.wav");
                ///string temp;
                //for (unsigned int k=0;k<m_dic.m_chinese.size();k++)
                //{
                //        temp=m_dic.m_chinese.at(k);
                //}
                        
                //return 1;
        }
        else
        {

                //mout<<"�r�έ����s�b"<<memo;
                //char nonexistin[4096];
                //strcpy(nonexistin,"");
                //for (int j=0;j<dynamic.m_nonexist.size();j++)
                //{
                        //strcat(nonexistin,dynamic.m_nonexist.at(j).c_str());
                        //strcat(nonexistin," ");
                //}
                //mout<<nonexistin<<memo;
                return 0;
	}
        */

        dynamic.doDynamicProgramming("Run\\TTS.wav","Run\\thread.wav");
        int z=0;
        if (dynamic.m_dtwsegbou.size()>0)
        {
                wsi.allc(dynamic.m_dtwsegbou.size()+2);
                if (strcmp(dynamic.m_pingin.at(z).c_str(),"sil1")!=0)
                        wsi.push(0,'-');
                else
                        wsi.push(0,'=');
                z++;

                float length=(float)pwav.GetBufLength()/samplrate;
                float oldbound=0.0;
                for (unsigned int i=0;i<dynamic.m_dtwsegbou.size();i++)
                {
                        /*
                        if ((dynamic.m_dtwsegbou.at(i)-0.0)<=0.02)
                                dynamic.m_dtwsegbou.at(i)=dynamic.m_dtwsegbou.at(i)+0.02;

                        if ((length-dynamic.m_dtwsegbou.at(i))<=0.05)
                                dynamic.m_dtwsegbou.at(i)=dynamic.m_dtwsegbou.at(i)-0.05;

                        oldbound=dynamic.m_dtwsegbou.at(i-1);
                        //�|��boundary�ۦP�����p
                        if (dynamic.m_dtwsegbou.at(i)==oldbound)
                        {
                                //mout<<"�o��Boundary�ۦP���p"<<memo;

                                dynamic.m_dtwsegbou.at(i)=dynamic.m_dtwsegbou.at(i)+0.03;
                        }
                        */
                        if (strcmp(dynamic.m_pingin.at(z).c_str(),"sil1")!=0)
                                wsi.push(dynamic.m_dtwsegbou.at(i)*samplrate,'-');
                        else
                                wsi.push(dynamic.m_dtwsegbou.at(i)*samplrate,'=');
                        z++;
                }
                /*
                if (strcmp(dynamic.m_pingin.at(z).c_str(),"sil1")!=0)
                        wsi.push(dynamic.m_dtwsegbou.at(i)*samplrate,'-');
                else
                        wsi.push(dynamic.m_dtwsegbou.at(i)*samplrate,'=');
                */
                wsi.push((float)pwav.GetBufLength(),'0');


                /*
                ofstream fout;
                fout.open("led.txt",ios::out);
                fout<<wsi.size()<<endl;
                fout<<dynamic.m_disgrade.size()<<endl;
                */
                for (unsigned int v=0;v<dynamic.m_disgrade.size();v++)
                {
                  grade.push_back(dynamic.m_disgrade.at(v));
                //  fout<<dynamic.m_disgrade.at(v)<<endl;
                }
               //fout.close();
                /*
                float length=m_SylBoundary.at(m_SylBoundary.size()-1);
                float oldbound=0.0;
                //�ѪR�פ���
                for(unsigned int i=1;i<m_SylBoundary.size()-1;i++)
                {

                                if ((m_SylBoundary.at(i)-0.0)<=0.02)
                                        m_SylBoundary.at(i)=m_SylBoundary.at(i)+0.02;
                                if ((length-m_SylBoundary.at(i))<=0.05)
                                m_SylBoundary.at(i)=m_SylBoundary.at(i)-0.05;

                                oldbound=m_SylBoundary.at(i-1);
                                //�|��boundary�ۦP�����p
                                if (m_SylBoundary.at(i)==oldbound)
                                {
                                        mout<<"�o��Boundary�ۦP���p"<<memo;
                                        m_SylBoundary.at(i)=m_SylBoundary.at(i)+0.03;
                                }

                }
                */

                return 1;
        }
        else
                return 0;

}
int wavseg0_::byHMM(wseginfo&wsi, cchar* pinimstr, short*wav, int len, int framesize, int samplrate)
{
        if (strcmp(pinimstr,"")==0)
                return 0;//�S����J�����r
        CWave wb;
        CMel mel;
        CMMF mmf;
        CNet net;
        CDic dic;
        CRec rec;
        CFeaBuf fb;

        //�{�EHMM BASED SEGMENT
        mmf.readBin("Run\\init\\mmf.bin");
        dic.readDic("Run\\init\\lexicon.dic",mmf);
        net.readTxt("Run\\init\\Zhau.net",dic);
        rec.init(mmf,dic,net);
        mel.settgtPK("MFCC_0_D_A_Z");
        mel.m_cfg.eNormalise = false;

        ofstream fout;
        fout.open("Run\\tmp.txt",ios::out);
        fout<<pinimstr<<endl;
        fout.close();
        bool bkwq=net.buildTreeNet("Run\\tmp.txt","Run\\tmp.net",dic);
        if (bkwq)
        {
                net.readTxt("Run\\tmp.net",dic);
                rec.changeNet(net);
        }
        else
        {

                /*
                mout<<"�r���s�b"<<memo;
                char nonexistin[4096];
                strcpy(nonexistin,"");
                for (unsigned int j=0;j<net.m_noexistword.size();j++)
                {
                        strcat(nonexistin,net.m_noexistword.at(j).c_str());
                        strcat(nonexistin," ");
                }
                mout<<nonexistin<<memo;
                */
                return 0;
        }

        PBuffer buf;
        buf.reserve(len);
        for (int z=0;z<len;z++)
                buf[z]=wav[z];
        buf.setformat();
        PWave pwav;
        pwav.makewave(buf,len);
        pwav.SaveWave("Run\\hmm.wav");

        wb.load("Run\\hmm.wav");
        mel.wav2fea(wb,fb);
        rec.doRec(fb);
/*
        for (unsigned int z=0;z<m_dynamic.m_pingin.size();z++)
        {
                m_dic.m_chinese.push_back(m_dynamic.m_pingin.at(z));
                m_SylCharacter.push_back(m_dynamic.m_pingin.at(z));
        }
*/
        if (rec.getSylBoundary(0).size()>0)
        {
                vector<int> pos = rec.getSylBoundary(0);

                wsi.allc(rec.getSylBoundary(0).size()+1);
                wsi.push(0,'=');

                //if (m_SylBoundary.size()>0)
                //        m_SylBoundary.clear();
                //m_SylBoundary.push_back(0.0);
                for(unsigned int i=0;i<rec.getSylBoundary(0).size()-1;i++)
                {
                        float value=(float)pos[i]/100.0;
                        wsi.push(value*samplrate,'-');
                        //m_SylBoundary.push_back(value);
                }
                wsi.push((float)wb.getNumSamples(),'=');
                //m_SylBoundary.push_back((float)wb.getNumSamples()/16000.0);
                return 1;
        }
        else
                return 0;

}
int wavseg0_::byAF(wseginfo&wsi, cchar* pinimstr, short*wav, int len, int framesize, int samplrate)
{
        char start_dir[MAXPATH];
        char wave_dir[MAXPATH];
        getcwd(start_dir,MAXPATH);

        PBuffer buf;
        buf.reserve(len);
        for (int z=0;z<len;z++)
                buf[z]=wav[z];
        buf.setformat();
        PWave pwav;
        pwav.makewave(buf,len);
        pwav.SaveWave("Run\\kf.wav");

        strcpy(wave_dir,start_dir);
        strcat(wave_dir,"\\Run\\");
        strcat(wave_dir,"kf");
        strcat(wave_dir,".wav");

        //�s��SCript���a��
        char script_dir[MAXPATH];
        char pitch_dir[MAXPATH];
        char intensity_dir[MAXPATH];
        strcpy(script_dir,start_dir);
        strcat(script_dir,"\\Run\\script\\");
        strcat(script_dir,"kf");
        strcat(script_dir,".scp");

        //�gScript��
        ofstream fout;
        fout.open(script_dir,ios::out);
        //����Pitch
        fout<<"Read from file... "<<wave_dir<<endl;
        fout<<"To Pitch (cc)... 0 75 15 no 0.03 0.45 0.01 0.35 0.14 600"<<endl;
        strcpy(pitch_dir,start_dir);
        strcat(pitch_dir,"\\Run\\script\\");
        strcat(pitch_dir,"kf");
        strcat(pitch_dir,".Pitch");
        fout<<"Write to text file... "<<pitch_dir<<endl;
        //����Intensity
        fout<<"Read from file... "<<wave_dir<<endl;
        fout<<"To Intensity... 100 0 yes"<<endl;
        strcpy(intensity_dir,start_dir);
        strcat(intensity_dir,"\\Run\\script\\");
        strcat(intensity_dir,"kf");
        strcat(intensity_dir,".Intensity");
        fout<<"Write to text file... "<<intensity_dir<<endl;
        fout.close();
        //��������ɮ�
        remove(pitch_dir);
        remove(intensity_dir);


        //������ϥ�ShellExecute�h����@��dos�U�������ɡA
        HINSTANCE rv=0;
        rv=ShellExecute(NULL,"open","Run\\praatcon.exe",script_dir,NULL,SW_HIDE);
        //GetConsoleMsg("praatcon.exe",script_dir,DegWin1);
        //���praatcon���ͪ��ɮ�
        //���pitch��

        ifstream fin;
        fin.open(pitch_dir,ios::in);
        while (1)
        {
                /*
                if (m_dynamic.file_exists(m_DTWTextGridPath))
                {
                        break;
                //        mout<<"�ɮצs�b"<<memo;
                }
                else
                        Sleep(50);
                */
                if (!fin.is_open())
                {
                        Sleep(50);
                        fin.open(pitch_dir,ios::in);
                }
                else
                        break;

        }
        fin.close();
        //���intensity��
        fin.open(intensity_dir,ios::in);
        while (1)
        {
                if (!fin.is_open())
                {
                        Sleep(50);
                        fin.open(intensity_dir,ios::in);
                }
                else
                        break;
        }
        fin.close();

        PPraat ppraat;
        PFeature fea;
        PScore score;
        ppraat.readPraatPitchFile(pitch_dir);
        //mHavePitch=true;

        //�Npraat��feature Ū�Jm_fea ��
        ppraat.readPraatIntensityFile(intensity_dir);
        fea.IntesityFromPrat(ppraat.m_intensity,ppraat.m_IntenInterVal);
        fea.FromPrat(ppraat.m_PitchVal,ppraat.m_PitchInterVal);

        score.Wav2Fea(pwav,fea);

        score.CalBoundary();
        int ques=score.Combine();
        if (ques==1)
        {
                //mout<<"Syllable�����D"<<memo;
                //score.m_Result.clear();
                return 0;
        }
        else if (ques==2)
        {
                //mout<<"�𭵦����D"<<memo;
                //score.m_Result.clear();
                return 0;
        }else
        {
                //mout<<"Combine���\"<<memo;
                score.GetAnswer();

                if (score.m_Result.size()>0)
                {
                        wsi.allc(score.m_Result.size()+3);
                        wsi.push(0,'=');

                        for(unsigned int i=0;i<score.m_Result.size();i++)
                        {
                                wsi.push(score.m_Result.at(i).stime*samplrate,'-');
                        }
                        wsi.push(score.m_Result.at(score.m_Result.size()-1).etime*samplrate,'-');
                        wsi.push((float)pwav.GetBufLength(),'=');
                }
                return 1;
        }

}
int wavseg_::byDTW(wseginfo&wsi, cchar* pinimstr, cchar*wavname, int framesize)
{

        PDynamic dynamic;
        PWave ttswav;
        PDic dic;

        dic.loadtable("Run\\init\\Tchr2Tsyl.v1.dic");
        dynamic.init("Run\\init\\Tchr2Tsyl.v1.dic","MFCC_0");
        //cout<<len<<endl;

        PWave wav;
        wav.load(wavname);
        

        if (strcmp(pinimstr,"")==0)
                return 0;//�S����J�����r
	//�����ؿ�
        //chdir(m_start_dir);
        if (dynamic.pinginwave(pinimstr))
        {
                //cout<<dynamic.
                ttswav.load("Run\\TTS.wav");
                //cout<<"Hihi"<<endl;
                //m_ttslength=m_ttswav.GetBufLength();
                /*
                for (unsigned int z=0;z<dynamic.m_pingin.size();z++)
                {
                        cout<<dynamic.m_pingin.at(z)<<endl;

                }
                */
                //return 1;

        }
        else
        {

                //cout<<"ForPA�Э����~"<<endl;
                //char nonexistin[4096];
                //strcpy(nonexistin,"");
                //for (int j=0;j<dynamic.m_nonexist.size();j++)
                //{
                        //cout<<dynamic.m_nonexist.at(j)<<endl;
                        //strcat(nonexistin,dynamic.m_nonexist.at(j).c_str());
                        //strcat(nonexistin," ");
                //}
                //mout<<nonexistin<<memo;
                return 0;
        }
        /*
        if (dynamic.connectwave(pinimstr))
        {
                dic.searchpinging(pinimstr);
                ttswav.load("TTS.wav");
                ///string temp;
                //for (unsigned int k=0;k<m_dic.m_chinese.size();k++)
                //{
                //        temp=m_dic.m_chinese.at(k);
                //}
                        
                //return 1;
        }
        else
        {

                //mout<<"�r�έ����s�b"<<memo;
                //char nonexistin[4096];
                //strcpy(nonexistin,"");
                //for (int j=0;j<dynamic.m_nonexist.size();j++)
                //{
                        //strcat(nonexistin,dynamic.m_nonexist.at(j).c_str());
                        //strcat(nonexistin," ");
                //}
                //mout<<nonexistin<<memo;
                return 0;
	}
        */


        dynamic.doDynamicProgramming("Run\\TTS.wav","Run\\thread.wav");
        if (dynamic.m_dtwsegbou.size()>0)
        {
                wsi.allc(dynamic.m_dtwsegbou.size()+2);
                wsi.push(0,'=');

                float length=(float)wav.GetBufLength()/wav.getsamplerate();
                float oldbound=0.0;
                for (unsigned int i=0;i<dynamic.m_dtwsegbou.size();i++)
                {
                        /*
                        if ((dynamic.m_dtwsegbou.at(i)-0.0)<=0.02)
                                dynamic.m_dtwsegbou.at(i)=dynamic.m_dtwsegbou.at(i)+0.02;

                        if ((length-dynamic.m_dtwsegbou.at(i))<=0.05)
                                dynamic.m_dtwsegbou.at(i)=dynamic.m_dtwsegbou.at(i)-0.05;

                        oldbound=dynamic.m_dtwsegbou.at(i-1);
                        //�|��boundary�ۦP�����p
                        if (dynamic.m_dtwsegbou.at(i)==oldbound)
                        {
                                //mout<<"�o��Boundary�ۦP���p"<<memo;

                                dynamic.m_dtwsegbou.at(i)=dynamic.m_dtwsegbou.at(i)+0.03;
                        }
                        */
                        wsi.push(dynamic.m_dtwsegbou.at(i)*wav.getsamplerate(),'-');
                }
                wsi.push((float)wav.GetBufLength(),'=');

                /*
                float length=m_SylBoundary.at(m_SylBoundary.size()-1);
                float oldbound=0.0;
                //�ѪR�פ���
                for(unsigned int i=1;i<m_SylBoundary.size()-1;i++)
                {

                                if ((m_SylBoundary.at(i)-0.0)<=0.02)
                                        m_SylBoundary.at(i)=m_SylBoundary.at(i)+0.02;
                                if ((length-m_SylBoundary.at(i))<=0.05)
                                m_SylBoundary.at(i)=m_SylBoundary.at(i)-0.05;

                                oldbound=m_SylBoundary.at(i-1);
                                //�|��boundary�ۦP�����p
                                if (m_SylBoundary.at(i)==oldbound)
                                {
                                        mout<<"�o��Boundary�ۦP���p"<<memo;
                                        m_SylBoundary.at(i)=m_SylBoundary.at(i)+0.03;
                                }

                }
                */
                cout<<wav.getsamplerate()<<endl;
                return 1;
        }
        else
                return 0;
	
}

int wavseg_::byHMM(wseginfo&wsi, cchar* pinimstr, cchar*wavname, int framesize)
{
        if (strcmp(pinimstr,"")==0)
                return 0;//�S����J�����r
        CWave wb;
        CMel mel;
        CMMF mmf;
        CNet net;
        CDic dic;
        CRec rec;
        CFeaBuf fb;

        //�{�EHMM BASED SEGMENT
        mmf.readBin("Run\\init\\mmf.bin");
        dic.readDic("Run\\init\\lexicon.dic",mmf);
        net.readTxt("Run\\init\\Zhau.net",dic);
        rec.init(mmf,dic,net);
        mel.settgtPK("MFCC_0_D_A_Z");
        mel.m_cfg.eNormalise = false;

        ofstream fout;
        fout.open("Run\\tmp.txt",ios::out);
        fout<<pinimstr<<endl;
        fout.close();
        bool bkwq=net.buildTreeNet("Run\\tmp.txt","Run\\tmp.net",dic);
        if (bkwq)
        {
                net.readTxt("Run\\tmp.net",dic);
                rec.changeNet(net);
        }
        else
        {

                /*
                mout<<"�r���s�b"<<memo;
                char nonexistin[4096];
                strcpy(nonexistin,"");
                for (unsigned int j=0;j<net.m_noexistword.size();j++)
                {
                        strcat(nonexistin,net.m_noexistword.at(j).c_str());
                        strcat(nonexistin," ");
                }
                mout<<nonexistin<<memo;
                */
                return 0;
        }

        wb.load(wavname);
        mel.wav2fea(wb,fb);
        rec.doRec(fb);
/*
        for (unsigned int z=0;z<m_dynamic.m_pingin.size();z++)
        {
                m_dic.m_chinese.push_back(m_dynamic.m_pingin.at(z));
                m_SylCharacter.push_back(m_dynamic.m_pingin.at(z));
        }
*/
        if (rec.getSylBoundary(0).size()>0)
        {
                vector<int> pos = rec.getSylBoundary(0);

                wsi.allc(rec.getSylBoundary(0).size()+1);
                wsi.push(0,'=');

                //if (m_SylBoundary.size()>0)
                //        m_SylBoundary.clear();
                //m_SylBoundary.push_back(0.0);
                for(unsigned int i=0;i<rec.getSylBoundary(0).size()-1;i++)
                {
                        float value=(float)pos[i]/100.0;
                        wsi.push(value*wb.getsamplerate(),'-');
                        //m_SylBoundary.push_back(value);
                }
                wsi.push((float)wb.getNumSamples(),'=');
                //cout<<wb.getsamplerate()<<endl;
                //m_SylBoundary.push_back((float)wb.getNumSamples()/16000.0);
                return 1;
        }
        else
                return 0;
}

int wavseg_::byAF(wseginfo&wsi, cchar* pinimstr, cchar*wavname, int framesize)
{
        char start_dir[MAXPATH];
        char wave_dir[MAXPATH];
        getcwd(start_dir,MAXPATH);

        
        PWave wav;
        wav.load(wavname);
        wav.SaveWave("Run\\kf.wav");
        
        strcpy(wave_dir,start_dir);
        strcat(wave_dir,"\\Run\\");
        strcat(wave_dir,"kf");
        strcat(wave_dir,".wav");

        //�s��SCript���a��
        char script_dir[MAXPATH];
        char pitch_dir[MAXPATH];
        char intensity_dir[MAXPATH];
        strcpy(script_dir,start_dir);
        strcat(script_dir,"\\Run\\script\\");
        strcat(script_dir,"kf");
        strcat(script_dir,".scp");

        //�gScript��
        ofstream fout;
        fout.open(script_dir,ios::out);
        //����Pitch
        fout<<"Read from file... "<<wave_dir<<endl;
        fout<<"To Pitch (cc)... 0 75 15 no 0.03 0.45 0.01 0.35 0.14 600"<<endl;
        strcpy(pitch_dir,start_dir);
        strcat(pitch_dir,"\\Run\\script\\");
        strcat(pitch_dir,"kf");
        strcat(pitch_dir,".Pitch");
        fout<<"Write to text file... "<<pitch_dir<<endl;
        //����Intensity
        fout<<"Read from file... "<<wave_dir<<endl;
        fout<<"To Intensity... 100 0 yes"<<endl;
        strcpy(intensity_dir,start_dir);
        strcat(intensity_dir,"\\Run\\script\\");
        strcat(intensity_dir,"kf");
        strcat(intensity_dir,".Intensity");
        fout<<"Write to text file... "<<intensity_dir<<endl;
        fout.close();
        //��������ɮ�
        remove(pitch_dir);
        remove(intensity_dir);


        //������ϥ�ShellExecute�h����@��dos�U�������ɡA
        HINSTANCE rv=0;
        rv=ShellExecute(NULL,"open","Run\\praatcon.exe",script_dir,NULL,SW_HIDE);
        //GetConsoleMsg("praatcon.exe",script_dir,DegWin1);
        //���praatcon���ͪ��ɮ�
        //���pitch��

        ifstream fin;
        fin.open(pitch_dir,ios::in);
        while (1)
        {
                /*
                if (m_dynamic.file_exists(m_DTWTextGridPath))
                {
                        break;
                //        mout<<"�ɮצs�b"<<memo;
                }
                else
                        Sleep(50);
                */
                if (!fin.is_open())
                {
                        Sleep(50);
                        fin.open(pitch_dir,ios::in);
                }
                else
                        break;

        }
        fin.close();
        //���intensity��
        fin.open(intensity_dir,ios::in);
        while (1)
        {
                if (!fin.is_open())
                {
                        Sleep(50);
                        fin.open(intensity_dir,ios::in);
                }
                else
                        break;
        }
        fin.close();

        PPraat ppraat;
        PFeature fea;
        PScore score;
        ppraat.readPraatPitchFile(pitch_dir);
        //mHavePitch=true;

        //�Npraat��feature Ū�Jm_fea ��
        ppraat.readPraatIntensityFile(intensity_dir);
        fea.IntesityFromPrat(ppraat.m_intensity,ppraat.m_IntenInterVal);
        fea.FromPrat(ppraat.m_PitchVal,ppraat.m_PitchInterVal);

        score.Wav2Fea(wav,fea);

        score.CalBoundary();
        int ques=score.Combine();
        if (ques==1)
        {
                //mout<<"Syllable�����D"<<memo;
                //score.m_Result.clear();
                return 0;
        }
        else if (ques==2)
        {
                //mout<<"�𭵦����D"<<memo;
                //score.m_Result.clear();
                return 0;
        }else
        {
                //mout<<"Combine���\"<<memo;
                score.GetAnswer();

                if (score.m_Result.size()>0)
                {
                        wsi.allc(score.m_Result.size()+3);
                        wsi.push(0,'=');

                        for(unsigned int i=0;i<score.m_Result.size();i++)
                        {
                                wsi.push(score.m_Result.at(i).stime*wav.getsamplerate(),'-');
                        }
                        wsi.push(score.m_Result.at(score.m_Result.size()-1).etime*wav.getsamplerate(),'-');
                        wsi.push((float)wav.GetBufLength(),'=');
                }
                return 1;
        }	
	
}

