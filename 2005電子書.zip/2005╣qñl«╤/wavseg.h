//// wavseg.h
//// api for wave-segmentor
//// copyright 2005-08 HongVun Zia, IngZin Gang, RenYuan Lyu

#ifndef WAVSEG_H
#define WAVSEG_H



typedef const char cchar;

////////////////////////////////////////////////////
////////////////////////////////////////////////////
class	AF_ {///(frame-based) acoustic feature
public:
	int energy	(double& outp, short*wav, int len);
	int picth	(double& outp, short*wav, int len);
	/// ...
};
extern AF_ AF;
////////////////////////////////////////////////////
////////////////////////////////////////////////////

struct	wboundkind {///wave bound and kind
		wboundkind():sn(0),kd(0){}
	int		sn; ///sample number of the bound
	short	kd; ///kind to the right of bound(sn), char or something else
};

struct	wseginfo {///bk[0].sn=0, bk[SZ-1].sn=wavelength, bk[SZ-1].kd=0
		wseginfo():bk(0),SZ(0),ALLCSZ(0){}
	   ~wseginfo(){dllc();}
public:
	void		clear		(	){SZ=0;}
	int			size		(	){return SZ;}
	int			push		(int sn, short kd);
	int			app			(int sn, short kd)	{return push(sn,kd);}
	wboundkind&	operator[]	(int n)				{return bk[n];}
public:
	wboundkind*	bk; 
	int			SZ,		ALLCSZ;
public:
	int	allc(int size1);	///allocation, re-alloc if size1>ALLCSZ
	int	dllc(	);			///de-allocation
};

class	wavseg0_ {
public:
	int byHMM	(wseginfo&wsi, cchar* pinimstr, short*wav, int len, int framesize, int samplrate=16000);
	int byAF	(wseginfo&wsi, cchar* pinimstr, short*wav, int len, int framesize, int samplrate=16000);
	int byDTW	(wseginfo&wsi,vector<double>& grade, cchar* pinimstr, short*wav, int len, int framesize, int samplrate=16000);
	int setDTW	(cchar* pathname);
};

class	wavseg_ {
	wavseg0_ ws;
public:
	int byHMM	(wseginfo&wsi, cchar* pinimstr, cchar*wavname, int framesize);
	int byAF	(wseginfo&wsi, cchar* pinimstr, cchar*wavname, int framesize);
	int byDTW	(wseginfo&wsi, cchar* pinimstr, cchar*wavname, int framesize);
public:
	int setDTW	(cchar* pathname);
};
extern wavseg0_ wavseg;
////////////////////////////////////////////////////
////////////////////////////////////////////////////

#endif WAVSEG_H

