//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        m_bmpBookForm=new Graphics::TBitmap();
        m_bmpBookForm->Height=PaintBook1->Height;
        m_bmpBookForm->Width=PaintBook1->Width;

        m_NumPer5file=0;
        m_value=0.05;
        m_x=0;
        m_charpos=0;
        m_recordx=0;
        m_first=0;
        m_x=0;
        m_bemousedown=false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OneCharacter()
{
        if (m_wordwidth.size()>0)
                m_wordwidth.clear();
        if (m_wordheight.size()>0)
                m_wordheight.clear();
        word tmpwidth;
        wordvec wordtempvec;
        if (Choose1->Tag%3==0 || Choose1->Tag%3==1)
        {
                if (m_test.size()>0)
                {
                        PaintBook1->Canvas->Font->Color = clBlack;
                        PaintBook1->Canvas->Font->Size = 16;
                        float pvalue=0.05;
                        int x=((m_page-1)*5)/5;
                        for (unsigned int i=(m_page-1)*5;i<m_page*5;i++)
                        {

                                if (wordtempvec.size()>0)
                                        wordtempvec.clear();

                                if (i<m_test.size())
                                {

                                        int offset;
                                        float val=0.0;
                                        int start=1*PaintBook1->Canvas->TextWidth("��");
                                        int end;
                                        int temp;

                                        float rr=m_test.at(i).at(0).length()%2;
                                        if (rr==0){
                                                val=val+m_test.at(i).at(0).length()/2;
                                                temp=m_test.at(i).at(0).length()/2;
                                        }
                                        else{
                                                val=val+(m_test.at(i).at(0).length()+1)/2;
                                                temp=(m_test.at(i).at(0).length()+1)/2;
                                        }
                                        offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                        start = offset;
                                        for (unsigned int j=1;j<m_test.at(i).size();j++)
                                        {
                                                float rr=m_test.at(i).at(j).length()%2;
                                                if (rr==0){
                                                        val=val+m_test.at(i).at(j).length()/2;
                                                        temp=m_test.at(i).at(j).length()/2;
                                                }
                                                else{
                                                        val=val+(m_test.at(i).at(j).length()+1)/2;
                                                        temp=(m_test.at(i).at(j).length()+1)/2;
                                                }

                                                offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_test.at(i).at(j).c_str());
                                                end=offset;
                                                tmpwidth.start=start;
	                                        tmpwidth.end=end;
	                                        wordtempvec.push_back(tmpwidth);
                                                start=end;
                                        }
                                        int tailsize=m_test.at(i).size()-1;
                                        rr=m_test.at(i).at(tailsize).length()%2;
                                        if (rr==0){
                                                val=val+m_test.at(i).at(tailsize).length()/2;
                                                temp=m_test.at(i).at(tailsize).length()/2;
                                        }
                                        else{
                                                val=val+(m_test.at(i).at(tailsize).length()+1)/2;
                                                temp=(m_test.at(i).at(tailsize).length()+1)/2;
                                        }

                                        offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_test.at(i).at(j).c_str());
                                        end=offset;
                                        tmpwidth.start=start;
                                        tmpwidth.end=end;
                                        wordtempvec.push_back(tmpwidth);
                                        pvalue=pvalue+0.15;
                                }
                                m_wordwidth.push_back(wordtempvec);

                        }

                }
                int start, end;
                float pvalue=0.05;
                for (unsigned int i=(m_page-1)*5;i<m_page*5;i++)
                {
                        if (i<m_test.size())
                        {
                                start=PaintBook1->Height*pvalue;
                                end=start+PaintBook1->Canvas->TextHeight("�r");
                                tmpwidth.start=start;
	                        tmpwidth.end=end;
	                        m_wordheight.push_back(tmpwidth);
                                pvalue=pvalue+0.15;
                        }

                }
        }
        else
        {

                if (m_ChineseWord.size()>0)
                {
                        PaintBook1->Canvas->Font->Color = clBlack;
                        PaintBook1->Canvas->Font->Size = 16;
                        float pvalue=0.05;
                        int x=((m_page-1)*5)/5;
                        for (unsigned int i=(m_page-1)*5;i<m_page*5;i++)
                        {

                                if (wordtempvec.size()>0)
                                        wordtempvec.clear();

                                if (i<m_ChineseWord.size())
                                {

                                        int offset;
                                        int start=1*PaintBook1->Canvas->TextWidth("��");
                                        int end;
                                        float val=0.0;
                                        float val2=0.0;
                                        int temp,temp2;

                                        float rr=m_ChineseWord.at(i).at(0).length()%2;
                                        if (rr==0){
                                                val=val+m_ChineseWord.at(i).at(0).length()/2;
                                                temp=m_ChineseWord.at(i).at(0).length()/2;
                                        }
                                        else{
                                                val=val+(m_ChineseWord.at(i).at(0).length()+1)/2;
                                                temp=(m_ChineseWord.at(i).at(0).length()+1)/2;
                                        }
                                        //offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                        //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_ChineseWord.at(i).at(j).c_str());

                                        float rr2=m_PingInWord.at(i).at(0).length()%2;
                                        if (rr2==0){
                                                val2=val2+m_PingInWord.at(i).at(0).length()/2;
                                                temp2=m_PingInWord.at(i).at(0).length()/2;
                                        }
                                        else{
                                                val2=val2+(m_PingInWord.at(i).at(0).length()+1)/2;
                                                temp2=(m_PingInWord.at(i).at(0).length()+1)/2;
                                        }
                                        offset = (1+val2)*PaintBook1->Canvas->TextWidth("��")-temp2*PaintBook1->Canvas->TextWidth("��") ;

                                        start = offset;
                                        for (unsigned int j=1;j<m_ChineseWord.at(i).size();j++)
                                        {
                                                float rr=m_ChineseWord.at(i).at(j).length()%2;
                                                if (rr==0){
                                                        val=val+m_ChineseWord.at(i).at(j).length()/2;
                                                        temp=m_ChineseWord.at(i).at(j).length()/2;
                                                }
                                                else{
                                                        val=val+(m_ChineseWord.at(i).at(j).length()+1)/2;
                                                        temp=(m_ChineseWord.at(i).at(j).length()+1)/2;
                                                }
                                                //offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_ChineseWord.at(i).at(j).c_str());

                                                float rr2=m_PingInWord.at(i).at(j).length()%2;
                                                if (rr2==0){
                                                        val2=val2+m_PingInWord.at(i).at(j).length()/2;
                                                        temp2=m_PingInWord.at(i).at(j).length()/2;
                                                }
                                                else{
                                                        val2=val2+(m_PingInWord.at(i).at(j).length()+1)/2;
                                                        temp2=(m_PingInWord.at(i).at(j).length()+1)/2;
                                                }
                                                offset = (1+val2)*PaintBook1->Canvas->TextWidth("��")-temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_test.at(i).at(j).c_str());
                                                end=offset;
                                                tmpwidth.start=start;
	                                        tmpwidth.end=end;
	                                        wordtempvec.push_back(tmpwidth);
                                                start=end;
                                        }
                                        int tailsize=m_ChineseWord.at(i).size()-1;
                                        rr=m_ChineseWord.at(i).at(tailsize).length()%2;
                                        if (rr==0){
                                                val=val+m_ChineseWord.at(i).at(tailsize).length()/2;
                                                temp=m_ChineseWord.at(i).at(tailsize).length()/2;
                                        }
                                        else{
                                                val=val+(m_ChineseWord.at(i).at(tailsize).length()+1)/2;
                                                temp=(m_ChineseWord.at(i).at(tailsize).length()+1)/2;
                                        }
                                        //offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                        //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_ChineseWord.at(i).at(j).c_str());

                                        rr2=m_PingInWord.at(i).at(tailsize).length()%2;
                                        if (rr2==0){
                                                val2=val2+m_PingInWord.at(i).at(tailsize).length()/2;
                                                temp2=m_PingInWord.at(i).at(tailsize).length()/2;
                                        }
                                        else{
                                                val2=val2+(m_PingInWord.at(i).at(tailsize).length()+1)/2;
                                                temp2=(m_PingInWord.at(i).at(tailsize).length()+1)/2;
                                        }
                                        offset = (1+val2)*PaintBook1->Canvas->TextWidth("��")-temp2*PaintBook1->Canvas->TextWidth("��") ;
                                        
                                        end=offset;
                                        tmpwidth.start=start;
                                        tmpwidth.end=end;
                                        wordtempvec.push_back(tmpwidth);
                                        pvalue=pvalue+0.15;
                                }
                                m_wordwidth.push_back(wordtempvec);

                        }

                }
                int start, end;
                float pvalue=0.05;
                for (unsigned int i=(m_page-1)*5;i<m_page*5;i++)
                {
                        if (i<m_ChineseWord.size())
                        {
                                start=PaintBook1->Height*pvalue;
                                end=start+PaintBook1->Canvas->TextHeight("�r");
                                tmpwidth.start=start;
	                        tmpwidth.end=end;
	                        m_wordheight.push_back(tmpwidth);
                                pvalue=pvalue+0.15;
                        }

                }

        }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::PaintBook1Paint(TObject *Sender)
{

        PaintBook1->Canvas->CopyMode = cmSrcCopy;
        PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
        plotWord();



}
//---------------------------------------------------------------------------
void TForm1::plotWord()
{
        if (Choose1->Tag%3==0 || Choose1->Tag%3==1)
        {
                if (m_test.size()>0)
                {
                        PaintBook1->Canvas->Font->Color = clBlack;
                        PaintBook1->Canvas->Font->Size = 16;
                        SetBkMode(PaintBook1->Canvas->Handle, TRANSPARENT);
                        //int offset;
                        float pvalue=0.05;
                        int x=((m_page-1)*5)/5;
                        for (unsigned int i=(m_page-1)*5;i<m_page*5;i++)
                        {

                                if (i<m_test.size())
                                {

                                        int offset;
                                        float val=0.0;
                                        int temp;
                                        for (unsigned int j=0;j<m_test.at(i).size();j++)
                                        {
                                                float rr=m_test.at(i).at(j).length()%2;
                                                if (rr==0){
                                                        val=val+m_test.at(i).at(j).length()/2;
                                                        temp=m_test.at(i).at(j).length()/2;
                                                }
                                                else{
                                                        val=val+(m_test.at(i).at(j).length()+1)/2;
                                                        temp=(m_test.at(i).at(j).length()+1)/2;
                                                }
                                                offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_test.at(i).at(j).c_str());
                                                //offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,"�áģ�����������");
                                        }
                                        pvalue=pvalue+0.15;
                                }


                        }

                }
        }
        else
        {
                if (m_ChineseWord.size()>0)
                {
                        PaintBook1->Canvas->Font->Color = clBlack;
                        PaintBook1->Canvas->Font->Size = 16;
                        SetBkMode(PaintBook1->Canvas->Handle, TRANSPARENT);
                        //int offset;
                        float pvalue=0.05;
                        int x=((m_page-1)*5)/5;
                        for (int i=(m_page-1)*5;i<m_page*5;i++)
                        {

                                if (i<m_ChineseWord.size())
                                {

                                        int offset;
                                        float val=0.0;
                                        float val2=0.0;
                                        int temp,temp2;//,tempbig;
                                        for (unsigned int j=0;j<m_ChineseWord.at(i).size();j++)
                                        {
                                                float rr=m_ChineseWord.at(i).at(j).length()%2;
                                                if (rr==0){
                                                        val=val+m_ChineseWord.at(i).at(j).length()/2;
                                                        temp=m_ChineseWord.at(i).at(j).length()/2;
                                                }
                                                else{
                                                        val=val+(m_ChineseWord.at(i).at(j).length()+1)/2;
                                                        temp=(m_ChineseWord.at(i).at(j).length()+1)/2;
                                                }
                                                //offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_ChineseWord.at(i).at(j).c_str());

                                                float rr2=m_PingInWord.at(i).at(j).length()%2;
                                                if (rr2==0){
                                                        val2=val2+m_PingInWord.at(i).at(j).length()/2;
                                                        temp2=m_PingInWord.at(i).at(j).length()/2;
                                                }
                                                else{
                                                        val2=val2+(m_PingInWord.at(i).at(j).length()+1)/2;
                                                        temp2=(m_PingInWord.at(i).at(j).length()+1)/2;
                                                }
                                                /*
                                                if (temp1>=temp2)
                                                        tempbig=temp1;
                                                else
                                                        tempbig=temp2;
                                                */
                                                offset = (1+val2)*PaintBook1->Canvas->TextWidth("��")-temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_ChineseWord.at(i).at(j).c_str());
                                                offset = (1+val2)*PaintBook1->Canvas->TextWidth("��")-temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*(pvalue+0.05),m_PingInWord.at(i).at(j).c_str());
                                                
                                        }
                                        pvalue=pvalue+0.15;
                                }


                        }

                }


        }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
void __fastcall TForm1::GetWord()
{
        if (Choose1->Tag%3==0)
        {
                if (m_test.size()>0)
                        m_test.clear();
                PDic dic;
                char szTmp[4096];
                strvec strvectemp;
                string book="";
                for (int i=0;i<m_tcp.m_tcpvec.size();i++)
                {
                        string tmp=m_tcp.m_tcpvec.at(i).word;
                        strcpy(szTmp,tmp.c_str());
                        dic.getChineseWord(szTmp);
                        m_test.push_back(dic.m_ChineseWord);
                }
        }
        else if (Choose1->Tag%3==1)
        {
                if (m_test.size()>0)
                        m_test.clear();
                char* substring;
                char seps[]="_=- /";
                char LineBuf[1024];
                vector<string> pingin;
                for (int i=0;i<m_tcp.m_tcpvec.size();i++)
                {
                        string tmp=m_tcp.m_tcpvec.at(i).pingin;
                        strcpy(LineBuf,tmp.c_str());

                	substring=strtok(LineBuf,seps);
	                if (pingin.size()>0)
		                pingin.clear();
	                while(substring!=NULL)
	                {
		                string tmp=substring;
		                pingin.push_back(tmp);
		                substring=strtok(NULL,seps);
	                }
                        if (sertau->Tag%3==1)
                        {
                                string NewCon;
                                if (Language1->Tag%4==0)
                                {
                                        //strcat(m_LanguagePath,"/�x�y��.bmp");

                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==48)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==49 || pingin.at(i)[pingin.at(i).length()-1]==54)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        //NewCon=NewCon+"�¡u";
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50 || pingin.at(i)[pingin.at(i).length()-1]==55)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        //NewCon=NewCon+"�Тt";

                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51 || pingin.at(i)[pingin.at(i).length()-1]==56)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        //NewCon=NewCon+"_�v";
                                                        NewCon=NewCon+"_ ";

                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==57)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }  
                                }
                                else if (Language1->Tag%4==1)
                                {
                                         //strcat(m_LanguagePath,"/�ػy��.bmp");
                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==48)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==49)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"_ ";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }
                                }
                                else if (Language1->Tag%4==2)
                                {
                                        //strcat(m_LanguagePath,"/�Ȯa����.bmp");
                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==49   )
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"_ ";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==54)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==55)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else  if (pingin.at(i)[pingin.at(i).length()-1]==56)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }
                                }
                                else
                                {
                                        //strcat(m_LanguagePath,"/�Ȯa�|��.bmp");
                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==49   )
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"_ ";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==54)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==55)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else  if (pingin.at(i)[pingin.at(i).length()-1]==56)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }
                                }



                        }
                        if (sertau->Tag%3==2)
                        {
                                string NewCon;
                                for (unsigned int i=0;i<pingin.size();i++)
                                {
                                        NewCon="";
                                        if (pingin.at(i)[pingin.at(i).length()-1]>=49 && pingin.at(i)[pingin.at(i).length()-1]<=57)
                                        {
                                                for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                        NewCon=NewCon+pingin.at(i)[j];
                                                pingin.at(i)=NewCon;
                                        }
                                        else
                                        {
                                                pingin.at(i)=pingin.at(i);
                                        }
                                }
                        }
                        m_test.push_back(pingin);
                }

        }
        else
        {
                if ( m_ChineseWord.size()>0)
                         m_ChineseWord.clear();
                PDic dic;
                char szTmp[4096];
                strvec strvectemp;
                string book="";
                for (int i=0;i<m_tcp.m_tcpvec.size();i++)
                {
                        string tmp=m_tcp.m_tcpvec.at(i).word;
                        strcpy(szTmp,tmp.c_str());
                        dic.getChineseWord(szTmp);
                        m_ChineseWord.push_back(dic.m_ChineseWord);
                }
                if (m_PingInWord.size()>0)
                         m_PingInWord.clear();

                char* substring;
                char seps[]="_=- /";
                char LineBuf[1024];
                vector<string> pingin;
                for (int i=0;i<m_tcp.m_tcpvec.size();i++)
                {
                        string tmp=m_tcp.m_tcpvec.at(i).pingin;
                        strcpy(LineBuf,tmp.c_str());

                	substring=strtok(LineBuf,seps);
	                if (pingin.size()>0)
		                pingin.clear();
	                while(substring!=NULL)
	                {
		                string tmp=substring;
		                pingin.push_back(tmp);
		                substring=strtok(NULL,seps);
	                }
                        if (sertau->Tag%3==1)
                        {
                                string NewCon;
                                if (Language1->Tag%4==0)
                                {
                                        //strcat(m_LanguagePath,"/�x�y��.bmp");

                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==48)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==49 || pingin.at(i)[pingin.at(i).length()-1]==54)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        //NewCon=NewCon+"�¡u";
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50 || pingin.at(i)[pingin.at(i).length()-1]==55)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        //NewCon=NewCon+"�Тt";

                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51 || pingin.at(i)[pingin.at(i).length()-1]==56)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        //NewCon=NewCon+"_�v";
                                                        NewCon=NewCon+"_ ";

                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==57)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }  
                                }
                                else if (Language1->Tag%4==1)
                                {
                                         //strcat(m_LanguagePath,"/�ػy��.bmp");
                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==48)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==49)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"_ ";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }
                                }
                                else if (Language1->Tag%4==2)
                                {
                                        //strcat(m_LanguagePath,"/�Ȯa����.bmp");
                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==49   )
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"_ ";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==54)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==55)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else  if (pingin.at(i)[pingin.at(i).length()-1]==56)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }
                                }
                                else
                                {
                                        //strcat(m_LanguagePath,"/�Ȯa�|��.bmp");
                                        for (unsigned int i=0;i<pingin.size();i++)
                                        {
                                                NewCon="";
                                                if (pingin.at(i)[pingin.at(i).length()-1]==49   )
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                 NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==50)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==51)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==52)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"�u";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==53)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"_ ";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==54)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else if (pingin.at(i)[pingin.at(i).length()-1]==55)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else  if (pingin.at(i)[pingin.at(i).length()-1]==56)
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length()-1;j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                                else
                                                {
                                                        for (unsigned int j=0;j<pingin.at(i).length();j++)
                                                                NewCon=NewCon+pingin.at(i)[j];
                                                        NewCon=NewCon+"��";
                                                        pingin.at(i)=NewCon;
                                                }
                                        }
                                }



                        }
                        if (sertau->Tag%3==2)
                        {
                                string NewCon;
                                for (int i=0;i<pingin.size();i++)
                                {
                                        NewCon="";
                                        if (pingin.at(i)[pingin.at(i).length()-1]>=49 && pingin.at(i)[pingin.at(i).length()-1]<=57)
                                        {
                                                for (int j=0;j<pingin.at(i).length()-1;j++)
                                                        NewCon=NewCon+pingin.at(i)[j];
                                                pingin.at(i)=NewCon;
                                        }
                                        else
                                        {
                                                pingin.at(i)=pingin.at(i);
                                        }
                                }
                        }
                        m_PingInWord.push_back(pingin);


                }

        }

}
void __fastcall TForm1::SpeedButton8Click(TObject *Sender)
{
        try
        {
                if (OpenDialogTCP1->Execute())
                {
                        PTcp tcp;
                        tcp.readGangsTCP2(OpenDialogTCP1->FileName.c_str());
                        vector<strvec> ChineseWord;
                        vector<strvec> PingInWord;
                        if (ChineseWord.size()>0)
                                ChineseWord.clear();
                        PDic dic;
                        char szTmp[4096];
                        strvec strvectemp;
                        string book="";
                        for (int i=0;i<tcp.m_tcpvec.size();i++)
                        {
                                string tmp=tcp.m_tcpvec.at(i).word;
                                strcpy(szTmp,tmp.c_str());
                                dic.getChineseWord(szTmp);
                                ChineseWord.push_back(dic.m_ChineseWord);
                        }
                        if (PingInWord.size()>0)
                                PingInWord.clear();
                        char* substring;
                        char seps[]="_=- /";
                        char LineBuf[1024];
                        vector<string> pingin;
                        for (int i=0;i<tcp.m_tcpvec.size();i++)
                        {
                                string tmp=tcp.m_tcpvec.at(i).pingin;
                                strcpy(LineBuf,tmp.c_str());

                	        substring=strtok(LineBuf,seps);
	                        if (pingin.size()>0)
		                        pingin.clear();
	                         while(substring!=NULL)
	                        {
		                        string tmp=substring;
		                        pingin.push_back(tmp);
		                        substring=strtok(NULL,seps);
	                        }
                                PingInWord.push_back(pingin);
                        }
                        tcpcomponet temptcp;
                        vector<tcpcomponet> newtcpfile;
                        string chinese;
                        string engpingin;
                        //vector<strvec> NewChineseWord;
                        for (int i=0;i<ChineseWord.size();i++)
                        {
                                int res=ChineseWord.at(i).size()%10;
                                int count=ChineseWord.at(i).size()/10;
                                if (count==0)
                                        count++;
                                else
                                {
                                        if (res!=0)
                                                count++;
                                }
                                for (int j=0;j<count;j++)
                                {
                                        // if (chinese.size()>0)
                                                //chinese.clear();
                                        chinese="";
                                        engpingin="";
                                        for (int k=j*10;k<(j+1)*10;k++)
                                        {
                                                if (k<ChineseWord.at(i).size())
                                                {
                                                        chinese=chinese+"="+ChineseWord.at(i).at(k);
                                                        engpingin=engpingin+"_"+PingInWord.at(i).at(k);
                                                        //chinese.push_back(ChineseWord.at(i).at(k));
                                                }

                                        }
                                        temptcp.filename=tcp.m_tcpvec.at(i).filename;
                                        temptcp.word=chinese;
                                        temptcp.pingin=engpingin;
                                        newtcpfile.push_back(temptcp);

                                        //NewChineseWord.push_back(chinese);
                                }

                        }

                        char extrapath[MAXPATH];
                        strcpy(extrapath,m_start_dir);
                        strcat(extrapath,"\\Run\\newtcp.dzc");
                        //ShowMessage(extrapath);
                        //return;
                        ofstream fout;
                        fout.open(extrapath,ios::out);
                        for (int i=0;i<newtcpfile.size();i++){
                                fout<<newtcpfile.at(i).filename<<"\t"<<newtcpfile.at(i).word<<"\t"<<newtcpfile.at(i).pingin<<endl;
                        }
                        fout.close();


                        m_tcp.readGangsTCP2(extrapath);

                        //�ɮצW
                        char fn[500];
                        strcpy(fn,OpenDialogTCP1->FileName.c_str());
                        // ���X�ɦW
                        char drive[MAXDRIVE];
                        char dir[MAXDIR];
                        char tempfilename[MAXFILE];
                        char ext[MAXEXT];
                        fnsplit(fn,drive,dir,tempfilename,ext);
                        AnsiString tfile=tempfilename;
                        strcpy(m_Source,drive);
                        strcat(m_Source,dir);

                        PaintBook1->Canvas->CopyMode = cmSrcCopy;
                        m_tcp.plotGround(PaintBook1->Canvas->Handle);
                        TRect destRect(0,0,PaintBook1->Width,PaintBook1->Height);
                         m_bmpBookForm->Canvas->CopyRect(destRect,PaintBook1->Canvas,destRect);



                        GetWord();
                        if (Choose1->Tag%3==0 || Choose1->Tag%3==1)
                        {

                                float over=m_test.size()%5;

                                if (over!=0)
                                {
                                        m_NumPer5file=m_test.size()/5+1;
                                }
                                else
                                {
                                        if (m_test.size()/5==0)
                                                 m_NumPer5file=1;
                                        else
                                                m_NumPer5file=m_test.size()/5;
                                }
                        }
                        else
                        {
                                float over=m_ChineseWord.size()%5;

                                if (over!=0)
                                {
                                        m_NumPer5file=m_ChineseWord.size()/5+1;
                                }
                                else
                                {
                                        if (m_ChineseWord.size()/5==0)
                                                m_NumPer5file=1;
                                        else
                                                m_NumPer5file=m_ChineseWord.size()/5;
                                }
                        }

                        m_page=1;
                        strcpy(m_WavePath,m_Source);
                        strcat(m_WavePath,"\\Connected.wav");
                        strcpy(m_TextGridPath,m_Source);
                        strcat(m_TextGridPath,"\\Total.TextGrid");
                        if (m_dynamic.file_exists(m_WavePath))
                        {
                                if (m_dynamic.file_exists(m_TextGridPath))
                                {
                                        m_wav.load(m_WavePath);
                                        m_ppraat.readPraatTextGridFile(m_TextGridPath);


                                        if (m_boundary.size()>0)
                                                m_boundary.clear();
                                        m_boundary.push_back(0.0);
                                        for (int i=0;i<m_ppraat.m_labbou.Bouder.size();i++)
                                        {
                                                m_boundary.push_back(m_ppraat.m_labbou.Bouder.at(i).etime);
                                        }

                                        if (m_context.size()>0)
                                                m_context.clear();
                                        for (int i=0;i<m_ppraat.m_labbou.Bouder.size();i++)
                                        {
                                                m_context.push_back(m_ppraat.m_labbou.Bouder.at(i).sylname);
                                        }
                                }
                                m_isload=true;
                        }


                        plotWord();
                        OneCharacter();
                        m_i=-1;
                        m_j=-1;
                }
        }
        catch(...)
        {
                //ShowMessage("Error occured");
                Edit1->Text="Error occured";
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
        //����@�}�l���ؿ�
        getcwd(m_start_dir,MAXPATH);

        m_charpos=0;
        m_recordx=0;
        m_first=0;
        m_tcpi=0;
        m_tcpj=0;
        m_val=0.0;
        m_val2=0.0;
        m_onlyplaythepage=false;
        m_onlyoneword=false;
        m_i=-1;
        m_j=-1;
        m_isload=false; 
}
//---------------------------------------------------------------------------
void __fastcall TForm1::wavestop1Click(TObject *Sender)
{
        try{
                if (m_isload)
                {
                        if(m_play.isplaying())
                        {
                                m_play.playstop();


                        }

                        PlayTimer1->Enabled = false;
                        m_charpos=0;
                        m_recordx=0;
                        m_first=0;
                        m_val=0.0;
                        m_val2=0.0;
                        m_value=0.05;
                        m_page=1;
                        m_tcpi=0;
                        m_tcpj=0;
                        // m_x=((m_page-1)*50)/10;
                        PaintBook1->Canvas->CopyMode = cmSrcCopy;
                        PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
                        plotWord();
                        m_onlyplaythepage=false;
                        m_pagestarttime=0.0;
                        m_onlyoneword=false;
               }
        }catch(...){
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
        try{

                if (!m_play.isplaying())
                {

                        PaintBook1->Canvas->CopyMode = cmSrcCopy;
                        PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
                        m_page++;
                        if (m_page>m_NumPer5file)
                                m_page--;
                        plotWord();
                        OneCharacter();
                }
        }catch(...){
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
        try{

                if (!m_play.isplaying())
                {
                        PaintBook1->Canvas->CopyMode = cmSrcCopy;
                        PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
                        m_page--;
                        if (m_page<=0)
                                m_page++;
                        plotWord();
                        OneCharacter();
                }
        }catch(...)
        {
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton4Click(TObject *Sender)
{
        try{

                if (m_isload)
                {
                        if (Choose1->Tag%3==0 || Choose1->Tag%3==1)
                        {
                                if(m_play.isplaying())
                                {
                                        m_play.playstop();
                                }
                                PlayTimer1->Enabled = false;
                                PaintBook1->Canvas->CopyMode = cmSrcCopy;
                                 PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
                                plotWord();
                                m_tcpi=(m_page-1)*5;
                                m_tcpj=0;
                                int position=0;
                                for (int i=0;i<m_tcpi;i++)
                                {
                                        if (i<m_test.size())
                                        {
                                                position=position+m_test.at(i).size();
                                        }
                                }
                                position=position+m_tcpj;

                                int count=-1;
                                int pk=0;
                                for (unsigned int j=0;j<m_context.size();j++)
                                {
                                        if (strcmp(m_context.at(j).c_str(),"\"=\"")!=0)
                                        {
                                                count++;
                                                if (count==position)
                                                {
                                                        pk=j;
                                                        //mout<<count<<memo;
                                                        break;
                                                }
                                        }
                                }
                                m_charpos=pk;
                                m_recordx=0;
                                m_first=0;
                                m_val=0.0;
                                m_value=0.05;

                                if (m_wav.GetBufLength()>0)
                                {
                                        int start=m_boundary.at(m_charpos)*16000;
                                        int end=m_boundary.at(m_boundary.size()-1)*16000;
                                        m_onlyplaythepage=true;
                                        m_pagestarttime=m_boundary.at(m_charpos);
                                        m_play.tplay(m_wav.GetBuf(),start,end);

                                        PlayTimer1->Enabled=true;
                                        wavestop1->Tag=0;
                                }
                        }
                        else
                        {
                                if(m_play.isplaying())
                                {
                                        m_play.playstop();
                                }
                                PlayTimer1->Enabled = false;
                                PaintBook1->Canvas->CopyMode = cmSrcCopy;
                                PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
                                plotWord();
                                m_tcpi=(m_page-1)*5;
                                m_tcpj=0;
                                int position=0;
                                for (unsigned int i=0;i<m_tcpi;i++)
                                {
                                        if (i<m_ChineseWord.size())
                                        {
                                                position=position+m_ChineseWord.at(i).size();
                                        }
                                }
                                position=position+m_tcpj;

                                int count=-1;
                                int pk=0;
                                for (unsigned int j=0;j<m_context.size();j++)
                                {
                                        if (strcmp(m_context.at(j).c_str(),"\"=\"")!=0)
                                        {
                                                count++;
                                                if (count==position)
                                                {
                                                        pk=j;
                                                        //mout<<count<<memo;
                                                        break;
                                                }
                                        }
                                }
                                m_charpos=pk;
                                m_recordx=0;
                                m_first=0;
                                m_val=0.0;
                                m_val2=0.0;
                                m_value=0.05;

                                if (m_wav.GetBufLength()>0)
                                {
                                        int start=m_boundary.at(m_charpos)*16000;
                                        int end=m_boundary.at(m_boundary.size()-1)*16000;
                                        m_onlyplaythepage=true;
                                        m_pagestarttime=m_boundary.at(m_charpos);
                                        m_play.tplay(m_wav.GetBuf(),start,end);

                                        PlayTimer1->Enabled=true;
                                        wavestop1->Tag=0;
                                }

                        }
                }
        }catch(...){
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton3Click(TObject *Sender)
{
        try {

                if (m_isload)
                {
                        wavestop1->Click();
                        m_play.setReset();
                        if (m_wav.GetBufLength()>0)
                        {
                                m_play.tplay(m_wav.GetBuf());


                                PlayTimer1->Enabled=true;
                                wavestop1->Tag=0;
                        }
                }
        }catch(...)
        {
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{

        wavestop1Click(Sender);

        if (m_wav.GetBufLength()>0)
        {
                m_play.tplay(m_wav.GetBuf());

                PlayTimer1->Enabled=true;
                wavestop1->Tag=0;
        }
}
//---------------------------------------------------------------------------





void __fastcall TForm1::PaintBook1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
        if (Button==mbLeft)
        {

                if (m_isload)
                {
                       // if (Choose1->Tag%3==0 || Choose1->Tag%3==1)
                       //{
                                m_bemousedown=true;
                                m_orix=X;   //���U�h���@�}�l��m
                                m_oriy=Y;
                                for (unsigned int j=0;j<m_wordheight.size();j++)
                                {
                                        if (m_oriy>=m_wordheight.at(j).start && m_oriy < m_wordheight.at(j).end)
                                        {
                                                m_j=j;
                                                for (unsigned int i=0;i<m_wordwidth.at(m_j).size();i++)
                                                {
                                                        if (m_orix>=m_wordwidth.at(m_j).at(i).start && m_orix < m_wordwidth.at(m_j).at(i).end)
                                                        {
                                                                m_i=i;
                                                                break;
                                                        }
                                                }
                                                break;
                                        }

                                }
                        //}
                }
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::PaintBook1MouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{


        if (m_isload)
        {
                if (Choose1->Tag%3==0 || Choose1->Tag%3==1)
                {
                        m_bemousedown=false;
                        int position=0;
                        if (m_i>=0 &&m_j>=0 )
                        {
                                for (unsigned int i=0;i<(m_page-1)*5+m_j;i++)
                                {
                                        if (i<m_test.size())
                                        {
                                                position=position+m_test.at(i).size();
                                        }
                                }
                                position=position+m_i;


                                if(m_play.isplaying())
                                {
                                        m_play.playstop();
                                }
                                PlayTimer1->Enabled = false;


                                int count=-1;
                                int pk=0;
                                for (unsigned int j=0;j<m_context.size();j++)
                                {
                                        if (strcmp(m_context.at(j).c_str(),"\"=\"")!=0)
                                        {
                                                count++;
                                                if (count==position)
                                                {
                                                        pk=j;
                                                        break;
                                                }
                                        }
                                }
                                m_charpos=pk;

                                m_first=0;
                                m_tcpi=m_j+(m_page-1)*5;
                                m_tcpj=m_i;
                                int offset;
                                float val=0.0;
                                int temp;

                                for (unsigned int j=0;j<m_i;j++)
                                {
                                        float rr=m_test.at(m_tcpi).at(j).length()%2;
                                        if (rr==0)
                                        {
                                                val=val+m_test.at(m_tcpi).at(j).length()/2;
                                                temp=m_test.at(m_tcpi).at(j).length()/2;
                                        }
                                        else{
                                                val=val+(m_test.at(m_tcpi).at(j).length()+1)/2;
                                                temp=(m_test.at(m_tcpi).at(j).length()+1)/2;
                                        }

                                        offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;

                                }
                                m_val=val;

                                m_recordx=0;
                                m_value=0.05+m_j*0.15;

                                if (m_wav.GetBufLength()>0)
                                {
                                        int start=m_boundary.at(m_charpos)*16000;
                                        int end=m_boundary.at(m_charpos+1)*16000;
                                        m_onlyplaythepage=true;
                                        m_onlyoneword=true;
                                        m_pagestarttime=m_boundary.at(m_charpos);
                                        m_play.tplay(m_wav.GetBuf(),start,end);

                                        PlayTimer1->Enabled=true;
                                        wavestop1->Tag=0;
                                }

                        }

                        m_i=-1;
                        m_j=-1;
                }
                else
                {

                        m_bemousedown=false;
                        int position=0;
                        if (m_i>=0 &&m_j>=0 )
                        {
                                for (unsigned int i=0;i<(m_page-1)*5+m_j;i++)
                                {
                                        if (i<m_PingInWord.size())
                                        {
                                                position=position+m_PingInWord.at(i).size();
                                        }
                                }
                                position=position+m_i;


                                if(m_play.isplaying())
                                {
                                        m_play.playstop();
                                }
                                PlayTimer1->Enabled = false;


                                int count=-1;
                                int pk=0;
                                for (unsigned int j=0;j<m_context.size();j++)
                                {
                                        if (strcmp(m_context.at(j).c_str(),"\"=\"")!=0)
                                        {
                                                count++;
                                                if (count==position)
                                                {
                                                        pk=j;
                                                        break;
                                                }
                                        }
                                }
                                m_charpos=pk;

                                m_first=0;
                                m_tcpi=m_j+(m_page-1)*5;
                                m_tcpj=m_i;
                                int offset;
                                float val,val2=0.0;
                                int temp,temp2;

                                for (unsigned int j=0;j<m_i;j++)
                                {

                                        float rr=m_ChineseWord.at(m_tcpi).at(j).length()%2;
                                        if (rr==0){
                                                val=val+m_ChineseWord.at(m_tcpi).at(j).length()/2;
                                                temp=m_ChineseWord.at(m_tcpi).at(j).length()/2;
                                        }
                                        else{
                                                val=val+(m_ChineseWord.at(m_tcpi).at(j).length()+1)/2;
                                                temp=(m_ChineseWord.at(m_tcpi).at(j).length()+1)/2;
                                        }
                                        //offset = (1+val)*PaintBook1->Canvas->TextWidth("��")-temp*PaintBook1->Canvas->TextWidth("��") ;
                                        //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*pvalue,m_ChineseWord.at(i).at(j).c_str());

                                        float rr2=m_PingInWord.at(m_tcpi).at(j).length()%2;
                                        if (rr2==0){
                                                val2=val2+m_PingInWord.at(m_tcpi).at(j).length()/2;
                                                temp2=m_PingInWord.at(m_tcpi).at(j).length()/2;
                                        }
                                        else{
                                                val2=val2+(m_PingInWord.at(m_tcpi).at(j).length()+1)/2;
                                                temp2=(m_PingInWord.at(m_tcpi).at(j).length()+1)/2;
                                        }

                                        offset = (1+val2)*PaintBook1->Canvas->TextWidth("��")-temp2*PaintBook1->Canvas->TextWidth("��") ;

                                }
                                m_val=val;
                                m_val2=val2;

                                m_recordx=0;
                                m_value=0.05+m_j*0.15;

                                if (m_wav.GetBufLength()>0)
                                {
                                        int start=m_boundary.at(m_charpos)*16000;
                                        int end=m_boundary.at(m_charpos+1)*16000;
                                        m_onlyplaythepage=true;
                                        m_onlyoneword=true;
                                        m_pagestarttime=m_boundary.at(m_charpos);
                                        m_play.tplay(m_wav.GetBuf(),start,end);

                                        PlayTimer1->Enabled=true;
                                        wavestop1->Tag=0;
                                }

                        }

                        m_i=-1;
                        m_j=-1;
                       
                }
        }

}
//---------------------------------------------------------------------------




void __fastcall TForm1::SpeedButton6Click(TObject *Sender)
{
/*
        wavestop1->Click();
        m_play.setReset();

        if (m_wav.GetBufLength()>0)
        {

                wavestop1->Tag=0;
        }
*/
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PlayTimer1Timer(TObject *Sender)
{
        try{
                if (Choose1->Tag%3==0 || Choose1->Tag%3==1)
                {
                        if ((m_tcpi/5+1)!=m_page)
                        {
                                PaintBook1->Canvas->CopyMode = cmSrcCopy;
                                PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
                                m_page++;
                                if (m_page>m_NumPer5file)
                                        m_page--;
                                plotWord();
                                m_val=0.0;
                                 m_value=0.05;

                                float rr=m_test.at(m_tcpi).at(m_tcpj).length()%2;
                                if (rr==0){
                                        m_val=m_val+m_test.at(m_tcpi).at(m_tcpj).length()/2;
                                        m_temp=m_test.at(m_tcpi).at(m_tcpj).length()/2;
                                }
                                else{
                                        m_val=m_val+(m_test.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                        m_temp=(m_test.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                }
                        }


                        double samples = m_play.getPosition();// + (20*16000)/PaintBox1->Width;
                        float sample_time = samples/16000.0;

                        if (m_onlyplaythepage)
                        {
                                sample_time = sample_time + m_pagestarttime;
                        }

                        if (m_test.size()>0)
                        {

                                int dx;
                                int spos = 0;
                                int epos = 0;
                                float spstart;
                                float spend;
                                for (unsigned int d=m_recordx;d<m_boundary.size()-1;d++)
                                {
                                        spstart=m_boundary.at(d);
                                        spend=m_boundary.at(d+1);
                                        PaintBook1->Canvas->Font->Color = clRed;
                                        PaintBook1->Canvas->Font->Size = 16;
                                        SetBkMode(PaintBook1->Canvas->Handle, TRANSPARENT);
                                        if (spstart<=sample_time && sample_time<spend )
                                        {
                                                dx=d;
                                                int offset;
                                                if (m_charpos<m_context.size()){
                                                        if (m_first==0)
                                                        {
                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                {
                                                                        break;
                                                                }
                                                                m_first++;
                                                                m_recordx=dx;

                                                                float rr=m_test.at(m_tcpi).at(m_tcpj).length()%2;
                                                                if (rr==0){
                                                                        m_val=m_val+m_test.at(m_tcpi).at(m_tcpj).length()/2;
                                                                        m_temp=m_test.at(m_tcpi).at(m_tcpj).length()/2;
                                                                }
                                                                else{
                                                                        m_val=m_val+(m_test.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                        m_temp=(m_test.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                }

                                                        }
                                                        else
                                                        {
                                                                if (m_onlyoneword)
                                                                {
                                                                        if (dx==m_recordx)
                                                                        {

                                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                                {
                                                                                        break;
                                                                                }
                                                                                offset = (1+ m_val)*PaintBook1->Canvas->TextWidth("��")-m_temp*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_test.at(m_tcpi).at(m_tcpj).c_str());
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        if (dx==m_recordx)
                                                                        {
                                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                                {
                                                                                        break;
                                                                                }
                                                                                offset = (1+ m_val)*PaintBook1->Canvas->TextWidth("��")-m_temp*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_test.at(m_tcpi).at(m_tcpj).c_str());
                                                                        }
                                                                        else
                                                                        {
                                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                                {
                                                                                        break;
                                                                                }
                                                                                m_recordx=dx;
                                                                                m_charpos++;
                                                                                if (m_charpos==m_context.size())
                                                                                {
                                                                                        m_charpos=m_charpos-1;
                                                                                        continue;
                                                                                }
                                                                                m_tcpj++;
                                                                                if (m_tcpj>=m_test.at(m_tcpi).size())
                                                                                {
                                                                                        m_tcpi++;
                                                                                        m_value=m_value+0.15;
                                                                                        m_tcpj=0;
                                                                                        m_val=0.0;

                                                                                }
                                                                                float rr=m_test.at(m_tcpi).at(m_tcpj).length()%2;
                                                                                if (rr==0){
                                                                                        m_val=m_val+m_test.at(m_tcpi).at(m_tcpj).length()/2;
                                                                                        m_temp=m_test.at(m_tcpi).at(m_tcpj).length()/2;
                                                                                }
                                                                                else{
                                                                                        m_val=m_val+(m_test.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                                        m_temp=(m_test.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                                }
                                                                                offset = (1+ m_val)*PaintBook1->Canvas->TextWidth("��")-m_temp*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_test.at(m_tcpi).at(m_tcpj).c_str());
                                                                        }
                                                                }
                                                        }
                                                }

                                                break;
                                        }

                                }

                        }



                        if(!m_play.isplaying())
                        {
                                PlayTimer1->Enabled = false;
                                 m_charpos=0;
                                m_recordx=0;
                                m_first=0;
                                m_val=0.0;
                                m_value=0.05;
                                m_tcpi=0;
                                m_tcpj=0;
                                m_onlyplaythepage=false;
                                m_pagestarttime=0.0;
                                m_onlyoneword=false;
                        }
                }
                else
                {
                        if ((m_tcpi/5+1)!=m_page)
                        {
                                PaintBook1->Canvas->CopyMode = cmSrcCopy;
                                PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
                                m_page++;
                                if (m_page>m_NumPer5file)
                                        m_page--;
                                plotWord();
                                m_val=0.0;
                                m_val2=0.0;
                                m_value=0.05;

                                float rr=m_ChineseWord.at(m_tcpi).at(m_tcpj).length()%2;
                                if (rr==0){
                                        m_val=m_val+m_ChineseWord.at(m_tcpi).at(m_tcpj).length()/2;
                                        m_temp=m_ChineseWord.at(m_tcpi).at(m_tcpj).length()/2;
                                }
                                else{
                                        m_val=m_val+(m_ChineseWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                        m_temp=(m_ChineseWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                }

                                float rr2=m_PingInWord.at(m_tcpi).at(m_tcpj).length()%2;
                                if (rr2==0){
                                        m_val2=m_val2+m_PingInWord.at(m_tcpi).at(m_tcpj).length()/2;
                                        m_temp2=m_PingInWord.at(m_tcpi).at(m_tcpj).length()/2;
                                }
                                else{
                                        m_val2=m_val2+(m_PingInWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                        m_temp2=(m_PingInWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                }
                        }


                        double samples = m_play.getPosition();// + (20*16000)/PaintBox1->Width;
                        float sample_time = samples/16000.0;

                        if (m_onlyplaythepage)
                        {
                                sample_time = sample_time + m_pagestarttime;
                        }

                        if (m_ChineseWord.size()>0)
                        {

                                int dx;
                                int spos = 0;
                                int epos = 0;
                                float spstart;
                                float spend;
                                for (unsigned int d=m_recordx;d<m_boundary.size()-1;d++)
                                {
                                        spstart=m_boundary.at(d);
                                        spend=m_boundary.at(d+1);
                                        PaintBook1->Canvas->Font->Color = clRed;
                                        PaintBook1->Canvas->Font->Size = 16;
                                        SetBkMode(PaintBook1->Canvas->Handle, TRANSPARENT);
                                        if (spstart<=sample_time && sample_time<spend )
                                        {
                                                dx=d;
                                                int offset;
                                                if (m_charpos<m_context.size()){
                                                        if (m_first==0)
                                                        {
                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                {
                                                                        break;
                                                                }
                                                                m_first++;
                                                                m_recordx=dx;

                                                                float rr=m_ChineseWord.at(m_tcpi).at(m_tcpj).length()%2;
                                                                if (rr==0){
                                                                        m_val=m_val+m_ChineseWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                        m_temp=m_ChineseWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                }
                                                                else{
                                                                        m_val=m_val+(m_ChineseWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                        m_temp=(m_ChineseWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                }

                                                                float rr2=m_PingInWord.at(m_tcpi).at(m_tcpj).length()%2;
                                                                if (rr2==0){
                                                                        m_val2=m_val2+m_PingInWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                        m_temp2=m_PingInWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                }
                                                                else{
                                                                        m_val2=m_val2+(m_PingInWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                        m_temp2=(m_PingInWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                }
                                                        }
                                                        else
                                                        {
                                                                if (m_onlyoneword)
                                                                {
                                                                        if (dx==m_recordx)
                                                                        {

                                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                                {
                                                                                        break;
                                                                                }
                                                                                //offset = (1+ m_val)*PaintBook1->Canvas->TextWidth("��")-m_temp*PaintBook1->Canvas->TextWidth("��") ;
                                                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_ChineseWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                                offset = (1+ m_val2)*PaintBook1->Canvas->TextWidth("��")-m_temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_ChineseWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                                offset = (1+ m_val2)*PaintBook1->Canvas->TextWidth("��")-m_temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*(m_value+0.05),m_PingInWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        if (dx==m_recordx)
                                                                        {
                                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                                {
                                                                                        break;
                                                                                }
                                                                                //offset = (1+ m_val)*PaintBook1->Canvas->TextWidth("��")-m_temp*PaintBook1->Canvas->TextWidth("��") ;
                                                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_ChineseWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                                offset = (1+ m_val2)*PaintBook1->Canvas->TextWidth("��")-m_temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_ChineseWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                                offset = (1+ m_val2)*PaintBook1->Canvas->TextWidth("��")-m_temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*(m_value+0.05),m_PingInWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                        }
                                                                        else
                                                                        {
                                                                                if (strcmp(m_context.at(dx).c_str(),"\"=\"")==0)
                                                                                {
                                                                                        break;
                                                                                }
                                                                                m_recordx=dx;
                                                                                m_charpos++;
                                                                                if (m_charpos==m_context.size())
                                                                                {
                                                                                        m_charpos=m_charpos-1;
                                                                                        continue;
                                                                                }
                                                                                m_tcpj++;
                                                                                if (m_tcpj>=m_ChineseWord.at(m_tcpi).size())
                                                                                {
                                                                                        m_tcpi++;
                                                                                        m_value=m_value+0.15;
                                                                                        m_tcpj=0;
                                                                                        m_val=0.0;
                                                                                        m_val2=0.0;

                                                                                }
                                                                                float rr=m_ChineseWord.at(m_tcpi).at(m_tcpj).length()%2;
                                                                                if (rr==0){
                                                                                        m_val=m_val+m_ChineseWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                                        m_temp=m_ChineseWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                                }
                                                                                else{
                                                                                        m_val=m_val+(m_ChineseWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                                        m_temp=(m_ChineseWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                                }

                                                                                float rr2=m_PingInWord.at(m_tcpi).at(m_tcpj).length()%2;
                                                                                if (rr2==0){
                                                                                        m_val2=m_val2+m_PingInWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                                        m_temp2=m_PingInWord.at(m_tcpi).at(m_tcpj).length()/2;
                                                                                }
                                                                                else{
                                                                                        m_val2=m_val2+(m_PingInWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                                        m_temp2=(m_PingInWord.at(m_tcpi).at(m_tcpj).length()+1)/2;
                                                                                }
                                                                                offset = (1+ m_val2)*PaintBook1->Canvas->TextWidth("��")-m_temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_ChineseWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                                //offset = (1+ m_val)*PaintBook1->Canvas->TextWidth("��")-m_temp*PaintBook1->Canvas->TextWidth("��") ;
                                                                                //PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_ChineseWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                                offset = (1+ m_val2)*PaintBook1->Canvas->TextWidth("��")-m_temp2*PaintBook1->Canvas->TextWidth("��") ;
                                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*(m_value+0.05),m_PingInWord.at(m_tcpi).at(m_tcpj).c_str());
                                                                        }
                                                                }
                                                        }
                                                }

                                                break;
                                         }

                                }

                        }



                        if(!m_play.isplaying())
                        {
                                PlayTimer1->Enabled = false;
                                m_charpos=0;
                                m_recordx=0;
                                m_first=0;
                                m_val=0.0;
                                m_val2=0.0;
                                m_value=0.05;
                                m_tcpi=0;
                                m_tcpj=0;
                                m_onlyplaythepage=false;
                                m_pagestarttime=0.0;
                                m_onlyoneword=false;
                        }


                }
        }catch(...){
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }

/*
  // m_ttsoldLightPos=PaintWave2->Width*m_ttsplay.getPosition()/m_ttswav.GetBufLength();

    //double samples = m_ttsplay.getPosition();// + (20*16000)/PaintBox1->Width;
    //float sample_time = samples/16000.0;
    //erase old
       // mout<<"Hihi"<<memo;
    if ((m_charpos/50+1)!=m_page)
    {
        //SpeedButton2Click(Sender);

        PaintBook1->Canvas->CopyMode = cmSrcCopy;
        PaintBook1->Canvas->Draw(0,0,m_bmpBookForm);
        m_page++;
        if (m_page>m_NumPer5file)
                m_page--;
        plotWord();

        m_value=0.05;
         m_x=((m_page-1)*50)/10;
           // m_x=0;
           //mout<<"come in"<<memo;
    }


    double samples = m_play.getPosition();// + (20*16000)/PaintBox1->Width;
    float sample_time = samples/16000.0;

        if (m_onlyplaythepage)
        {
                sample_time = sample_time + m_pagestarttime;
        }
        if (m_context.size()>0)
        {

                int dx;
                 int spos = 0;
                 int epos = 0;
                 float spstart;
                 float spend;
                 for (unsigned int d=m_recordx;d<m_boundary.size()-1;d++)
                 {

                        spstart=m_boundary.at(d);
                        spend=m_boundary.at(d+1);
                        PaintBook1->Canvas->Font->Color = clRed;
                        PaintBook1->Canvas->Font->Size = 18;
                        SetBkMode(PaintBook1->Canvas->Handle, TRANSPARENT);
                        if (spstart<=sample_time && sample_time<spend )
                        {

                                if ((d/10)!= m_x)
                                {
                                        m_x=m_x+1;
                                        m_value=m_value+0.15;
                                //mout<<"Hihi"<<memo;
                                //mout<<d<<memo;
                                }

                                dx=d;
                                int offset;
                                if (m_charpos<(m_context.size())){


                                        offset = (2+m_charpos%10)*PaintBook1->Canvas->TextWidth("�r")-PaintBook1->Canvas->TextWidth("�r")/2 ;
                                        if (m_first==0)
                                        {
                                                m_first++;
                                                m_recordx=dx;
                                                //mout<<"1"<<memo;

                                        }
                                        else
                                        {


                                                if (m_onlyoneword)
                                                {
                                                        if (dx==m_recordx)
                                                        {
                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_context.at(m_charpos).c_str());
                                                                mout<<m_charpos<<memo;
                                                                char tmp[1024];
                                                        }
                                                }
                                                else
                                                {
                                                        if (dx==m_recordx)
                                                        {
                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_context.at(m_charpos).c_str());
                                                                mout<<m_charpos<<memo;
                                                                char tmp[1024];
                                                        }
                                                        else
                                                        {
                                                                m_recordx=dx;
                                                                m_charpos++;
                                                                if (m_charpos==m_context.size())
                                                                        m_charpos=m_charpos-1;
                                                                offset = (2+m_charpos%10)*PaintBook1->Canvas->TextWidth("�r")-PaintBook1->Canvas->TextWidth("�r")/2 ;
                                                                PaintBook1->Canvas->TextOut(offset,PaintBook1->Height*m_value,m_context.at(m_charpos).c_str());
                                                                mout<<m_charpos<<memo;
                                                        }
                                               }
                                        }
                                 }

                                 break;
                        }else
                                mout<<"><"<<memo;

                }

         }



      if(!m_play.isplaying())
      {
                PlayTimer1->Enabled = false;
                m_charpos=0;
                m_recordx=0;
                m_first=0;
                m_value=0.05;
                m_x=((m_page-1)*50)/10;
                m_onlyplaythepage=false;
                m_pagestarttime=0.0;
                m_onlyoneword=false;
        }
*/
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton7Click(TObject *Sender)
{
        try{

                if (m_isload)
                {
                        wavestop1->Tag++;
                        if (wavestop1->Tag%2 && m_play.isplaying())
                        {
                                m_play.playpause();
                                PlayTimer1->Enabled=false;
                        }
                        else
                        {
                                m_play.playrestart();
                                if (m_play.m_bpause)
                                        PlayTimer1->Enabled=true;;
                        }
                }
        }catch(...)
        {
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Choose1Click(TObject *Sender)
{
        try{

                if (!m_play.isplaying())
                {
                        strcpy(m_ImagePath,m_start_dir);
                        Choose1->Tag++;
                        if (Choose1->Tag%3==0)
                        {
                                Choose1->Caption="��";
                                //strcat(m_ImagePath,"/un.bmp");
                        }
                        else if (Choose1->Tag%3==1)
                        {
                                Choose1->Caption="��";
                                //strcat(m_ImagePath,"/pingin.bmp");
                        }
                        else
                        {
                                Choose1->Caption="����";
                                //strcat(m_ImagePath,"/inun.bmp");

                         }
                        //Choose1->Glyph->LoadFromFile(m_ImagePath);

                        PaintBook1->Canvas->CopyMode = cmSrcCopy;
                        m_tcp.plotGround(PaintBook1->Canvas->Handle);
                        TRect destRect(0,0,PaintBook1->Width,PaintBook1->Height);
                        m_bmpBookForm->Canvas->CopyRect(destRect,PaintBook1->Canvas,destRect);
                        GetWord();
                        plotWord();
                        OneCharacter();
                }
        }catch(...)
        {
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }

}
//---------------------------------------------------------------------------


void __fastcall TForm1::sertauClick(TObject *Sender)
{
        try{

                if (!m_play.isplaying())
                {
                        strcpy(m_SerTauPath,m_start_dir);
                        sertau->Tag++;
                        if (sertau->Tag%3==0)
                        {
                                sertau->Caption="�Ʀr��";
                                //strcat(m_SerTauPath,"/�Ʀr��.bmp");
                        }
                        else if (sertau->Tag%3==1)
                        {
                                sertau->Caption="�է�";
                                //strcat(m_SerTauPath,"/�է�.bmp");
                        }
                        else
                        {
                                sertau->Caption="�L��";
                                //strcat(m_SerTauPath,"/�L��.bmp");

                        }
                        //sertau->Glyph->LoadFromFile(m_SerTauPath);

                        PaintBook1->Canvas->CopyMode = cmSrcCopy;
                        m_tcp.plotGround(PaintBook1->Canvas->Handle);
                         TRect destRect(0,0,PaintBook1->Width,PaintBook1->Height);
                        m_bmpBookForm->Canvas->CopyRect(destRect,PaintBook1->Canvas,destRect);
                        GetWord();
                        plotWord();
                        OneCharacter();
                }
        }
        catch(...){
                ShowMessage("Error Occured");
        }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Language1Click(TObject *Sender)
{
        try{

                if (!m_play.isplaying())
                {
                        strcpy(m_LanguagePath,m_start_dir);
                        Language1->Tag++;
                        if (Language1->Tag%4==0)
                        {
                                Language1->Caption="�x�y��";
                                //strcat(m_LanguagePath,"/�x�y��.bmp");
                        }
                        else if (Language1->Tag%4==1)
                        {
                                Language1->Caption="�ػy��";
                                //strcat(m_LanguagePath,"/�ػy��.bmp");
                        }
                        else if (Language1->Tag%4==2)
                        {
                                Language1->Caption="�Ȯa����";
                                //strcat(m_LanguagePath,"/�Ȯa����.bmp");
                        }
                        else
                        {
                                Language1->Caption="�Ȯa�|��";
                                //strcat(m_LanguagePath,"/�Ȯa�|��.bmp");
                        }
                        //Language1->Glyph->LoadFromFile(m_LanguagePath);

                        PaintBook1->Canvas->CopyMode = cmSrcCopy;
                        m_tcp.plotGround(PaintBook1->Canvas->Handle);
                        TRect destRect(0,0,PaintBook1->Width,PaintBook1->Height);
                        m_bmpBookForm->Canvas->CopyRect(destRect,PaintBook1->Canvas,destRect);
                        GetWord();
                        plotWord();
                        OneCharacter();
                }
        }catch(...){
                Edit1->Text="Error occured";
                //ShowMessage("Error Occured");
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::close1Click(TObject *Sender)
{
        Form1->Close();        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Minimize1Click(TObject *Sender)
{
        //Form1->WindowState=wsMinimized;      
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
                /*
                Graphics::TBitmap* tempbitmap;
                tempbitmap=new Graphics::TBitmap();
                ImageList1->GetBitmap(2,tempbitmap);
                Choose1->Glyph->Canvas->Draw(0,0,tempbitmap);
                */
}
//---------------------------------------------------------------------------


