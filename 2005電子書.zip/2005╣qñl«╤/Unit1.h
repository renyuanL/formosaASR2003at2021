//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>


#include "Compile/PLib/PMatrix.h"
#include "Compile/PLib/PPlay.h"
#include "Compile/PLib/PPraat.h"
#include "Compile/PLib/SSP.h"
#include "Compile/PLib/PFeature.h"
#include "Compile/PLib/PScore.h"
#include "Compile/PLib/PLokim.h"
#include "Compile/PLib/PWavInLokim.h"
#include "Compile/PLib/PDynamic.h"
#include "Compile/PLib/PTcp.h"
//���Ѯv
#include "Compile/incl32/di5mout.h"

//�{�EHMM
#include "Compile/inc/CRec.h"
#include "Compile/inc/CMel.h"
#include "Compile/inc/CWaveIn.h"
#include "Compile/inc/CWaveOut.h"
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <math.hpp>
#include <io.h>
#include <dir.h>
#include <conio.h>
#include <dos.h>
#include <dir.h>
#include <Graphics.hpp>
#include <ImgList.hpp>
struct word
{
	int start;
	int end;
};
typedef vector<string> strvec;
typedef vector<word> wordvec;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TOpenDialog *OpenDialogTCP1;
        TTimer *PlayTimer1;
        TOpenDialog *OpenDialog1;
        TPanel *Panel1;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TSpeedButton *waveplay1;
        TSpeedButton *SpeedButton6;
        TSpeedButton *wavestop1;
        TSpeedButton *SpeedButton8;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton2;
        TSpeedButton *SpeedButton7;
        TSpeedButton *Choose1;
        TSpeedButton *sertau;
        TSpeedButton *Language1;
        TLabel *Label1;
        TSpeedButton *bern1;
        TSpeedButton *Minimize1;
        TSpeedButton *close1;
        TLabel *Label3;
        TPanel *Panel2;
        TPaintBox *PaintBook1;
        TEdit *Edit1;
        void __fastcall PaintBook1Paint(TObject *Sender);
        void __fastcall SpeedButton8Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall wavestop1Click(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton4Click(TObject *Sender);
        void __fastcall SpeedButton3Click(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall PaintBook1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall PaintBook1MouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall SpeedButton6Click(TObject *Sender);
        void __fastcall PlayTimer1Timer(TObject *Sender);
        void __fastcall SpeedButton7Click(TObject *Sender);
        void __fastcall Choose1Click(TObject *Sender);
        void __fastcall sertauClick(TObject *Sender);
        void __fastcall Language1Click(TObject *Sender);
        void __fastcall close1Click(TObject *Sender);
        void __fastcall Minimize1Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

        PBuffer m_buffer;
        PPlay m_play;
        PWave m_wav;
        PPraat m_ppraat;
        PTcp m_tcp;
        PDynamic m_dynamic;
        char m_tcppath[MAXPATH];
        char m_tcpwavpath[MAXPATH];

        //�p����|������
        char m_start_dir[MAXPATH];

        vector<float> m_SylBoundary;//Syllabe boundary, �@�}�l�|��J0
        void __fastcall OneCharacter();

        vector<strvec> m_ChineseWord;
        vector<strvec> m_PingInWord;
        vector<strvec> m_test;
        Graphics::TBitmap *m_bmpBookForm;
        int m_NumPer5file;
        int m_page;
        void plotWord();

        int m_temp;
        float m_val;
        int m_temp2;
        float m_val2;
        
        int m_tcpi;
        int m_tcpj;

        unsigned int m_charpos;
        int m_first;
        int m_recordx;

        char m_Source[MAXPATH];
        char m_WavePath[MAXPATH];
        char m_TextGridPath[MAXPATH];

        vector<float> m_boundary;
        vector<string> m_context;

        void __fastcall GetWord();

        float m_value;
        int m_x;
        bool m_bemousedown;
        int  m_orix;
        int m_oriy;
        vector<wordvec> m_wordwidth;
        vector<word> m_wordheight;

        int m_i;
        int m_j;

        bool m_onlyplaythepage;
        float m_pagestarttime;
        bool m_onlyoneword;

        char m_ImagePath[MAXPATH];
        char m_SerTauPath[MAXPATH];
        char m_LanguagePath[MAXPATH];

        bool m_isload;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
